---
name: Bug report
about: 버그를 제보해주세요
title: '[BUG] '
labels: bug
---

## 버그 설명

## 재현 방법
1.
2.

## 예상 동작

## 실제 동작

## 환경
- OS:
- Browser:
- Node:
