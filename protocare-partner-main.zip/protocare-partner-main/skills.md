# 🛠 Mappia Tech Stack

### 프론트엔드 (Frontend)
- **Core**: React 19 (Vite 기반)
- **Native Bridge**: Capacitor 6.0 (Camera, Geolocation, Push)
- **Styling**: TailwindCSS 4 (Mobile-first)
- **State**: Zustand (Local), TanStack Query v5 (Server)
- **Animation**: Framer Motion (앱 수준의 부드러운 전환)

### 백엔드 연동 (API)
- **HTTP**: Axios (Interceptor를 통한 JWT 처리)
- **Validation**: Zod (런타임 타입 체크)