# 🐕 Mappia Project Coding Rules

### 1. 하이브리드 최적화 (Capacitor)
- 모든 기능은 Web 표준으로 먼저 개발하되, 기기 제어는 Capacitor Plugin으로 일원화한다.
- 모바일 네트워크 환경(3G/LTE)을 고려하여 API 응답 캐싱(TanStack Query)을 필수로 적용한다.

### 2. 컴포넌트 설계
- Atomic Design 패턴을 지향하며, 재사용 가능한 UI는 `components/ui`에 둔다.
- 모바일 터치 타겟(최소 44x44px)을 준수하고, 웹 특유의 호버(Hover) 효과 대신 액티브(Active) 효과를 사용한다.

### 3. 데이터 흐름
- 서버 데이터는 `services/api`에서 정의하며, UI로 전달 전 반드시 `mapper`를 거친다.
- 전역 상태(Zustand)는 인증 및 기기 설정 등 최소한의 정보만 담는다.