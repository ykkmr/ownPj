# frontend-starter

> Vite + React + TypeScript + TanStack Query v5 + axios 기반 프론트엔드 보일러플레이트

## 기술 스택

| 구분 | 라이브러리 |
|---|---|
| 빌드 | Vite 6 |
| UI | React 18 |
| 타입 | TypeScript 5.6 (strict) |
| 서버 상태 | TanStack Query v5 |
| HTTP | axios + 인터셉터 |
| 라우팅 | React Router v6 |
| 에러 모니터링 | Sentry |
| 코드 품질 | ESLint + Prettier + Husky |

## 시작하기

```bash
# 1. 레포 복제 (GitHub Template 사용 시 "Use this template" 버튼 클릭)
git clone https://github.com/YOUR_USERNAME/frontend-starter.git my-project
cd my-project

# 2. 환경변수 설정
cp .env.example .env
# .env 파일을 열어 값 입력

# 3. 의존성 설치
npm install

# 4. 개발 서버 실행
npm run dev
```

## 폴더 구조

```
src/
├── api/          # axios 인스턴스, 에러 계층, 토큰 저장
├── components/   # 공통 컴포넌트 (auth 가드, 에러 경계)
├── config/       # 환경변수, Sentry 설정
├── features/     # 도메인별 기능 (여기서 기능 개발)
├── hooks/        # 공통 커스텀 훅
├── pages/        # 라우트 페이지
├── providers/    # 전역 Provider (TanStack Query)
├── router/       # 라우트 정의
├── store/        # 전역 클라이언트 상태 (필요 시)
├── types/        # 공통 타입
└── utils/        # 유틸 함수
```

## 도메인 특화 수정 체크리스트

새 프로젝트에서 이 템플릿을 사용할 때 아래 항목을 교체하세요.

- [ ] `src/config/sentry.ts` → `SENSITIVE_KEYS` 도메인 민감 필드 추가
- [ ] `src/types/domain.ts` → 도메인 타입 전면 작성
- [ ] `src/router/index.tsx` → 서비스 경로 구성
- [ ] `src/features/` → 도메인 폴더 추가 및 기능 구현
- [ ] `.env.example` → 필요한 환경변수 추가
- [ ] `index.html` → `<title>` 변경

## 주요 설계 결정

### 토큰 저장: 인메모리
Access Token을 sessionStorage/localStorage 대신 모듈 변수에 저장합니다.
XSS 한 번으로 토큰이 탈취되는 것을 방지합니다.
페이지 새로고침 시 초기화되며, Refresh Token(HttpOnly 쿠키)으로 재발급합니다.

### 401 처리: 이벤트 버스
axios 인터셉터가 React Router를 직접 import하지 않고
커스텀 이벤트(`app.auth:expired`)를 발행하면 `App.tsx`에서 처리합니다.
레이어 간 의존성을 없애 테스트와 유지보수가 쉬워집니다.

### 에러 계층: AppError
HTTP 상태 코드 대신 `UnauthorizedError`, `ValidationError` 등
도메인 에러 클래스를 사용합니다. UI가 HTTP를 몰라도 됩니다.

### Sentry PHI 스크러빙
`beforeSend` 훅에서 4계층 필터링합니다.
(요청 데이터 키 기반 / 헤더 / URL 쿼리스트링 / 에러 메시지 패턴)

## 스크립트

| 명령어 | 설명 |
|---|---|
| `npm run dev` | 개발 서버 |
| `npm run build` | 프로덕션 빌드 |
| `npm run typecheck` | TypeScript 타입 체크 |
| `npm run lint` | ESLint 검사 |
| `npm run lint:fix` | ESLint 자동 수정 |
| `npm run format` | Prettier 포맷 |
