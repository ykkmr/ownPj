/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_API_URL: string;
  readonly VITE_APP_SENTRY_DSN: string;
  readonly VITE_APP_SENTRY_ENVIRONMENT: string;
  readonly VITE_APP_SENTRY_TRACES_SAMPLE_RATE: string;
  readonly VITE_APP_ENABLE_DEVTOOLS: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
