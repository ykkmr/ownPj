import { z } from 'zod';

export const careRequestSchema = z
  .object({
    type: z.enum(['HOSPITAL', 'ELDERLY', 'CHILD'], {
      error: '서비스 유형을 선택해주세요.',
    }),
    startAt: z.string().min(1, '시작 시간을 입력해주세요.'),
    endAt: z.string().min(1, '종료 시간을 입력해주세요.'),
    from: z.string().optional(),
    to: z.string().optional(),
    addRequest: z.string().max(500, '추가 요청사항은 500자 이내로 입력해주세요.').optional(),
  })
  .refine((data) => data.startAt < data.endAt, {
    message: '종료 시간은 시작 시간보다 이후여야 합니다.',
    path: ['endAt'],
  });

export type CareRequestFormValues = z.infer<typeof careRequestSchema>;
