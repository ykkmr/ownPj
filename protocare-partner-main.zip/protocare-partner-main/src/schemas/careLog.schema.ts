import { z } from 'zod';

export const careLogSchema = z.object({
  type: z.enum(['MEAL', 'BATH', 'PHOTO', 'MEMO', 'OTHER'], {
    error: '기록 유형을 선택해주세요.',
  }),
  content: z
    .string()
    .min(1, '내용을 입력해주세요.')
    .max(1000, '내용은 1000자 이내로 입력해주세요.'),
  mediaUrls: z.array(z.string()).optional().default([]),
});

export type CareLogFormValues = z.infer<typeof careLogSchema>;
