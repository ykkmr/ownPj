import { z } from 'zod';

export const postSchema = z.object({
  title: z.string().min(1, '제목을 입력해주세요.').max(100, '제목은 100자 이내로 입력해주세요.'),
  content: z
    .string()
    .min(1, '내용을 입력해주세요.')
    .max(2000, '내용은 2000자 이내로 입력해주세요.'),
  isAnonymous: z.boolean().optional().default(false),
});

export const commentSchema = z.object({
  content: z.string().min(1, '댓글을 입력해주세요.').max(500, '댓글은 500자 이내로 입력해주세요.'),
  parentId: z.number().optional(),
});

export type PostFormValues = z.infer<typeof postSchema>;
export type CommentFormValues = z.infer<typeof commentSchema>;
