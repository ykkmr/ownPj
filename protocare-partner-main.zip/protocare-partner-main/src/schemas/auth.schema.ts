import { z } from 'zod';

const PHONE_REGEX = /^01[016789]\d{7,8}$/;

export const phoneSchema = z.object({
  phone: z
    .string()
    .min(1, '전화번호를 입력해주세요.')
    .refine((v) => PHONE_REGEX.test(v), '올바른 휴대폰 번호를 입력해주세요. (예: 01012345678)'),
});

export const verifySchema = z.object({
  phone: z
    .string()
    .min(1, '전화번호를 입력해주세요.')
    .refine((v) => PHONE_REGEX.test(v), '올바른 휴대폰 번호를 입력해주세요.'),
  code: z
    .string()
    .min(1, '인증번호를 입력해주세요.')
    .refine((v) => v.length === 4, '인증번호는 4자리입니다.'),
});

export const loginSchema = z.object({
  email: z.string().min(1, '이메일을 입력해주세요.').email('올바른 이메일 형식이 아닙니다.'),
  password: z
    .string()
    .min(1, '비밀번호를 입력해주세요.')
    .min(8, '비밀번호는 8자 이상이어야 합니다.'),
});

export type PhoneFormValues = z.infer<typeof phoneSchema>;
export type VerifyFormValues = z.infer<typeof verifySchema>;
export type LoginFormValues = z.infer<typeof loginSchema>;
