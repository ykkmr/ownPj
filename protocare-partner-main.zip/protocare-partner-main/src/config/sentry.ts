import * as Sentry from '@sentry/react';
import { env } from './env';

/**
 * 에러 모니터링 설정
 * Sentry 초기화.
 * - DSN 없으면 초기화 건너뜀 (로컬 개발환경)
 * - 기본 PII 전송 비활성화
 * - beforeSend 훅에서 민감 필드 스크러빙
 *
 * ★ SENSITIVE_KEYS: 프로젝트 도메인에 맞는 필드명으로 교체하기
 */

const SENSITIVE_KEYS = [
  'password',
  'token',
  'authorization',
  'apiKey',
  'secret',
  'email',
  'phone',
  // TODO: 프로젝트 도메인 민감 필드 추가
];

const SENSITIVE_QUERY_PARAMS = [
  'token',
  'access_token',
  'refresh_token',
  'id_token',
  'key',
  'api_key',
  'apikey',
  'secret',
  'password',
  'authorization',
];

const MESSAGE_SCRUB_PATTERNS: Array<[RegExp, string]> = [
  [/Bearer\s+[A-Za-z0-9._~+/=-]+/gi, 'Bearer [Filtered]'],
  [/eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+/g, '[Filtered-JWT]'],
  [/[\w.+-]+@[\w-]+\.[\w.-]+/g, '[Filtered-Email]'],
];

const scrub = (value: unknown): unknown => {
  if (value === null || value === undefined) return value;
  if (typeof value !== 'object') return value;
  if (Array.isArray(value)) return value.map(scrub);
  const obj = value as Record<string, unknown>;
  const result: Record<string, unknown> = {};
  for (const key of Object.keys(obj)) {
    result[key] = SENSITIVE_KEYS.some((k) => key.toLowerCase().includes(k.toLowerCase()))
      ? '[Filtered]'
      : scrub(obj[key]);
  }
  return result;
};

const scrubMessage = (msg: string): string =>
  MESSAGE_SCRUB_PATTERNS.reduce(
    (acc, [pattern, replacement]) => acc.replace(pattern, replacement),
    msg,
  );

const scrubUrl = (url: string): string => {
  try {
    const isAbsolute = /^https?:\/\//i.test(url);
    const parsed = isAbsolute ? new URL(url) : new URL(url, 'http://placeholder.local');
    let mutated = false;
    for (const param of SENSITIVE_QUERY_PARAMS) {
      if (parsed.searchParams.has(param)) {
        parsed.searchParams.set(param, '[Filtered]');
        mutated = true;
      }
    }
    if (!mutated) return url;
    return isAbsolute ? parsed.toString() : `${parsed.pathname}${parsed.search}${parsed.hash}`;
  } catch {
    return url;
  }
};

export const initSentry = (): void => {
  if (!env.sentry.dsn) {
    if (env.isDev) console.warn('[Sentry] DSN not set, skipping initialization.');
    return;
  }

  Sentry.init({
    dsn: env.sentry.dsn,
    environment: env.sentry.environment,
    tracesSampleRate: env.sentry.tracesSampleRate,
    sendDefaultPii: false,
    beforeSend(event) {
      if (event.request?.data) event.request.data = scrub(event.request.data);
      if (event.extra) event.extra = scrub(event.extra) as typeof event.extra;

      if (event.request?.headers) {
        const h = event.request.headers as Record<string, string>;
        delete h['Authorization'];
        delete h['authorization'];
        delete h['Cookie'];
        delete h['cookie'];
      }
      if (event.request?.url) event.request.url = scrubUrl(event.request.url);
      if (event.request?.query_string && typeof event.request.query_string === 'string') {
        event.request.query_string = scrubUrl(`?${event.request.query_string}`).replace(/^\?/, '');
      }

      if (event.breadcrumbs) {
        event.breadcrumbs = event.breadcrumbs.map((crumb) => {
          const next = { ...crumb };
          if (next.data) {
            const data = scrub(next.data) as Record<string, unknown>;
            if (typeof data['url'] === 'string') data['url'] = scrubUrl(data['url']);
            next.data = data;
          }
          if (typeof next.message === 'string') next.message = scrubMessage(next.message);
          return next;
        });
      }

      if (event.exception?.values) {
        event.exception.values = event.exception.values.map((ex) =>
          ex.value ? { ...ex, value: scrubMessage(ex.value) } : ex,
        );
      }
      if (event.message) event.message = scrubMessage(event.message);

      return event;
    },
  });
};
