/**
 * 환경변수 접근 단일 진입점.
 * - 런타임 검증으로 잘못된 설정 조기 감지
 * - 민감정보 코드 내 하드코딩 금지
 */

type NodeEnv = 'development' | 'production' | 'test';

const required = (key: keyof ImportMetaEnv): string => {
  const value = import.meta.env[key];
  if (!value) {
    if (import.meta.env.PROD) {
      throw new Error(`[env] Required environment variable missing: ${key}`);
    }
    console.warn(`[env] Missing environment variable: ${key}`);
    return '';
  }
  return value;
};

const optionalNumber = (key: keyof ImportMetaEnv, fallback: number): number => {
  const raw = import.meta.env[key];
  if (!raw) return fallback;
  const parsed = Number(raw);
  return Number.isFinite(parsed) ? parsed : fallback;
};

const optionalBool = (key: keyof ImportMetaEnv, fallback: boolean): boolean => {
  const raw = import.meta.env[key];
  if (raw === undefined || raw === '') return fallback;
  return raw === 'true' || raw === '1';
};

export const env = {
  mode: import.meta.env.MODE as NodeEnv,
  isDev: import.meta.env.DEV,
  isProd: import.meta.env.PROD,

  api: {
    baseUrl: import.meta.env.PROD
      ? required('VITE_API_URL')
      : import.meta.env.VITE_API_URL || 'http://localhost:8080/api',
  },

  sentry: {
    dsn: import.meta.env.VITE_APP_SENTRY_DSN ?? '',
    environment: import.meta.env.VITE_APP_SENTRY_ENVIRONMENT ?? 'local',
    tracesSampleRate: optionalNumber('VITE_APP_SENTRY_TRACES_SAMPLE_RATE', 0.1),
  },

  features: {
    enableDevtools: optionalBool('VITE_APP_ENABLE_DEVTOOLS', import.meta.env.DEV),
  },
} as const;
