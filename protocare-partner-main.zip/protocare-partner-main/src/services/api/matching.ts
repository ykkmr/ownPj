import { apiClient } from './client';
import type {
  Matching,
  CareSchedule,
  CareLog,
  CareLogType,
  ApiResponse,
  PaginatedResponse,
} from '@/types';

export interface MatchingListParams {
  page?: number;
  size?: number;
  status?: string;
}

export interface CareLogListParams {
  page?: number;
  size?: number;
}

export interface CreateCareLogBody {
  type: CareLogType;
  content: string;
  mediaUrls?: string[];
}

export const matchingApi = {
  getList: async (params?: MatchingListParams) => {
    const { data } = await apiClient.get<PaginatedResponse<Matching>>('/matchings', { params });
    return data.data;
  },

  getOne: async (id: number) => {
    const { data } = await apiClient.get<ApiResponse<Matching>>(`/matchings/${id}`);
    return data.data;
  },

  getSchedules: async (id: number) => {
    const { data } = await apiClient.get<ApiResponse<CareSchedule[]>>(`/matchings/${id}/schedules`);
    return data.data;
  },

  getLogs: async (id: number, params?: CareLogListParams) => {
    const { data } = await apiClient.get<PaginatedResponse<CareLog>>(`/matchings/${id}/logs`, {
      params,
    });
    return data.data;
  },

  createLog: async (id: number, body: CreateCareLogBody) => {
    const { data } = await apiClient.post<ApiResponse<CareLog>>(`/matchings/${id}/logs`, body);
    return data.data;
  },

  start: async (id: number) => {
    const { data } = await apiClient.patch<ApiResponse<Matching>>(`/matchings/${id}/start`);
    return data.data;
  },

  complete: async (id: number) => {
    const { data } = await apiClient.patch<ApiResponse<Matching>>(`/matchings/${id}/complete`);
    return data.data;
  },
};
