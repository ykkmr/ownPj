import { apiClient } from './client';
import type { CareRequest, CareRequestType, ApiResponse, PaginatedResponse } from '@/types';

export interface CareRequestListParams {
  page?: number;
  size?: number;
  type?: CareRequestType;
  status?: string;
}

export interface CreateCareRequestBody {
  type: CareRequestType;
  startAt: string;
  endAt: string;
  addRequest?: string;
  from?: string;
  to?: string;
}

export const careRequestApi = {
  getList: async (params?: CareRequestListParams) => {
    const { data } = await apiClient.get<PaginatedResponse<CareRequest>>('/care-requests', {
      params,
    });
    return data.data;
  },

  getOne: async (id: number) => {
    const { data } = await apiClient.get<ApiResponse<CareRequest>>(`/care-requests/${id}`);
    return data.data;
  },

  create: async (body: CreateCareRequestBody) => {
    const { data } = await apiClient.post<ApiResponse<CareRequest>>('/care-requests', body);
    return data.data;
  },

  update: async (id: number, body: Partial<CreateCareRequestBody>) => {
    const { data } = await apiClient.patch<ApiResponse<CareRequest>>(`/care-requests/${id}`, body);
    return data.data;
  },

  cancel: async (id: number) => {
    const { data } = await apiClient.patch<ApiResponse<CareRequest>>(`/care-requests/${id}/cancel`);
    return data.data;
  },
};
