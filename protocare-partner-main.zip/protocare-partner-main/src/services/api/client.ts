import axios, { type AxiosError, type InternalAxiosRequestConfig } from 'axios';
import { tokenStorage } from './tokenStorage';
import { useAuthStore } from '@/store/auth.store';
import type { ApiResponse, TokenResponse } from '@/types/api';

const BASE_URL = 'https://api-dev.all-concierge.shop/api/v1';

export const apiClient = axios.create({
  baseURL: BASE_URL,
  timeout: 10_000,
  headers: { 'Content-Type': 'application/json' },
});

// ── Request Interceptor: 인메모리 토큰 자동 첨부 ─────────────
apiClient.interceptors.request.use((config: InternalAxiosRequestConfig) => {
  const token = tokenStorage.get();
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// ── Refresh 경쟁 조건 방지 — 단일 Promise 잠금 ──────────────
let refreshPromise: Promise<string> | null = null;

const PUBLIC_PREFIXES = [
  '/login',
  '/signup',
  '/onboarding',
  '/supporter-intro',
  '/supporter/apply',
];

const doRefresh = (): Promise<string> => {
  if (refreshPromise) return refreshPromise;

  const refreshToken = tokenStorage.getRefresh();

  if (!refreshToken) {
    useAuthStore.getState().clearSession();
    const isPublic = PUBLIC_PREFIXES.some((p) => window.location.pathname.startsWith(p));
    if (!isPublic) window.location.replace('/login');
    return Promise.reject(new Error('No refresh token'));
  }

  // Refresh Token은 body로 전송 (서버가 body로 반환하므로)
  refreshPromise = axios
    .post<ApiResponse<TokenResponse>>(`${BASE_URL}/auth/supporter/reissue`, { refreshToken })
    .then(({ data }) => {
      const { accessToken, refreshToken: newRefresh } = data.data;
      tokenStorage.set(accessToken);
      tokenStorage.setRefresh(newRefresh);
      return accessToken;
    })
    .catch((err) => {
      useAuthStore.getState().clearSession();
      const isPublic = PUBLIC_PREFIXES.some((p) => window.location.pathname.startsWith(p));
      if (!isPublic) window.location.replace('/login');
      throw err;
    })
    .finally(() => {
      refreshPromise = null;
    });

  return refreshPromise;
};

// ── Response Interceptor: 401 시 토큰 갱신 후 원래 요청 재시도 ──
apiClient.interceptors.response.use(
  (response) => response,
  async (error: AxiosError) => {
    const originalRequest = error.config as InternalAxiosRequestConfig & { _retry?: boolean };

    if (error.response?.status === 401 && !originalRequest._retry) {
      originalRequest._retry = true;
      try {
        const newToken = await doRefresh();
        originalRequest.headers.Authorization = `Bearer ${newToken}`;
        return apiClient(originalRequest);
      } catch {
        return Promise.reject(error);
      }
    }

    return Promise.reject(error);
  },
);
