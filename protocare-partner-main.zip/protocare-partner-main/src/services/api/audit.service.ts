import * as Sentry from '@sentry/react';
import { apiClient } from './client';

const safePost = async (path: string, payload: unknown): Promise<void> => {
  try {
    await apiClient.post(path, payload);
  } catch (err) {
    Sentry.captureException(err, { tags: { context: 'audit-log', path } });
  }
};

const now = () => new Date().toISOString();

export const auditService = {
  logLogin: (userId: string): Promise<void> =>
    safePost('/audit/login', { userId, timestamp: now() }),

  logLogout: (userId: string): Promise<void> =>
    safePost('/audit/logout', { userId, timestamp: now() }),

  logDataAccess: (userId: string, resource: string, resourceId: string): Promise<void> =>
    safePost('/audit/access', { userId, resource, resourceId, timestamp: now() }),
};
