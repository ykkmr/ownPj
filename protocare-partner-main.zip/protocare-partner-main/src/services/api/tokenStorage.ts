/**
 * 토큰 저장소
 *
 * 보안 설계:
 * - Access Token: 모듈 스코프 인메모리 → XSS 불가, 페이지 리로드 시 소멸
 * - Refresh Token: sessionStorage → 탭 닫힘 시 소멸, reissue로 Access Token 복구 목적
 *   (서버가 body로 반환하므로 HttpOnly 쿠키 저장 불가)
 */

let accessToken: string | null = null;
const REFRESH_KEY = 'rt';

export const tokenStorage = {
  get: (): string | null => accessToken,
  set: (token: string): void => {
    accessToken = token;
  },
  clear: (): void => {
    accessToken = null;
  },

  getRefresh: (): string | null => sessionStorage.getItem(REFRESH_KEY),
  setRefresh: (token: string): void => {
    sessionStorage.setItem(REFRESH_KEY, token);
  },
  clearRefresh: (): void => {
    sessionStorage.removeItem(REFRESH_KEY);
  },

  clearAll: (): void => {
    accessToken = null;
    sessionStorage.removeItem(REFRESH_KEY);
  },
};

// 레거시 호환 어댑터
export const getAccessToken = tokenStorage.get;
export const setAccessToken = tokenStorage.set;
export const clearAccessToken = tokenStorage.clear;
