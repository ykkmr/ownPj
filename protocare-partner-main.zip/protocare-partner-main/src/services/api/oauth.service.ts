export type OAuthProvider = 'KAKAO' | 'NAVER' | 'GOOGLE';

function redirectUri(provider: string): string {
  const base = import.meta.env.VITE_OAUTH_REDIRECT_BASE ?? window.location.origin;
  return `${base}/oauth/callback/${provider.toLowerCase()}`;
}

function buildKakaoUrl(): string {
  const clientId = import.meta.env.VITE_KAKAO_CLIENT_ID;
  if (!clientId) throw new Error('VITE_KAKAO_CLIENT_ID가 설정되지 않았습니다.');
  return `https://kauth.kakao.com/oauth/authorize?${new URLSearchParams({
    client_id: clientId,
    redirect_uri: redirectUri('kakao'),
    response_type: 'code',
  })}`;
}

function buildNaverUrl(): string {
  const clientId = import.meta.env.VITE_NAVER_CLIENT_ID;
  if (!clientId) throw new Error('VITE_NAVER_CLIENT_ID가 설정되지 않았습니다.');
  const state = crypto.randomUUID();
  sessionStorage.setItem('naver_oauth_state', state);
  return `https://nid.naver.com/oauth2.0/authorize?${new URLSearchParams({
    client_id: clientId,
    redirect_uri: redirectUri('naver'),
    response_type: 'code',
    state,
  })}`;
}

function buildGoogleUrl(): string {
  const clientId = import.meta.env.VITE_GOOGLE_CLIENT_ID;
  if (!clientId) throw new Error('VITE_GOOGLE_CLIENT_ID가 설정되지 않았습니다.');
  return `https://accounts.google.com/o/oauth2/v2/auth?${new URLSearchParams({
    client_id: clientId,
    redirect_uri: redirectUri('google'),
    response_type: 'code',
    scope: 'email profile',
  })}`;
}

const BUILDERS: Record<OAuthProvider, () => string> = {
  KAKAO: buildKakaoUrl,
  NAVER: buildNaverUrl,
  GOOGLE: buildGoogleUrl,
};

export const oauthService = {
  redirectTo(provider: OAuthProvider): void {
    window.location.href = BUILDERS[provider]();
  },
};
