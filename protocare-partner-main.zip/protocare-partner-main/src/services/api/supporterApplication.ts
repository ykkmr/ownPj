import { apiClient } from './client';
import type {
  ApiResponse,
  ApplicationOverviewResponse,
  BasicInfoRequest,
  BasicInfoResponse,
  CertificationType,
  InitResponse,
  QualificationResponse,
  TagCode,
  TagItem,
  TermsRequest,
  TermsResponse,
} from '@/types/api';

export interface SaveCareTypeBody {
  experienceTag: TagCode;
  styleTag: TagCode;
  activityTags: TagCode[];
  conditionTags?: TagCode[];
}

export const supporterApplicationApi = {
  getOverview: async (): Promise<ApplicationOverviewResponse> => {
    const { data } = await apiClient.get<ApiResponse<ApplicationOverviewResponse>>(
      '/supporter-applications/me',
    );
    return data.data;
  },

  init: async (): Promise<InitResponse> => {
    const { data } = await apiClient.post<ApiResponse<InitResponse>>(
      '/supporter-applications/me/init',
    );
    return data.data;
  },

  getTerms: async (): Promise<TermsResponse> => {
    const { data } = await apiClient.get<ApiResponse<TermsResponse>>(
      '/supporter-applications/me/terms',
    );
    return data.data;
  },

  saveTerms: async (body: TermsRequest): Promise<TermsResponse> => {
    const { data } = await apiClient.post<ApiResponse<TermsResponse>>(
      '/supporter-applications/me/terms',
      body,
    );
    return data.data;
  },

  getBasicInfo: async (): Promise<BasicInfoResponse> => {
    const { data } = await apiClient.get<ApiResponse<BasicInfoResponse>>(
      '/supporter-applications/me/basic-info',
    );
    return data.data;
  },

  updateBasicInfo: async (body: BasicInfoRequest): Promise<BasicInfoResponse> => {
    const { data } = await apiClient.patch<ApiResponse<BasicInfoResponse>>(
      '/supporter-applications/me/basic-info',
      body,
    );
    return data.data;
  },

  uploadProfileImage: async (file: File): Promise<BasicInfoResponse> => {
    const formData = new FormData();
    formData.append('file', file);
    const { data } = await apiClient.post<ApiResponse<BasicInfoResponse>>(
      '/supporter-applications/me/basic-info/profile-image',
      formData,
      { headers: { 'Content-Type': 'multipart/form-data' } },
    );
    return data.data;
  },

  getCareType: async (): Promise<Record<number, TagItem[]>> => {
    const { data } = await apiClient.get<ApiResponse<Record<number, TagItem[]>>>(
      '/supporter-applications/me/care-type',
    );
    return data.data;
  },

  updateCareType: async (body: SaveCareTypeBody): Promise<Record<number, TagItem[]>> => {
    const { data } = await apiClient.put<ApiResponse<Record<number, TagItem[]>>>(
      '/supporter-applications/me/care-type',
      body,
    );
    return data.data;
  },

  getQualifications: async (): Promise<QualificationResponse> => {
    const { data } = await apiClient.get<ApiResponse<QualificationResponse>>(
      '/supporter-applications/me/qualifications',
    );
    return data.data;
  },

  uploadCertification: async (body: {
    file: File;
    certificationType: CertificationType;
    certificationNumber?: string;
    issuer?: string;
    issuedAt?: string;
  }): Promise<QualificationResponse> => {
    const formData = new FormData();
    formData.append('file', body.file);
    formData.append('certificationType', body.certificationType);
    if (body.certificationNumber) formData.append('certificationNumber', body.certificationNumber);
    if (body.issuer) formData.append('issuer', body.issuer);
    if (body.issuedAt) formData.append('issuedAt', body.issuedAt);
    const { data } = await apiClient.post<ApiResponse<QualificationResponse>>(
      '/supporter-applications/me/qualifications/certifications',
      formData,
      { headers: { 'Content-Type': 'multipart/form-data' } },
    );
    return data.data;
  },

  uploadCriminalRecord: async (
    file: File,
    sexCrimeConsentAgreed?: boolean,
  ): Promise<QualificationResponse> => {
    const formData = new FormData();
    formData.append('file', file);
    if (sexCrimeConsentAgreed !== undefined) {
      formData.append('sexCrimeConsentAgreed', String(sexCrimeConsentAgreed));
    }
    const { data } = await apiClient.post<ApiResponse<QualificationResponse>>(
      '/supporter-applications/me/qualifications/criminal-record',
      formData,
      { headers: { 'Content-Type': 'multipart/form-data' } },
    );
    return data.data;
  },

  submit: async (): Promise<ApplicationOverviewResponse> => {
    const { data } = await apiClient.post<ApiResponse<ApplicationOverviewResponse>>(
      '/supporter-applications/me/submit',
    );
    return data.data;
  },
};
