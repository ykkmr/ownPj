import type { ApiErrorBody } from '@/types/api';

/**
 * 도메인 에러 클래스 계층.
 * UI가 HTTP 상태 코드를 직접 다루지 않아도 되도록 캡슐화.
 */
export class AppError extends Error {
  readonly code: string;
  readonly status: number;
  readonly details?: Record<string, string[]>;

  constructor(message: string, code: string, status: number, details?: Record<string, string[]>) {
    super(message);
    this.name = 'AppError';
    this.code = code;
    this.status = status;
    this.details = details;
  }
}

export class UnauthorizedError extends AppError {
  constructor(message = '인증이 필요합니다.', body?: ApiErrorBody) {
    super(message, body?.code ?? 'UNAUTHORIZED', 401, body?.details);
    this.name = 'UnauthorizedError';
  }
}

export class ForbiddenError extends AppError {
  constructor(message = '접근 권한이 없습니다.', body?: ApiErrorBody) {
    super(message, body?.code ?? 'FORBIDDEN', 403, body?.details);
    this.name = 'ForbiddenError';
  }
}

export class NotFoundError extends AppError {
  constructor(message = '요청한 리소스를 찾을 수 없습니다.', body?: ApiErrorBody) {
    super(message, body?.code ?? 'NOT_FOUND', 404, body?.details);
    this.name = 'NotFoundError';
  }
}

export class ValidationError extends AppError {
  constructor(message = '입력값이 올바르지 않습니다.', body?: ApiErrorBody) {
    super(message, body?.code ?? 'VALIDATION_FAILED', 400, body?.details);
    this.name = 'ValidationError';
  }
}

export class NetworkError extends AppError {
  constructor(message = '네트워크 연결을 확인해주세요.') {
    super(message, 'NETWORK_ERROR', 0);
    this.name = 'NetworkError';
  }
}
