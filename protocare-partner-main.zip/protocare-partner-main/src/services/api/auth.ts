import { apiClient } from './client';
import type { ApiResponse } from '@/types/api';
import type { User } from '@/types/user';

export interface LoginRequest {
  email: string;
  password: string;
}

export interface LoginResponse {
  data: { accessToken: any; user: any; };
  accessToken: string;
  refreshToken: string;
  user: User;
}

export interface SignupRequest {
  userId: string;
  password: string;
  name: string;
  email: string;
  phoneNumber: string;
  type: 'REQUESTER' | 'SUPPORTER';
  gender: string;
  birth: string;
}

export const authApi = {
  login: (body: LoginRequest) =>
    apiClient.post<ApiResponse<LoginResponse>>('/auth/login', body),

  signup: (body: SignupRequest) =>
    apiClient.post<ApiResponse<User>>('/auth/signup', body),

  logout: () =>
    apiClient.post<ApiResponse<null>>('/auth/logout'),

  refresh: (refreshToken: string) =>
    apiClient.post<ApiResponse<{ accessToken: string }>>('/auth/refresh', { refreshToken }),

  socialLogin: (provider: 'KAKAO' | 'NAVER', code: string) =>
    apiClient.post<ApiResponse<LoginResponse>>(`/auth/social/${provider.toLowerCase()}`, { code }),

  sendVerification: (phoneNumber: string, type: string) =>
    apiClient.post<ApiResponse<null>>('/auth/verify/send', { phoneNumber, type }),

  confirmVerification: (phoneNumber: string, code: string) =>
    apiClient.post<ApiResponse<{ ci: string }>>('/auth/verify/confirm', { phoneNumber, code }),
};
