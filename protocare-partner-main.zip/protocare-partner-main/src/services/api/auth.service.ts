import { apiClient } from './client';
import { tokenStorage } from './tokenStorage';
import { useAuthStore } from '@/store/auth.store';
import type { ApiResponse, TokenResponse, VerifyResponse } from '@/types/api';
import type { AuthUser } from '@/types/domain';
import type { OAuthProvider } from './oauth.service';

export type SmsVerifyType = 'SIGNUP' | 'LOGIN' | 'RESET_PASSWORD';

export interface SupporterSignupPayload {
  name: string;
  email: string;
  phoneNumber: string;
  password: string;
}

function decodeJwt(token: string): Record<string, string> | null {
  try {
    const parts = token.split('.');
    if (parts.length < 2 || !parts[1]) return null;
    return JSON.parse(atob(parts[1])) as Record<string, string>;
  } catch {
    return null;
  }
}

// ── Mobile Auth API (SMS 인증 + Danal 본인인증) ──────────────
export const mobileAuthService = {
  sendSms: (phoneNumber: string, type: SmsVerifyType) =>
    apiClient.post<ApiResponse<void>>('/mobile-auth/send', { phoneNumber, type }),

  verifySms: async (phoneNumber: string, type: SmsVerifyType, code: string) => {
    const { data } = await apiClient.post<ApiResponse<VerifyResponse>>('/mobile-auth/verify', {
      phoneNumber,
      type,
      code,
    });
    return data.data;
  },

  danalPreRegister: async (): Promise<{ identityVerificationId: string }> => {
    const { data } = await apiClient.post<ApiResponse<{ identityVerificationId: string }>>(
      '/mobile-auth/danal/pre-register',
    );
    return data.data;
  },

  danalVerify: async (
    identityVerificationId: string,
    type: SmsVerifyType,
  ): Promise<VerifyResponse> => {
    const { data } = await apiClient.post<ApiResponse<VerifyResponse>>(
      '/mobile-auth/danal/verify',
      { identityVerificationId, type },
    );
    return data.data;
  },
};

// ── Supporter Auth API ────────────────────────────────────────
export const supporterAuthService = {
  login: async (email: string, password: string): Promise<AuthUser> => {
    const { data } = await apiClient.post<ApiResponse<TokenResponse>>('/auth/supporter/login', {
      email,
      password,
    });

    const { accessToken, refreshToken } = data.data;
    tokenStorage.set(accessToken);
    tokenStorage.setRefresh(refreshToken);

    const claims = decodeJwt(accessToken);
    const user: AuthUser = {
      id: claims?.sub ?? '',
      name: claims?.name ?? '',
      role: (claims?.role as AuthUser['role']) ?? 'SUPPORTER',
      email: claims?.email,
    };

    useAuthStore.getState().login(user, accessToken);
    return user;
  },

  signup: async (payload: SupporterSignupPayload) => {
    const { data } = await apiClient.post<ApiResponse<void>>('/auth/supporter/signup', payload);
    return data;
  },

  logout: () => {
    tokenStorage.clearAll();
    useAuthStore.getState().clearSession();
    window.location.replace('/login');
  },

  findId: (phoneNumber: string) =>
    apiClient.post<ApiResponse<void>>('/auth/supporter/find-id', {
      phoneNumber,
      type: 'RESET_PASSWORD' as SmsVerifyType,
    }),

  findPassword: (phoneNumber: string, email: string) =>
    apiClient.post<ApiResponse<void>>('/auth/supporter/find-password', {
      phoneNumber,
      email,
      type: 'RESET_PASSWORD' as SmsVerifyType,
    }),

  resetPassword: async (phoneNumber: string, code: string) => {
    const { data } = await apiClient.post<ApiResponse<VerifyResponse>>(
      '/auth/supporter/reset-password',
      { phoneNumber, type: 'RESET_PASSWORD' as SmsVerifyType, code },
    );
    return data.data;
  },

  socialLogin: async (provider: OAuthProvider, code: string): Promise<AuthUser> => {
    const { data } = await apiClient.post<ApiResponse<TokenResponse>>(
      `/auth/supporter/oauth/${provider}/login`,
      null,
      { params: { code } },
    );
    const { accessToken, refreshToken } = data.data;
    tokenStorage.set(accessToken);
    tokenStorage.setRefresh(refreshToken);
    const claims = decodeJwt(accessToken);
    const user: AuthUser = {
      id: claims?.sub ?? '',
      name: claims?.name ?? '',
      role: (claims?.role as AuthUser['role']) ?? 'SUPPORTER',
      email: claims?.email,
    };
    useAuthStore.getState().login(user, accessToken);
    return user;
  },
};

// ── 하위 호환성 — 기존 코드(useAuth, LoginPage, useInitAuth)에서 authService 사용 ──
export const authService = {
  login: async (payload: { email: string; password: string }) => {
    const user = await supporterAuthService.login(payload.email, payload.password);
    return { user };
  },

  signup: (payload: SupporterSignupPayload) => supporterAuthService.signup(payload),

  logout: supporterAuthService.logout,

  // 세션 복구용: 인메모리 토큰 디코딩 → 없으면 reissue 후 디코딩
  getMe: async (): Promise<AuthUser> => {
    const tryDecode = (token: string): AuthUser | null => {
      const claims = decodeJwt(token);
      if (!claims?.sub) return null;
      return {
        id: claims.sub,
        name: claims.name ?? '',
        role: (claims.role as AuthUser['role']) ?? 'SUPPORTER',
        email: claims.email,
      };
    };

    const existing = tokenStorage.get();
    if (existing) {
      const user = tryDecode(existing);
      if (user) return user;
    }

    const refreshToken = tokenStorage.getRefresh();
    if (!refreshToken) throw new Error('UNAUTHORIZED');

    const { data } = await apiClient.post<ApiResponse<TokenResponse>>('/auth/supporter/reissue', {
      refreshToken,
    });
    const { accessToken, refreshToken: newRefresh } = data.data;
    tokenStorage.set(accessToken);
    tokenStorage.setRefresh(newRefresh);

    const user = tryDecode(accessToken);
    if (!user) throw new Error('UNAUTHORIZED');
    return user;
  },

  sendCode: (payload: { phoneNumber: string; type?: SmsVerifyType }) =>
    mobileAuthService.sendSms(payload.phoneNumber, payload.type ?? 'SIGNUP'),

  verifyCode: (payload: { phoneNumber: string; code: string; type?: SmsVerifyType }) =>
    mobileAuthService.verifySms(payload.phoneNumber, payload.type ?? 'SIGNUP', payload.code),
};
