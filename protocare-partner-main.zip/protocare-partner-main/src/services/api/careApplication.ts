import { apiClient } from './client';
import type {
  CareApplication,
  CareApplicationStatus,
  ApiResponse,
  PaginatedResponse,
} from '@/types';

export interface CareApplicationListParams {
  page?: number;
  size?: number;
  status?: CareApplicationStatus;
}

export interface ApplyCareRequestBody {
  message?: string;
}

export const careApplicationApi = {
  getList: async (params?: CareApplicationListParams) => {
    const { data } = await apiClient.get<PaginatedResponse<CareApplication>>('/care-applications', {
      params,
    });
    return data.data;
  },

  apply: async (careRequestId: number, body?: ApplyCareRequestBody) => {
    const { data } = await apiClient.post<ApiResponse<CareApplication>>(
      `/care-requests/${careRequestId}/apply`,
      body,
    );
    return data.data;
  },

  cancel: async (id: number) => {
    const { data } = await apiClient.patch<ApiResponse<CareApplication>>(
      `/care-applications/${id}/cancel`,
    );
    return data.data;
  },
};
