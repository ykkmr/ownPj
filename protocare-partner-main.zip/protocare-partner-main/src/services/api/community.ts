import { apiClient } from './client';
import type { CommunityPost, CommunityComment, ApiResponse, PaginatedResponse } from '@/types';

export interface CommunityPostListParams {
  page?: number;
  size?: number;
}

export interface CreatePostBody {
  title: string;
  content: string;
  isAnonymous?: boolean;
}

export interface CreateCommentBody {
  content: string;
  parentId?: number;
}

export const communityApi = {
  getPosts: async (params?: CommunityPostListParams) => {
    const { data } = await apiClient.get<PaginatedResponse<CommunityPost>>('/community/posts', {
      params,
    });
    return data.data;
  },

  getPost: async (id: number) => {
    const { data } = await apiClient.get<ApiResponse<CommunityPost>>(`/community/posts/${id}`);
    return data.data;
  },

  createPost: async (body: CreatePostBody) => {
    const { data } = await apiClient.post<ApiResponse<CommunityPost>>('/community/posts', body);
    return data.data;
  },

  getComments: async (postId: number) => {
    const { data } = await apiClient.get<ApiResponse<CommunityComment[]>>(
      `/community/posts/${postId}/comments`,
    );
    return data.data;
  },

  createComment: async (postId: number, body: CreateCommentBody) => {
    const { data } = await apiClient.post<ApiResponse<CommunityComment>>(
      `/community/posts/${postId}/comments`,
      body,
    );
    return data.data;
  },
};
