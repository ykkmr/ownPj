import { apiClient } from './client';
import type {
  ApiResponse,
  CertificationType,
  CertificationResponse,
  TagCode,
  TagResponse,
  NotificationConfig,
} from '@/types/api';
import type { SupporterProfile, TrainingHistory } from '@/types';
import { supporterAuthService } from './auth.service';

// ── Request body types ────────────────────────────────────────
export interface UpdateSupporterProfileBody {
  currentPassword?: string;
  newPassword?: string;
  serviceTypes?: string[];
  activityRegions?: string[];
  intro?: string;
  isVisible?: boolean;
}

export interface CertificationUploadBody {
  file: File;
  certificationType: CertificationType;
  certificationNumber?: string;
  issuer?: string;
  issuedAt?: string; // yyyy-MM-dd
}

// Backward-compat alias — prefer CertificationUploadBody for new code
export type UploadCertificationBody = CertificationUploadBody;

export interface SaveTagsBody {
  experienceTag: TagCode;
  styleTag: TagCode;
  activityTags: TagCode[]; // minItems: 1
  conditionTags?: TagCode[];
}

export interface SupporterEarnings {
  thisMonth: number;
  lastMonth: number;
  totalHours: number;
  pendingSettlement: number;
}

// ── API ───────────────────────────────────────────────────────
export const supporterApi = {
  // Auth (thin wrapper kept for LoginPage compatibility)
  login: async (body: { email: string; password: string }) => {
    const user = await supporterAuthService.login(body.email, body.password);
    return { user };
  },

  // ── Profile ────────────────────────────────────────────────
  getProfile: async () => {
    const { data } = await apiClient.get<ApiResponse<SupporterProfile>>('/supporters/me');
    return data.data;
  },

  updateProfile: async (body: UpdateSupporterProfileBody) => {
    const { data } = await apiClient.patch<ApiResponse<SupporterProfile>>('/supporters/me', body);
    return data.data;
  },

  // ── Personality Tags ───────────────────────────────────────
  getPersonalityTags: async () => {
    const { data } = await apiClient.get<ApiResponse<TagResponse>>(
      '/supporters/me/personality-tags',
    );
    return data.data;
  },

  updatePersonalityTags: async (body: SaveTagsBody) => {
    const { data } = await apiClient.put<ApiResponse<TagResponse>>(
      '/supporters/me/personality-tags',
      body,
    );
    return data.data;
  },

  // ── Notification Configs ───────────────────────────────────
  getNotificationConfigs: async () => {
    const { data } = await apiClient.get<ApiResponse<NotificationConfig>>(
      '/supporters/me/notification-configs',
    );
    return data.data;
  },

  updateNotificationConfigs: async (body: NotificationConfig) => {
    const { data } = await apiClient.put<ApiResponse<NotificationConfig>>(
      '/supporters/me/notification-configs',
      body,
    );
    return data.data;
  },

  // ── Certifications ─────────────────────────────────────────
  getCertifications: async () => {
    const { data } = await apiClient.get<ApiResponse<CertificationResponse[]>>('/certifications');
    return data.data;
  },

  getCertificationById: async (certId: number) => {
    const { data } = await apiClient.get<ApiResponse<CertificationResponse>>(
      `/certifications/${certId}`,
    );
    return data.data;
  },

  uploadCertification: async (body: CertificationUploadBody) => {
    const formData = new FormData();
    formData.append('file', body.file);
    formData.append('certificationType', body.certificationType);
    if (body.certificationNumber) formData.append('certificationNumber', body.certificationNumber);
    if (body.issuer) formData.append('issuer', body.issuer);
    if (body.issuedAt) formData.append('issuedAt', body.issuedAt);
    const { data } = await apiClient.post<ApiResponse<CertificationResponse>>(
      '/certifications',
      formData,
      { headers: { 'Content-Type': 'multipart/form-data' } },
    );
    return data.data;
  },

  verifyCertification: async (certId: number) => {
    const { data } = await apiClient.post<ApiResponse<CertificationResponse>>(
      `/certifications/${certId}/verify`,
    );
    return data.data;
  },

  // ── Criminal Record ────────────────────────────────────────
  uploadCriminalRecord: async (file: File, sexCrimeConsentAgreed?: boolean) => {
    const formData = new FormData();
    formData.append('file', file);
    if (sexCrimeConsentAgreed !== undefined) {
      formData.append('sexCrimeConsentAgreed', String(sexCrimeConsentAgreed));
    }
    const { data } = await apiClient.post<ApiResponse<void>>('/criminal-records', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
    return data;
  },

  // ── Non-Swagger methods (separate backend APIs) ────────────
  getEarnings: async () => {
    const { data } = await apiClient.get<ApiResponse<SupporterEarnings>>('/supporter/earnings');
    return data.data;
  },

  getTraining: async () => {
    const { data } = await apiClient.get<ApiResponse<TrainingHistory[]>>('/supporter/training');
    return data.data;
  },

  updateTrainingProgress: async (id: number, progress: number) => {
    const { data } = await apiClient.patch<ApiResponse<TrainingHistory>>(
      `/supporter/training/${id}/progress`,
      { progress },
    );
    return data.data;
  },
};
