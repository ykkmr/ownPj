/**
 * Analytics 서비스 — 어댑터 패턴.
 * GA4, 내부 감사 로그 등 여러 수집처를 동시에 지원합니다.
 *
 * 의료 서비스 PHI 보호 규칙:
 *  - 이벤트 속성에 환자 이름·생년월일·진단명 등의 직접 식별자를 포함하지 마세요.
 *  - userId 는 반드시 해시된 내부 식별자만 사용합니다.
 *  - DENY_LIST 에 등록된 키는 전송 전 자동으로 제거됩니다.
 */

export interface AnalyticsEvent {
  name: string;
  properties?: Record<string, unknown>;
}

export interface AnalyticsAdapter {
  track(event: AnalyticsEvent): void;
  identify(userId: string, traits?: Record<string, unknown>): void;
  page(name: string, properties?: Record<string, unknown>): void;
}

// PHI 포함 가능성이 있는 속성 키 — 절대 외부로 전송하지 않습니다.
const DENY_LIST = new Set([
  'patientName',
  'patientId',
  'birthDate',
  'diagnosis',
  'prescription',
  'ssn',
  'phone',
  'address',
  'email',
]);

function sanitize(properties?: Record<string, unknown>): Record<string, unknown> {
  if (!properties) return {};
  return Object.fromEntries(
    Object.entries(properties).filter(([key]) => !DENY_LIST.has(key))
  );
}

// ── 어댑터 구현체 ──────────────────────────────────────────────────────────────

/** 개발 환경용: 콘솔에 출력합니다. */
const consoleAdapter: AnalyticsAdapter = {
  track: (event) => {
    console.debug('[Analytics] track:', event.name, sanitize(event.properties));
  },
  identify: (userId, traits) => {
    console.debug('[Analytics] identify:', userId, sanitize(traits));
  },
  page: (name, properties) => {
    console.debug('[Analytics] page:', name, sanitize(properties));
  },
};

/**
 * GA4 어댑터 — window.gtag 가 로드된 이후에만 동작합니다.
 * index.html 에 GA4 스크립트 태그를 추가하면 자동으로 활성화됩니다.
 */
const ga4Adapter: AnalyticsAdapter = {
  track: (event) => {
    if (typeof window.gtag !== 'function') return;
    window.gtag('event', event.name, sanitize(event.properties));
  },
  identify: (userId) => {
    if (typeof window.gtag !== 'function') return;
    window.gtag('config', 'GA_MEASUREMENT_ID', { user_id: userId });
  },
  page: (name, properties) => {
    if (typeof window.gtag !== 'function') return;
    window.gtag('event', 'page_view', { page_title: name, ...sanitize(properties) });
  },
};

// ── 서비스 싱글턴 ──────────────────────────────────────────────────────────────

function createAnalyticsService(adapters: AnalyticsAdapter[]) {
  return {
    track(name: string, properties?: Record<string, unknown>): void {
      const safe = sanitize(properties);
      adapters.forEach((a) => a.track({ name, properties: safe }));
    },

    identify(userId: string, traits?: Record<string, unknown>): void {
      const safe = sanitize(traits);
      adapters.forEach((a) => a.identify(userId, safe));
    },

    page(name: string, properties?: Record<string, unknown>): void {
      const safe = sanitize(properties);
      adapters.forEach((a) => a.page(name, safe));
    },
  };
}

const isDev = import.meta.env.DEV;

export const analytics = createAnalyticsService(
  isDev ? [consoleAdapter] : [ga4Adapter]
);

// gtag 전역 타입 보강
declare global {
  interface Window {
    gtag?: (...args: unknown[]) => void;
  }
}