import { QueryCache, MutationCache, QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ReactQueryDevtools } from '@tanstack/react-query-devtools';
import { useState, type ReactNode } from 'react';
import { env } from '@/config/env';
import {
  UnauthorizedError,
  ValidationError,
  ForbiddenError,
  AppError,
} from '@/services/api/errors';
import { toast } from '@/store/toast.store';
import { useAuthStore } from '@/store/auth.store';

// 404는 페이지·훅 레벨에서 개별 처리 — 보조 리소스 404에도 전역 리다이렉트되는 문제 방지
const handleGlobalError = (error: unknown) => {
  if (!(error instanceof AppError)) return;

  if (error instanceof UnauthorizedError) {
    useAuthStore.getState().logout();
    window.location.replace('/login');
    return;
  }

  if (error instanceof ForbiddenError) {
    toast.warning('접근 권한이 없습니다.');
    window.location.replace('/');
    return;
  }

  if (error.status === 422) {
    toast.warning(error.message || '요청이 올바르지 않습니다. 입력값을 확인해 주세요.');
    return;
  }

  if (error.status >= 500) {
    toast.danger('서버 오류가 발생했습니다. 잠시 후 다시 시도해 주세요.');
  }
};

const createQueryClient = (): QueryClient =>
  new QueryClient({
    queryCache: new QueryCache({ onError: handleGlobalError }),
    mutationCache: new MutationCache({ onError: handleGlobalError }),
    defaultOptions: {
      queries: {
        staleTime: 0,
        gcTime: 5 * 60_000,
        refetchOnWindowFocus: false,
        retry: (failureCount, error) => {
          if (error instanceof UnauthorizedError) return false;
          if (error instanceof ValidationError) return false;
          return failureCount < 2;
        },
      },
      mutations: {
        retry: false,
      },
    },
  });

export const QueryProvider = ({ children }: { children: ReactNode }) => {
  const [client] = useState(createQueryClient);

  return (
    <QueryClientProvider client={client}>
      {children}
      {env.features.enableDevtools ? <ReactQueryDevtools initialIsOpen={false} /> : null}
    </QueryClientProvider>
  );
};
