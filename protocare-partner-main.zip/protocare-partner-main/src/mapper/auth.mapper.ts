import type { AuthUser, UserRole } from '@/types/domain';

export interface ApiAuthUser {
  id: string;
  name: string;
  role: string;
  email?: string;
}

const VALID_ROLES: readonly UserRole[] = [
  'USER',
  'PATIENT',
  'DOCTOR',
  'NURSE',
  'ADMIN',
  'STAFF',
  'SUPPORTER_BASIC',
  'SUPPORTER_PREMIUM',
];

export const isValidRole = (role: unknown): role is UserRole =>
  typeof role === 'string' && (VALID_ROLES as string[]).includes(role);

export const mapApiUserToAuthUser = (raw: ApiAuthUser): AuthUser => ({
  id: raw.id,
  name: raw.name,
  // 👈 결과를 UserRole로 강제 단언 (TS2322 해결)
  role: (raw.role === 'USER' ? 'REQUESTER' : raw.role) as UserRole,
  email: raw.email,
});
// src/mapper/auth.mapper.ts
// 2. 매퍼 로직에서 백엔드 값('USER')을 프론트 규격('REQUESTER')으로 치환해야 합니다.
