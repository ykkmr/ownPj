import { Stepper, FormField, Input, Button } from '@/components/ui';
import { AuthLayout } from '@/components/layout';
import { useForm } from '@/components/ui/FormController';
import { useSignup } from '@/hooks/useAuth';
import { toast } from '@/store/toast.store';

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const PHONE_REGEX = /^[0-9]{10,11}$/;

const SIGNUP_RULES = {
  name: { required: '이름을 입력해 주세요.' },
  email: {
    required: '이메일을 입력해 주세요.',
    pattern: { value: EMAIL_REGEX, message: '올바른 이메일 형식이 아닙니다.' },
  },
  phone: {
    required: '전화번호를 입력해 주세요.',
    pattern: { value: PHONE_REGEX, message: '숫자만 입력해 주세요 (- 제외).' },
  },
  password: {
    required: '비밀번호를 입력해 주세요.',
    minLength: { value: 8, message: '비밀번호는 8자리 이상이어야 합니다.' },
  },
  confirmPassword: { required: '비밀번호 확인을 입력해 주세요.' },
} as const;

export const SignupStep2 = () => {
  const signup = useSignup();

  const form = useForm({
    initialValues: { name: '', email: '', phone: '', password: '', confirmPassword: '' },
    rules: SIGNUP_RULES,
  });

  const handleNext = () => {
    const isFieldsValid = form.validate();

    if (form.values.password !== form.values.confirmPassword) {
      form.setError('confirmPassword', '비밀번호가 일치하지 않습니다.');
    }

    if (!isFieldsValid || form.values.password !== form.values.confirmPassword) {
      toast.danger('입력 정보를 다시 확인해 주세요.');
      return;
    }

    signup.mutate({
      name: form.values.name,
      email: form.values.email,
      phoneNumber: form.values.phone,
      password: form.values.password,
    });
  };

  return (
    <AuthLayout title="정보 입력">
      <div className="flex-none p-4">
        <Stepper
          steps={[{ label: '본인인증' }, { label: '정보입력' }, { label: '가입완료' }]}
          currentStep={1}
        />
      </div>

      <div className="flex-1 overflow-y-auto p-6 space-y-6">
        <FormField label="이름" error={form.errors.name}>
          <Input
            placeholder="실명을 입력해 주세요"
            value={form.values.name}
            onChange={form.handleChange('name')}
          />
        </FormField>

        <FormField label="이메일" error={form.errors.email}>
          <Input
            placeholder="example@mail.com"
            value={form.values.email}
            onChange={form.handleChange('email')}
          />
        </FormField>

        <FormField label="전화번호" error={form.errors.phone}>
          <Input
            placeholder="숫자만 입력 (- 제외)"
            value={form.values.phone}
            onChange={form.handleChange('phone')}
          />
        </FormField>

        <FormField label="비밀번호" error={form.errors.password}>
          <Input
            type="password"
            placeholder="8자리 이상 입력"
            value={form.values.password}
            onChange={form.handleChange('password')}
          />
        </FormField>

        <FormField label="비밀번호 확인" error={form.errors.confirmPassword}>
          <Input
            type="password"
            placeholder="비밀번호를 한 번 더 입력"
            value={form.values.confirmPassword}
            onChange={form.handleChange('confirmPassword')}
          />
        </FormField>
      </div>

      <div className="flex-none border-t border-gray-100 p-4">
        <Button className="h-14 w-full" onClick={handleNext} isLoading={signup.isPending}>
          가입 완료
        </Button>
      </div>
    </AuthLayout>
  );
};



