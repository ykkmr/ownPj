import { PublicGnb } from '@/components/common/PublicGnb';
import { SignupInfoForm } from '@/components/auth/SignupInfoForm';

export const SignupStep1 = () => {
  return (
    <div className="terms-page">
      <PublicGnb />
      <div className="terms-page__content">
        <SignupInfoForm />
      </div>
    </div>
  );
};
