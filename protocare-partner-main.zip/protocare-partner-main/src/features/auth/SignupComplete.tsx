import { useNavigate } from 'react-router-dom';
import { PublicGnb } from '@/components/common/PublicGnb';
import './SignupComplete.css';

function CheckIcon() {
  return (
    <svg
      className="signup-complete-card__icon"
      viewBox="0 0 100 100"
      fill="none"
      aria-hidden="true"
    >
      <circle cx="50" cy="50" r="50" fill="#47c7ac" />
      <path
        d="M28 52l16 16 28-32"
        stroke="#ffffff"
        strokeWidth="6"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

export const SignupComplete = () => {
  const navigate = useNavigate();

  return (
    <div className="signup-complete-page">
      <PublicGnb />
      <div className="signup-complete-page__content">
        <div className="signup-complete-card">
          <div className="signup-complete-card__top">
            <CheckIcon />
            <p className="signup-complete-card__title">회원가입이 성공적으로 완료되었습니다!</p>
            <p className="signup-complete-card__subtitle">
              이제 Protocare의 서포터 지원서를 작성해 보세요.
            </p>
          </div>
          <button
            type="button"
            className="signup-complete-card__btn"
            onClick={() => navigate('/supporter/apply')}
          >
            서포터 지원서 작성하기
          </button>
        </div>
      </div>
    </div>
  );
};
