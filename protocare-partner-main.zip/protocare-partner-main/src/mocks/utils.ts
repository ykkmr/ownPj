// src/mocks/utils.ts
import { HttpResponse, delay } from 'msw';

export const withChaos = async (resolver: () => any) => {
  // 1. 10%의 확률로 서버 에러 발생
  const errorProbability = Math.random();
  
  if (errorProbability < 0.1) {
    await delay(500);
    return new HttpResponse(null, { status: 500 });
  }

  // 2. 5%의 확률로 권한 만료 (401) 테스트
  if (errorProbability > 0.95) {
    return new HttpResponse(null, { status: 401 });
  }

  return resolver();
};