import { http, HttpResponse, delay } from 'msw';

const MOCK_PROFILE = {
  id: 1,
  name: '김서포터',
  email: 'dev@protocare.kr',
  status: 'APPROVED',
  serviceTypes: ['HOSPITAL', 'ELDERLY'],
  activityRegions: ['서울 마포구', '서울 서대문구'],
  intro: '안녕하세요. 5년 경력의 병원동행 전문 서포터입니다.',
  profileImageUrl: null,
  isVisible: true,
  approvedAt: '2025-03-01T00:00:00.000Z',
  rejectedReason: null,
  createdAt: '2025-02-15T00:00:00.000Z',
};

const MOCK_CERTIFICATIONS = [
  {
    id: 1,
    supporterId: 1,
    certificationType: 'CARE_WORKER',
    certificationTypeName: '요양보호사',
    certificationNumber: '2022-001234',
    issuer: '한국보건의료인국가시험원',
    issuedAt: '2022-06-15',
    fileUrl: 'https://example.com/cert/sample.pdf',
    status: 'VERIFIED',
    verifiedAt: '2025-02-20T00:00:00.000Z',
    rejectedReason: null,
    createdAt: '2025-02-15T00:00:00.000Z',
  },
];

const MOCK_PERSONALITY_TAGS = {
  experienceTag: {
    tagCategory: 'CARE_EXPERIENCE',
    orderNumber: 1,
    tagCode: 'EXPERIENCE_HOSPITAL',
    tagName: '병원 동행 경험',
  },
  styleTag: {
    tagCategory: 'CARE_STYLE',
    orderNumber: 1,
    tagCode: 'STYLE_CALM',
    tagName: '차분하고 침착해요',
  },
  activityTags: [
    {
      tagCategory: 'PREFERRED_ACTIVITY',
      orderNumber: 1,
      tagCode: 'ACTIVITY_HOSPITAL',
      tagName: '병원 동행',
    },
  ],
  conditionTags: [],
};

const MOCK_NOTIFICATION_CONFIGS = {
  customActivityEnabled: true,
  activityScheduleEnabled: true,
  incomeSettlementEnabled: false,
  serviceGuideEnabled: true,
};

const MOCK_EARNINGS = {
  thisMonth: 1240500,
  lastMonth: 980000,
  totalHours: 48,
  pendingSettlement: 320000,
};

const MOCK_TRAINING = [
  {
    id: 1,
    userId: 1,
    contentType: 'VIDEO',
    contentId: 'video-001',
    contentName: '병원동행 서비스 기본 교육',
    progress: 100,
    isCompleted: true,
    completedAt: '2025-02-18T00:00:00.000Z',
    createdAt: '2025-02-15T00:00:00.000Z',
  },
  {
    id: 2,
    userId: 1,
    contentType: 'VIDEO',
    contentId: 'video-002',
    contentName: '어르신 케어 심화 과정',
    progress: 45,
    isCompleted: false,
    completedAt: null,
    createdAt: '2025-03-01T00:00:00.000Z',
  },
];

const wrap = <T>(data: T) => ({
  success: true,
  code: '200',
  message: null,
  data,
  fieldErrors: [],
  timestamp: new Date().toISOString(),
});

export const supporterHandlers = [
  // ── Supporter Profile ─────────────────────────────────────────
  http.get(/\/supporters\/me$/, async () => {
    await delay(300);
    return HttpResponse.json(wrap(MOCK_PROFILE));
  }),

  http.patch(/\/supporters\/me$/, async () => {
    await delay(400);
    return HttpResponse.json(wrap(MOCK_PROFILE));
  }),

  // ── Personality Tags ──────────────────────────────────────────
  http.get(/\/supporters\/me\/personality-tags$/, async () => {
    await delay(300);
    return HttpResponse.json(wrap(MOCK_PERSONALITY_TAGS));
  }),

  http.put(/\/supporters\/me\/personality-tags$/, async () => {
    await delay(400);
    return HttpResponse.json(wrap(MOCK_PERSONALITY_TAGS));
  }),

  // ── Notification Configs ──────────────────────────────────────
  http.get(/\/supporters\/me\/notification-configs$/, async () => {
    await delay(200);
    return HttpResponse.json(wrap(MOCK_NOTIFICATION_CONFIGS));
  }),

  http.put(/\/supporters\/me\/notification-configs$/, async () => {
    await delay(300);
    return HttpResponse.json(wrap(MOCK_NOTIFICATION_CONFIGS));
  }),

  // ── Certifications ────────────────────────────────────────────
  http.get(/\/certifications$/, async () => {
    await delay(300);
    return HttpResponse.json(wrap(MOCK_CERTIFICATIONS));
  }),

  http.post(/\/certifications$/, async () => {
    await delay(500);
    return HttpResponse.json(
      wrap({ ...MOCK_CERTIFICATIONS[0], id: 99, status: 'PENDING', verifiedAt: null }),
      { status: 201 },
    );
  }),

  http.get(/\/certifications\/\d+$/, async () => {
    await delay(200);
    return HttpResponse.json(wrap(MOCK_CERTIFICATIONS[0]));
  }),

  http.post(/\/certifications\/\d+\/verify$/, async () => {
    await delay(400);
    return HttpResponse.json(wrap({ ...MOCK_CERTIFICATIONS[0], status: 'VERIFIED' }));
  }),

  // ── Criminal Records ──────────────────────────────────────────
  http.post(/\/criminal-records$/, async () => {
    await delay(500);
    return HttpResponse.json(wrap(null), { status: 201 });
  }),

  // ── Non-Swagger (earnings / training) ─────────────────────────
  http.get(/\/supporter\/earnings$/, async () => {
    await delay(300);
    return HttpResponse.json(wrap(MOCK_EARNINGS));
  }),

  http.get(/\/supporter\/training$/, async () => {
    await delay(300);
    return HttpResponse.json(wrap(MOCK_TRAINING));
  }),

  http.patch(/\/supporter\/training\/\d+\/progress$/, async ({ params }) => {
    await delay(200);
    const id = Number(Object.values(params)[0]);
    const found = MOCK_TRAINING.find((t) => t.id === id);
    return HttpResponse.json(wrap(found ?? MOCK_TRAINING[0]));
  }),
];
