import { http, HttpResponse, delay } from 'msw';

// supporterAuthService.login 은 accessToken 을 JWT 디코딩해서 유저 정보를 추출함.
// btoa 로 클레임을 인코딩한 가짜 JWT 를 생성해 실제 디코딩 흐름이 통과하도록 함.
function makeFakeJwt(claims: Record<string, string>): string {
  const header = btoa(JSON.stringify({ alg: 'HS256', typ: 'JWT' })).replace(/=/g, '');
  const payload = btoa(JSON.stringify(claims)).replace(/=/g, '');
  return `${header}.${payload}.dev-fake-signature`;
}

const MOCK_CLAIMS = {
  sub: '1',
  name: 'kimSupporter',
  role: 'SUPPORTER',
  email: 'dev@protocare.kr',
};

const mockAccessToken = makeFakeJwt(MOCK_CLAIMS);
const mockRefreshToken = 'mock-refresh-token-dev';

// MSW v2: 크로스 오리진 URL은 glob 패턴이 매칭 안 됨 → 정규식 사용
export const authHandlers = [
  http.post(/\/auth\/supporter\/login$/, async () => {
    await delay(400);
    return HttpResponse.json({
      success: true,
      data: { accessToken: mockAccessToken, refreshToken: mockRefreshToken },
      message: null,
    });
  }),

  http.post(/\/auth\/supporter\/reissue$/, async () => {
    await delay(200);
    return HttpResponse.json({
      success: true,
      data: { accessToken: makeFakeJwt(MOCK_CLAIMS), refreshToken: mockRefreshToken },
      message: null,
    });
  }),

  http.post(/\/auth\/supporter\/signup$/, async () => {
    await delay(600);
    return HttpResponse.json({ success: true, data: null, message: null }, { status: 201 });
  }),

  http.post(/\/auth\/supporter\/oauth\/.+\/login$/, async () => {
    await delay(500);
    return HttpResponse.json({
      success: true,
      data: { accessToken: mockAccessToken, refreshToken: mockRefreshToken },
      message: null,
    });
  }),

  http.post(/\/mobile-auth\/send$/, async () => {
    await delay(300);
    return HttpResponse.json({ success: true, data: null, message: null });
  }),

  http.post(/\/mobile-auth\/verify$/, async () => {
    await delay(300);
    return HttpResponse.json({
      success: true,
      data: { verifiedToken: 'mock-verified-token-dev' },
      message: null,
    });
  }),

  http.post(/\/mobile-auth\/danal\/pre-register$/, async () => {
    await delay(300);
    return HttpResponse.json({
      success: true,
      data: { identityVerificationId: 'mock-danal-verification-id' },
      message: null,
    });
  }),

  http.post(/\/mobile-auth\/danal\/verify$/, async () => {
    await delay(400);
    return HttpResponse.json({
      success: true,
      data: { verifiedToken: 'mock-danal-verified-token' },
      message: null,
    });
  }),

  http.post(/\/auth\/supporter\/find-id$/, async () => {
    await delay(400);
    return HttpResponse.json({ success: true, data: null, message: null });
  }),

  http.post(/\/auth\/supporter\/find-password$/, async () => {
    await delay(400);
    return HttpResponse.json({ success: true, data: null, message: null });
  }),

  http.post(/\/auth\/supporter\/reset-password$/, async () => {
    await delay(400);
    return HttpResponse.json({
      success: true,
      data: { accessToken: mockAccessToken, refreshToken: mockRefreshToken },
      message: null,
    });
  }),

  http.post(/\/auth\/logout$/, async () => {
    await delay(200);
    return HttpResponse.json({ success: true, data: null, message: null });
  }),
];
