import { http, HttpResponse, delay } from 'msw';

const MOCK_POSTS = [
  {
    id: 1,
    title: '처음 병원동행 서포터로 활동하는데 팁 좀 부탁드려요',
    content:
      '이번 달부터 병원동행 서포터 활동을 시작했는데, 선배 서포터분들의 경험담이 궁금합니다.',
    isAnonymous: true,
    viewCount: 142,
    status: 'NORMAL',
    createdAt: '2026-04-20T10:00:00.000Z',
    updatedAt: null,
    createdBy: 3,
    updatedBy: null,
  },
  {
    id: 2,
    title: '정산 계좌 등록 방법 문의',
    content: '앱에서 정산 계좌를 어디서 등록하나요? 메뉴를 못 찾겠어요.',
    isAnonymous: false,
    viewCount: 87,
    status: 'NORMAL',
    createdAt: '2026-04-22T15:30:00.000Z',
    updatedAt: null,
    createdBy: 4,
    updatedBy: null,
  },
];

const MOCK_COMMENTS = [
  {
    id: 1,
    postId: 1,
    userId: 1,
    parentId: null,
    content: '저도 처음엔 많이 긴장했어요. 미리 병원 동선을 파악해두는 게 도움이 많이 됩니다!',
    status: 'NORMAL',
    createdAt: '2026-04-20T11:00:00.000Z',
    updatedAt: null,
    createdBy: 1,
    updatedBy: null,
  },
];

export const communityHandlers = [
  http.get('*/community/posts', async () => {
    await delay(300);
    return HttpResponse.json({
      success: true,
      data: {
        content: MOCK_POSTS,
        totalElements: 2,
        totalPages: 1,
        page: 0,
        size: 20,
        hasNext: false,
      },
      message: null,
    });
  }),

  http.get('*/community/posts/:id', async ({ params }) => {
    await delay(200);
    const found = MOCK_POSTS.find((p) => p.id === Number(params['id']));
    if (!found) {
      return HttpResponse.json(
        { success: false, data: null, message: '게시글을 찾을 수 없습니다.' },
        { status: 404 },
      );
    }
    return HttpResponse.json({ success: true, data: found, message: null });
  }),

  http.post('*/community/posts', async () => {
    await delay(400);
    return HttpResponse.json(
      { success: true, data: { ...MOCK_POSTS[0], id: 99 }, message: null },
      { status: 201 },
    );
  }),

  http.get('*/community/posts/:id/comments', async () => {
    await delay(200);
    return HttpResponse.json({ success: true, data: MOCK_COMMENTS, message: null });
  }),

  http.post('*/community/posts/:id/comments', async () => {
    await delay(300);
    return HttpResponse.json(
      { success: true, data: { ...MOCK_COMMENTS[0], id: 99 }, message: null },
      { status: 201 },
    );
  }),
];
