import { http, HttpResponse, delay } from 'msw';

const MOCK_MATCHINGS = [
  {
    id: 1,
    careRequestId: 1,
    supporterId: 1,
    status: 'MATCHED',
    matchedAt: '2026-05-05T14:00:00.000Z',
    startedAt: null,
    completedAt: null,
    cancelledAt: null,
    cancelReason: null,
    totalAmount: 45000,
    createdAt: '2026-05-05T14:00:00.000Z',
    updatedAt: null,
    createdBy: 2,
    updatedBy: null,
  },
  {
    id: 2,
    careRequestId: 2,
    supporterId: 1,
    status: 'IN_PROGRESS',
    matchedAt: '2026-05-08T10:00:00.000Z',
    startedAt: '2026-05-12T09:00:00.000Z',
    completedAt: null,
    cancelledAt: null,
    cancelReason: null,
    totalAmount: 80000,
    createdAt: '2026-05-08T10:00:00.000Z',
    updatedAt: null,
    createdBy: 3,
    updatedBy: null,
  },
];

const MOCK_SCHEDULES = [
  {
    id: 1,
    matchingId: 1,
    supporterId: 1,
    careRequestId: 1,
    scheduledDate: '2026-05-10',
    startTime: '10:00',
    endTime: '13:00',
    status: 'SCHEDULED',
    isAuto: true,
    createdAt: '2026-05-05T14:00:00.000Z',
    updatedAt: null,
    createdBy: 1,
    updatedBy: null,
  },
];

const MOCK_CARE_LOGS = [
  {
    id: 1,
    matchingId: 2,
    supporterId: 1,
    type: 'MEAL',
    content: '점심 식사 완료. 죽 반 그릇 드심.',
    mediaUrls: [],
    recordedAt: '2026-05-12T12:30:00.000Z',
    createdAt: '2026-05-12T12:35:00.000Z',
    updatedAt: null,
    createdBy: 1,
    updatedBy: null,
  },
];

export const matchingHandlers = [
  http.get('*/matchings', async () => {
    await delay(300);
    return HttpResponse.json({
      success: true,
      data: {
        content: MOCK_MATCHINGS,
        totalElements: 2,
        totalPages: 1,
        page: 0,
        size: 20,
        hasNext: false,
      },
      message: null,
    });
  }),

  http.get('*/matchings/:id', async ({ params }) => {
    await delay(200);
    const found = MOCK_MATCHINGS.find((m) => m.id === Number(params['id']));
    if (!found) {
      return HttpResponse.json(
        { success: false, data: null, message: '매칭을 찾을 수 없습니다.' },
        { status: 404 },
      );
    }
    return HttpResponse.json({ success: true, data: found, message: null });
  }),

  http.get('*/matchings/:id/schedules', async () => {
    await delay(200);
    return HttpResponse.json({ success: true, data: MOCK_SCHEDULES, message: null });
  }),

  http.get('*/matchings/:id/logs', async () => {
    await delay(200);
    return HttpResponse.json({
      success: true,
      data: {
        content: MOCK_CARE_LOGS,
        totalElements: 1,
        totalPages: 1,
        page: 0,
        size: 20,
        hasNext: false,
      },
      message: null,
    });
  }),

  http.post('*/matchings/:id/logs', async () => {
    await delay(400);
    return HttpResponse.json(
      { success: true, data: { ...MOCK_CARE_LOGS[0], id: 99 }, message: null },
      { status: 201 },
    );
  }),

  http.patch('*/matchings/:id/start', async ({ params }) => {
    await delay(300);
    const found = MOCK_MATCHINGS.find((m) => m.id === Number(params['id']));
    return HttpResponse.json({
      success: true,
      data: { ...found, status: 'IN_PROGRESS', startedAt: new Date().toISOString() },
      message: null,
    });
  }),

  http.patch('*/matchings/:id/complete', async ({ params }) => {
    await delay(300);
    const found = MOCK_MATCHINGS.find((m) => m.id === Number(params['id']));
    return HttpResponse.json({
      success: true,
      data: { ...found, status: 'COMPLETED', completedAt: new Date().toISOString() },
      message: null,
    });
  }),
];
