import { http, HttpResponse, delay } from 'msw';

const wrap = <T>(data: T) => ({
  success: true,
  code: '200',
  message: null,
  data,
  fieldErrors: [],
  timestamp: new Date().toISOString(),
});

const MOCK_TERMS = {
  privacyPolicyAgreed: false,
  privacyPolicyRespondedAt: null,
  patientDataAgreed: false,
  patientDataRespondedAt: null,
  marketingAgreed: null,
  marketingRespondedAt: null,
  profilePromotionAgreed: null,
  profilePromotionRespondedAt: null,
};

const MOCK_BASIC_INFO = {
  name: null,
  birthDate: null,
  gender: null,
  genderDisplayName: null,
  activitySigu: null,
  activityDong: null,
  intro: null,
  profileImageUrl: null,
  complete: false,
};

const MOCK_CARE_TYPE = {
  1: [
    {
      tagCategory: 'CARE_EXPERIENCE',
      orderNumber: 1,
      tagCode: 'EXPERIENCE_HOSPITAL',
      tagName: '병원 동행 경험',
    },
    {
      tagCategory: 'CARE_EXPERIENCE',
      orderNumber: 2,
      tagCode: 'EXPERIENCE_SENIOR',
      tagName: '어르신 돌봄 경험',
    },
    {
      tagCategory: 'CARE_EXPERIENCE',
      orderNumber: 3,
      tagCode: 'EXPERIENCE_CHILD',
      tagName: '아이 돌봄 경험',
    },
    {
      tagCategory: 'CARE_EXPERIENCE',
      orderNumber: 4,
      tagCode: 'EXPERIENCE_FAMILY',
      tagName: '가족 돌봄 경험',
    },
    {
      tagCategory: 'CARE_EXPERIENCE',
      orderNumber: 5,
      tagCode: 'EXPERIENCE_PROFESSIONAL',
      tagName: '전문 돌봄 자격 보유',
    },
    {
      tagCategory: 'CARE_EXPERIENCE',
      orderNumber: 6,
      tagCode: 'EXPERIENCE_NONE',
      tagName: '경험 없음',
    },
  ],
  2: [
    {
      tagCategory: 'CARE_STYLE',
      orderNumber: 1,
      tagCode: 'STYLE_CALM',
      tagName: '차분하고 침착해요',
    },
    {
      tagCategory: 'CARE_STYLE',
      orderNumber: 2,
      tagCode: 'STYLE_BRIGHT',
      tagName: '밝고 에너지 넘쳐요',
    },
    {
      tagCategory: 'CARE_STYLE',
      orderNumber: 3,
      tagCode: 'STYLE_TALKATIVE',
      tagName: '대화를 즐겨요',
    },
    {
      tagCategory: 'CARE_STYLE',
      orderNumber: 4,
      tagCode: 'STYLE_QUIET',
      tagName: '조용하고 안정적이에요',
    },
    {
      tagCategory: 'CARE_STYLE',
      orderNumber: 5,
      tagCode: 'STYLE_DETAIL',
      tagName: '세심하고 꼼꼼해요',
    },
  ],
  3: [
    {
      tagCategory: 'PREFERRED_ACTIVITY',
      orderNumber: 1,
      tagCode: 'ACTIVITY_HOSPITAL',
      tagName: '병원 동행',
    },
    {
      tagCategory: 'PREFERRED_ACTIVITY',
      orderNumber: 2,
      tagCode: 'ACTIVITY_SENIOR',
      tagName: '어르신 돌봄',
    },
    {
      tagCategory: 'PREFERRED_ACTIVITY',
      orderNumber: 3,
      tagCode: 'ACTIVITY_CHILD',
      tagName: '아이 돌봄',
    },
  ],
  4: [
    {
      tagCategory: 'SPECIAL_CONDITION',
      orderNumber: 1,
      tagCode: 'CONDITION_EMERGENCY',
      tagName: '응급 상황 대응',
    },
    {
      tagCategory: 'SPECIAL_CONDITION',
      orderNumber: 2,
      tagCode: 'CONDITION_NIGHT',
      tagName: '야간 활동',
    },
    {
      tagCategory: 'SPECIAL_CONDITION',
      orderNumber: 3,
      tagCode: 'CONDITION_LONG_DISTANCE',
      tagName: '장거리 이동',
    },
    {
      tagCategory: 'SPECIAL_CONDITION',
      orderNumber: 4,
      tagCode: 'CONDITION_LONG_TERM',
      tagName: '장기 케어',
    },
    {
      tagCategory: 'SPECIAL_CONDITION',
      orderNumber: 5,
      tagCode: 'CONDITION_SIGN_LANGUAGE',
      tagName: '수어 가능',
    },
  ],
};

const MOCK_QUALIFICATIONS = {
  certifications: [],
  criminalRecord: null,
  complete: false,
};

const MOCK_OVERVIEW = {
  applicationId: 1,
  status: 'DRAFT',
  statusDisplayName: '작성 중',
  step1Completed: false,
  step2Completed: false,
  step3Completed: false,
  step4Completed: false,
  submittable: false,
  submittedAt: null,
  rejectedReason: null,
  terms: MOCK_TERMS,
  basicInfo: MOCK_BASIC_INFO,
  qualifications: MOCK_QUALIFICATIONS,
};

export const supporterApplicationHandlers = [
  // ── Overview ──────────────────────────────────────────────────
  http.get(/\/supporter-applications\/me$/, async () => {
    await delay(400);
    return HttpResponse.json(wrap(MOCK_OVERVIEW));
  }),

  // ── Init ──────────────────────────────────────────────────────
  http.post(/\/supporter-applications\/me\/init$/, async () => {
    await delay(300);
    return HttpResponse.json(wrap({ applicationId: 1, created: true, status: 'DRAFT' }));
  }),

  // ── Terms (Step 1) ────────────────────────────────────────────
  http.get(/\/supporter-applications\/me\/terms$/, async () => {
    await delay(300);
    return HttpResponse.json(wrap(MOCK_TERMS));
  }),

  http.post(/\/supporter-applications\/me\/terms$/, async ({ request }) => {
    await delay(400);
    const body = (await request.json()) as Record<string, unknown>;
    const now = new Date().toISOString();
    return HttpResponse.json(
      wrap({
        privacyPolicyAgreed: body['privacyPolicyAgreed'] ?? false,
        privacyPolicyRespondedAt: now,
        patientDataAgreed: body['patientDataAgreed'] ?? false,
        patientDataRespondedAt: now,
        marketingAgreed: body['marketingAgreed'] ?? null,
        marketingRespondedAt: body['marketingAgreed'] != null ? now : null,
        profilePromotionAgreed: body['profilePromotionAgreed'] ?? null,
        profilePromotionRespondedAt: body['profilePromotionAgreed'] != null ? now : null,
      }),
    );
  }),

  // ── Basic Info (Step 2) ───────────────────────────────────────
  http.get(/\/supporter-applications\/me\/basic-info$/, async () => {
    await delay(300);
    return HttpResponse.json(wrap(MOCK_BASIC_INFO));
  }),

  http.patch(/\/supporter-applications\/me\/basic-info$/, async ({ request }) => {
    await delay(400);
    const body = (await request.json()) as Record<string, unknown>;
    const updated = { ...MOCK_BASIC_INFO, ...body };
    const complete = !!(
      updated.name &&
      updated.birthDate &&
      updated.gender &&
      updated.activitySigu &&
      updated.activityDong
    );
    return HttpResponse.json(wrap({ ...updated, complete }));
  }),

  http.post(/\/supporter-applications\/me\/basic-info\/profile-image$/, async () => {
    await delay(600);
    return HttpResponse.json(
      wrap({ ...MOCK_BASIC_INFO, profileImageUrl: 'https://example.com/profile/mock.jpg' }),
    );
  }),

  // ── Care Type (Step 3) ────────────────────────────────────────
  http.get(/\/supporter-applications\/me\/care-type$/, async () => {
    await delay(300);
    return HttpResponse.json(wrap(MOCK_CARE_TYPE));
  }),

  http.put(/\/supporter-applications\/me\/care-type$/, async () => {
    await delay(400);
    return HttpResponse.json(wrap(MOCK_CARE_TYPE));
  }),

  // ── Qualifications (Step 4) ───────────────────────────────────
  http.get(/\/supporter-applications\/me\/qualifications$/, async () => {
    await delay(300);
    return HttpResponse.json(wrap(MOCK_QUALIFICATIONS));
  }),

  http.post(/\/supporter-applications\/me\/qualifications\/certifications$/, async () => {
    await delay(600);
    return HttpResponse.json(
      wrap({
        certifications: [
          {
            id: 99,
            certificationType: 'CARE_WORKER',
            certificationTypeDisplayName: '요양보호사',
            status: 'PENDING',
            fileUrl: 'https://example.com/cert/mock.pdf',
          },
        ],
        criminalRecord: null,
        complete: false,
      }),
      { status: 201 },
    );
  }),

  http.post(/\/supporter-applications\/me\/qualifications\/criminal-record$/, async () => {
    await delay(600);
    return HttpResponse.json(
      wrap({
        certifications: [],
        criminalRecord: {
          id: 1,
          status: 'PENDING',
          sexCrimeConsentAgreed: true,
          fileUrl: 'https://example.com/criminal/mock.pdf',
        },
        complete: false,
      }),
      { status: 201 },
    );
  }),

  // ── Submit ────────────────────────────────────────────────────
  http.post(/\/supporter-applications\/me\/submit$/, async () => {
    await delay(600);
    return HttpResponse.json(
      wrap({
        ...MOCK_OVERVIEW,
        status: 'SUBMITTED',
        statusDisplayName: '심사 대기',
        step1Completed: true,
        step2Completed: true,
        step3Completed: true,
        step4Completed: true,
        submittable: false,
        submittedAt: new Date().toISOString(),
      }),
    );
  }),
];
