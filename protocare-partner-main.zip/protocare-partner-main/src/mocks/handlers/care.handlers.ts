import { http, HttpResponse, delay } from 'msw';

const MOCK_CARE_REQUESTS = [
  {
    id: 1,
    type: 'HOSPITAL',
    addRequest: '휠체어 지참 부탁드립니다.',
    startAt: '2026-05-10T10:00:00.000Z',
    endAt: '2026-05-10T13:00:00.000Z',
    from: '서울 마포구 서교동',
    to: '연세세브란스병원',
    createdAt: '2026-05-01T00:00:00.000Z',
    updatedAt: null,
    createdBy: 2,
    updatedBy: null,
  },
  {
    id: 2,
    type: 'ELDERLY',
    addRequest: null,
    startAt: '2026-05-12T09:00:00.000Z',
    endAt: '2026-05-12T18:00:00.000Z',
    from: null,
    to: null,
    createdAt: '2026-05-02T00:00:00.000Z',
    updatedAt: null,
    createdBy: 3,
    updatedBy: null,
  },
];

const MOCK_CARE_APPLICATIONS = [
  {
    id: 1,
    careRequestId: 1,
    supporterId: 1,
    status: 'PENDING',
    message: '성심껏 도와드리겠습니다.',
    appliedAt: '2026-05-03T10:00:00.000Z',
    acceptedAt: null,
    rejectedAt: null,
    rejectedReason: null,
    createdAt: '2026-05-03T10:00:00.000Z',
    updatedAt: null,
    createdBy: 1,
    updatedBy: null,
  },
];

export const careHandlers = [
  http.get('*/care-requests', async () => {
    await delay(300);
    return HttpResponse.json({
      success: true,
      data: {
        content: MOCK_CARE_REQUESTS,
        totalElements: 2,
        totalPages: 1,
        page: 0,
        size: 20,
        hasNext: false,
      },
      message: null,
    });
  }),

  http.get('*/care-requests/:id', async ({ params }) => {
    await delay(200);
    const found = MOCK_CARE_REQUESTS.find((r) => r.id === Number(params['id']));
    if (!found) {
      return HttpResponse.json(
        { success: false, data: null, message: '케어요청을 찾을 수 없습니다.' },
        { status: 404 },
      );
    }
    return HttpResponse.json({ success: true, data: found, message: null });
  }),

  http.post('*/care-requests', async () => {
    await delay(400);
    return HttpResponse.json(
      { success: true, data: { ...MOCK_CARE_REQUESTS[0], id: 99 }, message: null },
      { status: 201 },
    );
  }),

  http.get('*/care-applications', async () => {
    await delay(300);
    return HttpResponse.json({
      success: true,
      data: {
        content: MOCK_CARE_APPLICATIONS,
        totalElements: 1,
        totalPages: 1,
        page: 0,
        size: 20,
        hasNext: false,
      },
      message: null,
    });
  }),

  http.post('*/care-requests/:id/apply', async () => {
    await delay(400);
    return HttpResponse.json(
      { success: true, data: { ...MOCK_CARE_APPLICATIONS[0], id: 99 }, message: null },
      { status: 201 },
    );
  }),

  http.patch('*/care-applications/:id/cancel', async () => {
    await delay(300);
    return HttpResponse.json({
      success: true,
      data: { ...MOCK_CARE_APPLICATIONS[0], status: 'CANCELLED' },
      message: null,
    });
  }),
];
