import { authHandlers } from './auth.handlers';
import { careHandlers } from './care.handlers';
import { matchingHandlers } from './matching.handlers';
import { supporterHandlers } from './supporter.handlers';
import { supporterApplicationHandlers } from './supporterApplication.handlers';
import { communityHandlers } from './community.handlers';

export const handlers = [
  ...authHandlers,
  ...supporterApplicationHandlers,
  ...careHandlers,
  ...matchingHandlers,
  ...supporterHandlers,
  ...communityHandlers,
];
