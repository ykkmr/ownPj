// src/mocks/handlers.ts
import { http, HttpResponse } from 'msw';
export const handlers = [
  http.get('/api/care-requests', () => {
    return HttpResponse.json([/* ... */]);
  }),];