import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';
import { formatRelativeDate, formatDuration, formatElapsedBetween, isExpired } from './date';

// KST = UTC+9
const KST = (y: number, M: number, d: number, h = 0, m = 0) =>
  new Date(Date.UTC(y, M - 1, d, h - 9, m)).toISOString();

describe('formatRelativeDate', () => {
  beforeEach(() => {
    vi.useFakeTimers();
    vi.setSystemTime(new Date(KST(2025, 4, 30, 12, 0)));
  });
  afterEach(() => vi.useRealTimers());

  it('오늘 날짜는 "오늘" 반환', () => {
    expect(formatRelativeDate(KST(2025, 4, 30, 9, 0))).toBe('오늘');
  });

  it('다른 날짜는 "M월 D일" 반환', () => {
    expect(formatRelativeDate(KST(2025, 4, 29, 9, 0))).toBe('4월 29일');
  });

  it('유효하지 않은 문자열은 "-" 반환', () => {
    expect(formatRelativeDate('not-a-date')).toBe('-');
  });
});

describe('formatDuration', () => {
  it('일반 케이스: 1시간 30분', () => {
    expect(formatDuration('09:00', '10:30')).toBe('1시간 30분');
  });

  it('정각: 2시간', () => {
    expect(formatDuration('08:00', '10:00')).toBe('2시간');
  });

  it('1시간 미만: 30분', () => {
    expect(formatDuration('09:00', '09:30')).toBe('30분');
  });

  it('자정 크로싱: 23:00 → 01:00 = 2시간', () => {
    expect(formatDuration('23:00', '01:00')).toBe('2시간');
  });

  it('동일 시간: 0분', () => {
    expect(formatDuration('09:00', '09:00')).toBe('0분');
  });
});

describe('formatElapsedBetween', () => {
  it('1시간 30분 경과', () => {
    expect(formatElapsedBetween('2025-04-29T09:00:00Z', '2025-04-29T10:30:00Z')).toBe('1시간 30분');
  });

  it('종료가 시작보다 이전이면 "-" 반환', () => {
    expect(formatElapsedBetween('2025-04-29T10:00:00Z', '2025-04-29T09:00:00Z')).toBe('-');
  });

  it('유효하지 않은 ISO 문자열이면 "-" 반환', () => {
    expect(formatElapsedBetween('bad', '2025-04-29T10:00:00Z')).toBe('-');
  });

  it('정확히 0분이면 "0분" 반환', () => {
    expect(formatElapsedBetween('2025-04-29T09:00:00Z', '2025-04-29T09:00:00Z')).toBe('0분');
  });
});

describe('isExpired', () => {
  beforeEach(() => {
    vi.useFakeTimers();
    vi.setSystemTime(new Date('2025-04-30T12:00:00Z'));
  });
  afterEach(() => vi.useRealTimers());

  it('과거 시각은 true', () => {
    expect(isExpired('2025-04-30T11:00:00Z')).toBe(true);
  });

  it('미래 시각은 false', () => {
    expect(isExpired('2025-04-30T13:00:00Z')).toBe(false);
  });

  it('유효하지 않은 문자열은 true(만료 처리)', () => {
    expect(isExpired('bad')).toBe(true);
  });
});
