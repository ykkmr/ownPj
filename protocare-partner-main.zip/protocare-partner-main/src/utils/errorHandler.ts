import { AppError, NetworkError } from '@/services/api/errors';

export const getErrorMessage = (error: unknown, fallback: string): string => {
  if (error instanceof NetworkError) return '네트워크 연결을 확인해주세요.';
  if (error instanceof AppError) return error.message;
  return fallback;
};
