/**
 * 의료 도메인 특화 날짜/시간 유틸.
 * 모든 함수는 순수 함수 — 외부 상태에 의존하지 않음.
 */

const KST_OFFSET_MS = 9 * 60 * 60 * 1000;

const toKstMidnight = (date: Date): number => {
  const kst = new Date(date.getTime() + KST_OFFSET_MS);
  return Date.UTC(kst.getUTCFullYear(), kst.getUTCMonth(), kst.getUTCDate());
};

/**
 * 오늘이면 "오늘", 아니면 "M월 D일" 반환.
 * @param isoString ISO 8601 날짜 문자열 (예: "2025-04-29T10:00:00Z")
 */
export const formatRelativeDate = (isoString: string): string => {
  const date = new Date(isoString);
  if (isNaN(date.getTime())) return '-';

  const todayMidnight = toKstMidnight(new Date());
  const targetMidnight = toKstMidnight(date);

  if (targetMidnight === todayMidnight) return '오늘';

  const kst = new Date(date.getTime() + KST_OFFSET_MS);
  const month = kst.getUTCMonth() + 1;
  const day = kst.getUTCDate();
  return `${month}월 ${day}일`;
};

const formatMinutes = (total: number): string => {
  if (total === 0) return '0분';
  const h = Math.floor(total / 60);
  const m = total % 60;
  if (h === 0) return `${m}분`;
  if (m === 0) return `${h}시간`;
  return `${h}시간 ${m}분`;
};

/**
 * "HH:mm" 형식의 두 시각으로 소요 시간 문자열 반환.
 * CareSchedule.startTime / endTime 전용.
 * @example formatDuration("09:00", "10:30") → "1시간 30분"
 */
export const formatDuration = (startTime: string, endTime: string): string => {
  const [startH = 0, startM = 0] = startTime.split(':').map(Number);
  const [endH = 0, endM = 0] = endTime.split(':').map(Number);

  let totalMinutes = endH * 60 + endM - (startH * 60 + startM);
  // 자정을 넘어가는 스케줄 처리 (예: 23:00 → 01:00 다음날)
  if (totalMinutes < 0) totalMinutes += 24 * 60;

  return formatMinutes(totalMinutes);
};

/**
 * ISO 문자열로 표현된 두 시각의 소요 시간 반환.
 * Matching.startedAt / completedAt 전용.
 * @example formatElapsedBetween("2025-04-29T09:00:00Z", "2025-04-29T10:30:00Z") → "1시간 30분"
 */
export const formatElapsedBetween = (startIso: string, endIso: string): string => {
  const start = new Date(startIso);
  const end = new Date(endIso);
  if (isNaN(start.getTime()) || isNaN(end.getTime())) return '-';

  const totalMinutes = Math.floor((end.getTime() - start.getTime()) / 60_000);
  if (totalMinutes < 0) return '-';

  return formatMinutes(totalMinutes);
};

/**
 * ISO 문자열이 현재 시각보다 과거인지 확인.
 * 예약 만료, 인증 토큰 만료 등 판단에 사용.
 */
export const isExpired = (isoString: string): boolean => {
  const date = new Date(isoString);
  if (isNaN(date.getTime())) return true;
  return date.getTime() < Date.now();
};
