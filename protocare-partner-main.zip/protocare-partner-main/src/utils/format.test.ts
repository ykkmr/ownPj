import { describe, it, expect } from 'vitest';
import { formatCurrency, formatPhone } from './format';

describe('formatCurrency', () => {
  it('숫자를 한국 통화 형식으로 변환', () => {
    expect(formatCurrency(150000)).toBe('150,000원');
  });

  it('0원 처리', () => {
    expect(formatCurrency(0)).toBe('0원');
  });

  it('1억 이상도 처리', () => {
    expect(formatCurrency(100000000)).toBe('100,000,000원');
  });
});

describe('formatPhone', () => {
  it('11자리 휴대폰: 010-XXXX-XXXX', () => {
    expect(formatPhone('01012345678')).toBe('010-1234-5678');
  });

  it('10자리 일반 전화: 02-XXXX-XXXX', () => {
    expect(formatPhone('0212345678')).toBe('02-1234-5678');
  });

  it('하이픈 포함 입력도 정규화', () => {
    expect(formatPhone('010-1234-5678')).toBe('010-1234-5678');
  });

  it('그 외 자릿수는 원본 반환', () => {
    expect(formatPhone('123')).toBe('123');
  });
});
