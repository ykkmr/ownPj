/**
 * 금융 및 개인정보 표시 포맷 유틸.
 * mask.ts와 달리 원본 값을 그대로 표시 형식으로 변환 (숨김 없음).
 */

const KRW_FORMATTER = new Intl.NumberFormat('ko-KR');

/**
 * 숫자를 한국 통화 표기로 변환.
 * @example formatCurrency(150000) → "150,000원"
 */
export const formatCurrency = (amount: number): string => `${KRW_FORMATTER.format(amount)}원`;

/**
 * 숫자 전화번호 문자열을 하이픈 구분 형식으로 변환.
 * 11자리(010): 010-XXXX-XXXX
 * 10자리(02 등): 02-XXXX-XXXX
 * 그 외: 원본 반환.
 * @example formatPhone("01012345678") → "010-1234-5678"
 */
export const formatPhone = (phone: string): string => {
  const digits = phone.replace(/\D/g, '');

  if (digits.length === 11) {
    return `${digits.slice(0, 3)}-${digits.slice(3, 7)}-${digits.slice(7)}`;
  }
  if (digits.length === 10) {
    return `${digits.slice(0, 2)}-${digits.slice(2, 6)}-${digits.slice(6)}`;
  }

  return phone;
};
