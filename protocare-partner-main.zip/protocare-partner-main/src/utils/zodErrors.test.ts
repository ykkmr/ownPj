import { describe, it, expect } from 'vitest';
import { z, ZodError } from 'zod';
import { getZodErrors, ZOD_ROOT_KEY } from './zodErrors';

const LoginSchema = z.object({
  email: z.string().email('이메일 형식이 아닙니다'),
  password: z.string().min(8, '8자 이상 입력해주세요'),
});

type LoginForm = z.infer<typeof LoginSchema>;

const parseErrors = (data: unknown) => {
  const result = LoginSchema.safeParse(data);
  if (result.success) throw new Error('validation should fail');
  return getZodErrors<LoginForm>(result.error);
};

describe('getZodErrors', () => {
  it('각 필드의 첫 번째 에러 메시지를 반환', () => {
    const errors = parseErrors({ email: 'not-email', password: 'short' });
    expect(errors.email).toBe('이메일 형식이 아닙니다');
    expect(errors.password).toBe('8자 이상 입력해주세요');
  });

  it('유효한 필드는 결과에 포함되지 않음', () => {
    const errors = parseErrors({ email: 'valid@email.com', password: 'short' });
    expect(errors.email).toBeUndefined();
    expect(errors.password).toBe('8자 이상 입력해주세요');
  });

  it('필드당 첫 번째 에러만 수집 (중복 없음)', () => {
    const MultiSchema = z.object({
      value: z.string().min(1, '필수입니다').max(3, '3자 이하'),
    });
    const result = MultiSchema.safeParse({ value: '' });
    if (result.success) throw new Error('should fail');
    const errors = getZodErrors(result.error);
    expect(Object.keys(errors).filter((k) => k === 'value')).toHaveLength(1);
  });

  it('루트 레벨 refine 에러는 _root 키로 수집', () => {
    const ConfirmSchema = z
      .object({ password: z.string(), confirm: z.string() })
      .refine((v) => v.password === v.confirm, '비밀번호가 일치하지 않습니다');

    const result = ConfirmSchema.safeParse({ password: 'abc', confirm: 'xyz' });
    if (result.success) throw new Error('should fail');
    const errors = getZodErrors(result.error);
    expect(errors[ZOD_ROOT_KEY]).toBe('비밀번호가 일치하지 않습니다');
  });

  it('에러가 없는 ZodError(빈 issues)이면 빈 객체 반환', () => {
    // Zod v4: ZodError는 타입 파라미터 없이 생성
    const emptyError = new ZodError([]) as ZodError<LoginForm>;
    const errors = getZodErrors<LoginForm>(emptyError);
    expect(errors).toEqual({});
  });
});
