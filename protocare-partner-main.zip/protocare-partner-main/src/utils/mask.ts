/**
 * 개인정보 (민감정보) 마스킹 유틸.
 * UI에서 민감 데이터 원본을 직접 노출하지 않도록 공통 처리.
 */

/** 홍길동 → 홍*동, 2자면 이* */
export const maskName = (name: string): string => {
  if (!name) return '';
  const chars = Array.from(name.trim());
  if (chars.length <= 1) return name.trim();
  if (chars.length === 2) return `${chars[0] ?? ''}*`;
  const first = chars[0] ?? '';
  const last = chars[chars.length - 1] ?? '';
  return `${first}${'*'.repeat(chars.length - 2)}${last}`;
};

/** 01012345678 → 010-****-5678 */
export const maskPhone = (phone: string): string => {
  if (!phone) return '';
  const digits = phone.replace(/\D/g, '');
  if (digits.length < 8) return '***';
  const head = digits.slice(0, 3);
  const tail = digits.slice(-4);
  return `${head}-****-${tail}`;
};

/** 901225-1234567 → 901225-******* */
export const maskSsn = (ssn: string): string => {
  if (!ssn) return '';
  const clean = ssn.replace(/[-\s]/g, '');
  if (clean.length < 6) return '***';
  return `${clean.slice(0, 6)}-*******`;
};

/** 1990-03-15 → 1990-**-** */
export const maskBirthDate = (date: string): string => {
  if (!date) return '';
  const year = date.split('-')[0] ?? '****';
  return `${year}-**-**`;
};

/** P-2024-001234 → P-2024-****** */
export const maskPatientNumber = (num: string): string => {
  if (!num) return '';
  if (num.length <= 6) return '****';
  return `${num.slice(0, 6)}${'*'.repeat(num.length - 6)}`;
};
