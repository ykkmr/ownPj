import type { ZodError } from 'zod';

/** .refine() 등 루트 레벨 검증 실패 메시지를 담는 예약 키 */
export const ZOD_ROOT_KEY = '_root' as const;

type ZodErrorRecord<T> = Partial<Record<keyof T | typeof ZOD_ROOT_KEY, string>>;

/**
 * ZodError의 첫 번째 에러 메시지를 Input error prop 형태의 Record로 변환.
 * 루트 레벨 refine 에러(path=[])는 '_root' 키로 수집.
 *
 * 사용 예:
 *   const errors = getZodErrors<LoginFormValues>(zodError);
 *   <Input error={errors.email} />
 *   {errors._root && <p className="text-red-500">{errors._root}</p>}
 */
export const getZodErrors = <T extends Record<string, unknown>>(
  error: ZodError<T>,
): ZodErrorRecord<T> => {
  const result: ZodErrorRecord<T> = {};

  for (const issue of error.issues) {
    const key = issue.path[0] as keyof T | undefined;

    if (key === undefined) {
      if (result[ZOD_ROOT_KEY] === undefined) {
        result[ZOD_ROOT_KEY] = issue.message;
      }
    } else if (result[key] === undefined) {
      result[key] = issue.message;
    }
  }

  return result;
};
