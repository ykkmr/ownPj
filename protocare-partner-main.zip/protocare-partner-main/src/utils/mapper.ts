import type { MatchingStatus, CareApplicationStatus, CareRequestType } from '@/types/care';
import type { SupporterStatus } from '@/types/supporter';
import type { UserRole } from '@/types/auth';

type BadgeVariant = 'primary' | 'success' | 'warning' | 'danger' | 'info' | 'default';

interface StatusMeta {
  label: string;
  variant: BadgeVariant;
}

interface RoleMeta {
  label: string;
  icon: string;
}

// ── MatchingStatus ────────────────────────────────────────────
export const MATCHING_STATUS: Record<MatchingStatus, StatusMeta> = {
  PENDING: { label: '대기중', variant: 'default' },
  MATCHED: { label: '매칭완료', variant: 'primary' },
  IN_PROGRESS: { label: '진행중', variant: 'info' },
  COMPLETED: { label: '완료', variant: 'success' },
  CANCELLED: { label: '취소', variant: 'danger' },
};

// ── CareApplicationStatus ─────────────────────────────────────
export const APPLICATION_STATUS: Record<CareApplicationStatus, StatusMeta> = {
  PENDING: { label: '검토 대기', variant: 'default' },
  IN_REVIEW: { label: '검토중', variant: 'info' },
  ACCEPTED: { label: '수락됨', variant: 'success' },
  REJECTED: { label: '거절됨', variant: 'danger' },
  CANCELLED: { label: '취소됨', variant: 'warning' },
};

// ── CareRequestType ───────────────────────────────────────────
export const CARE_REQUEST_TYPE: Record<CareRequestType, StatusMeta> = {
  HOSPITAL: { label: '병원 동행', variant: 'primary' },
  ELDERLY: { label: '노인 돌봄', variant: 'info' },
  CHILD: { label: '아동 돌봄', variant: 'success' },
};

// ── SupporterStatus ───────────────────────────────────────────
export const SUPPORTER_STATUS: Record<SupporterStatus, StatusMeta> = {
  PENDING: { label: '심사중', variant: 'warning' },
  APPROVED: { label: '승인됨', variant: 'success' },
  REJECTED: { label: '거절됨', variant: 'danger' },
};

// ── UserRole ──────────────────────────────────────────────────
export const USER_ROLE: Record<UserRole, RoleMeta> = {
  ADMIN: { label: '관리자', icon: '🛡️' },
  SUPPORTER: { label: '서포터', icon: '🤝' },
  SUPPORTER_BASIC: { label: '서포터(베이직)', icon: '🤝' },
  SUPPORTER_PREMIUM: { label: '서포터(프리미엄)', icon: '⭐' },
  USER: { label: '사용자', icon: '👤' },
  REQUESTER: { label: '의뢰인', icon: '👤' },
  PATIENT: { label: '환자', icon: '🏥' },
};
