import { useNavigate } from 'react-router-dom';
import { useAuthStore } from '@/store/auth.store';
import { supporterAuthService } from '@/services/api/auth.service';
import '../../styles/apply-shared.css';

type NavItem = '서비스 소개' | '지원가이드' | 'FAQ';

type PublicGnbProps = {
  activeNav?: NavItem;
};

export function PublicGnb({ activeNav }: PublicGnbProps) {
  const navigate = useNavigate();
  const isAuthenticated = useAuthStore((s) => s.isAuthenticated);

  const NAV_ROUTES: Record<NavItem, string> = {
    '서비스 소개': '/service-intro',
    지원가이드: '/guide',
    FAQ: '/faq',
  };

  return (
    <header className="apply-gnb">
      {/* Desktop layout */}
      <div className="apply-gnb__inner">
        <div
          className="apply-gnb__logo"
          aria-label="ProtoCare 로고"
          role="button"
          tabIndex={0}
          onClick={() => navigate('/')}
        />
        <nav className="apply-gnb__nav" aria-label="주요 메뉴">
          {(Object.keys(NAV_ROUTES) as NavItem[]).map((item) => (
            <button
              key={item}
              className={`apply-gnb__nav-item${activeNav === item ? ' apply-gnb__nav-item--active' : ''}`}
              onClick={() => navigate(NAV_ROUTES[item])}
            >
              {item}
            </button>
          ))}
        </nav>
        {isAuthenticated ? (
          <div className="apply-gnb__actions apply-gnb__actions--auth">
            <button className="apply-gnb__action-btn" onClick={() => supporterAuthService.logout()}>
              로그아웃
            </button>
            <button
              className="apply-gnb__cta-auth"
              onClick={() => navigate('/supporter/mysupport/schedule')}
            >
              마이 서포트
            </button>
          </div>
        ) : (
          <div className="apply-gnb__actions">
            <button className="apply-gnb__action-btn" onClick={() => navigate('/login')}>
              로그인
            </button>
            <button className="apply-gnb__action-btn" onClick={() => navigate('/signup/step1')}>
              회원가입
            </button>
          </div>
        )}
      </div>

      {/* Mobile layout */}
      <div className="apply-gnb__mobile">
        <div
          className="apply-gnb__logo"
          aria-label="ProtoCare 로고"
          role="button"
          tabIndex={0}
          onClick={() => navigate('/')}
        />
        <div className="apply-gnb__mobile-actions">
          <button className="apply-gnb__mobile-btn" aria-label="메뉴">
            <svg
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path d="M2 16H22V14H2V16ZM2 11H22V9H2V11ZM2 4V6H22V4H2Z" fill="#121212" />
            </svg>
          </button>
          <button
            className="apply-gnb__mobile-btn"
            aria-label="계정"
            onClick={() =>
              isAuthenticated ? navigate('/supporter/mysupport/schedule') : navigate('/login')
            }
          >
            <svg
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M12 2C6.48 2 2 6.48 2 12C2 17.52 6.48 22 12 22C17.52 22 22 17.52 22 12C22 6.48 17.52 2 12 2ZM12 5C13.66 5 15 6.34 15 8C15 9.66 13.66 11 12 11C10.34 11 9 9.66 9 8C9 6.34 10.34 5 12 5ZM12 19.2C9.5 19.2 7.29 17.92 6 16C6.03 14.01 10 12.9 12 12.9C13.99 12.9 17.97 14.01 18 16C16.71 17.92 14.5 19.2 12 19.2Z"
                fill="#121212"
              />
            </svg>
          </button>
        </div>
      </div>
    </header>
  );
}
