import { useNavigate } from 'react-router-dom';
import { useAuthStore } from '@/store/auth.store';
import '../../styles/apply-shared.css';

type ApplyGnbProps = {
  variant?: 'full' | 'simple';
  activeItem?: 'service' | 'guide' | 'faq';
};

export function ApplyGnb({ variant = 'full', activeItem }: ApplyGnbProps) {
  const navigate = useNavigate();
  const user = useAuthStore((s) => s.user);

  function navClass(item: NonNullable<ApplyGnbProps['activeItem']>) {
    return `apply-gnb__nav-item${activeItem === item ? ' apply-gnb__nav-item--active' : ''}`;
  }

  return (
    <header className={`apply-gnb${variant === 'simple' ? ' apply-gnb--simple' : ''}`}>
      <div className="apply-gnb__inner">
        <div
          className="apply-gnb__logo"
          aria-label="ProtoCare 로고"
          role="button"
          tabIndex={0}
          onClick={() => navigate('/')}
        />
        {variant === 'full' && (
          <>
            <nav className="apply-gnb__nav" aria-label="주요 메뉴">
              <button className={navClass('service')} onClick={() => navigate('/service-intro')}>
                서비스 소개
              </button>
              <button className={navClass('guide')} onClick={() => navigate('/guide')}>
                지원가이드
              </button>
              <button className={navClass('faq')} onClick={() => navigate('/faq')}>
                FAQ
              </button>
            </nav>
            <div className="apply-gnb__actions">
              <button className="apply-gnb__logout" onClick={() => navigate('/login')}>
                로그아웃
              </button>
              <button className="apply-gnb__cta" onClick={() => navigate('/supporter/mysupport')}>
                마이 서포트
              </button>
            </div>
          </>
        )}
        {variant === 'simple' && (
          <div className="apply-gnb__mysupport-right">
            <button
              type="button"
              className="apply-gnb__bell-btn"
              aria-label="알림"
              onClick={() => navigate('/supporter/mysupport/notifications')}
            >
              <svg
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M12 22C13.1 22 14 21.1 14 20H10C10 21.1 10.9 22 12 22ZM18 16V11C18 7.93 16.36 5.36 13.5 4.68V4C13.5 3.17 12.83 2.5 12 2.5C11.17 2.5 10.5 3.17 10.5 4V4.68C7.63 5.36 6 7.92 6 11V16L4 18V19H20V18L18 16Z"
                  fill="#121212"
                />
              </svg>
            </button>
            <div className="apply-gnb__profile">
              <div className="apply-gnb__avatar" aria-hidden="true" />
              <p className="apply-gnb__user-name">
                <strong>{user?.name ?? ''}</strong> 서포터님
              </p>
            </div>
          </div>
        )}
      </div>
    </header>
  );
}
