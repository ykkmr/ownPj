import { useNavigate } from 'react-router-dom';
import { useAuthStore } from '@/store/auth.store';
import './MobileDrawerMenu.css';

// ── Menu data ──────────────────────────────────────────────────────────────

interface MenuItem {
  label: string;
  path: string;
}

interface MenuGroup {
  id: string;
  label: string;
  iconSrc: string;
  items: MenuItem[];
}

const MENU_GROUPS: MenuGroup[] = [
  {
    id: 'care',
    label: '케어 관리',
    iconSrc: '/assets/icons/Icon/volunteer_activism.svg',
    items: [
      { label: '대시보드', path: '/supporter/mysupport' },
      { label: '케어 탐색', path: '/supporter/mysupport/explore' },
      { label: '이용 내역', path: '/supporter/mysupport/history' },
      { label: '일정 관리', path: '/supporter/mysupport/schedule' },
      { label: '정산 관리', path: '/supporter/mysupport/earnings' },
    ],
  },
  {
    id: 'account',
    label: '계정 설정',
    iconSrc: '/assets/icons/Icon/manage_accounts.svg',
    items: [
      { label: '내 정보 관리', path: '/supporter/mysupport/profile' },
      { label: '지원서 관리', path: '/supporter/mysupport/applications' },
      { label: '알림 설정', path: '/supporter/mysupport/notifications' },
    ],
  },
  {
    id: 'support',
    label: '고객센터',
    iconSrc: '/assets/icons/Icon/contact_mail.svg',
    items: [
      { label: '공지사항', path: '/supporter/mysupport/notices' },
      { label: 'FAQ', path: '/supporter/mysupport/faq' },
      { label: '이용약관', path: '/supporter/mysupport/terms' },
      { label: '1:1 문의함', path: '/supporter/mysupport/inquiry' },
    ],
  },
];

// ── Icons ──────────────────────────────────────────────────────────────────

function EditIcon() {
  return (
    <svg viewBox="0 0 24 24" width="20" height="20" fill="#121212" aria-hidden="true">
      <path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z" />
    </svg>
  );
}

function CloseIcon() {
  return (
    <svg viewBox="0 0 24 24" width="24" height="24" fill="#121212" aria-hidden="true">
      <path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z" />
    </svg>
  );
}

function PersonIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="#a4a4a4" aria-hidden="true">
      <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z" />
    </svg>
  );
}

// ── Component ──────────────────────────────────────────────────────────────

interface MobileDrawerMenuProps {
  onClose: () => void;
}

export function MobileDrawerMenu({ onClose }: MobileDrawerMenuProps) {
  const navigate = useNavigate();
  const user = useAuthStore((s) => s.user);
  const logout = useAuthStore((s) => s.logout);

  function handleNavClick(path: string) {
    navigate(path);
    onClose();
  }

  function handleLogout() {
    logout();
    navigate('/login', { replace: true });
    onClose();
  }

  const displayName = user?.name ?? '사용자';

  return (
    <div className="drawer-menu" role="dialog" aria-modal="true" aria-label="네비게이션 메뉴">
      {/* ── Profile section ──────────────────────────────────────── */}
      <div className="drawer-menu__profile">
        <div className="drawer-menu__profile-left">
          <div className="drawer-menu__avatar">
            <PersonIcon />
          </div>
          <div className="drawer-menu__user-info">
            <div className="drawer-menu__name-row">
              <span className="drawer-menu__name">{displayName}</span>
              <button
                type="button"
                className="drawer-menu__edit-btn"
                aria-label="프로필 편집"
                onClick={() => handleNavClick('/supporter/mysupport/profile')}
              >
                <EditIcon />
              </button>
            </div>
            <div className="drawer-menu__status-row">
              <span className="drawer-menu__status-label">매칭</span>
              <span className="drawer-menu__status-name">{displayName}</span>
            </div>
          </div>
        </div>
        <button
          type="button"
          className="drawer-menu__close-btn"
          aria-label="메뉴 닫기"
          onClick={onClose}
        >
          <CloseIcon />
        </button>
      </div>

      {/* ── Menu body ────────────────────────────────────────────── */}
      <div className="drawer-menu__body">
        <nav className="drawer-menu__nav" aria-label="사이드 메뉴">
          {MENU_GROUPS.map((group) => (
            <div key={group.id} className="drawer-menu__group">
              <div className="drawer-menu__group-header">
                <img
                  src={group.iconSrc}
                  alt=""
                  aria-hidden="true"
                  className="drawer-menu__group-icon"
                />
                <span className="drawer-menu__group-label">{group.label}</span>
              </div>
              {group.items.map((item) => (
                <button
                  key={item.label}
                  type="button"
                  className="drawer-menu__item"
                  onClick={() => handleNavClick(item.path)}
                >
                  {item.label}
                </button>
              ))}
            </div>
          ))}
        </nav>
        <button type="button" className="drawer-menu__logout" onClick={handleLogout}>
          로그아웃
        </button>
      </div>
    </div>
  );
}
