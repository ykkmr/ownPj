import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { MobileDrawerMenu } from './MobileDrawerMenu';
import './MobileGnb.css';

export function MobileGnb() {
  const navigate = useNavigate();
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <>
      <header className="mobile-gnb" aria-label="모바일 네비게이션">
        <div
          className="mobile-gnb__logo"
          aria-label="ProtoCare 로고"
          role="button"
          tabIndex={0}
          onClick={() => navigate('/')}
        />
        <div className="mobile-gnb__actions">
          <button
            type="button"
            className="mobile-gnb__icon-btn"
            aria-label="알림"
            onClick={() => navigate('/supporter/mysupport/notifications')}
          >
            <svg viewBox="0 0 24 24" width="24" height="24" fill="#121212" aria-hidden="true">
              <path d="M12 22c1.1 0 2-.9 2-2h-4c0 1.1.9 2 2 2zm6-6v-5c0-3.07-1.64-5.64-4.5-6.32V4c0-.83-.67-1.5-1.5-1.5s-1.5.67-1.5 1.5v.68C7.63 5.36 6 7.92 6 11v5l-2 2v1h16v-1l-2-2z" />
            </svg>
          </button>
          <button
            type="button"
            className="mobile-gnb__icon-btn"
            aria-label="메뉴 열기"
            aria-expanded={isMenuOpen}
            onClick={() => setIsMenuOpen(true)}
          >
            <svg viewBox="0 0 24 24" width="24" height="24" fill="#121212" aria-hidden="true">
              <path d="M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z" />
            </svg>
          </button>
        </div>
      </header>

      {isMenuOpen && <MobileDrawerMenu onClose={() => setIsMenuOpen(false)} />}
    </>
  );
}
