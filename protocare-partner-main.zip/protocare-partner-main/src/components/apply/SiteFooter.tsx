import '../../styles/apply-shared.css';

const SOCIAL_ASSETS = {
  instagram: '/assets/icons/Social link 1.svg',
  linkedin: '/assets/icons/Social link 2.svg',
  twitter: '/assets/icons/Social link 3.svg',
} as const;

const FOOTER_NAV = [
  { heading: '서비스 소개', items: ['분야별 소개', '수익 구조와 혜택', '서포터들의 이야기'] },
  { heading: '지원 가이드', items: ['등록 절차', '지원 자격 요건'] },
  { heading: '케어 활동 찾기', items: ['케어 활동 찾기'] },
  { heading: '마이 서포트', items: ['케어 관리', '계정 설정', '고객센터'] },
] as const;

export function SiteFooter() {
  return (
    <footer className="apply-footer">
      <div className="apply-footer__inner">
        <div className="apply-footer__brand">
          <div className="apply-footer__info">
            <div className="apply-footer__logo" aria-label="ProtoCare 로고" />
            <address className="apply-footer__address">
              {
                '(주)프로토타이\n서울시 강남구 역삼로 114 현죽빌딩 8층\n\n대표 : 박승현\n사업자등록번호 : 589-86-03334\n통신판매업신고번호 : 제2025-서울강남-03320호'
              }
            </address>
            <div className="apply-footer__links">
              <button className="apply-footer__link">개인정보 처리방침</button>
              <button className="apply-footer__link">이용약관</button>
              <button className="apply-footer__link">공지사항</button>
            </div>
          </div>
          <nav className="apply-footer__socials" aria-label="소셜 미디어">
            <button className="apply-footer__social-btn" aria-label="Instagram">
              <img src={SOCIAL_ASSETS.instagram} alt="" />
            </button>
            <button className="apply-footer__social-btn" aria-label="LinkedIn">
              <img src={SOCIAL_ASSETS.linkedin} alt="" />
            </button>
            <button className="apply-footer__social-btn" aria-label="X (Twitter)">
              <img src={SOCIAL_ASSETS.twitter} alt="" />
            </button>
          </nav>
        </div>
        <nav className="apply-footer__nav" aria-label="푸터 네비게이션">
          {FOOTER_NAV.map((col) => (
            <div key={col.heading} className="apply-footer__nav-col">
              <p className="apply-footer__nav-heading">{col.heading}</p>
              {col.items.map((item) => (
                <button key={item} className="apply-footer__nav-item">
                  {item}
                </button>
              ))}
            </div>
          ))}
        </nav>
      </div>
    </footer>
  );
}
