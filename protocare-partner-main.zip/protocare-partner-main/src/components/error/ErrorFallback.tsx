import { useQueryClient } from '@tanstack/react-query';
import { ErrorState } from '@/components/ui/ErrorState';

interface ErrorFallbackProps {
  error: Error;
  reset: () => void;
}

/**
 * 페이지 레벨 에러 경계 Fallback.
 * '다시 시도' 클릭 시 실패한 쿼리를 모두 재시도하고 경계 상태를 초기화.
 */
export const ErrorFallback = ({ error, reset }: ErrorFallbackProps) => {
  const queryClient = useQueryClient();

  const handleRetry = () => {
    queryClient.resetQueries();
    reset();
  };

  return (
    <>
      <ErrorState variant="generic" onRetry={handleRetry} />
      {import.meta.env.DEV && error?.message && (
        <pre className="mx-4 mt-2 overflow-auto rounded bg-red-50 p-3 text-xs text-red-700">
          {error.message}
        </pre>
      )}
    </>
  );
};
