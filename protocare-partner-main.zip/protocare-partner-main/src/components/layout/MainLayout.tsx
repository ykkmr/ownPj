import type { ReactNode } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Home, Calendar, Bell, User } from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import { MobileContainer } from './MobileContainer';

interface TabItem {
  label: string;
  icon: LucideIcon;
  path: string;
}

const TAB_ITEMS: TabItem[] = [
  { label: '홈', icon: Home, path: '/app' },
  { label: '일정', icon: Calendar, path: '/schedule' },
  { label: '알림', icon: Bell, path: '/notifications' },
  { label: '마이페이지', icon: User, path: '/mypage' },
];

const TAB_BAR_HEIGHT = 64;

interface MainLayoutProps {
  children: ReactNode;
}

const BottomTabBar = () => {
  const navigate = useNavigate();
  const { pathname } = useLocation();

  const isActive = (path: string) =>
    pathname === path || (path !== '/app' && pathname.startsWith(path));

  return (
    <nav
      aria-label="하단 탭 바"
      className="fixed inset-x-0 bottom-0 z-40 mx-auto max-w-md border-t border-gray-100 bg-white"
      style={{ height: TAB_BAR_HEIGHT }}
    >
      <ul className="flex h-full items-center justify-around">
        {TAB_ITEMS.map(({ label, icon: Icon, path }) => {
          const active = isActive(path);
          return (
            <li key={path}>
              <button
                type="button"
                onClick={() => navigate(path)}
                aria-label={label}
                aria-current={active ? 'page' : undefined}
                className={`flex min-h-[44px] min-w-[44px] flex-col items-center justify-center gap-1 px-3 transition-colors ${
                  active ? 'text-blue-600' : 'text-gray-400 hover:text-gray-600'
                }`}
              >
                <Icon size={22} />
                <span className="text-[10px] font-medium">{label}</span>
              </button>
            </li>
          );
        })}
      </ul>
    </nav>
  );
};

/**
 * 메인 대시보드 전용 레이아웃.
 * 하단 탭 바를 포함하며, 콘텐츠 영역은 탭 바 높이만큼 하단 패딩을 자동 적용합니다.
 */
export const MainLayout = ({ children }: MainLayoutProps) => (
  <MobileContainer>
    <main style={{ paddingBottom: TAB_BAR_HEIGHT }}>{children}</main>
    <BottomTabBar />
  </MobileContainer>
);