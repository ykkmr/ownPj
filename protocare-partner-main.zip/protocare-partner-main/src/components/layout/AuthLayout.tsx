import type { ReactNode } from 'react';
import { PageHeader } from '@/components/ui/PageHeader';
import { MobileContainer } from './MobileContainer';

interface AuthLayoutProps {
  title: string;
  children: ReactNode;
  showBack?: boolean;
  onBack?: () => void;
  right?: ReactNode;
}

/**
 * 인증/가입 플로우 전용 레이아웃.
 * 상단 PageHeader + MobileContainer 조합으로 반복 구조를 제거합니다.
 */
export const AuthLayout = ({
  title,
  children,
  showBack = true,
  onBack,
  right,
}: AuthLayoutProps) => (
  <MobileContainer className="flex flex-col">
    <PageHeader title={title} showBack={showBack} onBack={onBack} right={right} />
    {children}
  </MobileContainer>
);