import type { ReactNode } from 'react';

interface MobileContainerProps {
  children: ReactNode;
  className?: string;
}

export const MobileContainer = ({ children, className = '' }: MobileContainerProps) => (
  <div className={`relative mx-auto w-full max-w-md min-h-screen bg-white ${className}`}>
    {children}
  </div>
);