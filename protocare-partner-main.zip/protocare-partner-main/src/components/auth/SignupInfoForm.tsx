import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useSignup } from '@/hooks/useAuth';
import './SignupInfoForm.css';

// ── Types ──────────────────────────────────────────────────────────────────
interface FormState {
  name: string;
  email: string;
  password: string;
  passwordConfirm: string;
  phone: string;
}

type FormErrors = Partial<Record<keyof FormState, string>>;

// ── Validators ─────────────────────────────────────────────────────────────
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const PHONE_RE = /^01[0-9]{8,9}$/; // API 스펙: 하이픈 없이
const PASSWORD_RE = /^[0-9a-zA-Z!@#]+$/; // API 스펙: ^[0-9a-zA-Z!@#]+$

function stripHyphens(phone: string): string {
  return phone.replace(/-/g, '');
}

function validate(form: FormState): FormErrors {
  const errors: FormErrors = {};
  if (!form.name.trim()) errors.name = '이름을 입력해 주세요.';
  if (!form.email.trim()) {
    errors.email = '이메일을 입력해 주세요.';
  } else if (!EMAIL_RE.test(form.email)) {
    errors.email = '올바른 이메일 형식이 아닙니다.';
  }
  if (!form.password) {
    errors.password = '비밀번호를 입력해 주세요.';
  } else if (form.password.length < 8) {
    errors.password = '비밀번호는 8자 이상이어야 합니다.';
  } else if (!PASSWORD_RE.test(form.password)) {
    errors.password = '비밀번호는 영문, 숫자, !@# 만 사용 가능합니다.';
  }
  if (!form.passwordConfirm) {
    errors.passwordConfirm = '비밀번호 확인을 입력해 주세요.';
  } else if (form.password !== form.passwordConfirm) {
    errors.passwordConfirm = '비밀번호가 일치하지 않습니다.';
  }
  const phone = stripHyphens(form.phone);
  if (!phone) {
    errors.phone = '전화번호를 입력해 주세요.';
  } else if (!PHONE_RE.test(phone)) {
    errors.phone = '올바른 전화번호를 입력해 주세요. (예: 01012345678)';
  }
  return errors;
}

// ── Field ──────────────────────────────────────────────────────────────────
function Field({
  label,
  error,
  children,
}: {
  label: string;
  error?: string;
  children: React.ReactNode;
}) {
  return (
    <div className="signup-field">
      <p className="signup-field__label">{label}</p>
      {children}
      {error && <p className="signup-field__error">{error}</p>}
    </div>
  );
}

// ── Component ──────────────────────────────────────────────────────────────
export function SignupInfoForm() {
  const navigate = useNavigate();
  const signup = useSignup();

  const [form, setForm] = useState<FormState>({
    name: '',
    email: '',
    password: '',
    passwordConfirm: '',
    phone: '',
  });
  const [errors, setErrors] = useState<FormErrors>({});
  const [submitted, setSubmitted] = useState(false);

  function handleChange(field: keyof FormState) {
    return (e: React.ChangeEvent<HTMLInputElement>) => {
      const next = { ...form, [field]: e.target.value };
      setForm(next);
      if (submitted) setErrors(validate(next));
    };
  }

  function handleSubmit() {
    setSubmitted(true);
    const errs = validate(form);
    if (Object.keys(errs).length > 0) {
      setErrors(errs);
      return;
    }
    signup.mutate({
      name: form.name,
      email: form.email,
      phoneNumber: stripHyphens(form.phone),
      password: form.password,
    });
  }

  return (
    <div className="terms-form">
      <div className="terms-form__title-block">
        <h1 className="terms-form__title">회원가입</h1>
        <p className="terms-form__subtitle">
          정확한 정보를 입력해 주셔야
          <br />
          Protocare의 모든 서비스 이용이 가능합니다.
        </p>
      </div>

      <div className="signup-form__fields">
        <Field label="이름" error={errors.name}>
          <input
            type="text"
            className={`signup-input${errors.name ? ' signup-input--error' : ''}`}
            placeholder="실명을 입력해 주세요"
            value={form.name}
            onChange={handleChange('name')}
            autoComplete="name"
          />
        </Field>

        <Field label="이메일" error={errors.email}>
          <input
            type="email"
            className={`signup-input${errors.email ? ' signup-input--error' : ''}`}
            placeholder="이메일을 입력해 주세요"
            value={form.email}
            onChange={handleChange('email')}
            autoComplete="email"
          />
        </Field>

        <Field label="비밀번호" error={errors.password}>
          <input
            type="password"
            className={`signup-input${errors.password ? ' signup-input--error' : ''}`}
            placeholder="8자 이상, 영문·숫자·!@# 사용"
            value={form.password}
            onChange={handleChange('password')}
            autoComplete="new-password"
          />
        </Field>

        <Field label="비밀번호 확인" error={errors.passwordConfirm}>
          <input
            type="password"
            className={`signup-input${errors.passwordConfirm ? ' signup-input--error' : ''}`}
            placeholder="비밀번호를 한 번 더 입력해 주세요"
            value={form.passwordConfirm}
            onChange={handleChange('passwordConfirm')}
            autoComplete="new-password"
          />
        </Field>

        <Field label="전화번호" error={errors.phone}>
          <input
            type="tel"
            className={`signup-input${errors.phone ? ' signup-input--error' : ''}`}
            placeholder="01012345678 (하이픈 없이)"
            value={form.phone}
            onChange={handleChange('phone')}
            autoComplete="tel"
          />
        </Field>

        <div className="signup-form__actions">
          <button
            type="button"
            className="terms-form__submit"
            onClick={handleSubmit}
            disabled={signup.isPending}
          >
            {signup.isPending ? '처리 중...' : '가입 완료'}
          </button>
          <button type="button" className="signup-form__back" onClick={() => navigate(-1)}>
            뒤로 가기
          </button>
        </div>
      </div>
    </div>
  );
}
