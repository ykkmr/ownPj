import type { ReactNode } from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuthStore } from '@/store/auth.store';
import { ROUTES } from '@/constants/routes';

/**
 * 보호 라우트 가드.
 * - 미인증 시 /login?next=<현재경로> 로 redirect
 * - replace=true: 뒤로가기 시 보호 페이지로 튕기는 UX 버그 방지
 */
export function RequireAuth({ children }: { children: ReactNode }) {
  const isAuthenticated = useAuthStore((s) => s.isAuthenticated);
  const location = useLocation();

  if (!isAuthenticated) {
    const next = encodeURIComponent(location.pathname);
    return <Navigate to={`${ROUTES.login}?next=${next}`} replace />;
  }

  return <>{children}</>;
}
