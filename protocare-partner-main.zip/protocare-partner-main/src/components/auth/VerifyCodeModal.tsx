import { useState, useEffect } from 'react';
import { mobileAuthService, type SmsVerifyType } from '@/services/api/auth.service';
import { toast } from '@/store/toast.store';
import './VerifyCodeModal.css';

// ── Types ──────────────────────────────────────────────────────────────────
interface VerifyCodeModalProps {
  contact: string; // 전화번호 (하이픈 없이)
  type?: SmsVerifyType;
  onVerify: (code: string) => void;
  onClose: () => void;
}

// ── Helpers ────────────────────────────────────────────────────────────────
const TIMER_SECONDS = 60; // 서버 60초 쿨다운과 동기화

function formatTime(seconds: number): string {
  const m = Math.floor(seconds / 60)
    .toString()
    .padStart(2, '0');
  const s = (seconds % 60).toString().padStart(2, '0');
  return `${m}:${s}`;
}

// ── Component ──────────────────────────────────────────────────────────────
export function VerifyCodeModal({
  contact,
  type = 'SIGNUP',
  onVerify,
  onClose,
}: VerifyCodeModalProps) {
  const [code, setCode] = useState('');
  const [secondsLeft, setSecondsLeft] = useState(0);
  const [isSending, setIsSending] = useState(false);
  const [isVerifying, setIsVerifying] = useState(false);
  const [sent, setSent] = useState(false);

  // 모달 마운트 시 자동 발송
  useEffect(() => {
    void sendSms();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (secondsLeft <= 0) return;
    const id = setInterval(() => setSecondsLeft((s) => s - 1), 1000);
    return () => clearInterval(id);
  }, [secondsLeft]);

  async function sendSms() {
    setIsSending(true);
    try {
      await mobileAuthService.sendSms(contact, type);
      setSent(true);
      setSecondsLeft(TIMER_SECONDS);
      toast.success('인증번호가 발송되었습니다.');
    } catch (err: any) {
      toast.danger(err.response?.data?.message || 'SMS 발송에 실패했습니다.');
    } finally {
      setIsSending(false);
    }
  }

  async function handleVerify() {
    if (code.length < 6) return;
    setIsVerifying(true);
    try {
      await mobileAuthService.verifySms(contact, type, code);
      onVerify(code);
    } catch (err: any) {
      toast.danger(err.response?.data?.message || '인증번호가 올바르지 않습니다.');
    } finally {
      setIsVerifying(false);
    }
  }

  async function handleResend() {
    setCode('');
    await sendSms();
  }

  function handleCodeChange(e: React.ChangeEvent<HTMLInputElement>) {
    setCode(e.target.value.replace(/\D/g, '').slice(0, 6));
  }

  function handleOverlayClick(e: React.MouseEvent<HTMLDivElement>) {
    if (e.target === e.currentTarget) onClose();
  }

  return (
    <div className="verify-modal-overlay" onClick={handleOverlayClick}>
      <div
        className="verify-modal"
        role="dialog"
        aria-modal="true"
        aria-labelledby="verify-modal-title"
      >
        <div className="verify-modal__header">
          <p id="verify-modal-title" className="verify-modal__title">
            인증번호 입력
          </p>
          <p className="verify-modal__subtitle">
            {sent ? `${contact}로 발송된 번호를 입력해주세요.` : 'SMS를 발송하는 중입니다...'}
          </p>
        </div>

        <p className="verify-modal__timer">{formatTime(secondsLeft)}</p>

        <input
          type="text"
          inputMode="numeric"
          maxLength={6}
          className="verify-modal__input"
          placeholder="인증번호 6자리"
          value={code}
          onChange={handleCodeChange}
          autoComplete="one-time-code"
          disabled={!sent || isVerifying}
        />

        <div className="verify-modal__resend-row">
          <button
            type="button"
            className="verify-modal__resend"
            onClick={handleResend}
            disabled={isSending || secondsLeft > 0}
          >
            {isSending ? '발송 중...' : '인증번호 재발송'}
          </button>
        </div>

        <div className="verify-modal__actions">
          <button
            type="button"
            className="verify-modal__btn verify-modal__btn--primary"
            disabled={code.length < 6 || secondsLeft <= 0 || isVerifying}
            onClick={handleVerify}
          >
            {isVerifying ? '확인 중...' : '인증 완료'}
          </button>
          <button
            type="button"
            className="verify-modal__btn verify-modal__btn--secondary"
            onClick={onClose}
          >
            닫기
          </button>
        </div>
      </div>
    </div>
  );
}
