import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './SignupTermsForm.css';

// ── Types ──────────────────────────────────────────────────────────────────
type ConsentKey = 'service' | 'privacy' | 'thirdParty' | 'sensitive' | 'age' | 'promo';

interface ConsentItem {
  key: ConsentKey;
  label: string;
  hasLink: boolean;
}

// ── Config ─────────────────────────────────────────────────────────────────
const REQUIRED_ITEMS: ConsentItem[] = [
  { key: 'service', label: 'Protocare 서비스 이용약관 동의', hasLink: true },
  { key: 'privacy', label: '개인정보 수집 및 이용 동의', hasLink: true },
  { key: 'thirdParty', label: '개인 정보 제 3자 제공 동의', hasLink: true },
  { key: 'sensitive', label: '민감정보 수집 및 이용 동의', hasLink: true },
  { key: 'age', label: '만 14세 이상', hasLink: false },
];

const OPTIONAL_ITEMS: ConsentItem[] = [
  { key: 'promo', label: '프로모션 정보 수신 동의', hasLink: true },
];

const ALL_KEYS: ConsentKey[] = [
  ...REQUIRED_ITEMS.map((i) => i.key),
  ...OPTIONAL_ITEMS.map((i) => i.key),
];

const INITIAL_CONSENTS: Record<ConsentKey, boolean> = {
  service: false,
  privacy: false,
  thirdParty: false,
  sensitive: false,
  age: false,
  promo: false,
};

// ── Icons ──────────────────────────────────────────────────────────────────
function RadioIcon({ checked }: { checked: boolean }) {
  if (checked) {
    return (
      <svg viewBox="0 0 28 28" className="terms-radio-icon" aria-hidden="true">
        <circle cx="14" cy="14" r="11" fill="none" stroke="#40b39b" strokeWidth="2" />
        <circle cx="14" cy="14" r="6" fill="#40b39b" />
      </svg>
    );
  }
  return (
    <svg viewBox="0 0 28 28" className="terms-radio-icon" aria-hidden="true">
      <circle cx="14" cy="14" r="11" fill="none" stroke="#a4a4a4" strokeWidth="2" />
    </svg>
  );
}

function ChevronIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="#a4a4a4" aria-hidden="true" className="terms-chevron-icon">
      <path d="M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z" />
    </svg>
  );
}

// ── ConsentRow ─────────────────────────────────────────────────────────────
interface ConsentRowProps {
  item: ConsentItem;
  checked: boolean;
  onToggle: () => void;
}

function ConsentRow({ item, checked, onToggle }: ConsentRowProps) {
  return (
    <div className="terms-consent-row">
      <button type="button" className="terms-consent-row__left" onClick={onToggle}>
        <RadioIcon checked={checked} />
        <span className="terms-consent-row__label">{item.label}</span>
      </button>
      {item.hasLink && (
        <button
          type="button"
          className="terms-consent-row__link"
          aria-label={`${item.label} 상세 보기`}
        >
          <ChevronIcon />
        </button>
      )}
    </div>
  );
}

// ── Component ──────────────────────────────────────────────────────────────
export function SignupTermsForm() {
  const navigate = useNavigate();
  const [consents, setConsents] = useState<Record<ConsentKey, boolean>>(INITIAL_CONSENTS);

  const allChecked = ALL_KEYS.every((k) => consents[k]);
  const allRequiredChecked = REQUIRED_ITEMS.every((i) => consents[i.key]);

  function toggleAll() {
    const next = !allChecked;
    setConsents(Object.fromEntries(ALL_KEYS.map((k) => [k, next])) as Record<ConsentKey, boolean>);
  }

  function toggleOne(key: ConsentKey) {
    setConsents((prev) => ({ ...prev, [key]: !prev[key] }));
  }

  function handleSubmit() {
    if (!allRequiredChecked) return;
    navigate('/signup/step2');
  }

  return (
    <div className="terms-form">
      <div className="terms-form__title-block">
        <h1 className="terms-form__title">회원가입</h1>
        <p className="terms-form__subtitle">약관에 동의 후 회원가입을 진행해 주세요.</p>
      </div>

      <div className="terms-form__body">
        {/* 모두 동의 */}
        <div className="terms-agree-all">
          <button
            type="button"
            className={`terms-agree-all__btn${allChecked ? ' terms-agree-all__btn--active' : ''}`}
            onClick={toggleAll}
          >
            <RadioIcon checked={allChecked} />
            <span>모두 동의</span>
          </button>
          <p className="terms-agree-all__hint">필수 및 선택 정보를 한번에 동의하실 수 있습니다.</p>
        </div>

        {/* 동의 항목들 */}
        <div className="terms-sections">
          <div className="terms-section">
            <p className="terms-section__label">필수 동의</p>
            <div className="terms-section__items">
              {REQUIRED_ITEMS.map((item) => (
                <ConsentRow
                  key={item.key}
                  item={item}
                  checked={consents[item.key]}
                  onToggle={() => toggleOne(item.key)}
                />
              ))}
            </div>
          </div>

          <hr className="terms-divider" />

          <div className="terms-section">
            <p className="terms-section__label">선택 동의</p>
            <div className="terms-section__items">
              {OPTIONAL_ITEMS.map((item) => (
                <ConsentRow
                  key={item.key}
                  item={item}
                  checked={consents[item.key]}
                  onToggle={() => toggleOne(item.key)}
                />
              ))}
            </div>
          </div>
        </div>

        <button
          type="button"
          className="terms-form__submit"
          disabled={!allRequiredChecked}
          onClick={handleSubmit}
        >
          다음
        </button>
      </div>
    </div>
  );
}
