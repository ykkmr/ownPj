import type { ReactNode } from 'react';
import { usePermission } from '@/hooks/usePermission';
import type { PermissionCode } from '@/types/domain';

interface PermissionGuardProps {
  /** 필요한 권한 코드. 이 권한이 없으면 children 을 렌더링하지 않습니다. */
  code: PermissionCode;
  /**
   * 권한이 없을 때 표시할 대체 UI.
   * 생략하면 아무것도 렌더링하지 않습니다(null).
   */
  fallback?: ReactNode;
  children: ReactNode;
}

/**
 * 역할 기반 접근 제어(RBAC) 가드.
 * 버튼·메뉴·섹션 단위로 감싸면 권한 없는 사용자에게 해당 UI가 보이지 않습니다.
 *
 * ⚠️ 이 컴포넌트는 UX 보조용입니다.
 *    실제 데이터 보호는 반드시 서버(API) 레이어에서 수행해야 합니다.
 *
 * @example
 * <PermissionGuard code="PAYMENT_VIEW">
 *   <PaymentSection />
 * </PermissionGuard>
 *
 * <PermissionGuard code="ADMIN_PANEL" fallback={<AccessDeniedMessage />}>
 *   <AdminPanel />
 * </PermissionGuard>
 */
export const PermissionGuard = ({ code, fallback = null, children }: PermissionGuardProps) => {
  const { hasPermission } = usePermission();
  return hasPermission(code) ? <>{children}</> : <>{fallback}</>;
};