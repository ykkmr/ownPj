import { type ReactNode, type ComponentProps } from 'react';

interface CardProps extends ComponentProps<'div'> {
  children: ReactNode;
}

export const Card = ({ children, className = '', ...props }: CardProps) => (
  <div className={`rounded-xl border border-gray-200 bg-white shadow-sm ${className}`} {...props}>
    {children}
  </div>
);

export const CardHeader = ({ children, className = '', ...props }: CardProps) => (
  <div className={`border-b border-gray-100 px-4 py-3 ${className}`} {...props}>
    {children}
  </div>
);

export const CardBody = ({ children, className = '', ...props }: CardProps) => (
  <div className={`px-4 py-3 ${className}`} {...props}>
    {children}
  </div>
);

export const CardFooter = ({ children, className = '', ...props }: CardProps) => (
  <div className={`border-t border-gray-100 px-4 py-3 ${className}`} {...props}>
    {children}
  </div>
);
