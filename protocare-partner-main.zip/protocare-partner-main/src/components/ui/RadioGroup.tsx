import { useId } from 'react';

interface RadioOption {
  value: string;
  label: string;
  disabled?: boolean;
}

interface RadioGroupProps {
  name: string;
  options: RadioOption[];
  value?: string;
  onChange?: (value: string) => void;
  direction?: 'row' | 'column';
  error?: boolean;
  disabled?: boolean;
}

export const RadioGroup = ({
  name,
  options,
  value,
  onChange,
  direction = 'column',
  error = false,
  disabled = false,
}: RadioGroupProps) => {
  const baseId = useId();

  return (
    <div
      role="radiogroup"
      className={`flex gap-3 ${direction === 'row' ? 'flex-row flex-wrap' : 'flex-col'}`}
    >
      {options.map((option) => {
        const id = `${baseId}-${option.value}`;
        const isDisabled = disabled || option.disabled;
        const isChecked = value === option.value;

        return (
          <label
            key={option.value}
            htmlFor={id}
            className={`flex min-h-11 cursor-pointer items-center gap-3 ${isDisabled ? 'cursor-not-allowed opacity-50' : ''}`}
          >
            <input
              id={id}
              type="radio"
              name={name}
              value={option.value}
              checked={isChecked}
              disabled={isDisabled}
              aria-invalid={error}
              onChange={() => onChange?.(option.value)}
              className="h-4 w-4 cursor-pointer accent-blue-600 disabled:cursor-not-allowed"
            />
            <span className="text-sm text-gray-800">{option.label}</span>
          </label>
        );
      })}
    </div>
  );
};
