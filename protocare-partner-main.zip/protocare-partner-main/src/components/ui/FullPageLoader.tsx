import { Skeleton } from './Skeleton';

export type FullPageLoaderVariant = 'list' | 'feed' | 'profile' | 'detail';

interface FullPageLoaderProps {
  variant?: FullPageLoaderVariant;
  rows?: number;
}

const ListSkeleton = ({ rows }: { rows: number }) => (
  <div className="divide-y divide-gray-100">
    {Array.from({ length: rows }).map((_, i) => (
      <div key={i} className="flex items-center gap-4 px-4 py-4">
        <Skeleton width="44px" height="44px" rounded="md" />
        <div className="flex-1 space-y-2">
          <Skeleton height="14px" width="65%" />
          <Skeleton height="12px" width="45%" />
        </div>
        <Skeleton width="20px" height="20px" rounded="sm" />
      </div>
    ))}
  </div>
);

const FeedSkeleton = ({ rows }: { rows: number }) => (
  <div className="space-y-4 p-4">
    {Array.from({ length: rows }).map((_, i) => (
      <div key={i} className="space-y-3 rounded-xl border border-gray-100 p-4">
        <div className="flex items-center gap-3">
          <Skeleton width="40px" height="40px" rounded="full" />
          <div className="flex-1 space-y-2">
            <Skeleton height="14px" width="55%" />
            <Skeleton height="12px" width="35%" />
          </div>
        </div>
        <Skeleton height="12px" />
        <Skeleton height="12px" width="80%" />
        <Skeleton height="12px" width="60%" />
      </div>
    ))}
  </div>
);

const ProfileSkeleton = () => (
  <div className="space-y-6 p-6">
    <div className="flex items-center gap-4">
      <Skeleton width="64px" height="64px" rounded="full" />
      <div className="flex-1 space-y-2">
        <Skeleton height="18px" width="50%" />
        <Skeleton height="14px" width="70%" />
      </div>
    </div>
    <div className="space-y-3">
      {Array.from({ length: 5 }).map((_, i) => (
        <div key={i} className="flex justify-between py-2">
          <Skeleton height="14px" width="30%" />
          <Skeleton height="14px" width="40%" />
        </div>
      ))}
    </div>
  </div>
);

const DetailSkeleton = () => (
  <div className="space-y-4 p-4">
    <Skeleton height="200px" rounded="lg" />
    <Skeleton height="24px" width="60%" />
    <div className="space-y-2">
      <Skeleton height="14px" />
      <Skeleton height="14px" />
      <Skeleton height="14px" width="75%" />
    </div>
    <Skeleton height="48px" rounded="lg" />
  </div>
);

const SKELETON_MAP: Record<FullPageLoaderVariant, (rows: number) => React.ReactNode> = {
  list: (rows) => <ListSkeleton rows={rows} />,
  feed: (rows) => <FeedSkeleton rows={rows} />,
  profile: () => <ProfileSkeleton />,
  detail: () => <DetailSkeleton />,
};

/**
 * 데이터 로딩 중 보여주는 스켈레톤 UI.
 * variant로 페이지 유형에 맞는 형태를 선택합니다.
 */
export const FullPageLoader = ({ variant = 'list', rows = 5 }: FullPageLoaderProps) => (
  <div aria-busy="true" aria-label="콘텐츠를 불러오는 중입니다">
    {SKELETON_MAP[variant](rows)}
  </div>
);