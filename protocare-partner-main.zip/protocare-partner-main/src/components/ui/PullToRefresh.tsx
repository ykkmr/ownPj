import { useRef, useState, useEffect, type ReactNode } from 'react';
import { Spinner } from './Spinner';

interface PullToRefreshProps {
  onRefresh: () => Promise<void>;
  onError?: (err: unknown) => void;
  children: ReactNode;
  threshold?: number;
  className?: string;
}

type PullState = 'idle' | 'pulling' | 'ready' | 'refreshing';

const THRESHOLD_DEFAULT = 72;

export const PullToRefresh = ({
  onRefresh,
  onError,
  children,
  threshold = THRESHOLD_DEFAULT,
  className = '',
}: PullToRefreshProps) => {
  const [pullState, setPullState] = useState<PullState>('idle');
  const [pullDistance, setPullDistance] = useState(0);
  const startYRef = useRef<number | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const isMountedRef = useRef(true);

  useEffect(() => {
    isMountedRef.current = true;
    return () => { isMountedRef.current = false; };
  }, []);

  const isAtTop = () => (containerRef.current?.scrollTop ?? 0) === 0;

  const handleTouchStart = (e: React.TouchEvent) => {
    if (!isAtTop()) return;
    startYRef.current = e.touches[0]?.clientY ?? null;
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (startYRef.current === null || pullState === 'refreshing') return;
    if (!isAtTop()) return;

    const currentY = e.touches[0]?.clientY ?? 0;
    const delta = currentY - startYRef.current;
    if (delta <= 0) return;

    e.preventDefault();
    const resistance = Math.min(delta * 0.5, threshold * 1.2);
    setPullDistance(resistance);
    setPullState(resistance >= threshold ? 'ready' : 'pulling');
  };

  const handleTouchEnd = async () => {
    if (pullState === 'ready') {
      setPullState('refreshing');
      setPullDistance(threshold);
      try {
        await onRefresh();
      } catch (err) {
        if (isMountedRef.current) onError?.(err);
      } finally {
        if (isMountedRef.current) {
          setPullState('idle');
          setPullDistance(0);
        }
      }
    } else {
      setPullState('idle');
      setPullDistance(0);
    }
    startYRef.current = null;
  };

  const indicatorVisible = pullState !== 'idle';
  const indicatorOpacity = Math.min(pullDistance / threshold, 1);

  return (
    <div
      ref={containerRef}
      className={`relative overflow-y-auto ${className}`}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
    >
      {indicatorVisible && (
        <div
          aria-live="polite"
          aria-label={pullState === 'refreshing' ? '새로고침 중' : pullState === 'ready' ? '놓아서 새로고침' : '당겨서 새로고침'}
          className="absolute inset-x-0 top-0 z-10 flex items-center justify-center transition-all duration-150"
          style={{
            height: pullDistance,
            opacity: indicatorOpacity,
          }}
        >
          {pullState === 'refreshing' ? (
            <Spinner size="sm" />
          ) : (
            <svg
              width="20"
              height="20"
              viewBox="0 0 20 20"
              fill="none"
              aria-hidden="true"
              className={`text-blue-500 transition-transform duration-200 ${pullState === 'ready' ? 'rotate-180' : ''}`}
            >
              <path d="M10 3v11M5 9l5 5 5-5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          )}
        </div>
      )}
      <div
        style={{
          transform: pullState !== 'idle' ? `translateY(${pullDistance}px)` : 'translateY(0)',
          transition: pullState === 'idle' || pullState === 'refreshing' ? 'transform 0.2s ease' : 'none',
        }}
      >
        {children}
      </div>
    </div>
  );
};
