import { useRef, type ChangeEvent } from 'react';
import { Search, X } from 'lucide-react';

export interface StatusOption {
  label: string;
  value: string;
}

interface SearchFilterBarProps {
  /** 검색어 값 */
  search: string;
  onSearchChange: (value: string) => void;
  /** 상태 필터 현재 값. '' = 전체 */
  status?: string;
  onStatusChange?: (value: string) => void;
  /** 상태 필터 옵션 목록 */
  statusOptions?: StatusOption[];
  /** 기간 필터 표시 여부 */
  showDateFilter?: boolean;
  startDate?: string;
  endDate?: string;
  onDateRangeChange?: (start: string, end: string) => void;
  searchPlaceholder?: string;
  className?: string;
}

const ALL_OPTION: StatusOption = { label: '전체', value: '' };

/**
 * 리스트 화면 상단 필터 바.
 * 검색어·상태 칩·기간 선택을 조합해 사용할 수 있습니다.
 * 상태는 URL Query String 과 연동하려면 useListFilter 훅과 함께 사용합니다.
 *
 * @example
 * const { filter, setSearch, setStatus } = useListFilter();
 * <SearchFilterBar
 *   search={filter.search}
 *   onSearchChange={setSearch}
 *   status={filter.status}
 *   onStatusChange={setStatus}
 *   statusOptions={[
 *     { label: '대기', value: 'PENDING' },
 *     { label: '완료', value: 'DONE' },
 *   ]}
 * />
 */
export const SearchFilterBar = ({
  search,
  onSearchChange,
  status = '',
  onStatusChange,
  statusOptions = [],
  showDateFilter = false,
  startDate = '',
  endDate = '',
  onDateRangeChange,
  searchPlaceholder = '검색어를 입력하세요',
  className = '',
}: SearchFilterBarProps) => {
  const inputRef = useRef<HTMLInputElement>(null);

  const handleSearchChange = (e: ChangeEvent<HTMLInputElement>) =>
    onSearchChange(e.target.value);

  const clearSearch = () => {
    onSearchChange('');
    inputRef.current?.focus();
  };

  const chips = [ALL_OPTION, ...statusOptions];

  return (
    <div className={`space-y-3 bg-white px-4 py-3 ${className}`}>
      {/* 검색 입력 */}
      <div className="relative flex items-center">
        <Search
          size={16}
          className="absolute left-3 text-gray-400"
          aria-hidden="true"
        />
        <input
          ref={inputRef}
          type="search"
          role="searchbox"
          value={search}
          onChange={handleSearchChange}
          placeholder={searchPlaceholder}
          className="h-11 w-full rounded-lg border border-gray-200 bg-gray-50 pl-9 pr-9 text-sm outline-none transition-colors focus:border-blue-500 focus:bg-white focus:ring-2 focus:ring-blue-100"
        />
        {search && (
          <button
            type="button"
            onClick={clearSearch}
            aria-label="검색어 지우기"
            className="absolute right-3 flex size-5 items-center justify-center rounded-full bg-gray-300 text-white hover:bg-gray-400"
          >
            <X size={12} />
          </button>
        )}
      </div>

      {/* 상태 필터 칩 */}
      {onStatusChange && chips.length > 1 && (
        <div role="group" aria-label="상태 필터" className="flex gap-2 overflow-x-auto pb-1">
          {chips.map((option) => (
            <button
              key={option.value}
              type="button"
              onClick={() => onStatusChange(option.value)}
              aria-pressed={status === option.value}
              className={`flex-shrink-0 rounded-full px-4 py-1.5 text-sm font-medium transition-colors ${
                status === option.value
                  ? 'bg-blue-600 text-white'
                  : 'border border-gray-200 bg-white text-gray-600 hover:border-blue-300'
              }`}
            >
              {option.label}
            </button>
          ))}
        </div>
      )}

      {/* 기간 필터 */}
      {showDateFilter && onDateRangeChange && (
        <div className="flex items-center gap-2">
          <input
            type="date"
            value={startDate}
            onChange={(e) => onDateRangeChange(e.target.value, endDate)}
            className="h-9 flex-1 rounded-lg border border-gray-200 px-2 text-sm text-gray-700 focus:border-blue-500 focus:outline-none"
            aria-label="시작일"
          />
          <span className="text-sm text-gray-400">~</span>
          <input
            type="date"
            value={endDate}
            min={startDate}
            onChange={(e) => onDateRangeChange(startDate, e.target.value)}
            className="h-9 flex-1 rounded-lg border border-gray-200 px-2 text-sm text-gray-700 focus:border-blue-500 focus:outline-none"
            aria-label="종료일"
          />
        </div>
      )}
    </div>
  );
};
