import { type ComponentProps, useId } from 'react';

interface CheckboxProps extends Omit<ComponentProps<'input'>, 'type'> {
  label: string;
  error?: string;
}

export const Checkbox = ({
  label,
  error,
  id: externalId,
  className = '',
  ...props
}: CheckboxProps) => {
  const generatedId = useId();
  const id = externalId ?? generatedId;
  const errorId = `${id}-error`;

  return (
    <div className={`flex flex-col gap-1 ${className}`}>
      <label className="flex cursor-pointer items-center gap-2.5">
        <input
          id={id}
          type="checkbox"
          aria-invalid={!!error}
          aria-describedby={error ? errorId : undefined}
          className="size-4 cursor-pointer rounded border-gray-300 text-blue-600 focus:ring-blue-500 disabled:cursor-not-allowed"
          {...props}
        />
        <span className="text-sm text-gray-700">{label}</span>
      </label>
      {error && (
        <p id={errorId} role="alert" className="text-xs text-red-500">
          {error}
        </p>
      )}
    </div>
  );
};
