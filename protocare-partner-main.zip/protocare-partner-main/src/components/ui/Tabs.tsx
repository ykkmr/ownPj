import { type ReactNode } from 'react';

interface Tab {
  id: string;
  label: string;
  disabled?: boolean;
}

interface TabsProps {
  tabs: Tab[];
  activeId: string;
  onChange: (id: string) => void;
  children: ReactNode;
}

interface TabPanelProps {
  id: string;
  activeId: string;
  children: ReactNode;
}

export const Tabs = ({ tabs, activeId, onChange, children }: TabsProps) => (
  <div>
    <div role="tablist" className="flex border-b border-gray-200">
      {tabs.map((tab) => (
        <button
          key={tab.id}
          role="tab"
          type="button"
          id={`tab-${tab.id}`}
          aria-selected={activeId === tab.id}
          aria-controls={`panel-${tab.id}`}
          disabled={tab.disabled}
          onClick={() => onChange(tab.id)}
          className={`h-11 px-4 text-sm font-medium transition-colors focus-visible:outline-2 disabled:cursor-not-allowed disabled:text-gray-400 ${
            activeId === tab.id
              ? 'border-b-2 border-blue-600 text-blue-600'
              : 'text-gray-500 hover:text-gray-700'
          }`}
        >
          {tab.label}
        </button>
      ))}
    </div>
    {children}
  </div>
);

export const TabPanel = ({ id, activeId, children }: TabPanelProps) => {
  if (id !== activeId) return null;

  return (
    <div role="tabpanel" id={`panel-${id}`} aria-labelledby={`tab-${id}`}>
      {children}
    </div>
  );
};
