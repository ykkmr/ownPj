type AvatarSize = 'sm' | 'md' | 'lg' | 'xl';

interface AvatarProps {
  name: string;
  src?: string;
  size?: AvatarSize;
}

const sizeClass: Record<AvatarSize, string> = {
  sm: 'size-8 text-xs',
  md: 'size-10 text-sm',
  lg: 'size-12 text-base',
  xl: 'size-16 text-xl',
};

const getInitials = (name: string): string => {
  const words = name.trim().split(/\s+/);
  if (words.length === 1) return (words[0]?.[0] ?? '').toUpperCase();
  return ((words[0]?.[0] ?? '') + (words[words.length - 1]?.[0] ?? '')).toUpperCase();
};

export const Avatar = ({ name, src, size = 'md' }: AvatarProps) => {
  if (src) {
    return <img src={src} alt={name} className={`rounded-full object-cover ${sizeClass[size]}`} />;
  }

  return (
    <span
      aria-label={name}
      className={`inline-flex items-center justify-center rounded-full bg-blue-100 font-semibold text-blue-700 ${sizeClass[size]}`}
    >
      {getInitials(name)}
    </span>
  );
};
