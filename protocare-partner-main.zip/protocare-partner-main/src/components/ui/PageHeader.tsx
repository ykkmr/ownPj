import { type ReactNode } from 'react';
import { useNavigate } from 'react-router-dom';

interface PageHeaderProps {
  title: string;
  showBack?: boolean;
  onBack?: () => void;
  right?: ReactNode;
}

export const PageHeader = ({ title, showBack = false, onBack, right }: PageHeaderProps) => {
  const navigate = useNavigate();

  const handleBack = () => {
    if (onBack) {
      onBack();
    } else {
      navigate(-1);
    }
  };

  return (
    <header className="flex h-14 items-center justify-between border-b border-gray-100 bg-white px-4">
      <div className="w-10">
        {showBack && (
          <button
            type="button"
            onClick={handleBack}
            aria-label="뒤로가기"
            className="flex size-10 items-center justify-center rounded-lg text-gray-600 hover:bg-gray-100"
          >
            ←
          </button>
        )}
      </div>
      <h1 className="text-base font-semibold text-gray-900">{title}</h1>
      <div className="flex w-10 justify-end">{right}</div>
    </header>
  );
};
