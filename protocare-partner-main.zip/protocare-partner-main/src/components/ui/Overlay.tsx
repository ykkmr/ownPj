import { type ReactNode } from 'react';
import { Spinner } from './Spinner';

interface OverlayProps {
  isVisible: boolean;
  onClick?: () => void;
  isLoading?: boolean;
  loadingLabel?: string;
  className?: string;
  children?: ReactNode;
}

export const Overlay = ({
  isVisible,
  onClick,
  isLoading = false,
  loadingLabel = '로딩 중',
  className = '',
  children,
}: OverlayProps) => {
  if (!isVisible) return null;

  const isClickable = Boolean(onClick) && !isLoading;

  return (
    <div
      aria-hidden={!isLoading}
      aria-busy={isLoading}
      aria-label={isLoading ? loadingLabel : undefined}
      onClick={isClickable ? onClick : undefined}
      className={`fixed inset-0 z-40 bg-black/50 ${isClickable ? 'cursor-pointer' : 'cursor-default'} ${className}`}
    >
      {isLoading && (
        <div className="flex h-full items-center justify-center">
          <Spinner size="lg" />
        </div>
      )}
      {children}
    </div>
  );
};
