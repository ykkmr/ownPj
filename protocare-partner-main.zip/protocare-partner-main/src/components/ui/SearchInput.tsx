import { type ComponentProps } from 'react';

interface SearchInputProps extends Omit<ComponentProps<'input'>, 'type'> {
  onClear?: () => void;
}

export const SearchInput = ({
  value,
  onClear,
  className = '',
  ...props
}: SearchInputProps) => {
  const hasValue = Boolean(value);

  return (
    <div className={`relative flex items-center ${className}`}>
      <span className="pointer-events-none absolute left-3 text-gray-400" aria-hidden="true">
        <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
          <path
            d="M7 12A5 5 0 1 0 7 2a5 5 0 0 0 0 10ZM14 14l-3-3"
            stroke="currentColor"
            strokeWidth="1.5"
            strokeLinecap="round"
          />
        </svg>
      </span>
      <input
        type="search"
        value={value}
        autoComplete="off"
        className="h-11 w-full rounded-lg border border-gray-300 bg-white pr-10 pl-9 text-sm outline-none transition-colors placeholder:text-gray-400 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 focus:ring-offset-0 disabled:cursor-not-allowed disabled:bg-gray-50"
        {...props}
      />
      {hasValue && onClear && (
        <button
          type="button"
          onClick={onClear}
          aria-label="검색어 지우기"
          className="absolute right-3 flex h-5 w-5 items-center justify-center rounded-full bg-gray-300 text-gray-600 hover:bg-gray-400"
        >
          <svg width="10" height="10" viewBox="0 0 10 10" fill="none" aria-hidden="true">
            <path
              d="M1 1l8 8M9 1L1 9"
              stroke="currentColor"
              strokeWidth="1.5"
              strokeLinecap="round"
            />
          </svg>
        </button>
      )}
    </div>
  );
};
