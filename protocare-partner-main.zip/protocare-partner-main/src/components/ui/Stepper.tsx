interface StepperStep {
  label: string;
  description?: string;
}

interface StepperProps {
  steps: StepperStep[];
  currentStep: number;
  className?: string;
}

type StepState = 'completed' | 'active' | 'pending';

const getStepState = (index: number, currentStep: number): StepState => {
  if (index < currentStep) return 'completed';
  if (index === currentStep) return 'active';
  return 'pending';
};

const stepCircleClass: Record<StepState, string> = {
  completed: 'bg-blue-600 border-blue-600 text-white',
  active: 'bg-white border-blue-600 text-blue-600',
  pending: 'bg-white border-gray-300 text-gray-400',
};

const stepLabelClass: Record<StepState, string> = {
  completed: 'text-blue-600',
  active: 'text-gray-900 font-medium',
  pending: 'text-gray-400',
};

export const Stepper = ({ steps, currentStep, className = '' }: StepperProps) => (
  <nav aria-label="진행 단계" className={`w-full ${className}`}>
    <ol className="flex items-start">
      {steps.map((step, index) => {
        const state = getStepState(index, currentStep);
        const isLast = index === steps.length - 1;

        return (
          <li key={step.label} className="flex flex-1 flex-col items-center">
            <div className="flex w-full items-center">
              <div className="flex flex-1 justify-center">
                <span
                  aria-current={state === 'active' ? 'step' : undefined}
                  className={`flex h-8 w-8 items-center justify-center rounded-full border-2 text-sm font-semibold transition-colors ${stepCircleClass[state]}`}
                >
                  {state === 'completed' ? (
                    <svg width="14" height="14" viewBox="0 0 14 14" fill="none" aria-hidden="true">
                      <path
                        d="M2 7l4 4 6-6"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                    </svg>
                  ) : (
                    index + 1
                  )}
                </span>
              </div>
              {!isLast && (
                <div
                  className={`h-0.5 flex-1 transition-colors ${state === 'completed' ? 'bg-blue-600' : 'bg-gray-200'}`}
                />
              )}
            </div>
            <div className="mt-2 flex flex-col items-center text-center">
              <span className={`text-xs ${stepLabelClass[state]}`}>{step.label}</span>
              {step.description && (
                <span className="mt-0.5 text-xs text-gray-400">{step.description}</span>
              )}
            </div>
          </li>
        );
      })}
    </ol>
  </nav>
);
