type SpinnerSize = 'sm' | 'md' | 'lg';

interface SpinnerProps {
  size?: SpinnerSize;
  label?: string;
}

const sizeClass: Record<SpinnerSize, string> = {
  sm: 'size-4 border-2',
  md: 'size-6 border-2',
  lg: 'size-8 border-[3px]',
};

export const Spinner = ({ size = 'md', label = '로딩 중' }: SpinnerProps) => (
  <span
    role="status"
    aria-label={label}
    className={`inline-block animate-spin rounded-full border-current border-r-transparent ${sizeClass[size]}`}
  />
);
