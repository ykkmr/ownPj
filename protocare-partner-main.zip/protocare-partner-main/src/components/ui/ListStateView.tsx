import type { ReactNode } from 'react';
import { FullPageLoader, type FullPageLoaderVariant } from './FullPageLoader';
import { EmptyState } from './EmptyState';
import { ErrorState } from './ErrorState';
import type { ErrorStateVariant } from './ErrorState';

interface ListStateViewProps {
  isLoading: boolean;
  isError?: boolean;
  isEmpty?: boolean;
  /** 에러 재시도 콜백 */
  onRetry?: () => void;
  /** 로딩 스켈레톤 변형. 기본 'list' */
  skeletonVariant?: FullPageLoaderVariant;
  skeletonRows?: number;
  /** 빈 상태 텍스트 */
  emptyTitle?: string;
  emptyDescription?: string;
  emptyAction?: ReactNode;
  emptyIcon?: ReactNode;
  /** 에러 상태 변형 */
  errorVariant?: ErrorStateVariant;
  children: ReactNode;
}

/**
 * 리스트 화면의 로딩·빈 상태·에러 상태를 하나로 처리하는 뷰 컴포넌트.
 * TanStack Query 의 isLoading / isError 와 바로 연결해 사용합니다.
 *
 * @example
 * const { data, isLoading, isError, refetch } = useQuery(...);
 *
 * <ListStateView
 *   isLoading={isLoading}
 *   isError={isError}
 *   isEmpty={data?.length === 0}
 *   onRetry={refetch}
 *   emptyTitle="일정이 없습니다."
 *   emptyDescription="새 일정을 추가해 보세요."
 * >
 *   {data?.map((item) => <ScheduleCard key={item.id} item={item} />)}
 * </ListStateView>
 */
export const ListStateView = ({
  isLoading,
  isError = false,
  isEmpty = false,
  onRetry,
  skeletonVariant = 'list',
  skeletonRows = 5,
  emptyTitle = '조회된 항목이 없습니다.',
  emptyDescription,
  emptyAction,
  emptyIcon,
  errorVariant = 'generic',
  children,
}: ListStateViewProps) => {
  if (isLoading) {
    return <FullPageLoader variant={skeletonVariant} rows={skeletonRows} />;
  }

  if (isError) {
    return <ErrorState variant={errorVariant} onRetry={onRetry} />;
  }

  if (isEmpty) {
    return (
      <EmptyState
        title={emptyTitle}
        description={emptyDescription}
        action={emptyAction}
        icon={emptyIcon}
      />
    );
  }

  return <>{children}</>;
};
