import { useState, useCallback, type ReactNode, type ChangeEvent } from 'react';

export interface ValidationRule<V = unknown> {
  required?: boolean | string;
  minLength?: { value: number; message: string };
  maxLength?: { value: number; message: string };
  pattern?: { value: RegExp; message: string };
  validate?: (value: V) => string | true;
}

type FieldErrors<T> = Partial<Record<keyof T, string>>;
type ValidationRules<T> = { [K in keyof T]?: ValidationRule<T[K]> };

export interface UseFormReturn<T extends Record<string, unknown>> {
  values: T;
  errors: FieldErrors<T>;
  isValid: boolean;
  isDirty: boolean;
  setValue: <K extends keyof T>(field: K, value: T[K]) => void;
  setError: (field: keyof T, message: string) => void;
  validate: () => boolean;
  reset: () => void;
  handleChange: <K extends keyof T>(
    field: K
  ) => (e: ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => void;
}

function validateField<V>(value: V, rule: ValidationRule<V>): string | null {
  if (rule.required) {
    const msg = typeof rule.required === 'string' ? rule.required : '필수 입력 항목입니다.';
    const isEmpty = value === null || value === undefined || (typeof value === 'string' && !value.trim());
    if (isEmpty) return msg;
  }

  if (typeof value === 'string') {
    if (rule.minLength && value.length < rule.minLength.value) return rule.minLength.message;
    if (rule.maxLength && value.length > rule.maxLength.value) return rule.maxLength.message;
    if (rule.pattern && !rule.pattern.value.test(value)) return rule.pattern.message;
  }

  if (rule.validate) {
    const result = rule.validate(value);
    if (typeof result === 'string') return result;
  }

  return null;
}

/**
 * 폼 상태 및 유효성 검사를 관리하는 훅.
 *
 * @example
 * const form = useForm({
 *   initialValues: { name: '', email: '' },
 *   rules: {
 *     name: { required: '이름을 입력해 주세요.' },
 *     email: { required: true, pattern: { value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/, message: '이메일 형식이 아닙니다.' } },
 *   },
 * });
 */
export function useForm<T extends Record<string, unknown>>({
  initialValues,
  rules = {} as ValidationRules<T>,
}: {
  initialValues: T;
  rules?: ValidationRules<T>;
}): UseFormReturn<T> {
  const [values, setValues] = useState<T>(initialValues);
  const [errors, setErrors] = useState<FieldErrors<T>>({});
  const [isDirty, setIsDirty] = useState(false);

  const setValue = useCallback(<K extends keyof T>(field: K, value: T[K]) => {
    setValues((prev) => ({ ...prev, [field]: value }));
    setErrors((prev) => ({ ...prev, [field]: undefined }));
    setIsDirty(true);
  }, []);

  const setError = useCallback((field: keyof T, message: string) => {
    setErrors((prev) => ({ ...prev, [field]: message }));
  }, []);

  const validate = useCallback((): boolean => {
    const newErrors: FieldErrors<T> = {};
    for (const key of Object.keys(rules) as (keyof T)[]) {
      const rule = rules[key];
      if (!rule) continue;
      const error = validateField(values[key], rule as ValidationRule<T[keyof T]>);
      if (error) newErrors[key] = error;
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  }, [values, rules]);

  const reset = useCallback(() => {
    setValues(initialValues);
    setErrors({});
    setIsDirty(false);
  }, [initialValues]);

  const handleChange = useCallback(
    <K extends keyof T>(field: K) =>
      (e: ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
        setValue(field, e.target.value as T[K]);
      },
    [setValue]
  );

  const isValid = Object.values(errors).every((e) => !e);

  return { values, errors, isValid, isDirty, setValue, setError, validate, reset, handleChange };
}

interface FormControllerProps<T extends Record<string, unknown>> {
  initialValues: T;
  rules?: ValidationRules<T>;
  onSubmit: (values: T) => void | Promise<void>;
  children: (form: UseFormReturn<T>) => ReactNode;
}

/**
 * render-prop 방식의 폼 컨트롤러 컴포넌트.
 * 제출 시 validate()를 자동 실행하고 오류가 없을 때만 onSubmit을 호출합니다.
 */
export function FormController<T extends Record<string, unknown>>({
  initialValues,
  rules,
  onSubmit,
  children,
}: FormControllerProps<T>) {
  const form = useForm({ initialValues, rules });

  const handleSubmit = (e: { preventDefault: () => void }) => {
    e.preventDefault();
    if (form.validate()) {
      onSubmit(form.values);
    }
  };

  return <form onSubmit={handleSubmit} noValidate>{children(form)}</form>;
}