type ProgressBarVariant = 'default' | 'success' | 'warning' | 'danger';
type ProgressBarSize = 'sm' | 'md' | 'lg';

interface ProgressBarProps {
  value: number;
  max?: number;
  variant?: ProgressBarVariant;
  size?: ProgressBarSize;
  label?: string;
  showValue?: boolean;
  className?: string;
}

const variantClass: Record<ProgressBarVariant, string> = {
  default: 'bg-blue-600',
  success: 'bg-green-500',
  warning: 'bg-yellow-500',
  danger: 'bg-red-500',
};

const sizeClass: Record<ProgressBarSize, string> = {
  sm: 'h-1',
  md: 'h-2',
  lg: 'h-3',
};

export const ProgressBar = ({
  value,
  max = 100,
  variant = 'default',
  size = 'md',
  label,
  showValue = false,
  className = '',
}: ProgressBarProps) => {
  const clamped = Math.min(Math.max(value, 0), max);
  const percent = Math.round((clamped / max) * 100);

  return (
    <div className={`w-full ${className}`}>
      {(label || showValue) && (
        <div className="mb-1.5 flex items-center justify-between">
          {label && <span className="text-sm text-gray-700">{label}</span>}
          {showValue && <span className="text-xs text-gray-500">{percent}%</span>}
        </div>
      )}
      <div
        role="progressbar"
        aria-valuenow={clamped}
        aria-valuemin={0}
        aria-valuemax={max}
        aria-label={label}
        className={`w-full overflow-hidden rounded-full bg-gray-200 ${sizeClass[size]}`}
      >
        <div
          className={`h-full rounded-full transition-all duration-300 ${variantClass[variant]}`}
          style={{ width: `${percent}%` }}
        />
      </div>
    </div>
  );
};
