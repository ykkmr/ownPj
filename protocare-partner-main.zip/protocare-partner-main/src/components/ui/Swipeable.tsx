import { useState, useRef, type ReactNode } from 'react';

interface SwipeableProps {
  children: ReactNode[];
  showDots?: boolean;
  showArrows?: boolean;
  loop?: boolean;
  className?: string;
  onSlideChange?: (index: number) => void;
}

const SWIPE_THRESHOLD = 50;

export const Swipeable = ({
  children,
  showDots = true,
  showArrows = false,
  loop = false,
  className = '',
  onSlideChange,
}: SwipeableProps) => {
  const [activeIndex, setActiveIndex] = useState(0);
  const startXRef = useRef<number | null>(null);
  const isDraggingRef = useRef(false);

  const total = children.length;

  const goTo = (index: number) => {
    const clamped = loop
      ? (index + total) % total
      : Math.min(Math.max(index, 0), total - 1);
    setActiveIndex(clamped);
    onSlideChange?.(clamped);
  };

  const handleTouchStart = (e: React.TouchEvent) => {
    startXRef.current = e.touches[0]?.clientX ?? null;
    isDraggingRef.current = false;
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (startXRef.current === null) return;
    const delta = (e.touches[0]?.clientX ?? 0) - startXRef.current;
    if (Math.abs(delta) > 10) isDraggingRef.current = true;
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    if (startXRef.current === null || !isDraggingRef.current) return;
    const delta = (e.changedTouches[0]?.clientX ?? 0) - startXRef.current;
    if (delta < -SWIPE_THRESHOLD) goTo(activeIndex + 1);
    else if (delta > SWIPE_THRESHOLD) goTo(activeIndex - 1);
    startXRef.current = null;
  };

  const canGoPrev = loop || activeIndex > 0;
  const canGoNext = loop || activeIndex < total - 1;

  return (
    <div
      className={`relative overflow-hidden ${className}`}
      role="region"
      aria-label="슬라이드"
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
    >
      <div
        className="flex transition-transform duration-300 ease-in-out"
        style={{ transform: `translateX(-${activeIndex * 100}%)` }}
        aria-live="polite"
      >
        {children.map((child, index) => (
          <div
            key={index}
            role="group"
            aria-roledescription="슬라이드"
            aria-label={`${index + 1} / ${total}`}
            aria-hidden={index !== activeIndex}
            className="w-full shrink-0"
          >
            {child}
          </div>
        ))}
      </div>

      {showArrows && (
        <>
          <button
            type="button"
            aria-label="이전 슬라이드"
            disabled={!canGoPrev}
            onClick={() => goTo(activeIndex - 1)}
            className="absolute top-1/2 left-2 flex h-9 w-9 -translate-y-1/2 items-center justify-center rounded-full bg-white/80 shadow-md transition-opacity disabled:opacity-30"
          >
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true">
              <path d="M10 4L6 8l4 4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </button>
          <button
            type="button"
            aria-label="다음 슬라이드"
            disabled={!canGoNext}
            onClick={() => goTo(activeIndex + 1)}
            className="absolute top-1/2 right-2 flex h-9 w-9 -translate-y-1/2 items-center justify-center rounded-full bg-white/80 shadow-md transition-opacity disabled:opacity-30"
          >
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true">
              <path d="M6 4l4 4-4 4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </button>
        </>
      )}

      {showDots && total > 1 && (
        <div role="tablist" aria-label="슬라이드 목록" className="absolute bottom-3 left-0 right-0 flex justify-center gap-1.5">
          {Array.from({ length: total }, (_, i) => (
            <button
              key={i}
              type="button"
              role="tab"
              aria-selected={i === activeIndex}
              aria-label={`${i + 1}번 슬라이드`}
              onClick={() => goTo(i)}
              className={`h-2 rounded-full transition-all ${i === activeIndex ? 'w-4 bg-white' : 'w-2 bg-white/50'}`}
            />
          ))}
        </div>
      )}
    </div>
  );
};
