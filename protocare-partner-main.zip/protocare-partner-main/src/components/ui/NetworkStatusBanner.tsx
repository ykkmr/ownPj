import { useEffect, useRef, useState } from 'react';
import { useNetworkStatus } from '@/hooks/useNetworkStatus';

const RECONNECTED_BANNER_DURATION_MS = 3_000;

/**
 * 네트워크 상태 배너.
 * - 오프라인: 화면 상단에 빨간색 배너를 고정 표시합니다.
 * - 복구됨: 초록색 배너를 3초간 표시 후 사라집니다.
 *
 * App.tsx 최상단에 한 번만 마운트합니다.
 */
export const NetworkStatusBanner = () => {
  const { isOnline } = useNetworkStatus();
  const [showReconnected, setShowReconnected] = useState(false);
  const prevOnlineRef = useRef(true);

  useEffect(() => {
    const wasOffline = !prevOnlineRef.current;
    prevOnlineRef.current = isOnline;

    if (wasOffline && isOnline) {
      setShowReconnected(true);
      const timer = setTimeout(() => setShowReconnected(false), RECONNECTED_BANNER_DURATION_MS);
      return () => clearTimeout(timer);
    }
  }, [isOnline]);

  if (isOnline && !showReconnected) return null;

  const isOffline = !isOnline;

  return (
    <div
      role="status"
      aria-live="polite"
      className={`fixed inset-x-0 top-0 z-[400] py-2 text-center text-sm font-medium text-white transition-colors ${
        isOffline ? 'bg-red-500' : 'bg-green-500'
      }`}
    >
      {isOffline
        ? '오프라인 상태입니다. 인터넷 연결을 확인해 주세요.'
        : '인터넷 연결이 복구되었습니다.'}
    </div>
  );
};