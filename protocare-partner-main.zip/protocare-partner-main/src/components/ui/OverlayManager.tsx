import { useState } from 'react';
import {
  useOverlayStore,
  type ConfirmOverlay,
  type NoticeOverlay,
  type ConsentOverlay,
  type CustomOverlay,
} from '@/store/overlay.store';
import { Button } from './Button';

// ── Confirm ───────────────────────────────────────────────────────────────────

const ConfirmOverlayView = ({
  item,
  onClose,
}: {
  item: ConfirmOverlay;
  onClose: () => void;
}) => {
  const [isPending, setIsPending] = useState(false);

  const handleConfirm = async () => {
    setIsPending(true);
    try {
      await item.onConfirm();
    } finally {
      setIsPending(false);
      onClose();
    }
  };

  const handleCancel = () => {
    item.onCancel?.();
    onClose();
  };

  return (
    <div
      role="alertdialog"
      aria-modal="true"
      aria-labelledby="overlay-title"
      aria-describedby="overlay-desc"
      className="fixed left-1/2 top-1/2 z-[110] w-[calc(100%-3rem)] max-w-sm -translate-x-1/2 -translate-y-1/2 rounded-2xl bg-white p-6 shadow-xl"
    >
      <h2 id="overlay-title" className="mb-2 text-base font-bold text-gray-900">
        {item.title}
      </h2>
      <p id="overlay-desc" className="mb-6 text-sm leading-relaxed text-gray-600">
        {item.message}
      </p>
      <div className="flex gap-3">
        <Button variant="secondary" className="flex-1" onClick={handleCancel} disabled={isPending}>
          {item.cancelLabel ?? '취소'}
        </Button>
        <Button
          variant={item.variant === 'danger' ? 'danger' : 'primary'}
          className="flex-1"
          isLoading={isPending}
          onClick={handleConfirm}
        >
          {item.confirmLabel ?? '확인'}
        </Button>
      </div>
    </div>
  );
};

// ── Notice ────────────────────────────────────────────────────────────────────

const NoticeOverlayView = ({
  item,
  onClose,
}: {
  item: NoticeOverlay;
  onClose: (dismissToday: boolean) => void;
}) => {
  const [dismissToday, setDismissToday] = useState(false);

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="notice-title"
      className="fixed left-1/2 top-1/2 z-[110] w-[calc(100%-3rem)] max-w-sm -translate-x-1/2 -translate-y-1/2 overflow-hidden rounded-2xl bg-white shadow-xl"
    >
      {item.imageUrl && (
        <img src={item.imageUrl} alt="" aria-hidden="true" className="h-44 w-full object-cover" />
      )}
      <div className="p-6">
        <h2 id="notice-title" className="mb-2 text-base font-bold text-gray-900">
          {item.title}
        </h2>
        <p className="text-sm leading-relaxed text-gray-600">{item.message}</p>
      </div>
      <div className="flex items-center justify-between border-t border-gray-100 px-4 py-3">
        {item.allowDismissToday && item.dismissKey ? (
          <label className="flex cursor-pointer items-center gap-2 text-sm text-gray-500">
            <input
              type="checkbox"
              checked={dismissToday}
              onChange={(e) => setDismissToday(e.target.checked)}
              className="rounded"
            />
            오늘 하루 보지 않기
          </label>
        ) : (
          <span />
        )}
        <button
          type="button"
          onClick={() => onClose(dismissToday)}
          className="min-h-[44px] px-4 text-sm font-medium text-blue-600"
        >
          닫기
        </button>
      </div>
    </div>
  );
};

// ── Consent ───────────────────────────────────────────────────────────────────

const ConsentOverlayView = ({
  item,
  onClose,
}: {
  item: ConsentOverlay;
  onClose: () => void;
}) => {
  const [agreed, setAgreed] = useState<Record<string, boolean>>(
    Object.fromEntries(item.items.map((i) => [i.id, false]))
  );
  const [isPending, setIsPending] = useState(false);

  const toggle = (id: string) =>
    setAgreed((prev) => ({ ...prev, [id]: !prev[id] }));

  const allRequiredChecked = item.items
    .filter((i) => i.required)
    .every((i) => agreed[i.id]);

  const handleConsent = async () => {
    if (!allRequiredChecked) return;
    setIsPending(true);
    try {
      await item.onConsent(agreed);
      onClose();
    } finally {
      setIsPending(false);
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="consent-title"
      className="fixed inset-x-0 bottom-0 z-[110] rounded-t-2xl bg-white px-4 pb-8 pt-6 shadow-xl"
    >
      <div className="mx-auto mb-4 h-1 w-10 rounded-full bg-gray-200" />
      <h2 id="consent-title" className="mb-4 text-base font-bold text-gray-900">
        {item.title}
      </h2>
      <ul className="mb-6 space-y-3">
        {item.items.map((i) => (
          <li key={i.id}>
            <label className="flex cursor-pointer items-center gap-3">
              <input
                type="checkbox"
                checked={agreed[i.id] ?? false}
                onChange={() => toggle(i.id)}
                className="size-5 rounded border-gray-300 accent-blue-600"
              />
              <span className="text-sm text-gray-700">
                {i.required && <span className="mr-1 text-red-500">*</span>}
                {i.label}
              </span>
            </label>
          </li>
        ))}
      </ul>
      <Button
        className="w-full"
        onClick={handleConsent}
        disabled={!allRequiredChecked}
        isLoading={isPending}
      >
        동의하기
      </Button>
    </div>
  );
};

// ── Custom ────────────────────────────────────────────────────────────────────

const CustomOverlayView = ({ item, onClose }: { item: CustomOverlay; onClose: () => void }) => (
  <>{item.render(onClose)}</>
);

// ── Manager ───────────────────────────────────────────────────────────────────

/**
 * 전역 오버레이 렌더러.
 * App.tsx 최상단에 한 번만 마운트하고, overlay.push() 로 어디서든 팝업을 띄웁니다.
 * 높은 priority 가 먼저 표시됩니다.
 */
export const OverlayManager = () => {
  const { queue, dismiss } = useOverlayStore();
  const current = queue[0];

  if (!current) return null;

  const backdrop = (
    <div
      aria-hidden="true"
      className="fixed inset-0 z-[100] bg-black/50"
      onClick={() => dismiss(current.id)}
    />
  );

  const renderOverlay = () => {
    switch (current.type) {
      case 'confirm':
        return (
          <ConfirmOverlayView
            item={current}
            onClose={() => dismiss(current.id)}
          />
        );
      case 'notice':
        return (
          <NoticeOverlayView
            item={current}
            onClose={(dismissToday) => dismiss(current.id, dismissToday)}
          />
        );
      case 'consent':
        return (
          <ConsentOverlayView
            item={current}
            onClose={() => dismiss(current.id)}
          />
        );
      case 'custom':
        return (
          <CustomOverlayView
            item={current}
            onClose={() => dismiss(current.id)}
          />
        );
    }
  };

  return (
    <>
      {backdrop}
      {renderOverlay()}
    </>
  );
};