import { useLoadingStore } from '@/store/loading.store';
import { Spinner } from './Spinner';

/**
 * 전역 풀스크린 로딩 오버레이.
 * App.tsx 최상단에 한 번만 렌더링하고, globalLoading.show/hide() 로 어디서든 제어합니다.
 */
export const GlobalLoading = () => {
  const { count, message } = useLoadingStore();

  if (count === 0) return null;

  return (
    <div
      role="status"
      aria-live="polite"
      aria-label={message}
      className="fixed inset-0 z-[200] flex items-center justify-center bg-black/40"
    >
      <div className="flex flex-col items-center gap-3 rounded-2xl bg-white px-8 py-6 shadow-xl">
        <Spinner size="lg" />
        <p className="text-sm font-medium text-gray-700">{message}</p>
      </div>
    </div>
  );
};