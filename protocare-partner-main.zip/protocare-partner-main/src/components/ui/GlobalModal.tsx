import { useState } from 'react';
import { useModalStore } from '@/store/modal.store';
import { Button } from './Button';

/**
 * 전역 확인 모달.
 * App.tsx 최상단에 한 번만 렌더링하고, modal.confirm() 으로 어디서든 제어합니다.
 */
export const GlobalModal = () => {
  const { isOpen, options, close } = useModalStore();
  const [isPending, setIsPending] = useState(false);

  if (!isOpen) return null;

  const handleConfirm = async () => {
    setIsPending(true);
    try {
      await options.onConfirm();
    } finally {
      setIsPending(false);
      close();
    }
  };

  const handleCancel = () => {
    options.onCancel?.();
    close();
  };

  return (
    <>
      <div
        aria-hidden="true"
        className="fixed inset-0 z-50 bg-black/50"
        onClick={handleCancel}
      />
      <div
        role="alertdialog"
        aria-modal="true"
        aria-labelledby="gmodal-title"
        aria-describedby="gmodal-desc"
        className="fixed left-1/2 top-1/2 z-50 w-[calc(100%-3rem)] max-w-sm -translate-x-1/2 -translate-y-1/2 rounded-2xl bg-white p-6 shadow-xl"
      >
        <h2 id="gmodal-title" className="mb-2 text-base font-bold text-gray-900">
          {options.title}
        </h2>
        <p id="gmodal-desc" className="mb-6 text-sm leading-relaxed text-gray-600">
          {options.message}
        </p>
        <div className="flex gap-3">
          <Button variant="secondary" className="flex-1" onClick={handleCancel} disabled={isPending}>
            {options.cancelLabel}
          </Button>
          <Button
            variant={options.variant === 'danger' ? 'danger' : 'primary'}
            className="flex-1"
            isLoading={isPending}
            onClick={handleConfirm}
          >
            {options.confirmLabel}
          </Button>
        </div>
      </div>
    </>
  );
};