import { useState, useRef, useEffect, useCallback } from 'react';
import { useClickOutside } from '@/hooks/useClickOutside';

const TODAY = new Date();

interface DatePickerProps {
  value?: string;
  onChange?: (date: string) => void;
  placeholder?: string;
  min?: string;
  max?: string;
  disabled?: boolean;
  error?: boolean;
  className?: string;
}

interface RangePickerProps {
  startDate?: string;
  endDate?: string;
  onChange?: (range: { startDate: string; endDate: string }) => void;
  placeholder?: string;
  min?: string;
  max?: string;
  disabled?: boolean;
  error?: boolean;
  className?: string;
}

const CalendarIcon = () => (
  <svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true" className="shrink-0 text-gray-400">
    <rect x="1" y="3" width="14" height="12" rx="2" stroke="currentColor" strokeWidth="1.3" />
    <path d="M1 7h14M5 1v4M11 1v4" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" />
  </svg>
);

const formatDisplay = (dateStr: string): string => {
  if (!dateStr) return '';
  const parts = dateStr.split('-');
  if (parts.length !== 3) return dateStr;
  const [y, m, d] = parts;
  return `${y}년 ${m}월 ${d}일`;
};

const DAYS = ['일', '월', '화', '수', '목', '금', '토'];
const TODAY_STR = `${TODAY.getFullYear()}-${String(TODAY.getMonth() + 1).padStart(2, '0')}-${String(TODAY.getDate()).padStart(2, '0')}`;

const getDaysInMonth = (year: number, month: number) => new Date(year, month + 1, 0).getDate();
const getFirstDayOfMonth = (year: number, month: number) => new Date(year, month, 1).getDay();

const toDateString = (year: number, month: number, day: number) =>
  `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;

interface CalendarProps {
  selectedStart?: string;
  selectedEnd?: string;
  rangeMode?: boolean;
  min?: string;
  max?: string;
  onSelect: (date: string) => void;
}

const Calendar = ({ selectedStart, selectedEnd, rangeMode = false, min, max, onSelect }: CalendarProps) => {
  const [viewYear, setViewYear] = useState(
    selectedStart ? parseInt(selectedStart.split('-')[0] ?? String(TODAY.getFullYear())) : TODAY.getFullYear()
  );
  const [viewMonth, setViewMonth] = useState(
    selectedStart ? parseInt(selectedStart.split('-')[1] ?? String(TODAY.getMonth() + 1)) - 1 : TODAY.getMonth()
  );

  const daysInMonth = getDaysInMonth(viewYear, viewMonth);
  const firstDay = getFirstDayOfMonth(viewYear, viewMonth);

  const prevMonth = () => {
    if (viewMonth === 0) { setViewYear(y => y - 1); setViewMonth(11); }
    else setViewMonth(m => m - 1);
  };
  const nextMonth = () => {
    if (viewMonth === 11) { setViewYear(y => y + 1); setViewMonth(0); }
    else setViewMonth(m => m + 1);
  };

  const isDisabled = (dateStr: string) => {
    if (min && dateStr < min) return true;
    if (max && dateStr > max) return true;
    return false;
  };

  const isInRange = (dateStr: string) => {
    if (!rangeMode || !selectedStart || !selectedEnd) return false;
    return dateStr > selectedStart && dateStr < selectedEnd;
  };

  return (
    <div className="w-72 rounded-xl border border-gray-200 bg-white p-4 shadow-lg">
      <div className="mb-3 flex items-center justify-between">
        <button type="button" onClick={prevMonth} aria-label="이전 달" className="flex h-8 w-8 items-center justify-center rounded-lg hover:bg-gray-100">
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M10 4L6 8l4 4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" /></svg>
        </button>
        <span className="text-sm font-semibold text-gray-900">{viewYear}년 {viewMonth + 1}월</span>
        <button type="button" onClick={nextMonth} aria-label="다음 달" className="flex h-8 w-8 items-center justify-center rounded-lg hover:bg-gray-100">
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M6 4l4 4-4 4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" /></svg>
        </button>
      </div>

      <div className="grid grid-cols-7 gap-0.5">
        {DAYS.map((day) => (
          <span key={day} className="flex h-8 items-center justify-center text-xs font-medium text-gray-400">{day}</span>
        ))}
        {Array.from({ length: firstDay }, (_, i) => <span key={`empty-${i}`} />)}
        {Array.from({ length: daysInMonth }, (_, i) => {
          const day = i + 1;
          const dateStr = toDateString(viewYear, viewMonth, day);
          const isStart = dateStr === selectedStart;
          const isEnd = dateStr === selectedEnd;
          const inRange = isInRange(dateStr);
          const disabled = isDisabled(dateStr);
          const isToday = dateStr === TODAY_STR;

          return (
            <button
              key={day}
              type="button"
              disabled={disabled}
              onClick={() => onSelect(dateStr)}
              className={`flex h-8 w-full items-center justify-center rounded-lg text-sm transition-colors disabled:cursor-not-allowed disabled:opacity-30 ${
                isStart || isEnd
                  ? 'bg-blue-600 font-semibold text-white'
                  : inRange
                    ? 'bg-blue-50 text-blue-700'
                    : isToday
                      ? 'font-semibold text-blue-600 ring-1 ring-blue-300'
                      : 'text-gray-700 hover:bg-gray-100'
              }`}
            >
              {day}
            </button>
          );
        })}
      </div>
    </div>
  );
};

export const DatePicker = ({
  value = '',
  onChange,
  placeholder = '날짜 선택',
  min,
  max,
  disabled = false,
  error = false,
  className = '',
}: DatePickerProps) => {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  const close = useCallback(() => setOpen(false), []);
  useClickOutside(ref, close);

  return (
    <div ref={ref} className={`relative ${className}`}>
      <button
        type="button"
        disabled={disabled}
        aria-haspopup="dialog"
        aria-expanded={open}
        onClick={() => setOpen((o) => !o)}
        className={`flex h-11 w-full items-center gap-2 rounded-lg border px-3 text-sm transition-colors disabled:cursor-not-allowed disabled:bg-gray-50 ${
          error
            ? 'border-red-400 focus:border-red-400 focus:ring-2 focus:ring-red-200'
            : 'border-gray-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-200'
        } ${!value ? 'text-gray-400' : 'text-gray-900'}`}
      >
        <CalendarIcon />
        <span className="flex-1 text-left">{value ? formatDisplay(value) : placeholder}</span>
      </button>

      {open && (
        <div className="absolute top-full left-0 z-50 mt-1">
          <Calendar
            selectedStart={value}
            min={min}
            max={max}
            onSelect={(date) => {
              onChange?.(date);
              setOpen(false);
            }}
          />
        </div>
      )}
    </div>
  );
};

export const RangePicker = ({
  startDate = '',
  endDate = '',
  onChange,
  placeholder = '기간 선택',
  min,
  max,
  disabled = false,
  error = false,
  className = '',
}: RangePickerProps) => {
  const [open, setOpen] = useState(false);
  const [selecting, setSelecting] = useState<'start' | 'end'>('start');
  const [tempStart, setTempStart] = useState(startDate);
  const [tempEnd, setTempEnd] = useState(endDate);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setTempStart(startDate);
    setTempEnd(endDate);
  }, [startDate, endDate]);

  const close = useCallback(() => {
    setOpen(false);
    setSelecting('start');
  }, []);
  useClickOutside(ref, close);

  const handleSelect = (date: string) => {
    if (selecting === 'start') {
      setTempStart(date);
      setTempEnd('');
      setSelecting('end');
      return;
    }
    if (!tempStart) return;

    const [resolvedStart, resolvedEnd] = date < tempStart
      ? [date, tempStart]
      : [tempStart, date];

    setTempStart(resolvedStart);
    setTempEnd(resolvedEnd);
    onChange?.({ startDate: resolvedStart, endDate: resolvedEnd });
    setOpen(false);
    setSelecting('start');
  };

  const displayText = () => {
    if (!startDate && !endDate) return placeholder;
    if (startDate && !endDate) return formatDisplay(startDate);
    return `${formatDisplay(startDate)} ~ ${formatDisplay(endDate)}`;
  };

  return (
    <div ref={ref} className={`relative ${className}`}>
      <button
        type="button"
        disabled={disabled}
        aria-haspopup="dialog"
        aria-expanded={open}
        onClick={() => { setOpen((o) => !o); setSelecting('start'); }}
        className={`flex h-11 w-full items-center gap-2 rounded-lg border px-3 text-sm transition-colors disabled:cursor-not-allowed disabled:bg-gray-50 ${
          error
            ? 'border-red-400 focus:ring-2 focus:ring-red-200'
            : 'border-gray-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-200'
        } ${!startDate && !endDate ? 'text-gray-400' : 'text-gray-900'}`}
      >
        <CalendarIcon />
        <span className="flex-1 text-left">{displayText()}</span>
      </button>

      {open && (
        <div className="absolute top-full left-0 z-50 mt-1">
          <div className="mb-2 rounded-lg bg-blue-50 px-3 py-1.5 text-xs text-blue-700">
            {selecting === 'start' ? '시작일을 선택하세요' : '종료일을 선택하세요'}
          </div>
          <Calendar
            selectedStart={tempStart}
            selectedEnd={tempEnd}
            rangeMode
            min={min}
            max={max}
            onSelect={handleSelect}
          />
        </div>
      )}
    </div>
  );
};
