interface SkeletonProps {
  width?: string;
  height?: string;
  rounded?: 'sm' | 'md' | 'lg' | 'full';
  className?: string;
}

const roundedClass = {
  sm: 'rounded',
  md: 'rounded-lg',
  lg: 'rounded-xl',
  full: 'rounded-full',
};

export const Skeleton = ({
  width = '100%',
  height = '1rem',
  rounded = 'md',
  className = '',
}: SkeletonProps) => (
  <div
    aria-hidden="true"
    className={`animate-pulse bg-gray-200 ${roundedClass[rounded]} ${className}`}
    style={{ width, height }}
  />
);
