import { type ReactNode } from 'react';

type AlertVariant = 'info' | 'success' | 'warning' | 'danger';

interface AlertProps {
  variant?: AlertVariant;
  title?: string;
  children: ReactNode;
}

const variantClass: Record<AlertVariant, string> = {
  info: 'bg-blue-50 border-blue-200 text-blue-800',
  success: 'bg-green-50 border-green-200 text-green-800',
  warning: 'bg-yellow-50 border-yellow-200 text-yellow-800',
  danger: 'bg-red-50 border-red-200 text-red-800',
};

const roleMap: Record<AlertVariant, string> = {
  info: 'status',
  success: 'status',
  warning: 'alert',
  danger: 'alert',
};

export const Alert = ({ variant = 'info', title, children }: AlertProps) => (
  <div
    role={roleMap[variant]}
    className={`rounded-lg border px-4 py-3 text-sm ${variantClass[variant]}`}
  >
    {title && <p className="mb-1 font-semibold">{title}</p>}
    <p>{children}</p>
  </div>
);
