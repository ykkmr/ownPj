interface DividerProps {
  direction?: 'horizontal' | 'vertical';
  className?: string;
}

export const Divider = ({ direction = 'horizontal', className = '' }: DividerProps) => {
  if (direction === 'vertical') {
    return <div aria-hidden="true" className={`w-px self-stretch bg-gray-200 ${className}`} />;
  }

  return <hr aria-hidden="true" className={`border-0 border-t border-gray-200 ${className}`} />;
};
