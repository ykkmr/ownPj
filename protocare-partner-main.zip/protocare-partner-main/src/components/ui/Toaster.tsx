import { useToastStore, type ToastItem } from '@/store/toast.store';

const variantClass: Record<ToastItem['variant'], string> = {
  info: 'bg-gray-900 text-white',
  success: 'bg-green-600 text-white',
  warning: 'bg-yellow-500 text-white',
  danger: 'bg-red-600 text-white',
};

export const Toaster = () => {
  const { toasts, remove } = useToastStore();

  if (toasts.length === 0) return null;

  return (
    <div
      aria-live="polite"
      aria-atomic="false"
      className="fixed bottom-safe-or-4 left-1/2 z-50 flex -translate-x-1/2 flex-col gap-2"
    >
      {toasts.map((t) => (
        <div
          key={t.id}
          role="status"
          className={`flex min-w-64 items-center justify-between gap-3 rounded-xl px-4 py-3 text-sm shadow-lg ${variantClass[t.variant]}`}
        >
          <span>{t.message}</span>
          <button
            type="button"
            onClick={() => remove(t.id)}
            aria-label="닫기"
            className="shrink-0 opacity-70 hover:opacity-100"
          >
            ✕
          </button>
        </div>
      ))}
    </div>
  );
};
