import { type ComponentProps } from 'react';

interface InputProps extends ComponentProps<'input'> {
  error?: boolean;
}

export const Input = ({ error = false, className = '', ...props }: InputProps) => (
  <input
    aria-invalid={error}
    className={`h-11 w-full rounded-lg border px-3 text-sm outline-none transition-colors focus:ring-2 focus:ring-offset-0 disabled:cursor-not-allowed disabled:bg-gray-50 disabled:text-gray-400 ${
      error
        ? 'border-red-400 focus:border-red-400 focus:ring-red-200'
        : 'border-gray-300 focus:border-blue-500 focus:ring-blue-200'
    } ${className}`}
    {...props}
  />
);
