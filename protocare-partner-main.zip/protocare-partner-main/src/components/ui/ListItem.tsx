import { type ReactNode } from 'react';

interface ListItemProps {
  title: string;
  description?: string;
  leading?: ReactNode;
  trailing?: ReactNode;
  onClick?: () => void;
  disabled?: boolean;
  destructive?: boolean;
  className?: string;
}

const ChevronRight = () => (
  <svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true" className="shrink-0 text-gray-300">
    <path d="M6 4l4 4-4 4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

export const ListItem = ({
  title,
  description,
  leading,
  trailing,
  onClick,
  disabled = false,
  destructive = false,
  className = '',
}: ListItemProps) => {
  const hasClickHandler = Boolean(onClick);
  const titleColor = destructive ? 'text-red-600' : 'text-gray-900';

  const content = (
    <>
      {leading && (
        <span className="flex h-10 w-10 shrink-0 items-center justify-center text-gray-500">
          {leading}
        </span>
      )}
      <span className="flex min-w-0 flex-1 flex-col gap-0.5">
        <span className={`truncate text-sm font-medium ${titleColor} ${disabled ? 'opacity-50' : ''}`}>
          {title}
        </span>
        {description && (
          <span className={`truncate text-xs text-gray-500 ${disabled ? 'opacity-50' : ''}`}>
            {description}
          </span>
        )}
      </span>
      {trailing !== undefined ? (
        <span className="ml-2 shrink-0">{trailing}</span>
      ) : hasClickHandler && !disabled ? (
        <ChevronRight />
      ) : null}
    </>
  );

  if (hasClickHandler) {
    return (
      <button
        type="button"
        onClick={onClick}
        disabled={disabled}
        className={`flex min-h-14 w-full items-center gap-3 px-4 py-2 text-left transition-colors hover:bg-gray-50 active:bg-gray-100 disabled:cursor-not-allowed disabled:opacity-60 ${className}`}
      >
        {content}
      </button>
    );
  }

  return (
    <div className={`flex min-h-14 items-center gap-3 px-4 py-2 ${className}`}>
      {content}
    </div>
  );
};

interface ListGroupProps {
  children: ReactNode;
  label?: string;
  className?: string;
}

export const ListGroup = ({ children, label, className = '' }: ListGroupProps) => (
  <section className={`overflow-hidden rounded-xl border border-gray-200 bg-white ${className}`}>
    {label && (
      <div className="border-b border-gray-100 px-4 py-2">
        <span className="text-xs font-semibold uppercase tracking-wide text-gray-400">{label}</span>
      </div>
    )}
    <div className="divide-y divide-gray-100">{children}</div>
  </section>
);
