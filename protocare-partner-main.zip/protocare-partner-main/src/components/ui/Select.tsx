import { type ComponentProps } from 'react';

interface SelectOption {
  value: string;
  label: string;
  disabled?: boolean;
}

interface SelectProps extends ComponentProps<'select'> {
  options: SelectOption[];
  placeholder?: string;
  error?: boolean;
}

export const Select = ({
  options,
  placeholder,
  error = false,
  className = '',
  ...props
}: SelectProps) => (
  <select
    aria-invalid={error}
    className={`h-11 w-full rounded-lg border px-3 text-sm outline-none transition-colors focus:ring-2 focus:ring-offset-0 disabled:cursor-not-allowed disabled:bg-gray-50 disabled:text-gray-400 ${
      error
        ? 'border-red-400 focus:border-red-400 focus:ring-red-200'
        : 'border-gray-300 focus:border-blue-500 focus:ring-blue-200'
    } ${className}`}
    {...props}
  >
    {placeholder && (
      <option value="" disabled>
        {placeholder}
      </option>
    )}
    {options.map((opt) => (
      <option key={opt.value} value={opt.value} disabled={opt.disabled}>
        {opt.label}
      </option>
    ))}
  </select>
);
