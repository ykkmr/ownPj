import { ReactNode, useId } from 'react';

interface FormFieldProps {
  label: string;
  error?: string;
  children: ReactNode; // 👈 외부에서 전달하는 Input이나 div를 받음
  className?: string;
}

export const FormField = ({ label, error, children, className = "" }: FormFieldProps) => {
  const generatedId = useId();
  const errorId = `${generatedId}-error`;

  return (
    <div className={`flex flex-col gap-1.5 ${className}`}>
      <label className="text-sm font-medium text-gray-700">
        {label}
      </label>
      
      {/* 이제 여기서 <Input />을 직접 그리지 않고, 
        SignupStep1에서 넘겨준 <div class="flex">...</div>를 그대로 보여줍니다.
      */}
      {children} 

      {error && (
        <p id={errorId} role="alert" className="text-xs text-red-500">
          {error}
        </p>
      )}
    </div>
  );
};