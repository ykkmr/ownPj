import { type ComponentProps } from 'react';

interface TextareaProps extends ComponentProps<'textarea'> {
  error?: boolean;
}

export const Textarea = ({ error = false, className = '', ...props }: TextareaProps) => (
  <textarea
    aria-invalid={error}
    className={`w-full rounded-lg border px-3 py-2.5 text-sm outline-none transition-colors focus:ring-2 focus:ring-offset-0 disabled:cursor-not-allowed disabled:bg-gray-50 disabled:text-gray-400 ${
      error
        ? 'border-red-400 focus:border-red-400 focus:ring-red-200'
        : 'border-gray-300 focus:border-blue-500 focus:ring-blue-200'
    } ${className}`}
    {...props}
  />
);
