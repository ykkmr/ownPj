import { type ReactNode } from 'react';

interface BreadcrumbItem {
  label: string;
  href?: string;
  onClick?: () => void;
}

interface BreadcrumbProps {
  items: BreadcrumbItem[];
  separator?: ReactNode;
  className?: string;
}

const DefaultSeparator = () => (
  <svg width="12" height="12" viewBox="0 0 12 12" fill="none" aria-hidden="true">
    <path d="M4 2l4 4-4 4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

export const Breadcrumb = ({
  items,
  separator = <DefaultSeparator />,
  className = '',
}: BreadcrumbProps) => (
  <nav aria-label="breadcrumb" className={className}>
    <ol className="flex flex-wrap items-center gap-1 text-sm">
      {items.map((item, index) => {
        const isLast = index === items.length - 1;

        return (
          <li key={item.label} className="flex items-center gap-1">
            {isLast ? (
              <span aria-current="page" className="font-medium text-gray-900">
                {item.label}
              </span>
            ) : item.href ? (
              <a href={item.href} className="text-gray-500 hover:text-blue-600 transition-colors">
                {item.label}
              </a>
            ) : (
              <button
                type="button"
                onClick={item.onClick}
                className="text-gray-500 hover:text-blue-600 transition-colors"
              >
                {item.label}
              </button>
            )}
            {!isLast && <span className="text-gray-400">{separator}</span>}
          </li>
        );
      })}
    </ol>
  </nav>
);
