import { useState, useRef, useCallback } from 'react';
import { useClickOutside } from '@/hooks/useClickOutside';

interface TimePickerProps {
  value?: string;
  onChange?: (time: string) => void;
  placeholder?: string;
  minuteStep?: 5 | 10 | 15 | 30;
  minTime?: string;
  maxTime?: string;
  disabled?: boolean;
  error?: boolean;
  className?: string;
}

const ClockIcon = () => (
  <svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true" className="shrink-0 text-gray-400">
    <circle cx="8" cy="8" r="6.5" stroke="currentColor" strokeWidth="1.3" />
    <path d="M8 5v3.5l2 2" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

const pad = (n: number) => String(n).padStart(2, '0');

const toMinutes = (time: string): number => {
  const [h, m] = time.split(':').map(Number);
  return (h ?? 0) * 60 + (m ?? 0);
};

const buildTimeSlots = (step: number): string[] => {
  const slots: string[] = [];
  for (let h = 0; h < 24; h++) {
    for (let m = 0; m < 60; m += step) {
      slots.push(`${pad(h)}:${pad(m)}`);
    }
  }
  return slots;
};

export const TimePicker = ({
  value = '',
  onChange,
  placeholder = '시간 선택',
  minuteStep = 30,
  minTime,
  maxTime,
  disabled = false,
  error = false,
  className = '',
}: TimePickerProps) => {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const listRef = useRef<HTMLUListElement>(null);

  const close = useCallback(() => setOpen(false), []);
  useClickOutside(ref, close);

  const slots = buildTimeSlots(minuteStep).filter((t) => {
    if (minTime && toMinutes(t) < toMinutes(minTime)) return false;
    if (maxTime && toMinutes(t) > toMinutes(maxTime)) return false;
    return true;
  });

  const handleOpen = () => {
    if (disabled) return;
    setOpen((o) => !o);

    if (!open && value) {
      requestAnimationFrame(() => {
        const selected = listRef.current?.querySelector('[aria-selected="true"]');
        selected?.scrollIntoView({ block: 'center' });
      });
    }
  };

  const handleSelect = (time: string) => {
    onChange?.(time);
    setOpen(false);
  };

  return (
    <div ref={ref} className={`relative ${className}`}>
      <button
        type="button"
        disabled={disabled}
        aria-haspopup="listbox"
        aria-expanded={open}
        onClick={handleOpen}
        className={`flex h-11 w-full items-center gap-2 rounded-lg border px-3 text-sm transition-colors disabled:cursor-not-allowed disabled:bg-gray-50 ${
          error
            ? 'border-red-400 focus:border-red-400 focus:ring-2 focus:ring-red-200'
            : 'border-gray-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-200'
        } ${!value ? 'text-gray-400' : 'text-gray-900'}`}
      >
        <ClockIcon />
        <span className="flex-1 text-left">{value || placeholder}</span>
      </button>

      {open && (
        <ul
          ref={listRef}
          role="listbox"
          aria-label="시간 선택"
          className="absolute top-full left-0 z-50 mt-1 max-h-52 w-36 overflow-y-auto rounded-xl border border-gray-200 bg-white py-1 shadow-lg"
        >
          {slots.map((time) => {
            const isSelected = time === value;
            return (
              <li
                key={time}
                role="option"
                aria-selected={isSelected}
                onClick={() => handleSelect(time)}
                className={`flex h-10 cursor-pointer items-center px-4 text-sm transition-colors ${
                  isSelected
                    ? 'bg-blue-600 font-medium text-white'
                    : 'text-gray-700 hover:bg-gray-50'
                }`}
              >
                {time}
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
};
