import { useRef, useState, type ComponentProps } from 'react';

interface FileUploadProps extends Omit<ComponentProps<'input'>, 'type' | 'onChange'> {
  label?: string;
  hint?: string;
  error?: string;
  maxSizeMb?: number;
  onChange?: (files: File[]) => void;
}

const formatFileSize = (bytes: number): string => {
  if (bytes < 1024) return `${bytes}B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)}KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)}MB`;
};

export const FileUpload = ({
  label = '파일을 드래그하거나 클릭하여 업로드',
  hint,
  error,
  maxSizeMb = 10,
  accept,
  multiple,
  disabled,
  onChange,
  className = '',
}: FileUploadProps) => {
  const inputRef = useRef<HTMLInputElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [sizeError, setSizeError] = useState('');

  const maxBytes = maxSizeMb * 1024 * 1024;

  const handleFiles = (files: FileList | null) => {
    if (!files) return;
    const fileArray = Array.from(files);
    const oversized = fileArray.filter((f) => f.size > maxBytes);
    if (oversized.length > 0) {
      setSizeError(`파일 크기는 ${maxSizeMb}MB를 초과할 수 없습니다.`);
      return;
    }
    setSizeError('');
    setSelectedFiles(fileArray);
    onChange?.(fileArray);
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    if (!disabled) handleFiles(e.dataTransfer.files);
  };

  const removeFile = (index: number) => {
    const updated = selectedFiles.filter((_, i) => i !== index);
    setSelectedFiles(updated);
    onChange?.(updated);
  };

  const displayError = sizeError || error;

  return (
    <div className={`w-full ${className}`}>
      <div
        role="button"
        tabIndex={disabled ? -1 : 0}
        aria-disabled={disabled}
        onClick={() => !disabled && inputRef.current?.click()}
        onKeyDown={(e) => e.key === 'Enter' && !disabled && inputRef.current?.click()}
        onDragOver={(e) => { e.preventDefault(); if (!disabled) setIsDragging(true); }}
        onDragLeave={() => setIsDragging(false)}
        onDrop={handleDrop}
        className={`flex min-h-24 cursor-pointer flex-col items-center justify-center gap-2 rounded-lg border-2 border-dashed p-4 transition-colors ${
          disabled
            ? 'cursor-not-allowed border-gray-200 bg-gray-50 opacity-50'
            : isDragging
              ? 'border-blue-500 bg-blue-50'
              : displayError
                ? 'border-red-400 bg-red-50'
                : 'border-gray-300 bg-gray-50 hover:border-blue-400 hover:bg-blue-50'
        }`}
      >
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" aria-hidden="true" className="text-gray-400">
          <path d="M12 15V3m0 0L8 7m4-4 4 4M2 17l.621 2.485A2 2 0 0 0 4.561 21h14.878a2 2 0 0 0 1.94-1.515L22 17" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
        <span className="text-sm text-gray-600">{label}</span>
        {hint && <span className="text-xs text-gray-400">{hint}</span>}
      </div>

      <input
        ref={inputRef}
        type="file"
        accept={accept}
        multiple={multiple}
        disabled={disabled}
        onChange={(e) => handleFiles(e.target.files)}
        className="sr-only"
        aria-hidden="true"
      />

      {displayError && <p className="mt-1 text-xs text-red-500">{displayError}</p>}

      {selectedFiles.length > 0 && (
        <ul className="mt-2 space-y-1">
          {selectedFiles.map((file, index) => (
            <li
              key={`${file.name}-${index}`}
              className="flex items-center justify-between rounded-md bg-gray-50 px-3 py-2 text-sm"
            >
              <span className="truncate text-gray-700">{file.name}</span>
              <span className="ml-2 shrink-0 text-xs text-gray-400">{formatFileSize(file.size)}</span>
              <button
                type="button"
                onClick={() => removeFile(index)}
                aria-label={`${file.name} 삭제`}
                className="ml-3 shrink-0 text-gray-400 hover:text-red-500"
              >
                <svg width="14" height="14" viewBox="0 0 14 14" fill="none" aria-hidden="true">
                  <path d="M1 1l12 12M13 1L1 13" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
                </svg>
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};
