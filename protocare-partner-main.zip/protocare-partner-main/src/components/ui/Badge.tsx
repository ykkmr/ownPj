import { type ReactNode } from 'react';

type BadgeVariant = 'primary' | 'success' | 'warning' | 'danger' | 'info' | 'default';

interface BadgeProps {
  variant?: BadgeVariant;
  children: ReactNode;
}

// ← 색상 테마 변경 시 이 한 곳만 수정
const variantClass: Record<BadgeVariant, string> = {
  primary: 'bg-blue-100 text-blue-700',
  success: 'bg-green-100 text-green-700',
  warning: 'bg-yellow-100 text-yellow-700',
  danger: 'bg-red-100 text-red-700',
  info: 'bg-purple-100 text-purple-700',
  default: 'bg-gray-100 text-gray-700',
};

export const Badge = ({ variant = 'default', children }: BadgeProps) => (
  <span
    className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ${variantClass[variant]}`}
  >
    {children}
  </span>
);
