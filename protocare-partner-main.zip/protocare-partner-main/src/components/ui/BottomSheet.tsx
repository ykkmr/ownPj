import { useEffect, type ReactNode } from 'react';

interface BottomSheetProps {
  isOpen: boolean;
  onClose: () => void;
  title?: string;
  children: ReactNode;
}

export const BottomSheet = ({ isOpen, onClose, title, children }: BottomSheetProps) => {
  useEffect(() => {
    if (!isOpen) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    document.addEventListener('keydown', onKeyDown);
    return () => document.removeEventListener('keydown', onKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <>
      <div aria-hidden="true" className="fixed inset-0 z-40 bg-black/50" onClick={onClose} />
      <div
        role="dialog"
        aria-modal="true"
        aria-label={title}
        className="fixed inset-x-0 bottom-0 z-50 rounded-t-2xl bg-white pb-safe"
      >
        <div className="mx-auto my-3 h-1 w-10 rounded-full bg-gray-300" />
        {title && (
          <div className="border-b border-gray-100 px-4 pb-3">
            <h2 className="text-center text-base font-semibold text-gray-900">{title}</h2>
          </div>
        )}
        <div className="px-4 py-4">{children}</div>
      </div>
    </>
  );
};
