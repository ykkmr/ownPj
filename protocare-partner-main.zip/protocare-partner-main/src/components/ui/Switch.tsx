import { useId, type ComponentProps } from 'react';

interface SwitchProps extends Omit<ComponentProps<'input'>, 'type' | 'onChange'> {
  label?: string;
  description?: string;
  onChange?: (checked: boolean) => void;
}

export const Switch = ({
  label,
  description,
  checked,
  onChange,
  disabled,
  id: externalId,
  className = '',
  ...props
}: SwitchProps) => {
  const generatedId = useId();
  const id = externalId ?? generatedId;

  return (
    <label
      htmlFor={id}
      className={`flex min-h-11 cursor-pointer items-center justify-between gap-4 ${disabled ? 'cursor-not-allowed opacity-50' : ''} ${className}`}
    >
      {(label || description) && (
        <span className="flex flex-col gap-0.5">
          {label && <span className="text-sm font-medium text-gray-800">{label}</span>}
          {description && <span className="text-xs text-gray-500">{description}</span>}
        </span>
      )}
      <span className="relative shrink-0">
        <input
          id={id}
          type="checkbox"
          role="switch"
          checked={checked}
          disabled={disabled}
          onChange={(e) => onChange?.(e.target.checked)}
          className="peer sr-only"
          {...props}
        />
        <span
          className={`block h-6 w-11 rounded-full transition-colors peer-checked:bg-blue-600 peer-focus-visible:ring-2 peer-focus-visible:ring-blue-500 peer-focus-visible:ring-offset-2 peer-disabled:cursor-not-allowed ${checked ? 'bg-blue-600' : 'bg-gray-300'}`}
        />
        <span
          className={`absolute top-0.5 left-0.5 h-5 w-5 rounded-full bg-white shadow transition-transform ${checked ? 'translate-x-5' : 'translate-x-0'}`}
        />
      </span>
    </label>
  );
};
