import type { ReactNode, ComponentProps } from 'react';

// ── Floating Action Button (FAB) ──────────────────────────────────────────────

type FabPosition = 'bottom-right' | 'bottom-center' | 'bottom-left';

interface FloatingActionButtonProps extends ComponentProps<'button'> {
  icon: ReactNode;
  /** 버튼 아래 표시할 레이블 (선택) */
  label?: string;
  position?: FabPosition;
  /** 하단 탭바가 있을 때 겹치지 않도록 추가 오프셋 (px). 기본 16px */
  bottomOffset?: number;
}

const positionClass: Record<FabPosition, string> = {
  'bottom-right': 'right-4',
  'bottom-center': 'left-1/2 -translate-x-1/2',
  'bottom-left': 'left-4',
};

/**
 * 모바일 화면 하단에 고정되는 플로팅 액션 버튼.
 * 탭바가 있는 MainLayout 에서는 bottomOffset 을 탭바 높이(64)로 설정합니다.
 *
 * @example
 * // 탭바 없는 화면
 * <FloatingActionButton icon={<Plus size={24} />} onClick={handleCreate} />
 *
 * // 탭바(64px)가 있는 MainLayout 내부
 * <FloatingActionButton
 *   icon={<Plus size={24} />}
 *   label="새 일정"
 *   bottomOffset={80}
 *   onClick={handleCreate}
 * />
 */
export const FloatingActionButton = ({
  icon,
  label,
  position = 'bottom-right',
  bottomOffset = 16,
  className = '',
  ...props
}: FloatingActionButtonProps) => (
  <button
    type="button"
    aria-label={label ?? '액션 버튼'}
    className={`fixed z-30 flex flex-col items-center gap-1 ${positionClass[position]} ${className}`}
    style={{ bottom: bottomOffset }}
    {...props}
  >
    <span className="flex size-14 items-center justify-center rounded-full bg-blue-600 text-white shadow-lg transition-transform active:scale-95 hover:bg-blue-700">
      {icon}
    </span>
    {label && (
      <span className="rounded bg-gray-800/70 px-1.5 py-0.5 text-[10px] text-white">
        {label}
      </span>
    )}
  </button>
);

// ── Floating Bar ──────────────────────────────────────────────────────────────

interface FloatingBarProps {
  /** 바 내부에 배치할 버튼/텍스트 등 */
  children: ReactNode;
  /** 하단 탭바와의 간격 (px). 기본 0 */
  bottomOffset?: number;
  className?: string;
}

/**
 * 화면 하단에 고정되는 액션 바.
 * "상담하기", "결제하기" 등 주요 CTA 를 스크롤과 무관하게 항상 노출합니다.
 * MainLayout 탭바 위에 쌓이려면 bottomOffset={64} 으로 설정합니다.
 *
 * @example
 * <FloatingBar bottomOffset={64}>
 *   <Button className="flex-1">상담 신청하기</Button>
 * </FloatingBar>
 *
 * <FloatingBar bottomOffset={64}>
 *   <Button variant="secondary" className="flex-1">저장</Button>
 *   <Button className="flex-1">제출</Button>
 * </FloatingBar>
 */
export const FloatingBar = ({
  children,
  bottomOffset = 0,
  className = '',
}: FloatingBarProps) => (
  <div
    className={`fixed inset-x-0 z-30 mx-auto max-w-md border-t border-gray-100 bg-white px-4 py-3 shadow-[0_-4px_12px_rgba(0,0,0,0.06)] ${className}`}
    style={{ bottom: bottomOffset }}
  >
    <div className="flex gap-3">{children}</div>
  </div>
);
