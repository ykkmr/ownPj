import { useIsFetching } from '@tanstack/react-query';

/**
 * TanStack Query의 전역 fetching 카운트를 구독해 상단에 얇은 진행 바를 표시.
 * fetching이 없으면 DOM에서 완전히 제거됨 (레이아웃 영향 없음).
 */
export const QueryFetchingBar = () => {
  const isFetching = useIsFetching();

  if (!isFetching) return null;

  return (
    <div
      role="progressbar"
      aria-label="데이터 불러오는 중"
      aria-busy="true"
      className="fixed left-0 right-0 top-0 z-[300] h-0.5 bg-transparent overflow-hidden"
    >
      <div className="h-full animate-[fetchProgress_1.2s_ease-in-out_infinite] bg-blue-500" />
    </div>
  );
};
