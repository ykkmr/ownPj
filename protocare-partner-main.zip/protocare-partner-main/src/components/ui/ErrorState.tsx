import { type ReactNode } from 'react';
import { Button } from './Button';

export type ErrorStateVariant = 'network' | 'notFound' | 'forbidden' | 'generic';

interface ErrorStateProps {
  variant?: ErrorStateVariant;
  title?: string;
  message?: string;
  onRetry?: () => void;
  retryLabel?: string;
  extra?: ReactNode;
  className?: string;
}

const VARIANT_DEFAULTS: Record<ErrorStateVariant, { title: string; message: string; icon: string }> = {
  network: {
    title: '네트워크 연결 오류',
    message: '인터넷 연결을 확인한 후 다시 시도해 주세요.',
    icon: '📡',
  },
  notFound: {
    title: '페이지를 찾을 수 없습니다',
    message: '요청하신 페이지가 존재하지 않거나 삭제되었습니다.',
    icon: '🔍',
  },
  forbidden: {
    title: '접근 권한이 없습니다',
    message: '이 페이지를 열람할 권한이 없습니다. 담당자에게 문의하세요.',
    icon: '🔒',
  },
  generic: {
    title: '문제가 발생했습니다',
    message: '일시적인 오류입니다. 잠시 후 다시 시도해 주세요.',
    icon: '⚠️',
  },
};

export const ErrorState = ({
  variant = 'generic',
  title,
  message,
  onRetry,
  retryLabel = '다시 시도',
  extra,
  className = '',
}: ErrorStateProps) => {
  const defaults = VARIANT_DEFAULTS[variant];
  const displayTitle = title ?? defaults.title;
  const displayMessage = message ?? defaults.message;

  return (
    <div
      role="alert"
      className={`flex flex-col items-center justify-center gap-4 px-6 py-16 text-center ${className}`}
    >
      <span className="text-5xl" aria-hidden="true">{defaults.icon}</span>
      <div className="flex flex-col gap-1.5">
        <h2 className="text-base font-semibold text-gray-900">{displayTitle}</h2>
        <p className="text-sm leading-relaxed text-gray-500">{displayMessage}</p>
      </div>
      {onRetry && (
        <Button variant="primary" size="md" onClick={onRetry}>
          {retryLabel}
        </Button>
      )}
      {extra}
    </div>
  );
};
