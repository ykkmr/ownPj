import { useRef, useState } from 'react';
import './PhotoUploadModal.css';

interface PhotoUploadModalProps {
  onUpload: (file: File) => void;
  onClose: () => void;
}

const ACCEPTED_TYPES = ['image/jpeg', 'image/png', 'image/gif'];
const MAX_SIZE_BYTES = 10 * 1024 * 1024;

function IconAddPhoto() {
  return (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="#47c7ac" aria-hidden="true">
      <path d="M19 7v2.99s-1.99.01-2 0V7h-3s.01-1.99 0-2h3V2h2v3h3v2h-3zm-3 4V8h-3V5H5C3.9 5 3 5.9 3 7v12c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2v-8h-3zM5 19l3-4 2 3 3-4 4 5H5z" />
    </svg>
  );
}

export function PhotoUploadModal({ onUpload, onClose }: PhotoUploadModalProps) {
  const [isDragOver, setIsDragOver] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  function handleFile(file: File) {
    if (!ACCEPTED_TYPES.includes(file.type)) return;
    if (file.size > MAX_SIZE_BYTES) return;
    onUpload(file);
    onClose();
  }

  function handleDrop(e: React.DragEvent) {
    e.preventDefault();
    setIsDragOver(false);
    const file = e.dataTransfer.files[0];
    if (file) handleFile(file);
  }

  function handleChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (file) handleFile(file);
  }

  function handleOverlayClick(e: React.MouseEvent<HTMLDivElement>) {
    if (e.target === e.currentTarget) onClose();
  }

  return (
    <div className="photo-modal-overlay" onClick={handleOverlayClick}>
      <div
        className="photo-modal"
        role="dialog"
        aria-modal="true"
        aria-labelledby="photo-modal-title"
      >
        <p id="photo-modal-title" className="photo-modal__title">
          사진 업로드
        </p>

        <div
          className={`photo-modal__drop-area${isDragOver ? ' photo-modal__drop-area--over' : ''}`}
          role="button"
          tabIndex={0}
          onClick={() => inputRef.current?.click()}
          onKeyDown={(e) => e.key === 'Enter' && inputRef.current?.click()}
          onDragOver={(e) => {
            e.preventDefault();
            setIsDragOver(true);
          }}
          onDragLeave={() => setIsDragOver(false)}
          onDrop={handleDrop}
        >
          <span className="photo-modal__icon-wrap">
            <IconAddPhoto />
          </span>
          <span className="photo-modal__hints">
            <span className="photo-modal__click-text">클릭하여 파일 선택</span>
            <span className="photo-modal__drag-text">또는 파일을 이곳으로 드래그하세요</span>
          </span>
          <input
            ref={inputRef}
            type="file"
            accept="image/jpeg,image/png,image/gif"
            className="photo-modal__file-input"
            onChange={handleChange}
            onClick={(e) => e.stopPropagation()}
          />
        </div>

        <div className="photo-modal__notes">
          <p>・사진 파일은 10MB 미만의 JPG, JPEG, PNG, GIF 파일만 업로드 가능</p>
          <p>・사진 크기는 100*140 픽셀로 노출됩니다.</p>
        </div>

        <div className="photo-modal__actions">
          <button
            type="button"
            className="photo-modal__btn photo-modal__btn--secondary"
            onClick={onClose}
          >
            취소
          </button>
          <button
            type="button"
            className="photo-modal__btn photo-modal__btn--primary"
            onClick={onClose}
          >
            등록
          </button>
        </div>
      </div>
    </div>
  );
}
