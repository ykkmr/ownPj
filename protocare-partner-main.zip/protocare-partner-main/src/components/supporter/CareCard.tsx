import './CareCard.css';

export type CareType = '병원동행' | '어르신돌봄' | '아이돌봄';

export interface CareRecord {
  id: string;
  careType: CareType;
  title: string;
  patient: string;
  schedule: string;
  address: string;
  price: string;
  requests: string[];
  hasLog?: boolean;
}

export type CardVariant = 'applied' | 'scheduled' | 'completed';

interface CareCardProps {
  record: CareRecord;
  variant?: CardVariant;
  onDetailClick?: (id: string) => void;
  onCancelClick?: (id: string) => void;
  onContactClick?: (id: string) => void;
  onReviewClick?: (id: string) => void;
  onLogClick?: (id: string) => void;
}

const BADGE_CONFIG: Record<CareType, { label: string; modifier: string }> = {
  병원동행: { label: '병원 동행', modifier: 'care-card__badge--hospital' },
  어르신돌봄: { label: '어르신 돌봄', modifier: 'care-card__badge--elderly' },
  아이돌봄: { label: '아이 돌봄', modifier: 'care-card__badge--child' },
};

function ClockIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="#737373" aria-hidden="true" className="care-card__icon">
      <path d="M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm.5-13H11v6l5.25 3.15.75-1.23-4.5-2.67V7z" />
    </svg>
  );
}

function LocationIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="#737373" aria-hidden="true" className="care-card__icon">
      <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z" />
    </svg>
  );
}

function MoreVertIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="#737373" aria-hidden="true" className="care-card__more-icon">
      <path d="M12 8c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z" />
    </svg>
  );
}

export function CareCard({
  record,
  variant = 'applied',
  onDetailClick,
  onCancelClick,
  onContactClick,
  onReviewClick,
  onLogClick,
}: CareCardProps) {
  const badge = BADGE_CONFIG[record.careType];

  if (variant === 'completed') {
    return (
      <div className="care-card care-card--horizontal">
        <div className="care-card__main">
          <div className="care-card__header">
            <span className={`care-card__badge ${badge.modifier}`}>{badge.label}</span>
            <p className="care-card__title">{record.title}</p>
          </div>
          <div className="care-card__info-list">
            <div className="care-card__info-row">
              <ClockIcon />
              <span className="care-card__info-text">{record.schedule}</span>
            </div>
            <div className="care-card__info-row">
              <LocationIcon />
              <span className="care-card__info-text">{record.address}</span>
            </div>
          </div>
        </div>
        <div className="care-card__aside">
          <button
            type="button"
            className="care-card__review-link"
            onClick={() => onReviewClick?.(record.id)}
          >
            리뷰 보기
            <MoreVertIcon />
          </button>
          <button
            type="button"
            className={
              record.hasLog
                ? 'care-card__outline-btn care-card__outline-btn--full'
                : 'care-card__action-btn care-card__action-btn--full'
            }
            onClick={() => onLogClick?.(record.id)}
          >
            서포트 기록 {record.hasLog ? '수정' : '작성'}
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="care-card">
      <div className="care-card__header">
        <span className={`care-card__badge ${badge.modifier}`}>{badge.label}</span>
        <p className="care-card__title">{record.title}</p>
      </div>

      <div className="care-card__info-list">
        <div className="care-card__info-row">
          <ClockIcon />
          <span className="care-card__info-text">{record.schedule}</span>
        </div>
        <div className="care-card__info-row">
          <LocationIcon />
          <span className="care-card__info-text">{record.address}</span>
        </div>
      </div>

      <div className="care-card__footer">
        <button
          type="button"
          className="care-card__detail-link"
          onClick={() => onDetailClick?.(record.id)}
        >
          상세 보기
          <img
            src="/assets/icons/keyboard_arrow_down.svg"
            alt=""
            aria-hidden="true"
            className="care-card__detail-arrow"
          />
        </button>

        {variant === 'applied' && (
          <button
            type="button"
            className="care-card__cancel-btn"
            onClick={() => onCancelClick?.(record.id)}
          >
            지원 취소
          </button>
        )}

        {variant === 'scheduled' && (
          <button
            type="button"
            className="care-card__action-btn care-card__action-btn--full"
            onClick={() => onContactClick?.(record.id)}
          >
            보호자 연락하기
          </button>
        )}
      </div>
    </div>
  );
}
