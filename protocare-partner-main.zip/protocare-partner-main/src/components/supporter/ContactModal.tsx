import './ContactModal.css';

interface ContactModalProps {
  onClose: () => void;
  onSms?: () => void;
  onCall?: () => void;
}

export function ContactModal({ onClose, onSms, onCall }: ContactModalProps) {
  return (
    <div className="contact-modal__overlay" onClick={onClose}>
      <div className="contact-modal" onClick={(e) => e.stopPropagation()}>
        <div className="contact-modal__header">
          <h2 className="contact-modal__title">보호자와 연락하기</h2>
          <button
            type="button"
            className="contact-modal__close"
            onClick={onClose}
            aria-label="닫기"
          >
            <svg viewBox="0 0 24 24" fill="#121212" aria-hidden="true" width="24" height="24">
              <path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z" />
            </svg>
          </button>
        </div>
        <p className="contact-modal__body">
          급한 상황이거나 세부 확인이 필요할 때 이용해 주세요.
          <br />
          통화 시에는 서로를 배려하는 따뜻한 언어를 사용해 주세요.
        </p>
        <div className="contact-modal__actions">
          <button type="button" className="contact-modal__sms-btn" onClick={onSms}>
            문자하기
          </button>
          <button type="button" className="contact-modal__call-btn" onClick={onCall}>
            전화하기
          </button>
        </div>
      </div>
    </div>
  );
}
