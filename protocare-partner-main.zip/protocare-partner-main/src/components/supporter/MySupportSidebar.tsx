import { useNavigate } from 'react-router-dom';
import { useAuthStore } from '@/store/auth.store';
import './MySupportSidebar.css';

// 24×24 단색 아이콘 (Icon/ 서브폴더, fill="#399F8A") — filter로 gray/green 전환
const ICON_PATHS: Record<string, string> = {
  dashboard: '/assets/icons/Icon/download_dashboard.svg',
  explore: '/assets/icons/Icon/data_loss_prevention.svg',
  history: '/assets/icons/Icon/search_activity.svg',
  schedule: '/assets/icons/Icon/calendar_month.svg',
  earnings: '/assets/icons/Icon/credit_card_gear.svg',
  profile: '/assets/icons/Icon/manage_accounts.svg',
  applications: '/assets/icons/Icon/contact_mail.svg',
  notifications: '/assets/icons/Icon/notifications.svg',
  notices: '/assets/icons/Icon/error.svg',
  faq: '/assets/icons/Icon/help.svg',
  terms: '/assets/icons/Icon/heart_smile.svg',
  inquiry: '/assets/icons/Icon/volunteer_activism.svg',
};

// green (#399F8A) → gray (#737373): 채도 제거 후 밝기 조정
const ICON_FILTER_GRAY = 'saturate(0) brightness(0.8)';
const ICON_FILTER_GREEN = 'none';

function SidebarIcon({ src, isActive }: { src: string; isActive: boolean }) {
  return (
    <img
      src={src}
      alt=""
      aria-hidden="true"
      className="ms-sidebar__item-icon"
      style={{ filter: isActive ? ICON_FILTER_GREEN : ICON_FILTER_GRAY }}
    />
  );
}

// ── Routes ────────────────────────────────────────────────────
const ITEM_ROUTES: Record<string, string> = {
  dashboard: '/supporter/mysupport',
  explore: '/supporter/mysupport/explore',
  history: '/supporter/mysupport/history',
  schedule: '/supporter/mysupport/schedule',
  earnings: '/supporter/mysupport/earnings',
  profile: '/supporter/mysupport/profile',
  applications: '/supporter/mysupport/applications',
  notifications: '/supporter/mysupport/notifications',
  notices: '/supporter/mysupport/notices',
  faq: '/supporter/mysupport/faq',
  terms: '/supporter/mysupport/terms',
  inquiry: '/supporter/mysupport/inquiry',
};

// ── Types ──────────────────────────────────────────────────────────────────
interface SidebarItem {
  id: string;
  label: string;
}

interface SidebarGroup {
  groupLabel: string;
  items: SidebarItem[];
}

// ── Nav data ───────────────────────────────────────────────────────────────
const SIDEBAR_GROUPS: SidebarGroup[] = [
  {
    groupLabel: '케어 관리',
    items: [
      { id: 'dashboard', label: '대시보드' },
      { id: 'explore', label: '케어 탐색' },
      { id: 'history', label: '이용 내역' },
      { id: 'schedule', label: '일정 관리' },
      { id: 'earnings', label: '정산 관리' },
    ],
  },
  {
    groupLabel: '계정 설정',
    items: [
      { id: 'profile', label: '내 정보 관리' },
      { id: 'applications', label: '지원서 관리' },
      { id: 'notifications', label: '알림 관리' },
    ],
  },
  {
    groupLabel: '고객센터',
    items: [
      { id: 'notices', label: '공지사항' },
      { id: 'faq', label: 'FAQ' },
      { id: 'terms', label: '이용약관' },
      { id: 'inquiry', label: '1:1 문의함' },
    ],
  },
];

// ── Component ──────────────────────────────────────────────────────────────
interface MySupportSidebarProps {
  activeItemId: string;
  onItemClick?: (itemId: string) => void;
}

export function MySupportSidebar({ activeItemId, onItemClick }: MySupportSidebarProps) {
  const navigate = useNavigate();
  const logout = useAuthStore((s) => s.logout);

  function handleItemClick(itemId: string) {
    onItemClick?.(itemId);
    const route = ITEM_ROUTES[itemId];
    if (route) navigate(route);
  }

  async function handleLogout() {
    await logout();
    navigate('/login', { replace: true });
  }

  return (
    <aside className="ms-sidebar">
      <p className="ms-sidebar__title">마이서포트</p>
      {SIDEBAR_GROUPS.map((group) => (
        <div key={group.groupLabel} className="ms-sidebar__group">
          <p className="ms-sidebar__group-label">{group.groupLabel}</p>
          <ul className="ms-sidebar__list">
            {group.items.map((item) => {
              const isActive = item.id === activeItemId;
              const iconSrc = ICON_PATHS[item.id];
              return (
                <li key={item.id}>
                  <button
                    type="button"
                    className={`ms-sidebar__item${isActive ? ' ms-sidebar__item--active' : ''}`}
                    onClick={() => handleItemClick(item.id)}
                  >
                    {iconSrc && <SidebarIcon src={iconSrc} isActive={isActive} />}
                    <span className="ms-sidebar__item-label">{item.label}</span>
                  </button>
                </li>
              );
            })}
          </ul>
        </div>
      ))}
      <button type="button" className="ms-sidebar__logout" onClick={handleLogout}>
        로그아웃
      </button>
    </aside>
  );
}
