import { useEffect, useRef, type ReactNode } from 'react';
import { useTrack } from '@/hooks/useTrack';

interface TrackViewProps {
  /** 요소가 화면에 노출될 때 발송할 이벤트 이름 */
  event: string;
  properties?: Record<string, unknown>;
  /** 이벤트를 발송하기 위한 최소 노출 비율 (0 ~ 1). 기본값 0.5 */
  threshold?: number;
  children: ReactNode;
}

/**
 * 요소 노출(Impression) 이벤트를 자동으로 추적하는 래퍼 컴포넌트.
 * IntersectionObserver 를 사용하며, 첫 노출 시 한 번만 이벤트를 발송합니다.
 *
 * @example
 * <TrackView event="payment_section_viewed">
 *   <PaymentSection />
 * </TrackView>
 */
export const TrackView = ({
  event,
  properties,
  threshold = 0.5,
  children,
}: TrackViewProps) => {
  const ref = useRef<HTMLDivElement>(null);
  const hasTrackedRef = useRef(false);
  const { track } = useTrack();

  useEffect(() => {
    const element = ref.current;
    if (!element) return;

    const observer = new IntersectionObserver(
      (entries) => {
        const entry = entries[0];
        if (entry?.isIntersecting && !hasTrackedRef.current) {
          hasTrackedRef.current = true;
          track(event, properties);
          observer.disconnect();
        }
      },
      { threshold }
    );

    observer.observe(element);
    return () => observer.disconnect();
  }, [event, properties, threshold, track]);

  return <div ref={ref}>{children}</div>;
};