import type { ReactNode } from 'react';
import { useTrack } from '@/hooks/useTrack';

interface TrackClickProps {
  /** 발송할 이벤트 이름 (snake_case 권장) */
  event: string;
  properties?: Record<string, unknown>;
  children: ReactNode;
}

/**
 * 클릭 이벤트를 자동으로 추적하는 래퍼 컴포넌트.
 * `display: contents` 로 DOM 레이아웃에 영향을 주지 않습니다.
 *
 * @example
 * <TrackClick event="signup_submit_clicked" properties={{ step: 2 }}>
 *   <Button>가입 완료</Button>
 * </TrackClick>
 */
export const TrackClick = ({ event, properties, children }: TrackClickProps) => {
  const { track } = useTrack();

  return (
    <span
      className="contents"
      onClick={() => track(event, properties)}
    >
      {children}
    </span>
  );
};