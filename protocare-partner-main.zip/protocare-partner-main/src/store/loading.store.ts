import { create } from 'zustand';

interface LoadingState {
  count: number;
  message: string;
  show: (message?: string) => void;
  hide: () => void;
}

/**
 * 참조 카운팅 방식으로 중첩 로딩 호출을 안전하게 처리합니다.
 * show()를 n번 호출하면 hide()를 n번 호출해야 오버레이가 사라집니다.
 */
export const useLoadingStore = create<LoadingState>((set) => ({
  count: 0,
  message: '잠시만 기다려주세요...',

  show: (message = '잠시만 기다려주세요...') =>
    set((s) => ({ count: s.count + 1, message })),

  hide: () =>
    set((s) => ({ count: Math.max(0, s.count - 1) })),
}));

/** 어디서든 한 줄로 전체 화면 로딩을 제어합니다. */
export const globalLoading = {
  show: (message?: string) => useLoadingStore.getState().show(message),
  hide: () => useLoadingStore.getState().hide(),
};