import { create } from 'zustand';

export type ModalVariant = 'default' | 'danger';

export interface ModalOptions {
  title: string;
  message: string;
  confirmLabel?: string;
  cancelLabel?: string;
  variant?: ModalVariant;
  onConfirm: () => void | Promise<void>;
  onCancel?: () => void;
}

interface ResolvedOptions extends Required<Omit<ModalOptions, 'onCancel'>> {
  onCancel?: () => void;
}

interface ModalState {
  isOpen: boolean;
  options: ResolvedOptions;
  open: (options: ModalOptions) => void;
  close: () => void;
}

const DEFAULT_OPTIONS: ResolvedOptions = {
  title: '',
  message: '',
  confirmLabel: '확인',
  cancelLabel: '취소',
  variant: 'default',
  onConfirm: () => {},
  onCancel: undefined,
};

export const useModalStore = create<ModalState>((set) => ({
  isOpen: false,
  options: DEFAULT_OPTIONS,

  open: (options) =>
    set({
      isOpen: true,
      options: { ...DEFAULT_OPTIONS, ...options },
    }),

  close: () => set({ isOpen: false }),
}));

/** 어디서든 한 줄로 확인 모달을 띄웁니다. */
export const modal = {
  confirm: (options: ModalOptions) => useModalStore.getState().open(options),
  close: () => useModalStore.getState().close(),
};