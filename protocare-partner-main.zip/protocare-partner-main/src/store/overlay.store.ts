import { create } from 'zustand';
import type { ReactNode } from 'react';

export const OVERLAY_PRIORITY = {
  CRITICAL: 100,
  HIGH: 70,
  NORMAL: 50,
  LOW: 10,
} as const;

export type OverlayPriority = (typeof OVERLAY_PRIORITY)[keyof typeof OVERLAY_PRIORITY];

interface BaseOverlay {
  id: string;
  priority: OverlayPriority;
  /** localStorage key — 오늘 하루 보지 않기 기능 활성화 */
  dismissKey?: string;
  onClose?: () => void;
}

export interface ConfirmOverlay extends BaseOverlay {
  type: 'confirm';
  title: string;
  message: string;
  confirmLabel?: string;
  cancelLabel?: string;
  variant?: 'default' | 'danger';
  onConfirm: () => void | Promise<void>;
  onCancel?: () => void;
}

export interface NoticeOverlay extends BaseOverlay {
  type: 'notice';
  title: string;
  message: string;
  imageUrl?: string;
  /** true 이면 "오늘 하루 보지 않기" 체크박스를 표시합니다. dismissKey 필수. */
  allowDismissToday?: boolean;
}

export interface ConsentOverlay extends BaseOverlay {
  type: 'consent';
  title: string;
  items: Array<{ id: string; label: string; required: boolean }>;
  onConsent: (agreed: Record<string, boolean>) => void | Promise<void>;
}

export interface CustomOverlay extends BaseOverlay {
  type: 'custom';
  render: (close: () => void) => ReactNode;
}

export type OverlayItem = ConfirmOverlay | NoticeOverlay | ConsentOverlay | CustomOverlay;

type PushOptions = Omit<OverlayItem, 'id'> & { id?: string };

// ── 로컬스토리지 헬퍼 ──────────────────────────────────────────────────────────

const TODAY = () => new Date().toLocaleDateString('ko-KR');

function isDismissedToday(key: string): boolean {
  return localStorage.getItem(`overlay_dismiss_${key}`) === TODAY();
}

function markDismissedToday(key: string): void {
  localStorage.setItem(`overlay_dismiss_${key}`, TODAY());
}

// ── 스토어 ────────────────────────────────────────────────────────────────────

interface OverlayState {
  queue: OverlayItem[];
  push: (options: PushOptions) => void;
  dismiss: (id: string, dismissToday?: boolean) => void;
  dismissAll: () => void;
}

export const useOverlayStore = create<OverlayState>((set) => ({
  queue: [],

  push: (options) => {
    const id = options.id ?? `overlay-${Date.now()}-${Math.random().toString(36).slice(2)}`;
    const item = { ...options, id } as OverlayItem;

    if (item.dismissKey && isDismissedToday(item.dismissKey)) return;

    set((s) => ({
      queue: [...s.queue, item].sort((a, b) => b.priority - a.priority),
    }));
  },

  dismiss: (id, dismissToday = false) => {
    set((s) => {
      const target = s.queue.find((o) => o.id === id);
      if (target?.dismissKey && dismissToday) {
        markDismissedToday(target.dismissKey);
      }
      target?.onClose?.();
      return { queue: s.queue.filter((o) => o.id !== id) };
    });
  },

  dismissAll: () => set({ queue: [] }),
}));

/** 어디서든 팝업을 큐에 추가합니다. */
export const overlay = {
  push: (options: PushOptions) => useOverlayStore.getState().push(options),
  dismiss: (id: string) => useOverlayStore.getState().dismiss(id),
  dismissAll: () => useOverlayStore.getState().dismissAll(),
};