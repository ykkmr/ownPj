// src/store/auth.store.ts
import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import type { AuthUser } from '@/types/domain';
import { tokenStorage } from '@/services/api/tokenStorage';

// 1. 상태 타입 정의 (구현체와 일치시켜야 합니다)
interface AuthState {
  isAuthenticated: boolean;
  user: AuthUser | null;
  // 인터페이스에 정의된 모든 함수는 반드시 아래 (set) 안에서 구현되어야 합니다.
  login: (user: AuthUser, accessToken: string) => void;
  setSession: (user: AuthUser) => void; 
  logout: () => void; // async가 필요 없다면 일반 함수로
  clearSession: () => void;
  setUser: (user: AuthUser) => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      isAuthenticated: false,
      user: null,

      // 로그인 성공 시 호출
      login: (user, accessToken) => {
        tokenStorage.set(accessToken);
        set({ isAuthenticated: true, user });
      },

      // 세션 정보를 업데이트 (authService 등에서 호출용)
      setSession: (user) => {
        set({ isAuthenticated: true, user });
      },

      // 로그아웃 로직 (API 호출은 Service에서 하고, 스토어는 상태만 비웁니다)
      logout: () => {
        tokenStorage.clear();
        set({ isAuthenticated: false, user: null });
        sessionStorage.clear(); // 영구 저장소 비우기
      },

      // 인터셉터에서 세션 만료 시 호출
      clearSession: () => {
        tokenStorage.clear();
        set({ isAuthenticated: false, user: null });
      },

      setUser: (user) => set({ user }),
    }),
    {
      name: 'auth-storage',
      storage: createJSONStorage(() => sessionStorage),
      // 보안을 위해 인증 여부만 저장하고 유저 정보는 제외 (새로고침 시 /me 로 복구 권장)
      partialize: (state) => ({ isAuthenticated: state.isAuthenticated }),
    },
  ),
);