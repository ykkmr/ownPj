// Swagger 표준 응답 스키마 (api-dev.all-concierge.shop 기준)
export interface ApiResponse<T> {
  success: boolean;
  code: string;
  message: string;
  data: T;
  fieldErrors: ApiFieldError[];
  timestamp: string;
}

export interface ApiFieldError {
  field: string;
  message: string;
  rejectedValue: unknown;
}

export interface TokenResponse {
  accessToken: string;
  refreshToken: string;
}

export interface VerifyResponse {
  verifiedToken: string;
  value: string;
}

export interface ApiErrorBody {
  success: false;
  code: string;
  message: string;
  fieldErrors: ApiFieldError[];
  details?: Record<string, string[]>;
  timestamp: string;
}

export interface PageResponse<T> {
  content: T[];
  page: number;
  size: number;
  totalElements: number;
  totalPages: number;
}

// ── Certification ─────────────────────────────────────────────
export type CertificationType =
  | 'SOCIAL_WORKER'
  | 'CARE_WORKER'
  | 'ACTIVITY_SUPPORT_WORKER'
  | 'CHILD_CARE_WORKER'
  | 'DISABILITY_CARE_WORKER';

export type CertificationStatus = 'PENDING' | 'VERIFIED' | 'REJECTED';

export interface CertificationResponse {
  id: number;
  supporterId: number;
  certificationType: CertificationType;
  certificationTypeName: string;
  certificationNumber: string | null;
  issuer: string | null;
  issuedAt: string | null;
  fileUrl: string;
  status: CertificationStatus;
  verifiedAt: string | null;
  rejectedReason: string | null;
  createdAt: string;
}

// ── Personality Tags ──────────────────────────────────────────
export type TagCode =
  | 'EXPERIENCE_HOSPITAL'
  | 'EXPERIENCE_SENIOR'
  | 'EXPERIENCE_CHILD'
  | 'EXPERIENCE_FAMILY'
  | 'EXPERIENCE_PROFESSIONAL'
  | 'EXPERIENCE_NONE'
  | 'STYLE_CALM'
  | 'STYLE_BRIGHT'
  | 'STYLE_TALKATIVE'
  | 'STYLE_QUIET'
  | 'STYLE_DETAIL'
  | 'ACTIVITY_HOSPITAL'
  | 'ACTIVITY_SENIOR'
  | 'ACTIVITY_CHILD'
  | 'CONDITION_EMERGENCY'
  | 'CONDITION_NIGHT'
  | 'CONDITION_LONG_DISTANCE'
  | 'CONDITION_LONG_TERM'
  | 'CONDITION_SIGN_LANGUAGE';

export type TagCategory =
  | 'CARE_EXPERIENCE'
  | 'CARE_STYLE'
  | 'PREFERRED_ACTIVITY'
  | 'SPECIAL_CONDITION';

export interface TagItem {
  tagCategory: TagCategory;
  orderNumber: number;
  tagCode: TagCode;
  tagName: string;
}

export interface TagResponse {
  experienceTag: TagItem | null;
  styleTag: TagItem | null;
  activityTags: TagItem[];
  conditionTags: TagItem[];
}

// ── Notification Config ───────────────────────────────────────
export interface NotificationConfig {
  customActivityEnabled: boolean;
  activityScheduleEnabled: boolean;
  incomeSettlementEnabled: boolean;
  serviceGuideEnabled: boolean;
}

// ── Identity Verification (Danal) ─────────────────────────────
export interface PreRegisterResponse {
  identityVerificationId: string;
}

// ── Supporter Application ─────────────────────────────────────
export type ApplicationStatus = 'DRAFT' | 'SUBMITTED' | 'UNDER_REVIEW' | 'APPROVED' | 'REJECTED';

export type Gender = 'MALE' | 'FEMALE';

export interface InitResponse {
  applicationId: number;
  created: boolean;
  status: ApplicationStatus;
}

export interface TermsRequest {
  privacyPolicyAgreed: boolean;
  patientDataAgreed: boolean;
  marketingAgreed?: boolean;
  profilePromotionAgreed?: boolean;
}

export interface TermsResponse {
  privacyPolicyAgreed: boolean;
  privacyPolicyRespondedAt: string | null;
  patientDataAgreed: boolean;
  patientDataRespondedAt: string | null;
  marketingAgreed: boolean | null;
  marketingRespondedAt: string | null;
  profilePromotionAgreed: boolean | null;
  profilePromotionRespondedAt: string | null;
}

export interface BasicInfoRequest {
  name?: string;
  birthDate?: string; // yyyy-MM-dd
  gender?: Gender;
  activitySigu?: string;
  activityDong?: string;
  intro?: string;
}

export interface BasicInfoResponse {
  name: string | null;
  birthDate: string | null;
  gender: Gender | null;
  genderDisplayName: string | null;
  activitySigu: string | null;
  activityDong: string | null;
  intro: string | null;
  profileImageUrl: string | null;
  complete: boolean;
}

export interface CertificationSummary {
  id: number;
  certificationType: CertificationType;
  certificationTypeDisplayName: string;
  status: CertificationStatus;
  fileUrl: string;
}

export interface CriminalRecordSummary {
  id: number;
  status: CertificationStatus;
  sexCrimeConsentAgreed: boolean | null;
  fileUrl: string;
}

export interface QualificationResponse {
  certifications: CertificationSummary[];
  criminalRecord: CriminalRecordSummary | null;
  complete: boolean;
}

export interface ApplicationOverviewResponse {
  applicationId: number;
  status: ApplicationStatus;
  statusDisplayName: string;
  step1Completed: boolean;
  step2Completed: boolean;
  step3Completed: boolean;
  step4Completed: boolean;
  submittable: boolean;
  submittedAt: string | null;
  rejectedReason: string | null;
  terms: TermsResponse | null;
  basicInfo: BasicInfoResponse | null;
  qualifications: QualificationResponse | null;
}
