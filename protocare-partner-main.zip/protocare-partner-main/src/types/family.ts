// ============================================================
// 가족그룹 (family_groups)
// ============================================================
export interface FamilyGroup {
  id: number;
  userId: number;
  familyName: string;
  createdAt: string;
  updatedAt: string | null;
}

// ============================================================
// 가족그룹 구성원 (family_group_members)
// ============================================================
export interface FamilyGroupMember {
  id: number;
  familyGroupId: number;
  userId: number | null;
  role: string | null;
  allergy: string | null;
  underlyingDisease: string | null;
  prescriptionMedicine: string | null;
  other: string | null;
  reserveSchedule: string | null;
  medicalDevices: string | null;
  relationship: string | null;
  createdAt: string;
  updatedAt: string | null;
}
