// ============================================================
// 은행 계좌 정보 (bank_accounts)
// ============================================================
export interface BankAccount {
  id: number;
  userId: number;
  bankCode: string;
  bankName: string;
  accountNumber: string;
  createdAt: string;
  updatedAt: string | null;
  createdBy: number;
  updatedBy: number | null;
}

// ============================================================
// 결제 내역 (payments)
// ============================================================
export type PaymentMethod =
  | 'CARD'
  | 'KAKAO_PAY'
  | 'NAVER_PAY'
  | 'BANK_TRANSFER';

export type PaymentStatus =
  | 'PENDING'
  | 'PAID'
  | 'CANCELLED'
  | 'REFUNDED'
  | 'PARTIAL_REFUNDED';

export interface Payment {
  id: number;
  matchingId: number;
  payerId: number;
  amount: number;
  method: PaymentMethod;
  status: PaymentStatus;
  pgProvider: string | null;
  pgTxId: string | null;
  paidAt: string | null;
  cancelledAt: string | null;
  refundAmount: number;
  refundReason: string | null;
  createdAt: string;
  updatedAt: string | null;
  createdBy: number;
  updatedBy: number | null;
}

// ============================================================
// 정산 내역 (settlements)
// ============================================================
export type SettlementStatus =
  | 'PENDING'
  | 'PROCESSING'
  | 'COMPLETED'
  | 'FAILED';

export interface Settlement {
  id: number;
  matchingId: number;
  supporterId: number;
  bankAccountId: number;
  amount: number;
  fee: number;
  netAmount: number;
  status: SettlementStatus;
  scheduledAt: string | null;
  completedAt: string | null;
  txId: string | null;
  createdAt: string;
  updatedAt: string | null;
  createdBy: number;
  updatedBy: number | null;
}
