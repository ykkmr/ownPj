
// ============================================================
// 약관 동의 내역 (term_agreements)
// ============================================================
export interface TermAgreement {
  id: number;
  termsType: string;
  agree: boolean;
  createdAt: string;
  updatedAt: string | null;
}

// ============================================================
// AI 문답 (ai_conversations)
// ============================================================
export interface AiConversation {
  id: number;
  userId: number;
  question: string;
  answer: string | null;
  createdAt: string;
  updatedAt: string | null;
}

// ============================================================
// 요청자/서포터 리뷰 (reviews)
// ============================================================
export interface Review {
  id: number;
  matchingId: number;
  reviewerId: number;
  supporterId: number;
  rating: 1 | 2 | 3 | 4 | 5;
  content: string | null;
  isVisible: boolean;
  createdAt: string;
  updatedAt: string | null;
  createdBy: number;
  updatedBy: number | null;
}

// ============================================================
// 요청자/서포터 신고 (user_reports)
// ============================================================
export type UserReportType = 'COMPLAINT' | 'SPECIAL_NOTE';
export type UserReportStatus = 'RECEIVED' | 'IN_REVIEW' | 'RESOLVED';

export interface UserReport {
  id: number;
  matchingId: number;
  reporterId: number;
  type: UserReportType;
  content: string;
  status: UserReportStatus;
  resolvedAt: string | null;
  resolvedMemo: string | null;
  createdAt: string;
  updatedAt: string | null;
  createdBy: number;
  updatedBy: number | null;
}

// ============================================================
// 고객센터 문의 (support_inquiries)
// ============================================================
export type InquiryCategory = 'SERVICE' | 'PAYMENT' | 'ACCOUNT' | 'MATCHING' | 'ETC';
export type InquiryStatus = 'RECEIVED' | 'IN_PROGRESS' | 'ANSWERED' | 'CLOSED';

export interface SupportInquiry {
  id: number;
  userId: number | null;
  category: InquiryCategory;
  title: string;
  content: string;
  attachmentUrls: string[];
  status: InquiryStatus;
  answer: string | null;
  answeredAt: string | null;
  answeredBy: number | null;
  contactEmail: string | null;
  createdAt: string;
  updatedAt: string | null;
  createdBy: number;
  updatedBy: number | null;
}

// ============================================================
// 알림 발송 이력 (notification_logs)
// ============================================================
export type NotificationChannel = 'KAKAO' | 'SMS' | 'PUSH';
export type NotificationType = 'STATUS_CHANGE' | 'REVIEW_REQUEST' | 'MATCHING' | 'MARKETING';
export type NotificationStatus = 'SENT' | 'FAILED' | 'PENDING';

export interface NotificationLog {
  id: number;
  userId: number;
  channel: NotificationChannel;
  type: NotificationType;
  title: string | null;
  content: string;
  status: NotificationStatus;
  sentAt: string | null;
  refId: number | null;
  refType: string | null;
  createdAt: string;
  updatedAt: string | null;
  createdBy: number;
  updatedBy: number | null;
}

// ============================================================
// 공통 API 응답 래퍼
// ============================================================
export interface ApiResponse<T> {
  success: boolean;
  data: T;
  message: string | null;
}

export interface PaginatedResponse<T> {
  success: boolean;
  data: {
    content: T[];
    totalElements: number;
    totalPages: number;
    page: number;
    size: number;
    hasNext: boolean;
  };
  message: string | null;
}
