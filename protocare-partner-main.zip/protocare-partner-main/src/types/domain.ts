/**
 * 공통 도메인 타입.
 * 세부 도메인별 타입은 features/{domain}/types.ts 로 분리 권장.
 */
export type UserRole =
  | 'USER' | 'REQUESTER' | 'PATIENT' | 'DOCTOR' | 'NURSE' 
  | 'ADMIN' | 'STAFF' | 'SUPPORTER' | 'SUPPORTER_BASIC' | 'SUPPORTER_PREMIUM';

export interface AuthUser {
  id: string;
  name: string;
  role: UserRole; // 👈 특정 문자열 대신 UserRole 타입을 사용
  email?: string;
}

export type PermissionCode =
  | 'PROFILE_EDIT'
  | 'SCHEDULE_VIEW'
  | 'SCHEDULE_MANAGE'
  | 'MATCH_REQUEST'
  | 'PAYMENT_VIEW'
  | 'PAYMENT_REQUEST'
  | 'REPORT_VIEW'
  | 'ADMIN_PANEL'
  | 'MEDICAL_RECORD_READ'
  | 'MEDICAL_RECORD_WRITE';

export const ROLE_PERMISSIONS: Record<UserRole, PermissionCode[]> = {
  USER: ['PROFILE_EDIT'],
  REQUESTER: ['PROFILE_EDIT'],
  PATIENT: ['PROFILE_EDIT', 'SCHEDULE_VIEW', 'MEDICAL_RECORD_READ'],
  NURSE: ['PROFILE_EDIT', 'SCHEDULE_VIEW', 'MEDICAL_RECORD_READ'],
  STAFF: ['PROFILE_EDIT', 'SCHEDULE_VIEW', 'SCHEDULE_MANAGE'],
  DOCTOR: [
    'PROFILE_EDIT',
    'SCHEDULE_VIEW',
    'SCHEDULE_MANAGE',
    'MEDICAL_RECORD_READ',
    'MEDICAL_RECORD_WRITE',
  ],
  SUPPORTER_BASIC: ['PROFILE_EDIT', 'SCHEDULE_VIEW', 'SCHEDULE_MANAGE', 'MATCH_REQUEST'],
  SUPPORTER_PREMIUM: [
    'PROFILE_EDIT',
    'SCHEDULE_VIEW',
    'SCHEDULE_MANAGE',
    'MATCH_REQUEST',
    'PAYMENT_VIEW',
    'PAYMENT_REQUEST',
    'REPORT_VIEW',
  ],
  ADMIN: [
    'PROFILE_EDIT',
    'SCHEDULE_VIEW',
    'SCHEDULE_MANAGE',
    'MATCH_REQUEST',
    'PAYMENT_VIEW',
    'PAYMENT_REQUEST',
    'REPORT_VIEW',
    'ADMIN_PANEL',
    'MEDICAL_RECORD_READ',
    'MEDICAL_RECORD_WRITE',
  ],
  SUPPORTER: []
};