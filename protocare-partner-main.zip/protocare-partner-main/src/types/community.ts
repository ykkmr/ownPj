// ============================================================
// 익명 커뮤니티 게시글 (community_posts)
// ============================================================
export interface CommunityPost {
  id: number;
  title: string;
  content: string;
  authorId: number;
  isAnonymous: boolean;
  likeCount: number;
  commentCount: number;
  viewCount: number;
  createdAt: string;
  updatedAt: string | null;
  createdBy: number;
  updatedBy: number | null;
}

// ============================================================
// 익명 커뮤니티 댓글 (community_comments)
// ============================================================
export interface CommunityComment {
  id: number;
  postId: number;
  parentId: number | null;   // 대댓글용
  content: string;
  authorId: number;
  isAnonymous: boolean;
  likeCount: number;
  createdAt: string;
  updatedAt: string | null;
  createdBy: number;
  updatedBy: number | null;
}

// ============================================================
// 커뮤니티 좋아요 (community_likes)
// ============================================================
export type CommunityLikeTargetType = 'POST' | 'COMMENT';

export interface CommunityLike {
  id: number;
  userId: number;
  targetType: CommunityLikeTargetType;
  targetId: number;
  likedAt: string;
  createdAt: string;
  updatedAt: string | null;
}

// ============================================================
// 익명 커뮤니티 신고 (community_reports)
// ============================================================
export type CommunityReportTargetType = 'POST' | 'COMMENT';
export type CommunityReportReason =
  | 'SPAM'
  | 'OBSCENE'
  | 'ABUSE'
  | 'ILLEGAL'
  | 'ETC';
export type CommunityReportStatus =
  | 'RECEIVED'
  | 'IN_REVIEW'
  | 'ACTION_TAKEN'
  | 'DISMISSED';

export interface CommunityReport {
  id: number;
  reporterId: number;
  targetType: CommunityReportTargetType;
  targetId: number;
  reason: CommunityReportReason;
  description: string | null;
  status: CommunityReportStatus;
  resolvedAt: string | null;
  resolvedBy: number | null;
  createdAt: string;
  updatedAt: string | null;
  createdBy: number;
  updatedBy: number | null;
}
