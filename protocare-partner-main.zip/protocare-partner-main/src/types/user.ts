// ============================================================
// 회원 (users)
// ============================================================
export type UserType = 'REQUESTER' | 'SUPPORTER';
export type UserGender = 'MALE' | 'FEMALE' | 'OTHER';
export type SocialProvider = 'KAKAO' | 'NAVER';

export interface User {
  id: number;
  userId: string;
  name: string;
  email: string | null;
  phoneNumber: string | null;
  type: UserType;
  gender: UserGender | null;
  birth: string | null;
  provider: SocialProvider | null;
  providerId: string | null;
  profileImageUrl: string | null;
  lastLoginAt: string;
  createdAt: string;
  updatedAt: string | null;
  notificationSetting: boolean;
  marketingInfoAgree: boolean;
}

// ============================================================
// 소셜 계정 연동 (social_accounts)
// ============================================================
export interface SocialAccount {
  id: number;
  userId: number;
  provider: SocialProvider;
  providerId: string;
  email: string | null;
  linkedAt: string;
  unlinkedAt: string | null;
  createdAt: string;
  updatedAt: string | null;
}

// ============================================================
// 디바이스 토큰 (device_tokens)
// ============================================================
export type DevicePlatform = 'AOS' | 'IOS';

export interface DeviceToken {
  id: number;
  userId: number;
  token: string;
  platform: DevicePlatform;
  deviceId: string | null;
  appVersion: string | null;
  isActive: boolean;
  lastUsedAt: string | null;
  createdAt: string;
  updatedAt: string | null;
}

// ============================================================
// 본인인증 이력 (identity_verifications)
// ============================================================
export type VerificationType = 'SIGNUP' | 'SUPPORTER_REG' | 'PASSWORD_RESET';
export type VerificationMethod = 'SMS' | 'KAKAO';
export type VerificationStatus = 'PENDING' | 'SUCCESS' | 'FAILED' | 'EXPIRED';

export interface IdentityVerification {
  id: number;
  userId: number | null;
  type: VerificationType;
  method: VerificationMethod;
  phoneNumber: string;
  status: VerificationStatus;
  verifiedAt: string | null;
  expiredAt: string;
  attemptCount: number;
  ci: string | null;
  createdAt: string;
  updatedAt: string | null;
}

// ============================================================
// 알림 설정 (notification_settings)
// ============================================================
export interface NotificationSetting {
  id: number;
  userId: number;
  statusPushOn: boolean;
  statusKakaoOn: boolean;
  statusSmsOn: boolean;
  marketingPushOn: boolean;
  marketingKakaoOn: boolean;
  marketingSmsOn: boolean;
  nightPushBlock: boolean;
  createdAt: string;
  updatedAt: string | null;
}
