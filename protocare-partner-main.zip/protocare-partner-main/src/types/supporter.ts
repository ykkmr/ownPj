// ============================================================
// 서포터 프로필 (supporter_profiles)
// ============================================================
export type SupporterStatus = 'PENDING' | 'APPROVED' | 'REJECTED';
export type ServiceType = 'HOSPITAL' | 'ELDERLY' | 'CHILD';

export interface SupporterProfile {
  id: number;
  userId: number;
  status: SupporterStatus;
  serviceTypes: ServiceType[];
  activityRegions: string[];
  intro: string | null;
  profileImageUrl: string | null;
  isVisible: boolean;
  approvedAt: string | null;
  rejectedReason: string | null;
  createdAt: string;
  updatedAt: string | null;
  createdBy: number;
  updatedBy: number | null;
}

// ============================================================
// 자격증 (certifications)
// ============================================================
export type CertificationStatus = 'PENDING' | 'VERIFIED' | 'REJECTED';

export interface Certification {
  id: number;
  userId: number;
  name: string;
  issuer: string | null;
  issuedDate: string | null;
  fileUrl: string;
  status: CertificationStatus;
  verifiedAt: string | null;
  rejectedReason: string | null;
  createdAt: string;
  updatedAt: string | null;
  createdBy: number;
  updatedBy: number | null;
}

// ============================================================
// 자격시험 결과 (qualification_exam_results)
// ============================================================
export interface QualificationExamResult {
  id: number;
  userId: number;
  examVersion: string;
  score: number;
  passYn: boolean;
  takenAt: string;
  answers: Record<string, string> | null;
  createdAt: string;
  updatedAt: string | null;
  createdBy: number;
  updatedBy: number | null;
}

// ============================================================
// 성향 태그 (personality_tags)
// ============================================================
export type PersonalityTagCode = 'ACTIVE' | 'CARING' | 'QUIET' | 'CALM' | 'FRIENDLY';

export interface PersonalityTag {
  id: number;
  userId: number;
  tagCode: PersonalityTagCode;
  tagName: string;
  createdAt: string;
  updatedAt: string | null;
  createdBy: number;
  updatedBy: number | null;
}

// ============================================================
// 지원서 (supporter_applications)
// ============================================================
export type SupporterApplicationStatus = 'NORMAL' | 'DELETED';

export interface SupporterApplication {
  id: number;
  userId: number;
  status: SupporterApplicationStatus;
  intro: string | null;
  agreements: string | null;
  createdAt: string;
  updatedAt: string | null;
}

// ============================================================
// 파트너 교육 이력 (training_histories)
// ============================================================
export type TrainingContentType = 'VIDEO' | 'MANUAL';

export interface TrainingHistory {
  id: number;
  userId: number;
  contentType: TrainingContentType;
  contentId: string;
  contentName: string;
  progress: number; // 0~100
  isCompleted: boolean;
  completedAt: string | null;
  createdAt: string;
  updatedAt: string | null;
  createdBy: number;
  updatedBy: number | null;
}
