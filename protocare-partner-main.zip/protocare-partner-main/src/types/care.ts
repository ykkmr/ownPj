// ============================================================
// 케어요청 (care_requests)
// ============================================================
export type CareRequestType = 'HOSPITAL' | 'ELDERLY' | 'CHILD';

export interface CareRequest {
  id: number;
  type: CareRequestType;
  addRequest: string | null;
  startAt: string;
  endAt: string;
  from: string | null;
  to: string | null;
  createdAt: string;
  updatedAt: string | null;
  createdBy: number;
  updatedBy: number | null;
}

// ============================================================
// 케어 지원 (care_applications)
// ============================================================
export type CareApplicationStatus =
  | 'PENDING'
  | 'IN_REVIEW'
  | 'ACCEPTED'
  | 'REJECTED'
  | 'CANCELLED';

export interface CareApplication {
  id: number;
  careRequestId: number;
  supporterId: number;
  status: CareApplicationStatus;
  message: string | null;
  appliedAt: string;
  acceptedAt: string | null;
  rejectedAt: string | null;
  rejectedReason: string | null;
  createdAt: string;
  updatedAt: string | null;
  createdBy: number;
  updatedBy: number | null;
}

// ============================================================
// 매칭 (matchings)
// ============================================================
export type MatchingStatus =
  | 'PENDING'
  | 'MATCHED'
  | 'IN_PROGRESS'
  | 'COMPLETED'
  | 'CANCELLED';

export interface Matching {
  id: number;
  careRequestId: number;
  supporterId: number;
  status: MatchingStatus;
  matchedAt: string | null;
  startedAt: string | null;
  completedAt: string | null;
  cancelledAt: string | null;
  cancelReason: string | null;
  totalAmount: number;
  createdAt: string;
  updatedAt: string | null;
  createdBy: number;
  updatedBy: number | null;
}

// ============================================================
// 케어 일정 (care_schedules)
// ============================================================
export type CareScheduleStatus = 'SCHEDULED' | 'COMPLETED' | 'CANCELLED';

export interface CareSchedule {
  id: number;
  matchingId: number;
  supporterId: number;
  careRequestId: number;
  scheduledDate: string;   // YYYY-MM-DD
  startTime: string;       // HH:mm
  endTime: string;         // HH:mm
  status: CareScheduleStatus;
  isAuto: boolean;
  createdAt: string;
  updatedAt: string | null;
  createdBy: number;
  updatedBy: number | null;
}

// ============================================================
// 돌봄 기록 (care_logs)
// ============================================================
export type CareLogType = 'MEAL' | 'BATH' | 'PHOTO' | 'MEMO' | 'OTHER';

export interface CareLog {
  id: number;
  matchingId: number;
  supporterId: number;
  type: CareLogType;
  content: string | null;
  mediaUrls: string[];
  recordedAt: string;
  createdAt: string;
  updatedAt: string | null;
  createdBy: number;
  updatedBy: number | null;
}
