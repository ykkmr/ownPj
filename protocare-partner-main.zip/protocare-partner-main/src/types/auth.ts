export interface AuthSendRequest {
  phone: string;
}

export interface AuthVerifyRequest {
  phone: string;
  code: string;
}

export interface AuthResponse {
  success: boolean;
  message?: string;
  token?: string;
}

export type UserRole = 'USER' | 'PATIENT' | 'SUPPORTER_BASIC' | 'SUPPORTER_PREMIUM' | 'ADMIN' | 'SUPPORTER' | 'REQUESTER';

export interface User {
  id: string;
  name: string;
  role: UserRole;
}