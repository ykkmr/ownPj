import { Navigate, Outlet } from 'react-router-dom';
import { useAuthStore } from '../../store/auth.store';
import { UserRole } from '@/types/auth';

interface PrivateRouteProps {
  allowedTypes?: ('REQUESTER' | 'SUPPORTER')[];
}

// 상단에 매핑 테이블이 없다면 정의 (예시)
const ROLE_TO_TYPE: Record<UserRole, 'REQUESTER' | 'SUPPORTER' | 'ADMIN'> = {
  
  
  USER: 'REQUESTER',
  REQUESTER: 'REQUESTER',
  PATIENT: 'REQUESTER',
  SUPPORTER_BASIC: 'SUPPORTER',
  SUPPORTER_PREMIUM: 'SUPPORTER',
  SUPPORTER: 'SUPPORTER',
  ADMIN: 'ADMIN',
};

export default function PrivateRoute({ allowedTypes }: PrivateRouteProps) {
  const { isAuthenticated, user } = useAuthStore();

  if (!isAuthenticated || !user) {
    return <Navigate to="/login" replace />;
  }

  // 타입 단언을 통해 Record 인덱싱 에러 해결
  const userType = ROLE_TO_TYPE[user.role as UserRole];

  if (allowedTypes && !allowedTypes.includes(userType as any)) {
    return <Navigate to="/" replace />;
  }

  return <Outlet />;
}
