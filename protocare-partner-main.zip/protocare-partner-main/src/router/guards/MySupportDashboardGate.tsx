import { Navigate } from 'react-router-dom';
import { useAuthStore } from '@/store/auth.store';
import MySupportDashboardPage from '@/pages/supporter/MySupportDashboardPage';

const REGISTERED_SUPPORTER_ROLES = ['SUPPORTER', 'SUPPORTER_BASIC', 'SUPPORTER_PREMIUM'] as const;
type RegisteredRole = (typeof REGISTERED_SUPPORTER_ROLES)[number];

export default function MySupportDashboardGate() {
  const user = useAuthStore((state) => state.user);

  if (user && REGISTERED_SUPPORTER_ROLES.includes(user.role as RegisteredRole)) {
    return <Navigate to="/supporter/mysupport/active" replace />;
  }

  return <MySupportDashboardPage />;
}
