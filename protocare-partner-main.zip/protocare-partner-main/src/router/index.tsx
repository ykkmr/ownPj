import { createBrowserRouter, RouterProvider, Navigate } from 'react-router-dom';
import PrivateRoute from './guards/PrivateRoute';
import MySupportDashboardGate from './guards/MySupportDashboardGate';

// ── 공개 페이지 ───────────────────────────────────────────────
import OnboardingPage from '../pages/onboarding/OnboardingPage';
import LoginPage from '../pages/common/LoginPage';
import OAuthCallbackPage from '../pages/common/OAuthCallbackPage';
import SupporterIntroPage from '../pages/common/SupporterIntroPage';
import ServiceIntroPage from '../pages/common/ServiceIntroPage';
import SupporterGuidePage from '../pages/common/SupporterGuidePage';
import { FindAccount } from '../pages/auth/FindAccount';
import { FindIdComplete } from '../pages/auth/FindIdComplete';
import { PasswordReset } from '../pages/auth/PasswordReset';

// ── 회원가입 플로우 ───────────────────────────────────────────
import SignupPage from '../pages/common/SignupPage';
import { SignupStep1 } from '../features/auth/SignupStep1';
import { SignupComplete } from '../features/auth/SignupComplete';

// ── 마이서포트 (사이드바 대시보드) ───────────────────────────
import MySupportFaqPage from '../pages/supporter/MySupportFaqPage';
import MySupportActiveDashboardPage from '../pages/supporter/MySupportActiveDashboardPage';
import CareHistoryPage from '../pages/supporter/CareHistoryPage';
import MySupportSchedulePage from '../pages/supporter/MySupportSchedulePage';
import MySupportEarningsPage from '../pages/supporter/MySupportEarningsPage';
import MySupportExplorePage from '../pages/supporter/MySupportExplorePage';
import MySupportProfilePage from '../pages/supporter/MySupportProfilePage';
import MySupportApplicationsPage from '../pages/supporter/MySupportApplicationsPage';
import MySupportNotificationsPage from '../pages/supporter/MySupportNotificationsPage';
import MySupportNoticesPage from '../pages/supporter/MySupportNoticesPage';
import MySupportTermsPage from '../pages/supporter/MySupportTermsPage';
import MySupportInquiryPage from '../pages/supporter/MySupportInquiryPage';
import MySupportInquiryFormPage from '../pages/supporter/MySupportInquiryFormPage';
import SupportLogPage from '../pages/supporter/SupportLogPage';

// ── 서포터 지원 플로우 ────────────────────────────────────────
import SupporterApplyIntroPage from '../pages/supporter/apply/SupporterApplyIntroPage';
import SupporterApplyTermsPage from '../pages/supporter/apply/SupporterApplyTermsPage';
import SupporterApplyFormPage from '../pages/supporter/apply/SupporterApplyFormPage';
import SupporterApplyExamPage from '../pages/supporter/apply/SupporterApplyExamPage';
import SupporterApplyCertPage from '../pages/supporter/apply/SupporterApplyCertPage';
import SupporterApplyRegionPage from '../pages/supporter/apply/SupporterApplyRegionPage';
import SupporterApplyTagPage from '../pages/supporter/apply/SupporterApplyTagPage';
import SupporterApplyCompletePage from '../pages/supporter/apply/SupporterApplyCompletePage';

// ── 서포터 전용 페이지 (로그인 + SUPPORTER) ──────────────────
import SupporterHomePage from '../pages/supporter/SupporterHomePage';
import SupporterCareRequestListPage from '../pages/supporter/SupporterCareRequestListPage';
import SupporterApplicationListPage from '../pages/supporter/SupporterApplicationListPage';
import SupporterMatchingListPage from '../pages/supporter/SupporterMatchingListPage';
import SupporterMatchingDetailPage from '../pages/supporter/SupporterMatchingDetailPage';
import CareLogPage from '../pages/supporter/CareLogPage';
import CareSchedulePage from '../pages/supporter/CareSchedulePage';
import EarningsPage from '../pages/supporter/EarningsPage';
import SupporterMyPage from '../pages/supporter/SupporterMyPage';
import SupporterProfilePage from '../pages/supporter/SupporterProfilePage';
import SupporterCertListPage from '../pages/supporter/SupporterCertListPage';
import SupporterEducationPage from '../pages/supporter/SupporterEducationPage';
import SupporterReviewPage from '../pages/supporter/SupporterReviewPage';

// ── 의뢰인 전용 페이지 (로그인 + REQUESTER) ──────────────────
import RequesterHomePage from '../pages/requester/RequesterHomePage';
import CareRequestListPage from '../pages/requester/CareRequestListPage';
import CareRequestNewPage from '../pages/requester/CareRequestNewPage';
import CareRequestDetailPage from '../pages/requester/CareRequestDetailPage';
import RequesterMatchingListPage from '../pages/requester/RequesterMatchingListPage';
import RequesterMatchingDetailPage from '../pages/requester/RequesterMatchingDetailPage';
import RequesterMyPage from '../pages/requester/RequesterMyPage';
import FamilyGroupPage from '../pages/requester/FamilyGroupPage';
import RequesterPaymentPage from '../pages/requester/RequesterPaymentPage';
import RequesterReviewPage from '../pages/requester/RequesterReviewPage';

// ── 공통 인증 페이지 (로그인 필요, 타입 무관) ────────────────
import FaqPage from '../pages/common/FaqPage';
import CommunityListPage from '../pages/common/CommunityListPage';
import CommunityNewPage from '../pages/common/CommunityNewPage';
import CommunityDetailPage from '../pages/common/CommunityDetailPage';
import AiChatPage from '../pages/common/AiChatPage';
import SupportPage from '../pages/common/SupportPage';
import SupportNewPage from '../pages/common/SupportNewPage';
import SettingsPage from '../pages/common/SettingsPage';
import NotificationSettingPage from '../pages/common/NotificationSettingPage';
import AccountSettingPage from '../pages/common/AccountSettingPage';

const router = createBrowserRouter([
  // ───────────────────────────────────────────────────────────
  // 공개 (비로그인 접근 가능)
  // ───────────────────────────────────────────────────────────
  { path: '/', element: <OnboardingPage /> },
  { path: '/onboarding', element: <OnboardingPage /> },
  { path: '/login', element: <LoginPage /> },
  { path: '/oauth/callback/:provider', element: <OAuthCallbackPage /> },
  { path: '/supporter-intro', element: <SupporterIntroPage /> },
  { path: '/service-intro', element: <ServiceIntroPage /> },
  { path: '/guide', element: <SupporterGuidePage /> },
  { path: '/app', element: <Navigate to="/supporter/home" replace /> },
  { path: '/find-account', element: <FindAccount /> },
  { path: '/find-account/complete', element: <FindIdComplete /> },
  { path: '/reset-password', element: <PasswordReset /> },
  // ───────────────────────────────────────────────────────────
  // 회원가입 플로우
  //   /signup        → 진입점 (약관동의와 동일)
  //   /signup/step1  → 약관동의
  //   /signup/step2  → 정보 입력
  //   /signup/step3  → 가입 완료
  // ───────────────────────────────────────────────────────────
  { path: '/faq', element: <FaqPage /> },
  { path: '/signup', element: <SignupPage /> },
  { path: '/signup/step1', element: <SignupPage /> },
  { path: '/signup/step2', element: <SignupStep1 /> },
  { path: '/signup/step3', element: <SignupComplete /> },

  // ───────────────────────────────────────────────────────────
  // 서포터 지원 플로우 (비로그인 → 중간에 로그인 유도)
  //   /supporter/apply              → 소개
  //   /supporter/apply/terms        → 약관 동의
  //   /supporter/apply/form         → 지원서 작성
  //   /supporter/apply/exam         → 역량 검사
  //   /supporter/apply/certifications→ 자격증 등록
  //   /supporter/apply/regions      → 활동 지역
  //   /supporter/apply/tags         → 케어 태그
  //   /supporter/apply/complete     → 지원 완료
  // ───────────────────────────────────────────────────────────
  {
    path: '/supporter/apply',
    children: [
      { index: true, element: <SupporterApplyIntroPage /> },
      { path: 'terms', element: <SupporterApplyTermsPage /> },
      { path: 'form', element: <SupporterApplyFormPage /> },
      { path: 'exam', element: <SupporterApplyExamPage /> },
      { path: 'certifications', element: <SupporterApplyCertPage /> },
      { path: 'regions', element: <SupporterApplyRegionPage /> },
      { path: 'tags', element: <SupporterApplyTagPage /> },
      { path: 'complete', element: <SupporterApplyCompletePage /> },
    ],
  },

  // ───────────────────────────────────────────────────────────
  // 의뢰인 전용 (로그인 + REQUESTER)
  // ───────────────────────────────────────────────────────────
  {
    element: <PrivateRoute allowedTypes={['REQUESTER']} />,
    children: [
      { path: '/requester/home', element: <RequesterHomePage /> },
      { path: '/requester/care-requests', element: <CareRequestListPage /> },
      { path: '/requester/care-requests/new', element: <CareRequestNewPage /> },
      { path: '/requester/care-requests/:id', element: <CareRequestDetailPage /> },
      { path: '/requester/matchings', element: <RequesterMatchingListPage /> },
      { path: '/requester/matchings/:id', element: <RequesterMatchingDetailPage /> },
      { path: '/requester/mypage', element: <RequesterMyPage /> },
      { path: '/requester/mypage/family', element: <FamilyGroupPage /> },
      { path: '/requester/mypage/payments', element: <RequesterPaymentPage /> },
      { path: '/requester/mypage/reviews', element: <RequesterReviewPage /> },
    ],
  },

  // ───────────────────────────────────────────────────────────
  // 서포터 전용 (로그인 + SUPPORTER)
  //   마이서포트 포함 — 비로그인/비서포터는 각각 /login, / 로 리다이렉트
  // ───────────────────────────────────────────────────────────
  {
    element: <PrivateRoute allowedTypes={['SUPPORTER']} />,
    children: [
      // 마이서포트 대시보드
      { path: '/supporter/mysupport', element: <MySupportDashboardGate /> },
      { path: '/supporter/mysupport/active', element: <MySupportActiveDashboardPage /> },
      { path: '/supporter/mysupport/history', element: <CareHistoryPage /> },
      { path: '/supporter/mysupport/schedule', element: <MySupportSchedulePage /> },
      { path: '/supporter/mysupport/explore', element: <MySupportExplorePage /> },
      { path: '/supporter/mysupport/earnings', element: <MySupportEarningsPage /> },
      { path: '/supporter/mysupport/profile', element: <MySupportProfilePage /> },
      { path: '/supporter/mysupport/applications', element: <MySupportApplicationsPage /> },
      { path: '/supporter/mysupport/notifications', element: <MySupportNotificationsPage /> },
      { path: '/supporter/mysupport/notices', element: <MySupportNoticesPage /> },
      { path: '/supporter/mysupport/faq', element: <MySupportFaqPage /> },
      { path: '/supporter/mysupport/terms', element: <MySupportTermsPage /> },
      { path: '/supporter/mysupport/inquiry', element: <MySupportInquiryPage /> },
      { path: '/supporter/mysupport/inquiry/new', element: <MySupportInquiryFormPage /> },
      { path: '/supporter/mysupport/support-log', element: <SupportLogPage /> },
      // 서포터 전용
      { path: '/supporter/home', element: <SupporterHomePage /> },
      { path: '/supporter/care-requests', element: <SupporterCareRequestListPage /> },
      { path: '/supporter/care-applications', element: <SupporterApplicationListPage /> },
      { path: '/supporter/matchings', element: <SupporterMatchingListPage /> },
      { path: '/supporter/matchings/:id', element: <SupporterMatchingDetailPage /> },
      { path: '/supporter/matchings/:id/logs', element: <CareLogPage /> },
      { path: '/supporter/schedule', element: <CareSchedulePage /> },
      { path: '/supporter/earnings', element: <EarningsPage /> },
      { path: '/supporter/mypage', element: <SupporterMyPage /> },
      { path: '/supporter/mypage/profile', element: <SupporterProfilePage /> },
      { path: '/supporter/mypage/certifications', element: <SupporterCertListPage /> },
      { path: '/supporter/mypage/education', element: <SupporterEducationPage /> },
      { path: '/supporter/mypage/reviews', element: <SupporterReviewPage /> },
    ],
  },

  // ───────────────────────────────────────────────────────────
  // 공통 인증 페이지 (로그인 필요, 타입 무관)
  // ───────────────────────────────────────────────────────────
  {
    element: <PrivateRoute />,
    children: [
      { path: '/community', element: <CommunityListPage /> },
      { path: '/community/new', element: <CommunityNewPage /> },
      { path: '/community/:id', element: <CommunityDetailPage /> },
      { path: '/ai-chat', element: <AiChatPage /> },
      { path: '/support', element: <SupportPage /> },
      { path: '/support/new', element: <SupportNewPage /> },
      { path: '/settings', element: <SettingsPage /> },
      { path: '/settings/notifications', element: <NotificationSettingPage /> },
      { path: '/settings/account', element: <AccountSettingPage /> },
    ],
  },
]);

export default function AppRouter() {
  return <RouterProvider router={router} />;
}
