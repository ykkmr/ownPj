import { ErrorBoundary } from '@/components/error/ErrorBoundary';
import { ErrorFallback } from '@/components/error/ErrorFallback';
import { QueryProvider } from '@/providers/QueryProvider';
import AppRouter from '@/router';
import { useInitAuth } from '@/hooks/useInitAuth';
import { useSessionTimeout } from '@/hooks/useSessionTimeout';
import { I18nProvider } from '@/i18n';
import { Toaster } from '@/components/ui/Toaster';
import { GlobalModal } from '@/components/ui/GlobalModal';
import { GlobalLoading } from '@/components/ui/GlobalLoading';
import { OverlayManager } from '@/components/ui/OverlayManager';
import { NetworkStatusBanner } from '@/components/ui/NetworkStatusBanner';
import { QueryFetchingBar } from '@/components/ui/QueryFetchingBar';

const AppShell = () => {
  useSessionTimeout();
  return (
    <>
      <QueryFetchingBar />
      <NetworkStatusBanner />
      <AppRouter />
      <Toaster />
      <GlobalModal />
      <GlobalLoading />
      <OverlayManager />
    </>
  );
};

const AppContent = () => {
  const { isInitializing } = useInitAuth();
  if (isInitializing) return null;
  return <AppShell />;
};

/**
 * 앱 루트 — Provider 조립 순서:
 * I18nProvider → ErrorBoundary → QueryProvider → AppContent
 */
const App = () => (
  <I18nProvider>
    <ErrorBoundary>
      <QueryProvider>
        <ErrorBoundary fallback={(error, reset) => <ErrorFallback error={error} reset={reset} />}>
          <AppContent />
        </ErrorBoundary>
      </QueryProvider>
    </ErrorBoundary>
  </I18nProvider>
);

export default App;
