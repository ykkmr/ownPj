// TODO: UI 디자인 확정 후 구현
export default function CareRequestNewPage() {
  return <div>CareRequestNewPage</div>;
}
