import { useEffect, useState } from 'react';
import { ApplyGnb } from '@/components/apply/ApplyGnb';
import { SiteFooter } from '@/components/apply/SiteFooter';
import { MySupportSidebar } from '@/components/supporter/MySupportSidebar';
import { useNotificationConfigs, useUpdateNotificationConfigs } from '@/hooks/useSupporter';
import { toast } from '@/store/toast.store';
import type { NotificationConfig } from '@/types/api';
import './MySupportNotificationsPage.css';

// ── Toggle ─────────────────────────────────────────────────────────────────
interface ToggleProps {
  checked: boolean;
  onChange: (checked: boolean) => void;
  label: string;
}

function Toggle({ checked, onChange, label }: ToggleProps) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={label}
      className={`notif-toggle${checked ? ' notif-toggle--on' : ''}`}
      onClick={() => onChange(!checked)}
    >
      <span className="notif-toggle__knob" />
    </button>
  );
}

// ── NotificationRow ────────────────────────────────────────────────────────
interface NotificationRowProps {
  label: string;
  checked: boolean;
  onChange: (checked: boolean) => void;
}

function NotificationRow({ label, checked, onChange }: NotificationRowProps) {
  return (
    <div className="notif-row">
      <span className="notif-row__label">{label}</span>
      <Toggle checked={checked} onChange={onChange} label={label} />
    </div>
  );
}

// API 필드명 ↔ UI 키 매핑
const NOTIFICATION_ITEMS: { apiKey: keyof NotificationConfig; label: string }[] = [
  { apiKey: 'customActivityEnabled', label: '맞춤 활동 알림' },
  { apiKey: 'activityScheduleEnabled', label: '활동 및 스케줄 알림' },
  { apiKey: 'incomeSettlementEnabled', label: '수익 및 정산 알림' },
  { apiKey: 'serviceGuideEnabled', label: '서비스 가이드 및 공지 알림' },
];

const DEFAULT_CONFIG: NotificationConfig = {
  customActivityEnabled: true,
  activityScheduleEnabled: true,
  incomeSettlementEnabled: true,
  serviceGuideEnabled: false,
};

export default function MySupportNotificationsPage() {
  const { data: serverConfig, isLoading } = useNotificationConfigs();
  const { mutate: saveConfig } = useUpdateNotificationConfigs();

  const [localConfig, setLocalConfig] = useState<NotificationConfig>(DEFAULT_CONFIG);

  // 서버에서 데이터 로드되면 로컬 상태에 동기화
  useEffect(() => {
    if (serverConfig) setLocalConfig(serverConfig);
  }, [serverConfig]);

  function handleChange(apiKey: keyof NotificationConfig, value: boolean) {
    const updated = { ...localConfig, [apiKey]: value };
    setLocalConfig(updated);
    saveConfig(updated, {
      onError: () => {
        // 실패 시 이전 값으로 롤백
        setLocalConfig(localConfig);
        toast.danger('알림 설정 저장에 실패했습니다.');
      },
    });
  }

  return (
    <div className="mypage-page">
      <ApplyGnb variant="simple" />
      <main className="mypage-main">
        <MySupportSidebar activeItemId="notifications" />
        <div className="mypage-content">
          <div className="mypage-greeting">
            <h1 className="mypage-greeting__heading">알림 설정</h1>
            <p className="mypage-greeting__sub">
              내 주변의 새로운 케어 요청과 수익이 되는 소중한 기회들을 놓치지 않고 전해드려요.
            </p>
          </div>

          {isLoading ? (
            <p className="notif-loading">불러오는 중...</p>
          ) : (
            <div className="notif-list">
              {NOTIFICATION_ITEMS.map(({ apiKey, label }) => (
                <NotificationRow
                  key={apiKey}
                  label={label}
                  checked={localConfig[apiKey]}
                  onChange={(value) => handleChange(apiKey, value)}
                />
              ))}
            </div>
          )}
        </div>
      </main>
      <SiteFooter />
    </div>
  );
}
