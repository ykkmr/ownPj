import { useNavigate } from 'react-router-dom';
import { useCareApplicationList, useCancelCareApplication } from '@/hooks/useCareApplication';
import { PageHeader, Card, CardBody, ListStateView, Badge, Button } from '@/components/ui';
import { ApplyGnb } from '@/components/apply/ApplyGnb';
import { MobileGnb } from '@/components/apply/MobileGnb';
import { SiteFooter } from '@/components/apply/SiteFooter';
import type { CareApplicationStatus } from '@/types';

const STATUS_LABEL: Record<CareApplicationStatus, string> = {
  PENDING: '검토중',
  IN_REVIEW: '검토중',
  ACCEPTED: '수락됨',
  REJECTED: '거절됨',
  CANCELLED: '취소됨',
};

const STATUS_VARIANT: Record<CareApplicationStatus, 'default' | 'success' | 'danger' | 'warning'> =
  {
    PENDING: 'default',
    IN_REVIEW: 'warning',
    ACCEPTED: 'success',
    REJECTED: 'danger',
    CANCELLED: 'default',
  };

export default function SupporterApplicationListPage() {
  const navigate = useNavigate();
  const { data, isLoading, isError, refetch } = useCareApplicationList();
  const cancel = useCancelCareApplication();

  return (
    <div className="mypage-page">
      <MobileGnb />
      <ApplyGnb variant="simple" />
      <div className="flex flex-col">
        <PageHeader title="내 지원 목록" showBack onBack={() => navigate(-1)} />

        <div className="p-4">
          <ListStateView
            isLoading={isLoading}
            isError={isError}
            isEmpty={!data?.content.length}
            emptyTitle="지원 내역이 없습니다"
            emptyDescription="케어요청에 지원하면 여기에 표시됩니다"
            onRetry={refetch}
          >
            <div className="flex flex-col gap-3">
              {data?.content.map((app) => (
                <Card key={app.id}>
                  <CardBody>
                    <div className="flex items-center justify-between">
                      <div className="flex flex-col gap-1">
                        <p className="font-medium">케어요청 #{app.careRequestId}</p>
                        <p className="text-sm text-gray-500">
                          지원일: {app.appliedAt.slice(0, 10)}
                        </p>
                        {app.message && <p className="text-sm text-gray-400">{app.message}</p>}
                      </div>
                      <div className="flex flex-col items-end gap-2">
                        <Badge variant={STATUS_VARIANT[app.status]}>
                          {STATUS_LABEL[app.status]}
                        </Badge>
                        {app.status === 'PENDING' && (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => cancel.mutate(app.id)}
                            disabled={cancel.isPending}
                          >
                            취소
                          </Button>
                        )}
                      </div>
                    </div>
                  </CardBody>
                </Card>
              ))}
            </div>
          </ListStateView>
        </div>
      </div>
      <SiteFooter />
    </div>
  );
}
