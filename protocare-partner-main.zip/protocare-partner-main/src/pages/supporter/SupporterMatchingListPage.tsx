import { useNavigate } from 'react-router-dom';
import { useMatchingList } from '@/hooks/useMatching';
import { PageHeader, Card, CardBody, ListStateView, Badge } from '@/components/ui';
import { ApplyGnb } from '@/components/apply/ApplyGnb';
import { MobileGnb } from '@/components/apply/MobileGnb';
import { SiteFooter } from '@/components/apply/SiteFooter';
import type { MatchingStatus } from '@/types';

const STATUS_LABEL: Record<MatchingStatus, string> = {
  PENDING: '대기중',
  MATCHED: '매칭완료',
  IN_PROGRESS: '진행중',
  COMPLETED: '완료',
  CANCELLED: '취소됨',
};

const STATUS_VARIANT: Record<MatchingStatus, 'default' | 'primary' | 'success' | 'danger'> = {
  PENDING: 'default',
  MATCHED: 'primary',
  IN_PROGRESS: 'default',
  COMPLETED: 'success',
  CANCELLED: 'danger',
};

export default function SupporterMatchingListPage() {
  const navigate = useNavigate();
  const { data, isLoading, isError, refetch } = useMatchingList();

  return (
    <div className="mypage-page">
      <MobileGnb />
      <ApplyGnb variant="simple" />
      <div className="flex flex-col">
        <PageHeader title="매칭 목록" showBack onBack={() => navigate(-1)} />

        <div className="p-4">
          <ListStateView
            isLoading={isLoading}
            isError={isError}
            isEmpty={!data?.content.length}
            emptyTitle="매칭 내역이 없습니다"
            onRetry={refetch}
          >
            <div className="flex flex-col gap-3">
              {data?.content.map((matching) => (
                <Card
                  key={matching.id}
                  className="cursor-pointer active:bg-gray-50"
                  onClick={() => navigate(`/supporter/matchings/${matching.id}`)}
                >
                  <CardBody>
                    <div className="flex items-center justify-between">
                      <div className="flex flex-col gap-1">
                        <p className="font-medium">매칭 #{matching.id}</p>
                        <p className="text-sm text-gray-500">
                          {matching.matchedAt ? matching.matchedAt.slice(0, 10) : '-'} 매칭
                        </p>
                        <p className="text-sm font-medium text-blue-600">
                          {matching.totalAmount.toLocaleString()}원
                        </p>
                      </div>
                      <Badge variant={STATUS_VARIANT[matching.status]}>
                        {STATUS_LABEL[matching.status]}
                      </Badge>
                    </div>
                  </CardBody>
                </Card>
              ))}
            </div>
          </ListStateView>
        </div>
      </div>
      <SiteFooter />
    </div>
  );
}
