import { useState } from 'react';
import type { ReactNode } from 'react';
import { ApplyGnb } from '@/components/apply/ApplyGnb';
import { SiteFooter } from '@/components/apply/SiteFooter';
import { MySupportSidebar } from '@/components/supporter/MySupportSidebar';
import './MySupportNoticesPage.css';

// ── Types ──────────────────────────────────────────────────────────────────
interface Notice {
  id: number;
  category: string;
  title: string;
  body: ReactNode;
}

// ── Static data ─────────────────────────────────────────────────────────────
const NOTICES: Notice[] = [
  {
    id: 1,
    category: '규정',
    title: '노쇼(No-show) 및 당일 취소 시 활동 제한 규정 안내',
    body: (
      <>
        <p>안녕하세요, ProtoCare 운영팀입니다.</p>
        <p>
          {`ProtoCare는 파트너님과 사용자 간의 '상호 신뢰'를 바탕으로 운영되는 서비스입니다. 약속된 시간에 예고 없이 나타나지 않는 노쇼(No-show)나 직전 당일 취소는 케어를 간절히 기다리는 사용자에게 큰 상실감을 주며, 서비스 전체의 신뢰를 저하시킵니다.`}
        </p>
        <p>
          이에 따라 원활한 서비스 운영을 위한 활동 제한 규정을 아래와 같이 안내드리오니, 활동 전
          반드시 숙지해 주시기 바랍니다.
        </p>
        <p>&nbsp;</p>
        <p>1. 노쇼(No-show) 발생 시</p>
        <ul>
          <li>정의: 사전 연락 없이 약속된 케어 시간에 현장에 나타나지 않는 경우</li>
          <li>제한 조치: * 1회 발생: 서비스 이용 30일 정지 및 페널티 부과</li>
          <ul>
            <li>2회 발생: 파트너 자격 영구 박탈 및 재가입 불가</li>
          </ul>
        </ul>
        <p>2. 당일 취소 발생 시</p>
        <ul>
          <li>정의: 케어 시작 시간 기준 24시간 이내에 취소 의사를 밝히는 경우</li>
          <li>제한 조치: * 누적 3회 이상: 서비스 이용 14일 정지</li>
          <ul>
            <li>단, 갑작스러운 사고나 질병 등 증빙이 가능한 사유는 예외로 인정됩니다.</li>
          </ul>
        </ul>
        <p>3. 노쇼 및 취소 예방 가이드</p>
        <ul>
          <li>
            스케줄 재확인: 활동 전날 [예정된 돌봄] 탭에서 시간과 장소를 다시 한번 체크해 주세요.
          </li>
          <li>
            미리 소통하기: 부득이하게 늦거나 일정 변경이 필요한 경우, 즉시 앱 내 [보호자 연락하기]를
            통해 상황을 공유해 주세요.
          </li>
        </ul>
        <p>&nbsp;</p>
        <p>
          파트너님의 정직하고 책임감 있는 활동이 더 나은 케어 문화를 만듭니다. ProtoCare는 언제나
          파트너님의 소중한 활동을 지원하기 위해 최선을 다하겠습니다.
        </p>
        <p>&nbsp;</p>
        <p>감사합니다.</p>
      </>
    ),
  },
  {
    id: 2,
    category: '운영',
    title: '병원 동행 시 필수 체크리스트: 진료 기록지 작성법 안내',
    body: <p>공지 내용이 준비 중입니다.</p>,
  },
  {
    id: 3,
    category: '이벤트',
    title: "'나의 첫 케어 후기' 남기고 스타벅스 기프티콘 받으세요!",
    body: <p>공지 내용이 준비 중입니다.</p>,
  },
  {
    id: 4,
    category: '정산',
    title: '이번 주 정산 일정 변경 안내 (공휴일 관련)',
    body: <p>공지 내용이 준비 중입니다.</p>,
  },
  {
    id: 5,
    category: '안내',
    title: "서포터 안전을 위한 '안심번호 서비스' 도입 및 사용 방법",
    body: <p>공지 내용이 준비 중입니다.</p>,
  },
  {
    id: 6,
    category: '교육',
    title: '시니어 케어가 처음이신가요? 초보 서포터를 위한 가이드북 배포',
    body: <p>공지 내용이 준비 중입니다.</p>,
  },
  {
    id: 7,
    category: '업데이트',
    title: "더 빠르고 정확하게! '활동 일지' 작성 기능 개선 안내",
    body: <p>공지 내용이 준비 중입니다.</p>,
  },
  {
    id: 8,
    category: '수익',
    title: '5월 가정의 달 기념, 병원 동행 서비스 활동비 프로모션 안내',
    body: <p>공지 내용이 준비 중입니다.</p>,
  },
  {
    id: 9,
    category: '필독',
    title: "서포터 활동 시작 전 '성범죄 이력 및 배경 조회' 필수 안내",
    body: <p>공지 내용이 준비 중입니다.</p>,
  },
];

const TOTAL_PAGES = 5;

// ── Sub-components ─────────────────────────────────────────────────────────
interface NoticeRowProps {
  notice: Notice;
  isOpen: boolean;
  onToggle: () => void;
}

function NoticeRow({ notice, isOpen, onToggle }: NoticeRowProps) {
  return (
    <li className="notice-item">
      <button type="button" className="notice-row" onClick={onToggle} aria-expanded={isOpen}>
        <span className="notice-row__category">[{notice.category}]</span>
        <span className="notice-row__title">{notice.title}</span>
        <img
          src="/assets/icons/keyboard_arrow_down.svg"
          alt=""
          aria-hidden="true"
          className={`notice-row__arrow${isOpen ? ' notice-row__arrow--open' : ''}`}
        />
      </button>
      {isOpen && (
        <div className="notice-body">
          <div className="notice-body__box">{notice.body}</div>
        </div>
      )}
    </li>
  );
}

interface PaginationProps {
  current: number;
  total: number;
  onChange: (page: number) => void;
}

function Pagination({ current, total, onChange }: PaginationProps) {
  return (
    <nav className="notice-pagination" aria-label="페이지 탐색">
      {Array.from({ length: total }, (_, i) => i + 1).map((page) => (
        <button
          key={page}
          type="button"
          className={`notice-pagination__btn${current === page ? ' notice-pagination__btn--active' : ''}`}
          onClick={() => onChange(page)}
          aria-current={current === page ? 'page' : undefined}
        >
          {page}
        </button>
      ))}
      <button
        type="button"
        className="notice-pagination__next"
        onClick={() => onChange(Math.min(current + 1, total))}
        aria-label="다음 페이지"
        disabled={current === total}
      >
        <img
          src="/assets/icons/arrow_forward_ios.svg"
          alt=""
          aria-hidden="true"
          width={20}
          height={20}
        />
      </button>
    </nav>
  );
}

// ── Page ───────────────────────────────────────────────────────────────────
export default function MySupportNoticesPage() {
  const [currentPage, setCurrentPage] = useState(1);
  const [expandedId, setExpandedId] = useState<number | null>(1);

  function toggleNotice(id: number) {
    setExpandedId((prev) => (prev === id ? null : id));
  }

  return (
    <div className="mypage-page">
      <ApplyGnb variant="simple" />
      <main className="mypage-main">
        <MySupportSidebar activeItemId="notices" />
        <div className="mypage-content">
          <div className="mypage-greeting">
            <h1 className="mypage-greeting__heading">공지사항</h1>
            <p className="mypage-greeting__sub">
              서비스 이용 안내부터 중요 정책 변경까지, ProtoCare 서포터가 꼭 알아야 할 소식들을
              전해드립니다.
            </p>
          </div>

          <div className="notice-section">
            <ul className="notice-list">
              {NOTICES.map((notice) => (
                <NoticeRow
                  key={notice.id}
                  notice={notice}
                  isOpen={expandedId === notice.id}
                  onToggle={() => toggleNotice(notice.id)}
                />
              ))}
            </ul>

            <Pagination current={currentPage} total={TOTAL_PAGES} onChange={setCurrentPage} />
          </div>
        </div>
      </main>
      <SiteFooter />
    </div>
  );
}
