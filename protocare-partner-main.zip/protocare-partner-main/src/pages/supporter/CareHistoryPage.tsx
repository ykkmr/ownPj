import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ApplyGnb } from '@/components/apply/ApplyGnb';
import { MobileGnb } from '@/components/apply/MobileGnb';
import { SiteFooter } from '@/components/apply/SiteFooter';
import { MySupportSidebar } from '@/components/supporter/MySupportSidebar';
import { CareCard, CareRecord, CardVariant } from '@/components/supporter/CareCard';
import { ContactModal } from '@/components/supporter/ContactModal';
import './CareHistoryPage.css';

type TabId = '신청' | '예정' | '완료';

const TABS: { id: TabId; label: string }[] = [
  { id: '신청', label: '신청한 돌봄' },
  { id: '예정', label: '예정된 돌봄' },
  { id: '완료', label: '완료된 돌봄' },
];

const MOCK_APPLIED_RECORDS: CareRecord[] = [
  {
    id: '1',
    careType: '병원동행',
    title: '참나무요양병원',
    patient: '여성 / 64세 / 55kg이상 / 160cm이하',
    schedule: '26.05.02 (토) 오전 10:00 ~ 오후 1시 (3시간)',
    address: '서울특별시 구로구 고척로31길9 (개봉동)',
    price: '60,000원',
    requests: ['식사 시 천천히', '정확한 시간 약 복용', '응급시 보호자/병원 즉시 연락'],
  },
  {
    id: '2',
    careType: '병원동행',
    title: '참나무요양병원',
    patient: '여성 / 64세 / 55kg이상 / 160cm이하',
    schedule: '26.05.02 (토) 오전 10:00 ~ 오후 1시 (3시간)',
    address: '서울특별시 구로구 고척로31길9 (개봉동)',
    price: '60,000원',
    requests: ['식사 시 천천히', '정확한 시간 약 복용', '응급시 보호자/병원 즉시 연락'],
  },
  {
    id: '3',
    careType: '병원동행',
    title: '참나무요양병원',
    patient: '여성 / 64세 / 55kg이상 / 160cm이하',
    schedule: '26.05.02 (토) 오전 10:00 ~ 오후 1시 (3시간)',
    address: '서울특별시 구로구 고척로31길9 (개봉동)',
    price: '60,000원',
    requests: ['식사 시 천천히', '정확한 시간 약 복용', '응급시 보호자/병원 즉시 연락'],
  },
  {
    id: '4',
    careType: '병원동행',
    title: '참나무요양병원',
    patient: '여성 / 64세 / 55kg이상 / 160cm이하',
    schedule: '26.05.02 (토) 오전 10:00 ~ 오후 1시 (3시간)',
    address: '서울특별시 구로구 고척로31길9 (개봉동)',
    price: '60,000원',
    requests: ['식사 시 천천히', '정확한 시간 약 복용', '응급시 보호자/병원 즉시 연락'],
  },
];

const MOCK_SCHEDULED_RECORDS: CareRecord[] = [
  {
    id: '3',
    careType: '병원동행',
    title: '참나무요양병원',
    patient: '여성 / 64세 / 55kg이상 / 160cm이하',
    schedule: '26.05.02 (토) 오전 10:00 ~ 오후 1시 (3시간)',
    address: '서울특별시 구로구 고척로31길9 (개봉동)',
    price: '60,000원',
    requests: ['식사 시 천천히', '정확한 시간 약 복용', '응급시 보호자/병원 즉시 연락'],
  },
  {
    id: '4',
    careType: '어르신돌봄',
    title: '서울특별시 구로구',
    patient: '여성 / 64세 / 55kg이상 / 160cm이하',
    schedule: '26.05.02 (토) 오전 10:00 ~ 오후 6시 (8시간)',
    address: '서울특별시 구로구 고척로31길9 (개봉동)',
    price: '120,000원',
    requests: ['식사 시 천천히', '정확한 시간 약 복용', '응급시 보호자/병원 즉시 연락'],
  },
];

const MOCK_COMPLETED_RECORDS: CareRecord[] = [
  {
    id: '5',
    careType: '병원동행',
    title: '참나무요양병원',
    patient: '여성 / 64세 / 55kg이상 / 160cm이하',
    schedule: '26.05.02 (토) 오전 10:00 ~ 오후 1시 (3시간)',
    address: '서울특별시 구로구 고척로31길9 (개봉동)',
    price: '60,000원',
    requests: ['식사 시 천천히', '정확한 시간 약 복용', '응급시 보호자/병원 즉시 연락'],
  },
  {
    id: '6',
    careType: '병원동행',
    title: '참나무요양병원',
    patient: '여성 / 64세 / 55kg이상 / 160cm이하',
    schedule: '26.05.02 (토) 오전 10:00 ~ 오후 1시 (3시간)',
    address: '서울특별시 구로구 고척로31길9 (개봉동)',
    price: '60,000원',
    requests: ['식사 시 천천히', '정확한 시간 약 복용', '응급시 보호자/병원 즉시 연락'],
  },
  {
    id: '7',
    careType: '병원동행',
    title: '참나무요양병원',
    patient: '여성 / 64세 / 55kg이상 / 160cm이하',
    schedule: '26.05.02 (토) 오전 10:00 ~ 오후 1시 (3시간)',
    address: '서울특별시 구로구 고척로31길9 (개봉동)',
    price: '60,000원',
    requests: ['식사 시 천천히', '정확한 시간 약 복용', '응급시 보호자/병원 즉시 연락'],
    hasLog: true,
  },
];

const TAB_RECORDS: Record<TabId, CareRecord[]> = {
  신청: MOCK_APPLIED_RECORDS,
  예정: MOCK_SCHEDULED_RECORDS,
  완료: MOCK_COMPLETED_RECORDS,
};

const TAB_VARIANT: Record<TabId, CardVariant> = {
  신청: 'applied',
  예정: 'scheduled',
  완료: 'completed',
};

const BADGE_CONFIG: Record<string, { bg: string; label: string }> = {
  병원동행: { bg: '#e1f2ff', label: '병원 동행' },
  어르신돌봄: { bg: '#efeeff', label: '어르신 돌봄' },
  아이돌봄: { bg: '#fff4d3', label: '아이 돌봄' },
};

// ── Mobile icon components ─────────────────────────────────────────────────

function IconClock() {
  return (
    <svg className="m-history-card__icon" viewBox="0 0 24 24" fill="#737373" aria-hidden="true">
      <path d="M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm.5-13H11v6l5.25 3.15.75-1.23-4.5-2.67V7z" />
    </svg>
  );
}

function IconLocation() {
  return (
    <svg className="m-history-card__icon" viewBox="0 0 24 24" fill="#737373" aria-hidden="true">
      <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z" />
    </svg>
  );
}

function IconPerson() {
  return (
    <svg className="m-history-card__icon" viewBox="0 0 24 24" fill="#737373" aria-hidden="true">
      <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z" />
    </svg>
  );
}

function IconPrice() {
  return (
    <svg className="m-history-card__icon" viewBox="0 0 24 24" fill="#737373" aria-hidden="true">
      <path d="M21.41 11.58l-9-9C12.05 2.22 11.55 2 11 2H4c-1.1 0-2 .9-2 2v7c0 .55.22 1.05.59 1.42l9 9c.36.36.86.58 1.41.58.55 0 1.05-.22 1.41-.59l7-7c.37-.36.59-.86.59-1.41 0-.55-.23-1.06-.59-1.42zM5.5 7C4.67 7 4 6.33 4 5.5S4.67 4 5.5 4 7 4.67 7 5.5 6.33 7 5.5 7z" />
    </svg>
  );
}

// ── MobileHistoryCard ──────────────────────────────────────────────────────

interface MobileHistoryCardProps {
  record: CareRecord;
  variant: CardVariant;
  isOpen: boolean;
  onToggle: () => void;
  onContactClick?: (id: string) => void;
  onLogClick?: () => void;
}

function MobileHistoryCard({
  record,
  variant,
  isOpen,
  onToggle,
  onContactClick,
  onLogClick,
}: MobileHistoryCardProps) {
  const badge = BADGE_CONFIG[record.careType] ?? { bg: '#f0f0f0', label: record.careType };
  //const isScheduled = variant === 'scheduled';

  const chevronImg = (
    <img
      src="/assets/icons/keyboard_arrow_down.svg"
      alt=""
      aria-hidden="true"
      width="16"
      height="16"
      className={`m-history-card__chevron${isOpen ? ' m-history-card__chevron--open' : ''}`}
    />
  );

  return (
    <div className={`m-history-card${variant === 'completed' ? ' m-history-card--completed' : ''}`}>
      {/* Badge + title in horizontal row, then clock + location */}
      <div className="m-history-card__top">
        <div className="m-history-card__badge-row">
          <span className="m-history-card__badge" style={{ backgroundColor: badge.bg }}>
            {badge.label}
          </span>
          <h3 className="m-history-card__title">{record.title}</h3>
        </div>
        <div className="m-history-card__row">
          <IconClock />
          <span className="m-history-card__meta">{record.schedule}</span>
        </div>
        <div className="m-history-card__row">
          <IconLocation />
          <span className="m-history-card__meta">{record.address}</span>
        </div>
      </div>

      {/* Expanded detail: patient, price, requests — only for applied / scheduled */}
      {isOpen && variant !== 'completed' && (
        <div className="m-history-card__detail">
          {record.patient && (
            <div className="m-history-card__row">
              <IconPerson />
              <span className="m-history-card__meta">{record.patient}</span>
            </div>
          )}
          {record.price && (
            <div className="m-history-card__row">
              <IconPrice />
              <span className="m-history-card__meta">{record.price}</span>
            </div>
          )}
          {record.requests && record.requests.length > 0 && (
            <div className="m-history-card__requests">
              <p className="m-history-card__requests-label">요청 사항</p>
              <ul className="m-history-card__requests-list">
                {record.requests.map((req, i) => (
                  <li key={i}>{req}</li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}

      {/* Scheduled: always-visible footer — right-aligned toggle + filled button */}
      {variant === 'scheduled' && (
        <div className="m-history-card__footer">
          <button type="button" className="m-history-card__toggle-footer" onClick={onToggle}>
            상세 보기
            {chevronImg}
          </button>
          <button
            type="button"
            className="m-history-card__btn m-history-card__btn--filled"
            onClick={() => onContactClick?.(record.id)}
          >
            보호자 연락하기
          </button>
        </div>
      )}

      {/* Completed: no accordion — review link + log button always visible */}
      {variant === 'completed' && (
        <div className="m-history-card__completed-footer">
          <button type="button" className="m-history-card__review-link">
            리뷰 보기
          </button>
          <button
            type="button"
            className={`m-history-card__btn ${record.hasLog ? 'm-history-card__btn--outline' : 'm-history-card__btn--filled'}`}
            onClick={onLogClick}
          >
            {record.hasLog ? '서포트 기록 수정' : '서포트 기록 작성'}
          </button>
        </div>
      )}

      {/* Applied: centered toggle + outline button in expanded state */}
      {variant === 'applied' && (
        <>
          <button type="button" className="m-history-card__toggle" onClick={onToggle}>
            상세 보기
            {chevronImg}
          </button>
          {isOpen && (
            <div className="m-history-card__actions">
              <button type="button" className="m-history-card__btn m-history-card__btn--outline">
                지원 취소
              </button>
            </div>
          )}
        </>
      )}
    </div>
  );
}

// ── Page ───────────────────────────────────────────────────────────────────

export default function CareHistoryPage() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<TabId>('신청');
  const [contactRecordId, setContactRecordId] = useState<string | null>(null);
  const [openCardId, setOpenCardId] = useState<string | null>(null);

  function handleTabChange(tab: TabId) {
    setActiveTab(tab);
    setOpenCardId(null);
  }

  function handleCardToggle(id: string) {
    setOpenCardId((prev) => (prev === id ? null : id));
  }

  return (
    <div className="mypage-page">
      <MobileGnb />
      <ApplyGnb variant="simple" />
      <main className="mypage-main">
        <MySupportSidebar activeItemId="history" />
        <div className="mypage-content">
          <div className="mypage-greeting">
            <h1 className="mypage-greeting__heading">이용 내역</h1>
            <p className="mypage-greeting__sub">
              신청, 예정, 완료된 돌봄 이용 내역을 확인할 수 있습니다
            </p>
          </div>
          <div className="care-history__section">
            <div className="care-history__tabs-wrapper">
              <div className="care-history__tabs">
                {TABS.map((tab) => (
                  <button
                    key={tab.id}
                    type="button"
                    className={`care-history__tab${activeTab === tab.id ? ' care-history__tab--active' : ''}`}
                    onClick={() => handleTabChange(tab.id)}
                  >
                    {tab.label} ({TAB_RECORDS[tab.id].length})
                  </button>
                ))}
              </div>
            </div>
            <div
              className={`care-history__grid${activeTab === '완료' ? ' care-history__grid--single' : ''}`}
            >
              {TAB_RECORDS[activeTab].map((record) => (
                <CareCard
                  key={record.id}
                  record={record}
                  variant={TAB_VARIANT[activeTab]}
                  onContactClick={(id) => setContactRecordId(id)}
                  onLogClick={() => navigate('/supporter/mysupport/support-log')}
                />
              ))}
            </div>
          </div>
        </div>
      </main>

      {/* ── Mobile layout ────────────────────────────────────────── */}
      <div className="history-mobile">
        <div className="history-mobile__heading">
          <h1 className="history-mobile__title">이용 내역</h1>
          <p className="history-mobile__sub">
            신청, 예정, 완료된 돌봄 이용 내역을 확인할 수 있습니다
          </p>
        </div>

        <div className="history-mobile__tabs-wrapper">
          <div className="history-mobile__tabs">
            {TABS.map((tab) => (
              <button
                key={tab.id}
                type="button"
                className={`history-mobile__tab${activeTab === tab.id ? ' history-mobile__tab--active' : ''}`}
                onClick={() => handleTabChange(tab.id)}
              >
                {tab.label} ({TAB_RECORDS[tab.id].length})
              </button>
            ))}
          </div>
        </div>

        <div className="history-mobile__list">
          {TAB_RECORDS[activeTab].map((record) => (
            <MobileHistoryCard
              key={record.id}
              record={record}
              variant={TAB_VARIANT[activeTab]}
              isOpen={openCardId === record.id}
              onToggle={() => handleCardToggle(record.id)}
              onContactClick={(id) => setContactRecordId(id)}
              onLogClick={() => navigate('/supporter/mysupport/support-log')}
            />
          ))}
        </div>

        {activeTab === '완료' && (
          <button type="button" className="history-mobile__load-more">
            더보기
            <img
              src="/assets/icons/keyboard_arrow_down.svg"
              alt=""
              aria-hidden="true"
              width="24"
              height="24"
            />
          </button>
        )}
      </div>

      <SiteFooter />
      {contactRecordId && <ContactModal onClose={() => setContactRecordId(null)} />}
    </div>
  );
}
