import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { ApplyGnb } from '@/components/apply/ApplyGnb';
import { SiteFooter } from '@/components/apply/SiteFooter';
import { MySupportSidebar } from '@/components/supporter/MySupportSidebar';
import './MySupportNoticesPage.css';
import './MySupportInquiryPage.css';

// ── Types ──────────────────────────────────────────────────────────────────
type InquiryStatus = 'pending' | 'done';

interface InquiryItem {
  id: number;
  status: InquiryStatus;
  title: string;
  date: string;
  question: string;
  answer: string;
}

// ── Static data ─────────────────────────────────────────────────────────────
const INQUIRIES: InquiryItem[] = [
  {
    id: 1,
    status: 'pending',
    title: '현장에 도착했는데 보호자분과 연락이 안 됩니다. 노쇼 처리되나요?',
    date: '26.01.23',
    question: '현장에 도착했는데 보호자분과 연락이 안 됩니다. 노쇼 처리되나요?',
    answer: '',
  },
  {
    id: 2,
    status: 'done',
    title: '지난주 주말 활동비 가산금이 누락된 것 같아요. 확인 부탁드립니다.',
    date: '26.01.12',
    question: '지난주 주말 활동비 가산금이 누락된 것 같아요. 확인 부탁드립니다.',
    answer: `안녕하세요, 파트너님. 파트너님의 소중한 활동비 정산과 관련하여 불편을 드려 죄송합니다.

문의하신 [5월 2일(토) ~ 5월 3일(일)] 활동 내역을 확인한 결과, 시스템 상의 일시적인 동기화 오류로 인해 주말 가산금(20%)이 최종 정산액에 반영되지 않은 것으로 확인되었습니다.

정확한 처리 안내를 드립니다.

• 누락 항목: 5월 1주차 주말 활동 가산금 (총 2건)
• 처리 방법: 누락된 금액은 차주 목요일(5월 14일) 정산 시 '기타 지급액' 항목으로 합산되어 입금될 예정입니다.
• 확인 방법: [수익 관리 > 정산 내역 > 5월 2주차 상세 명세]에서 추가 지급 내역을 확인하실 수 있습니다.

항상 정직하게 활동해 주시는 파트너님의 권익을 보호하기 위해 더욱 세밀한 정산 시스템을 구축하도록 노력하겠습니다.
혹시 추가로 궁금하신 점이 있다면 언제든 문의해 주세요.

감사합니다. ProtoCare 운영팀 드림`,
  },
  {
    id: 3,
    status: 'done',
    title: '이동 보조 중에 어르신이 살짝 긁히는 찰과상을 입으셨습니다. 보험 접수 방법 알려주세요.',
    date: '25.11.22',
    question:
      '이동 보조 중에 어르신이 살짝 긁히는 찰과상을 입으셨습니다. 보험 접수 방법 알려주세요.',
    answer: `안녕하세요. 파트너님께서 빠르게 상황을 공유해 주셔서 감사합니다.

활동 중 발생한 사고에 대한 보험 접수 방법을 안내드립니다.

• 사진 촬영: 부상 부위 및 현장 사진을 촬영해 두세요.
• 앱 내 신고: 마이서포트 > 활동 내역 > 해당 활동 > '사고 신고' 버튼을 통해 접수해 주세요.
• 서류 준비: 의료기관 영수증, 진단서(필요 시) 등을 보관해 두세요.

접수 후 영업일 기준 2일 이내에 담당 매니저가 연락드릴 예정입니다.`,
  },
  {
    id: 4,
    status: 'done',
    title: '요양보호사 자격증을 새로 취득했는데 프로필 업데이트는 어디서 하나요?',
    date: '25.05.09',
    question: '요양보호사 자격증을 새로 취득했는데 프로필 업데이트는 어디서 하나요?',
    answer: `안녕하세요, 파트너님. 자격증 취득을 축하드립니다!

자격증 등록은 마이서포트 > 내 정보 관리 > 자격증 탭에서 진행하실 수 있습니다.

• 자격증 사진 또는 스캔본을 첨부해 주세요.
• 검토는 영업일 기준 1~2일 소요됩니다.
• 승인 완료 후 프로필에 자동으로 반영됩니다.

추가 문의 사항이 있으시면 언제든지 연락 주세요!`,
  },
  {
    id: 5,
    status: 'done',
    title: '사용자가 서비스 범위가 아닌 창문 청소를 요구하시는데 어떻게 해야 하죠?',
    date: '25.03.09',
    question: '사용자가 서비스 범위가 아닌 창문 청소를 요구하시는데 어떻게 해야 하죠?',
    answer: `안녕하세요, 파트너님. 불편한 상황에 처하셨군요.

창문 청소는 ProtoCare의 서비스 범위에 포함되지 않습니다. 이런 경우 다음과 같이 정중하게 안내해 주세요.

"죄송합니다만, 창문 청소는 제가 제공하는 돌봄 서비스 범위에 포함되어 있지 않아 도와드리기 어렵습니다."

• 의뢰인이 계속 요구할 경우 앱 내 '도움 요청' 버튼을 통해 운영팀에 즉시 연락해 주세요.
• 서비스 범위 외 요청을 거부하셔도 불이익이 발생하지 않습니다.`,
  },
];

const ITEMS_PER_PAGE = 9;

// ── Sub-components ─────────────────────────────────────────────────────────
interface InquiryRowProps {
  item: InquiryItem;
  isOpen: boolean;
  onToggle: () => void;
}

function InquiryRow({ item, isOpen, onToggle }: InquiryRowProps) {
  return (
    <li className="inquiry-item">
      <button type="button" className="inquiry-row" onClick={onToggle} aria-expanded={isOpen}>
        <span
          className={`inquiry-badge ${item.status === 'pending' ? 'inquiry-badge--pending' : 'inquiry-badge--done'}`}
        >
          {item.status === 'pending' ? '접수 완료' : '답변 완료'}
        </span>
        <span className="inquiry-row__title">{item.title}</span>
        <span className="inquiry-row__date">{item.date}</span>
        <img
          src="/assets/icons/keyboard_arrow_down.svg"
          alt=""
          aria-hidden="true"
          className={`inquiry-row__arrow${isOpen ? ' inquiry-row__arrow--open' : ''}`}
        />
      </button>

      {isOpen && item.status === 'done' && (
        <div className="inquiry-body">
          <div className="inquiry-qa-box">
            <div className="inquiry-qa-item">
              <div className="inquiry-qa-circle" aria-hidden="true">
                Q
              </div>
              <p className="inquiry-qa-text">{item.question}</p>
            </div>
            <hr className="inquiry-qa-divider" />
            <div className="inquiry-qa-item">
              <div className="inquiry-qa-circle" aria-hidden="true">
                A
              </div>
              <p className="inquiry-qa-text">{item.answer}</p>
            </div>
          </div>
        </div>
      )}
    </li>
  );
}

interface PaginationProps {
  current: number;
  total: number;
  onChange: (page: number) => void;
}

function Pagination({ current, total, onChange }: PaginationProps) {
  if (total <= 1) return null;
  return (
    <nav className="notice-pagination" aria-label="페이지 탐색">
      {Array.from({ length: total }, (_, i) => i + 1).map((page) => (
        <button
          key={page}
          type="button"
          className={`notice-pagination__btn${current === page ? ' notice-pagination__btn--active' : ''}`}
          onClick={() => onChange(page)}
          aria-current={current === page ? 'page' : undefined}
        >
          {page}
        </button>
      ))}
      <button
        type="button"
        className="notice-pagination__next"
        onClick={() => onChange(Math.min(current + 1, total))}
        aria-label="다음 페이지"
        disabled={current === total}
      >
        <img
          src="/assets/icons/arrow_forward_ios.svg"
          alt=""
          aria-hidden="true"
          width={20}
          height={20}
        />
      </button>
    </nav>
  );
}

// ── Page ───────────────────────────────────────────────────────────────────
export default function MySupportInquiryPage() {
  const navigate = useNavigate();
  const [expandedId, setExpandedId] = useState<number | null>(2);
  const [currentPage, setCurrentPage] = useState(1);

  const totalPages = Math.max(1, Math.ceil(INQUIRIES.length / ITEMS_PER_PAGE));
  const paginated = useMemo(
    () => INQUIRIES.slice((currentPage - 1) * ITEMS_PER_PAGE, currentPage * ITEMS_PER_PAGE),
    [currentPage],
  );

  function toggleInquiry(id: number) {
    setExpandedId((prev) => (prev === id ? null : id));
  }

  return (
    <div className="mypage-page">
      <ApplyGnb variant="simple" />
      <main className="mypage-main">
        <MySupportSidebar activeItemId="inquiry" />
        <div className="mypage-content">
          <div className="mypage-greeting">
            <h1 className="mypage-greeting__heading">1:1 문의함</h1>
            <p className="mypage-greeting__sub">
              활동 중 겪으신 불편함이나 궁금하신 점을 남겨주세요. ProtoCare 매니저가 확인 후 최대한
              빠르게 답변해 드립니다.
            </p>
          </div>

          <div className="inquiry-section">
            <div className="inquiry-header">
              <h2 className="inquiry-header__title">문의 내역</h2>
              <button
                type="button"
                className="inquiry-write-btn"
                onClick={() => navigate('/supporter/mysupport/inquiry/new')}
              >
                <img
                  src="/assets/icons/edit.svg"
                  alt=""
                  aria-hidden="true"
                  className="inquiry-write-btn__icon"
                />
                문의하기
              </button>
            </div>

            <ul className="inquiry-list">
              {paginated.map((item) => (
                <InquiryRow
                  key={item.id}
                  item={item}
                  isOpen={expandedId === item.id}
                  onToggle={() => toggleInquiry(item.id)}
                />
              ))}
            </ul>

            <Pagination current={currentPage} total={totalPages} onChange={setCurrentPage} />
          </div>
        </div>
      </main>
      <SiteFooter />
    </div>
  );
}
