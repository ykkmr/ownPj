import { ApplyGnb } from '@/components/apply/ApplyGnb';
import { SiteFooter } from '@/components/apply/SiteFooter';
import { MySupportSidebar } from '@/components/supporter/MySupportSidebar';
import './MySupportDashboardPage.css';

const STATUS_CARD_ICON = '/assets/icons/Registration.svg';

// ── Types & static data ────────────────────────────────────────────────────
type ProgressState = 'done' | 'in-progress' | 'pending';

interface ProgressStep {
  label: string;
  state: ProgressState;
}

const REGISTRATION_STEPS: ProgressStep[] = [
  { label: '지원 접수', state: 'done' },
  { label: '서류 검토 중', state: 'done' },
  { label: '면접 진행', state: 'in-progress' },
  { label: '등록 완료', state: 'pending' },
];

function StepDot({ state }: { state: ProgressState }) {
  if (state === 'done') {
    return (
      <div className="mypage-progress__dot mypage-progress__dot--done">
        <svg
          viewBox="0 0 24 24"
          fill="white"
          aria-hidden="true"
          className="mypage-progress__check-icon"
        >
          <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z" />
        </svg>
      </div>
    );
  }
  if (state === 'in-progress') {
    return (
      <div className="mypage-progress__dot mypage-progress__dot--in-progress">
        <div className="mypage-progress__inner-dot" />
      </div>
    );
  }
  return <div className="mypage-progress__dot mypage-progress__dot--pending" />;
}

function RegistrationStatusCard() {
  return (
    <div className="mypage-status-card">
      <div className="mypage-status-card__header">
        <img src={STATUS_CARD_ICON} alt="" className="mypage-status-card__icon" />
        <p className="mypage-status-card__title">현재 등록 진행 상태</p>
      </div>

      <div className="mypage-progress">
        {REGISTRATION_STEPS.map((step, idx) => {
          const isLast = idx === REGISTRATION_STEPS.length - 1;
          const lineIsDone = !isLast && step.state === 'done';
          return (
            <div key={step.label} className="mypage-progress__segment">
              <StepDot state={step.state} />
              {!isLast && (
                <div
                  className={`mypage-progress__line${lineIsDone ? ' mypage-progress__line--done' : ' mypage-progress__line--pending'}`}
                />
              )}
            </div>
          );
        })}
      </div>

      <div className="mypage-progress__labels">
        {REGISTRATION_STEPS.map((step) => (
          <span key={step.label} className="mypage-progress__label">
            {step.label}
          </span>
        ))}
      </div>
    </div>
  );
}

// ── Page ───────────────────────────────────────────────────────────────────
export default function MySupportDashboardPage() {
  return (
    <div className="mypage-page">
      <ApplyGnb variant="simple" />
      <main className="mypage-main">
        <MySupportSidebar activeItemId="dashboard" />
        <div className="mypage-content">
          <div className="mypage-greeting">
            <h1 className="mypage-greeting__heading">안녕하세요, 000 서포터님</h1>
            <p className="mypage-greeting__sub">
              오늘도 따뜻한 돌봄을 부탁드립니다. 현재 서포터님의 활동 상태를 확인하세요.
            </p>
          </div>
          <RegistrationStatusCard />
        </div>
      </main>
      <SiteFooter />
    </div>
  );
}
