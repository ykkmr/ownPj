
import { useNavigate } from 'react-router-dom';
import { useAuthStore } from '@/store/auth.store';
import { useSupporterProfile } from '@/hooks/useSupporter';
import { PageHeader, Card, CardBody, Badge, Button, ListStateView } from '@/components/ui';
import { ApplyGnb } from '@/components/apply/ApplyGnb';
import { MobileGnb } from '@/components/apply/MobileGnb';
import { SiteFooter } from '@/components/apply/SiteFooter';

const MENU_ITEMS = [
  { label: '프로필 관리', path: '/supporter/mypage/profile' },
  { label: '자격증 관리', path: '/supporter/mypage/certifications' },
  { label: '교육 이력', path: '/supporter/mypage/education' },
  { label: '리뷰 확인', path: '/supporter/mypage/reviews' },
];

export default function SupporterMyPage() {
  const navigate = useNavigate();
  const user = useAuthStore((s) => s.user);
  const { data: profile, isLoading, isError, refetch } = useSupporterProfile();

  return (
    <div className="mypage-page">
      <MobileGnb />
      <ApplyGnb variant="simple" />
      <div className="flex flex-col">
        <PageHeader title="마이페이지" />

        <div className="flex flex-col gap-4 p-4">
          <ListStateView isLoading={isLoading} isError={isError} onRetry={refetch}>
            {profile && (
              <Card>
                <CardBody className="flex flex-col gap-2">
                  <p className="text-lg font-semibold">{user?.name}</p>
                  <div>
                    <Badge variant={profile.status === 'APPROVED' ? 'success' : 'warning'}>
                      {profile.status}
                    </Badge>
                  </div>
                  {profile.intro && <p className="text-sm text-gray-500">{profile.intro}</p>}
                  <p className="text-sm text-gray-400">
                    활동지역: {profile.activityRegions.join(', ')}
                  </p>
                </CardBody>
              </Card>
            )}
          </ListStateView>

          <div className="flex flex-col gap-2">
            {MENU_ITEMS.map((item) => (
              <Button
                key={item.path}
                variant="outline"
                className="w-full justify-start"
                onClick={() => navigate(item.path)}
              >
                {item.label}
              </Button>
            ))}
          </div>
        </div>
      </div>
      <SiteFooter />
    </div>
  );
}
