import { useNavigate } from 'react-router-dom';
import { ApplyGnb } from '@/components/apply/ApplyGnb';
import { MobileGnb } from '@/components/apply/MobileGnb';
import { SiteFooter } from '@/components/apply/SiteFooter';
import { MySupportSidebar } from '@/components/supporter/MySupportSidebar';
import './MySupportActiveDashboardPage.css';

// ── Types ──────────────────────────────────────────────────────────────────
type CareType = 'hospital' | 'elderly' | 'child';

interface CareItem {
  id: string;
  type: CareType;
  title: string;
  patientInfo: string;
  schedule: string;
  location: string;
  price: string;
  requests: string[];
}

// ── Desktop mock data ──────────────────────────────────────────────────────
const UPCOMING_CARES: CareItem[] = [
  {
    id: '1',
    type: 'hospital',
    title: '참나무요양병원',
    patientInfo: '여성 / 64세 / 55kg이상 / 160cm이하',
    schedule: '26.05.02 (토) 오전 10:00 ~ 오후 1시 (3시간)',
    location: '서울특별시 구로구 고척로31길9 (개봉동)',
    price: '60,000원',
    requests: ['식사 시 천천히', '정확한 시간 약 복용', '응급시 보호자/병원 즉시 연락'],
  },
  {
    id: '2',
    type: 'elderly',
    title: '서울특별시 구로구',
    patientInfo: '여성 / 64세 / 55kg이상 / 160cm이하',
    schedule: '26.05.02 (토) 오전 10:00 ~ 오후 6시 (8시간)',
    location: '서울특별시 구로구 고척로31길9 (개봉동)',
    price: '120,000원',
    requests: ['식사 시 천천히', '정확한 시간 약 복용', '응급시 보호자/병원 즉시 연락'],
  },
];

const RECOMMENDED_CARES: CareItem[] = [
  {
    id: '3',
    type: 'elderly',
    title: '서울특별시 구로구 개봉동',
    patientInfo: '여성 / 64세 / 55kg이상 / 160cm이하',
    schedule: '26.05.02 (토) 오전 10:00 ~ 오후 6시 (8시간)',
    location: '서울특별시 구로구 고척로31길9 (개봉동)',
    price: '120,000원',
    requests: ['식사 시 천천히', '정확한 시간 약 복용', '응급시 보호자/병원 즉시 연락'],
  },
  {
    id: '4',
    type: 'child',
    title: '서울특별시 구로구 오류동',
    patientInfo: '여성 / 7세 / 13kg이상 / 110cm이하',
    schedule: '26.05.02 (토) 오전 10:00 ~ 오후 1시 (3시간)',
    location: '서울특별시 구로구 고척로31길9 (오류동)',
    price: '60,000원',
    requests: ['식사 후 양치', '군것질 금지', '핸드폰 사용 금지(아이)'],
  },
];

// ── Mobile static data ─────────────────────────────────────────────────────
const QUICK_ACTIONS = [
  {
    label: '케어 탐색',
    icon: '/assets/icons/data_loss_prevention.svg',
    path: '/supporter/mysupport/explore',
  },
  {
    label: '이용 내역',
    icon: '/assets/icons/search_activity.svg',
    path: '/supporter/mysupport/history',
  },
  {
    label: '정산 관리',
    icon: '/assets/icons/credit_card_gear.svg',
    path: '/supporter/mysupport/settlement',
  },
  {
    label: '1:1 문의함',
    icon: '/assets/icons/volunteer_activism.svg',
    path: '/supporter/mysupport/support/inquiry',
  },
] as const;

const MOBILE_STATS = [
  { label: '완료된 케어', value: '12', unit: '건' },
  { label: '평균 고객 평점', value: '4.9', unit: '/5.0' },
  { label: '이번달 예상 수익', value: '820,000', unit: '원' },
] as const;

const WEEK_DAYS = ['일', '월', '화', '수', '목', '금', '토'] as const;
const WEEK_DATES = [
  { date: 10, kind: 'sun' as const },
  { date: 11, kind: 'default' as const },
  { date: 12, kind: 'today' as const },
  { date: 13, kind: 'default' as const },
  { date: 14, kind: 'default' as const },
  { date: 15, kind: 'default' as const },
  { date: 16, kind: 'sat' as const },
];

const CARE_SCHEDULE = [
  { time: '9:00~13:00', type: 'elderly' as CareType, location: '영등포구 신림동', active: true },
  { time: '14:00~16:00', type: 'hospital' as CareType, location: '서울대병원', active: false },
  { time: '17:00~21:00', type: 'child' as CareType, location: '강서구 공항동', active: false },
];

const REVIEWS = [
  {
    name: '김*나',
    kind: '병원동행',
    rating: 4,
    text: '갑작스러운 부모님 정기 검진 날 업무 때문에 도저히 시간을 낼 수 없었는데, 매니저님이 병원 입구부터 수납, 약국까지 동행해주셔서 정말 든든했습니다. 특히 진료가 끝난 뒤 의사 선생님 말씀을 조목조목 정리해서 리포트로 보내주신 덕분에 저도 같이 진료를 본 기분이었어요.',
  },
  {
    name: '김*나',
    kind: '병원동행',
    rating: 4,
    text: '갑작스러운 부모님 정기 검진 날 업무 때문에 도저히 시간을 낼 수 없었는데, 매니저님이 병원 입구부터 수납, 약국까지 동행해주셔서 정말 든든했습니다. 특히 진료가 끝난 뒤 의사 선생님 말씀을 조목조목 정리해서 리포트로 보내주신 덕분에 저도 같이 진료를 본 기분이었어요.',
  },
  {
    name: '김*나',
    kind: '병원동행',
    rating: 4,
    text: '갑작스러운 부모님 정기 검진 날 업무 때문에 도저히 시간을 낼 수 없었는데, 매니저님이 병원 입구부터 수납, 약국까지 동행해주셔서 정말 든든했습니다. 특히 진료가 끝난 뒤 의사 선생님 말씀을 조목조목 정리해서 리포트로 보내주신 덕분에 저도 같이 진료를 본 기분이었어요.',
  },
];

// ── Desktop Icons ──────────────────────────────────────────────────────────
function IconPerson() {
  return (
    <svg className="ms-care-card__info-icon" viewBox="0 0 24 24" fill="#737373" aria-hidden="true">
      <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z" />
    </svg>
  );
}

function IconClock() {
  return (
    <svg className="ms-care-card__info-icon" viewBox="0 0 24 24" fill="#737373" aria-hidden="true">
      <path d="M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm.5-13H11v6l5.25 3.15.75-1.23-4.5-2.67V7z" />
    </svg>
  );
}

function IconLocation() {
  return (
    <svg className="ms-care-card__info-icon" viewBox="0 0 24 24" fill="#737373" aria-hidden="true">
      <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z" />
    </svg>
  );
}

function IconPrice() {
  return (
    <svg className="ms-care-card__info-icon" viewBox="0 0 24 24" fill="#737373" aria-hidden="true">
      <path d="M21.41 11.58l-9-9C12.05 2.22 11.55 2 11 2H4c-1.1 0-2 .9-2 2v7c0 .55.22 1.05.59 1.42l9 9c.36.36.86.58 1.41.58.55 0 1.05-.22 1.41-.59l7-7c.37-.36.59-.86.59-1.41 0-.55-.23-1.06-.59-1.42zM5.5 7C4.67 7 4 6.33 4 5.5S4.67 4 5.5 4 7 4.67 7 5.5 6.33 7 5.5 7z" />
    </svg>
  );
}

function IconArrow() {
  return (
    <img
      src="/assets/icons/arrow_forward_ios.svg"
      alt=""
      aria-hidden="true"
      width="20"
      height="20"
      style={{ filter: 'brightness(0) invert(1) brightness(0.45)', flexShrink: 0 }}
    />
  );
}

function IconCheck() {
  return <img src="/assets/icons/check.svg" alt="" aria-hidden="true" width="20" height="20" />;
}

function IconStats() {
  return (
    <svg className="ms-act-card__icon" viewBox="0 0 24 24" fill="#47c7ac" aria-hidden="true">
      <path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-7 14H7v-2h5v2zm5-4H7v-2h10v2zm0-4H7V7h10v2z" />
    </svg>
  );
}

// ── Badge ──────────────────────────────────────────────────────────────────
const BADGE_LABEL: Record<CareType, string> = {
  hospital: '병원 동행',
  elderly: '어르신 돌봄',
  child: '아이 돌봄',
};

function CareBadge({ type }: { type: CareType }) {
  return <span className={`ms-care-badge ms-care-badge--${type}`}>{BADGE_LABEL[type]}</span>;
}

// ── Desktop CareCard ───────────────────────────────────────────────────────
interface CareCardProps {
  item: CareItem;
  mode: 'upcoming' | 'recommended';
}

function CareCard({ item, mode }: CareCardProps) {
  return (
    <div className="ms-care-card">
      <CareBadge type={item.type} />
      <div className="ms-care-card__body">
        <p className="ms-care-card__title">{item.title}</p>
        <div className="ms-care-card__info">
          <div className="ms-care-card__info-row">
            <IconPerson />
            <span className="ms-care-card__info-text">{item.patientInfo}</span>
          </div>
          <div className="ms-care-card__info-row">
            <IconClock />
            <span className="ms-care-card__info-text">{item.schedule}</span>
          </div>
          <div className="ms-care-card__info-row">
            <IconLocation />
            <span className="ms-care-card__info-text">{item.location}</span>
          </div>
          <div className="ms-care-card__info-row">
            <IconPrice />
            <span className="ms-care-card__info-text">{item.price}</span>
          </div>
        </div>
        <div className="ms-care-card__requests">
          <span className="ms-care-card__req-label">요청 사항</span>
          <ul className="ms-care-card__req-list">
            {item.requests.map((req) => (
              <li key={req}>{req}</li>
            ))}
          </ul>
        </div>
      </div>
      {mode === 'upcoming' ? (
        <div className="ms-care-card__actions">
          <button type="button" className="ms-care-card__btn ms-care-card__btn--outline">
            보호자 연락하기
          </button>
          <button type="button" className="ms-care-card__btn ms-care-card__btn--primary">
            상세보기
          </button>
        </div>
      ) : (
        <button type="button" className="ms-care-card__btn ms-care-card__btn--primary">
          지원하기
        </button>
      )}
    </div>
  );
}

// ── Desktop SummaryCards ───────────────────────────────────────────────────
function SummaryCards() {
  return (
    <div className="ms-act-cards">
      <div className="ms-act-card ms-act-card--flex">
        <div className="ms-act-card__header">
          <IconStats />
          <p className="ms-act-card__title">완료된 케어 서비스</p>
        </div>
        <div className="ms-act-card__value-row">
          <span className="ms-act-card__value">12</span>
          <span className="ms-act-card__unit">건</span>
        </div>
        <div className="ms-act-card__divider" />
        <div className="ms-act-card__footer">
          <span>이번 달 누적 건</span>
          <span>31회</span>
        </div>
      </div>

      <div className="ms-act-card ms-act-card--flex">
        <div className="ms-act-card__header">
          <IconStats />
          <p className="ms-act-card__title">평균 고객 평점</p>
        </div>
        <div className="ms-act-card__value-row">
          <span className="ms-act-card__value">4.9</span>
          <span className="ms-act-card__unit">/5.0</span>
        </div>
        <div className="ms-act-card__divider" />
        <div className="ms-act-card__check-row">
          <IconCheck />
          <span className="ms-act-card__check-text">지난 달 대비 0.2% 상승</span>
        </div>
      </div>

      <div className="ms-act-card ms-act-card--fixed">
        <div className="ms-act-card__header">
          <IconStats />
          <p className="ms-act-card__title">이번달 예상 수익</p>
        </div>
        <div className="ms-act-card__value-row">
          <span className="ms-act-card__value">820,000</span>
          <span className="ms-act-card__unit">원</span>
        </div>
        <div className="ms-act-card__divider" />
        <div className="ms-act-card__footer">
          <span>상세 내역 보기</span>
          <span>→</span>
        </div>
      </div>
    </div>
  );
}

// ── Mobile sub-components ─────────────────────────────────────────────────
function MobileQuickActions() {
  const navigate = useNavigate();
  return (
    <div className="ms-act-quick">
      {QUICK_ACTIONS.map((action) => (
        <button
          key={action.label}
          type="button"
          className="ms-act-quick__btn"
          onClick={() => navigate(action.path)}
        >
          <img src={action.icon} alt="" className="ms-act-quick__icon" aria-hidden="true" />
          <span className="ms-act-quick__label">{action.label}</span>
        </button>
      ))}
    </div>
  );
}

function MobileStatCards() {
  return (
    <div className="ms-act-mobile-stats">
      {MOBILE_STATS.map((stat) => (
        <div key={stat.label} className="ms-act-mobile-stat">
          <span className="ms-act-mobile-stat__label">{stat.label}</span>
          <div className="ms-act-mobile-stat__right">
            <span className="ms-act-mobile-stat__value">{stat.value}</span>
            <span className="ms-act-mobile-stat__unit">{stat.unit}</span>
          </div>
          <img
            src="/assets/icons/arrow_forward_ios.svg"
            alt=""
            aria-hidden="true"
            className="ms-act-mobile-stat__arrow"
          />
        </div>
      ))}
    </div>
  );
}

function MobileWeeklyCalendar() {
  return (
    <div className="ms-act-calendar">
      <p className="ms-act-calendar__title">5월 12일 화요일</p>
      <div className="ms-act-calendar__week">
        <div className="ms-act-calendar__day-row">
          {WEEK_DAYS.map((day, i) => (
            <div
              key={day}
              className={`ms-act-calendar__day${i === 0 ? ' ms-act-calendar__day--sun' : ''}${i === 6 ? ' ms-act-calendar__day--sat' : ''}`}
            >
              {day}
            </div>
          ))}
        </div>
        <div className="ms-act-calendar__date-row">
          {WEEK_DATES.map((d) => (
            <div key={d.date} className={`ms-act-calendar__date ms-act-calendar__date--${d.kind}`}>
              {d.date}
            </div>
          ))}
        </div>
      </div>
      <div className="ms-act-calendar__divider" />
      <div className="ms-act-calendar__schedule">
        <div className="ms-act-calendar__timeline">
          {CARE_SCHEDULE.map((item) => (
            <div
              key={item.time}
              className={`ms-act-calendar__dot${item.active ? ' ms-act-calendar__dot--active' : ''}`}
            />
          ))}
        </div>
        <div className="ms-act-calendar__items">
          {CARE_SCHEDULE.map((item) => (
            <div
              key={item.time}
              className={`ms-act-calendar__item${item.active ? '' : ' ms-act-calendar__item--dim'}`}
            >
              <p className="ms-act-calendar__item-time">{item.time}</p>
              <div className="ms-act-calendar__item-info">
                <CareBadge type={item.type} />
                <span className="ms-act-calendar__item-location">{item.location}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function StarRating({ rating }: { rating: number }) {
  return (
    <div className="ms-act-star-rating">
      {[1, 2, 3, 4, 5].map((i) => (
        <svg
          key={i}
          className={`ms-act-star ${i <= rating ? 'ms-act-star--filled' : 'ms-act-star--empty'}`}
          viewBox="0 0 24 24"
          aria-hidden="true"
        >
          <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" />
        </svg>
      ))}
    </div>
  );
}

function MobileReviews() {
  return (
    <div className="ms-act-reviews">
      <div className="ms-act-reviews__header">
        <h2 className="ms-act-reviews__title">고객 리뷰</h2>
        <img
          src="/assets/icons/arrow_forward_ios.svg"
          alt=""
          aria-hidden="true"
          className="ms-act-reviews__arrow"
        />
      </div>
      {REVIEWS.map((review, i) => (
        <div key={i} className="ms-act-review-card">
          <div className="ms-act-review-card__top">
            <div className="ms-act-review-card__meta">
              <span className="ms-act-review-card__name">{review.name}</span>
              <span className="ms-act-review-card__type">{review.kind}</span>
            </div>
            <StarRating rating={review.rating} />
          </div>
          <p className="ms-act-review-card__text">{review.text}</p>
        </div>
      ))}
    </div>
  );
}

// ── Page ───────────────────────────────────────────────────────────────────
export default function MySupportActiveDashboardPage() {
  return (
    <div className="ms-act-page">
      <MobileGnb />
      <ApplyGnb variant="simple" />
      <main className="ms-act-main">
        <MySupportSidebar activeItemId="dashboard" />
        <div className="ms-act-content">
          <div className="ms-act-greeting">
            <h1 className="ms-act-greeting__heading">안녕하세요, 000 서포터님</h1>
            <p className="ms-act-greeting__sub">
              오늘도 따뜻한 돌봄을 부탁드립니다. 현재 서포터님의 활동 상태를 확인하세요.
            </p>
          </div>

          <SummaryCards />

          <section className="ms-care-section">
            <div className="ms-care-section__header">
              <h2 className="ms-care-section__title">다가오는 돌봄 일정</h2>
              <button type="button" className="ms-care-section__more">
                일정 더보기 <IconArrow />
              </button>
            </div>
            <div className="ms-care-section__cards">
              {UPCOMING_CARES.map((item) => (
                <CareCard key={item.id} item={item} mode="upcoming" />
              ))}
            </div>
          </section>

          <section className="ms-care-section">
            <div className="ms-care-section__header">
              <h2 className="ms-care-section__title">AI 추천 돌봄</h2>
              <button type="button" className="ms-care-section__more">
                추천 더보기 <IconArrow />
              </button>
            </div>
            <div className="ms-care-section__cards">
              {RECOMMENDED_CARES.map((item) => (
                <CareCard key={item.id} item={item} mode="recommended" />
              ))}
            </div>
          </section>
        </div>
      </main>

      <div className="ms-act-mobile">
        <div className="ms-act-mobile__greeting">
          <h1 className="ms-act-mobile__title">안녕하세요, 000 서포터님</h1>
          <p className="ms-act-mobile__subtitle">
            오늘도 따뜻한 돌봄을 부탁드립니다. 현재 서포터님의 활동 상태를 확인하세요.
          </p>
        </div>
        <MobileQuickActions />
        <MobileStatCards />
        <MobileWeeklyCalendar />
        <MobileReviews />
      </div>

      <SiteFooter />
    </div>
  );
}
