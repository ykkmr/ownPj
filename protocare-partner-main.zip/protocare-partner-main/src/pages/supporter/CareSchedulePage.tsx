import { useState, useMemo } from 'react';
import { ApplyGnb } from '@/components/apply/ApplyGnb';
import { MobileGnb } from '@/components/apply/MobileGnb';
import { SiteFooter } from '@/components/apply/SiteFooter';
import { MySupportSidebar } from '@/components/supporter/MySupportSidebar';
import './CareSchedulePage.css';

// ── Types ─────────────────────────────────────────────────────────────────

type EventStatus = 'matching_complete' | 'matching' | 'activity_complete';
type CareType = '어르신돌봄' | '아이돌봄' | '병원동행';

interface ScheduleEvent {
  id: string;
  date: string; // YYYY-MM-DD
  careType: CareType;
  location: string;
  timeRange: string;
  address: string;
  status: EventStatus;
}

// ── Mock data ──────────────────────────────────────────────────────────────

const MOCK_EVENTS: ScheduleEvent[] = [
  {
    id: '1',
    date: '2025-05-01',
    careType: '어르신돌봄',
    location: '서울특별시 구로구',
    timeRange: '오전 10:00 ~ 오후 6시 (8시간)',
    address: '서울특별시 구로구 고척로31길9 (개봉동)',
    status: 'matching_complete',
  },
  {
    id: '2',
    date: '2025-05-02',
    careType: '병원동행',
    location: '참나무요양병원',
    timeRange: '오전 10:00 ~ 오후 1시 (3시간)',
    address: '서울특별시 구로구 고척로31길9 (개봉동)',
    status: 'matching_complete',
  },
  {
    id: '3',
    date: '2025-05-06',
    careType: '어르신돌봄',
    location: '서울특별시 구로구',
    timeRange: '오전 9:00 ~ 오전 11시 (2시간)',
    address: '서울특별시 구로구 고척로31길9 (개봉동)',
    status: 'activity_complete',
  },
  {
    id: '4',
    date: '2025-05-07',
    careType: '병원동행',
    location: '참나무요양병원',
    timeRange: '오전 10:00 ~ 오후 1시 (3시간)',
    address: '서울특별시 구로구 고척로31길9 (개봉동)',
    status: 'activity_complete',
  },
  {
    id: '5',
    date: '2025-05-09',
    careType: '어르신돌봄',
    location: '서울특별시 구로구',
    timeRange: '오전 10:00 ~ 오후 2시 (4시간)',
    address: '서울특별시 구로구 고척로31길9 (개봉동)',
    status: 'activity_complete',
  },
  {
    id: '6',
    date: '2025-05-11',
    careType: '어르신돌봄',
    location: '서울특별시 구로구',
    timeRange: '오전 10:00 ~ 오후 6시 (8시간)',
    address: '서울특별시 구로구 고척로31길9 (개봉동)',
    status: 'activity_complete',
  },
  {
    id: '7',
    date: '2025-05-11',
    careType: '아이돌봄',
    location: '서울특별시 구로구',
    timeRange: '오후 6시 ~ 오후 8시 (2시간)',
    address: '서울특별시 구로구 고척로31길9 (개봉동)',
    status: 'activity_complete',
  },
  {
    id: '8',
    date: '2025-05-14',
    careType: '어르신돌봄',
    location: '서울특별시 구로구',
    timeRange: '오전 10:00 ~ 오후 6시 (8시간)',
    address: '서울특별시 구로구 고척로31길9 (개봉동)',
    status: 'matching_complete',
  },
  {
    id: '9',
    date: '2025-05-14',
    careType: '아이돌봄',
    location: '서울특별시 구로구',
    timeRange: '오후 6시 ~ 오후 8시 (2시간)',
    address: '서울특별시 구로구 고척로31길9 (개봉동)',
    status: 'matching',
  },
  {
    id: '10',
    date: '2025-05-16',
    careType: '어르신돌봄',
    location: '서울특별시 구로구',
    timeRange: '오전 10:00 ~ 오후 6시 (8시간)',
    address: '서울특별시 구로구 고척로31길9 (개봉동)',
    status: 'matching_complete',
  },
  {
    id: '11',
    date: '2025-05-16',
    careType: '병원동행',
    location: '참나무요양병원',
    timeRange: '오전 10:00 ~ 오후 1시 (3시간)',
    address: '서울특별시 구로구 고척로31길9 (개봉동)',
    status: 'matching_complete',
  },
  {
    id: '12',
    date: '2025-05-17',
    careType: '어르신돌봄',
    location: '서울특별시 구로구',
    timeRange: '오전 10:00 ~ 오후 6시 (8시간)',
    address: '서울특별시 구로구 고척로31길9 (개봉동)',
    status: 'matching_complete',
  },
  {
    id: '13',
    date: '2025-05-21',
    careType: '어르신돌봄',
    location: '서울특별시 구로구',
    timeRange: '오전 10:00 ~ 오후 6시 (8시간)',
    address: '서울특별시 구로구 고척로31길9 (개봉동)',
    status: 'matching_complete',
  },
  {
    id: '14',
    date: '2025-05-21',
    careType: '아이돌봄',
    location: '서울특별시 구로구',
    timeRange: '오후 6시 ~ 오후 8시 (2시간)',
    address: '서울특별시 구로구 고척로31길9 (개봉동)',
    status: 'matching',
  },
  {
    id: '15',
    date: '2025-05-23',
    careType: '어르신돌봄',
    location: '서울특별시 구로구',
    timeRange: '오전 10:00 ~ 오후 6시 (8시간)',
    address: '서울특별시 구로구 고척로31길9 (개봉동)',
    status: 'matching',
  },
  {
    id: '16',
    date: '2025-05-23',
    careType: '병원동행',
    location: '참나무요양병원',
    timeRange: '오전 10:00 ~ 오후 1시 (3시간)',
    address: '서울특별시 구로구 고척로31길9 (개봉동)',
    status: 'matching_complete',
  },
  {
    id: '17',
    date: '2025-05-24',
    careType: '어르신돌봄',
    location: '서울특별시 구로구',
    timeRange: '오전 10:00 ~ 오후 6시 (8시간)',
    address: '서울특별시 구로구 고척로31길9 (개봉동)',
    status: 'matching',
  },
  {
    id: '18',
    date: '2025-05-28',
    careType: '어르신돌봄',
    location: '서울특별시 구로구',
    timeRange: '오전 10:00 ~ 오후 6시 (8시간)',
    address: '서울특별시 구로구 고척로31길9 (개봉동)',
    status: 'matching',
  },
  {
    id: '19',
    date: '2025-05-28',
    careType: '아이돌봄',
    location: '서울특별시 구로구',
    timeRange: '오후 6시 ~ 오후 8시 (2시간)',
    address: '서울특별시 구로구 고척로31길9 (개봉동)',
    status: 'matching',
  },
  {
    id: '20',
    date: '2025-05-29',
    careType: '어르신돌봄',
    location: '서울특별시 구로구',
    timeRange: '오전 10:00 ~ 오후 6시 (8시간)',
    address: '서울특별시 구로구 고척로31길9 (개봉동)',
    status: 'matching',
  },
];

// ── Config maps ────────────────────────────────────────────────────────────

const STATUS_CONFIG: Record<
  EventStatus,
  {
    badgeBg: string;
    badgeText: string;
    label: string;
    dotColor: string;
    legendTextColor: string;
    borderColor: string;
  }
> = {
  matching_complete: {
    badgeBg: '#d7e7ff',
    badgeText: '#024c84',
    label: '매칭 완료',
    dotColor: '#0064b0',
    legendTextColor: '#0064b0',
    borderColor: '#d7e7ff',
  },
  matching: {
    badgeBg: '#edf9f7',
    badgeText: '#40b39b',
    label: '매칭 중',
    dotColor: '#40b39b',
    legendTextColor: '#40b39b',
    borderColor: '#edf9f7',
  },
  activity_complete: {
    badgeBg: '#e6e6e6',
    badgeText: '#6b6b6b',
    label: '활동 완료',
    dotColor: '#a4a4a4',
    legendTextColor: '#737373',
    borderColor: '#e6e6e6',
  },
};

const CARE_TYPE_CONFIG: Record<CareType, { bg: string; label: string }> = {
  어르신돌봄: { bg: '#efeeff', label: '어르신 돌봄' },
  아이돌봄: { bg: '#fff4d3', label: '아이 돌봄' },
  병원동행: { bg: '#e1f2ff', label: '병원 동행' },
};

const DAY_LABELS = ['일', '월', '화', '수', '목', '금', '토'];

// ── Calendar helpers ───────────────────────────────────────────────────────

function toDateKey(date: Date): string {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

function buildCalendarGrid(year: number, month: number) {
  const firstDow = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const daysInPrev = new Date(year, month, 0).getDate();
  const cells: { date: Date; isCurrentMonth: boolean }[] = [];

  for (let i = firstDow - 1; i >= 0; i--)
    cells.push({ date: new Date(year, month - 1, daysInPrev - i), isCurrentMonth: false });
  for (let d = 1; d <= daysInMonth; d++)
    cells.push({ date: new Date(year, month, d), isCurrentMonth: true });
  const trailing = (7 - (cells.length % 7)) % 7;
  for (let d = 1; d <= trailing; d++)
    cells.push({ date: new Date(year, month + 1, d), isCurrentMonth: false });

  return cells;
}

// ── Icons ──────────────────────────────────────────────────────────────────

function ClockIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="#737373"
      aria-hidden="true"
      className="schedule-event-card__icon"
    >
      <path d="M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm.5-13H11v6l5.25 3.15.75-1.23-4.5-2.67V7z" />
    </svg>
  );
}

function LocationIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="#737373"
      aria-hidden="true"
      className="schedule-event-card__icon"
    >
      <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z" />
    </svg>
  );
}

function ChevronLeft() {
  return (
    <svg viewBox="0 0 24 24" width="18" height="18" fill="#121212" aria-hidden="true">
      <path d="M15.41 7.41L14 6l-6 6 6 6 1.41-1.41L10.83 12z" />
    </svg>
  );
}

function ChevronRight() {
  return (
    <svg viewBox="0 0 24 24" width="18" height="18" fill="#121212" aria-hidden="true">
      <path d="M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z" />
    </svg>
  );
}

// ── ScheduleEventCard ──────────────────────────────────────────────────────

function ScheduleEventCard({ event }: { event: ScheduleEvent }) {
  const statusCfg = STATUS_CONFIG[event.status];
  const careCfg = CARE_TYPE_CONFIG[event.careType];
  return (
    <div className="schedule-event-card" style={{ borderLeftColor: statusCfg.borderColor }}>
      <div className="schedule-event-card__inner">
        <div className="schedule-event-card__content">
          <div className="schedule-event-card__header">
            <span
              className="schedule-event-card__care-badge"
              style={{ backgroundColor: careCfg.bg }}
            >
              {careCfg.label}
            </span>
            <p className="schedule-event-card__title">{event.location}</p>
          </div>
          <div className="schedule-event-card__row">
            <ClockIcon />
            <span className="schedule-event-card__meta">{event.timeRange}</span>
          </div>
          <div className="schedule-event-card__row">
            <LocationIcon />
            <span className="schedule-event-card__meta">{event.address}</span>
          </div>
        </div>
        <span
          className="schedule-event-card__status-badge"
          style={{ backgroundColor: statusCfg.badgeBg, color: statusCfg.badgeText }}
        >
          {statusCfg.label}
        </span>
      </div>
    </div>
  );
}

// ── MiniCalendar ───────────────────────────────────────────────────────────

interface MiniCalendarProps {
  year: number;
  month: number;
  selectedDate: string;
  eventsByDate: Map<string, ScheduleEvent[]>;
  onPrevMonth: () => void;
  onNextMonth: () => void;
  onSelectDate: (key: string) => void;
}

function MiniCalendar({
  year,
  month,
  selectedDate,
  eventsByDate,
  onPrevMonth,
  onNextMonth,
  onSelectDate,
}: MiniCalendarProps) {
  const cells = useMemo(() => buildCalendarGrid(year, month), [year, month]);
  const todayKey = useMemo(() => toDateKey(new Date()), []);
  const weeks: (typeof cells)[] = [];
  for (let i = 0; i < cells.length; i += 7) weeks.push(cells.slice(i, i + 7));

  return (
    <div className="mini-calendar">
      <div className="mini-calendar__header">
        <div className="mini-calendar__nav">
          <button
            type="button"
            className="mini-calendar__nav-btn"
            onClick={onPrevMonth}
            aria-label="이전 달"
          >
            <ChevronLeft />
          </button>
          <span className="mini-calendar__month-label">
            {year}년 {month + 1}월
          </span>
          <button
            type="button"
            className="mini-calendar__nav-btn"
            onClick={onNextMonth}
            aria-label="다음 달"
          >
            <ChevronRight />
          </button>
        </div>

        <div className="mini-calendar__legend">
          {(
            Object.entries(STATUS_CONFIG) as [EventStatus, (typeof STATUS_CONFIG)[EventStatus]][]
          ).map(([key, cfg]) => (
            <div key={key} className="mini-calendar__legend-item">
              <span
                className="mini-calendar__legend-dot"
                style={{ backgroundColor: cfg.dotColor }}
              />
              <span className="mini-calendar__legend-label" style={{ color: cfg.legendTextColor }}>
                {cfg.label}
              </span>
            </div>
          ))}
        </div>
      </div>

      <div className="mini-calendar__day-headers">
        {DAY_LABELS.map((label, i) => (
          <div
            key={label}
            className={[
              'mini-calendar__day-header',
              i === 0 ? 'mini-calendar__day-header--sun' : '',
              i === 6 ? 'mini-calendar__day-header--sat' : '',
            ].join(' ')}
          >
            {label}
          </div>
        ))}
      </div>

      <div className="mini-calendar__grid">
        {weeks.map((week, wi) => (
          <div key={wi} className="mini-calendar__week">
            {week.map((cell, di) => {
              const dateKey = toDateKey(cell.date);
              const events = eventsByDate.get(dateKey) ?? [];
              const isSelected = dateKey === selectedDate;
              const isToday = dateKey === todayKey;
              const isSun = di === 0;
              const isSat = di === 6;

              let dateColor = '#121212';
              if (!cell.isCurrentMonth) dateColor = '#a4a4a4';
              else if (isSun) dateColor = '#d32f2f';
              else if (isSat) dateColor = '#008cff';

              return (
                <button
                  key={dateKey}
                  type="button"
                  className={[
                    'mini-calendar__cell',
                    isSelected ? 'mini-calendar__cell--selected' : '',
                    isToday && !isSelected ? 'mini-calendar__cell--today' : '',
                  ].join(' ')}
                  onClick={() => onSelectDate(dateKey)}
                >
                  <span className="mini-calendar__date" style={{ color: dateColor }}>
                    {cell.date.getDate()}
                  </span>
                  {events.length > 0 && (
                    <div className="mini-calendar__dots">
                      {events.slice(0, 4).map((ev) => (
                        <span
                          key={ev.id}
                          className="mini-calendar__dot"
                          style={{ backgroundColor: STATUS_CONFIG[ev.status].dotColor }}
                        />
                      ))}
                    </div>
                  )}
                </button>
              );
            })}
          </div>
        ))}
      </div>
    </div>
  );
}

// ── Page ───────────────────────────────────────────────────────────────────

export default function CareSchedulePage() {
  const today = new Date();
  const [currentYear, setCurrentYear] = useState(today.getFullYear());
  const [currentMonth, setCurrentMonth] = useState(today.getMonth());
  const [selectedDate, setSelectedDate] = useState(toDateKey(today));

  const eventsByDate = useMemo(() => {
    const map = new Map<string, ScheduleEvent[]>();
    for (const ev of MOCK_EVENTS) {
      const list = map.get(ev.date) ?? [];
      list.push(ev);
      map.set(ev.date, list);
    }
    return map;
  }, []);

  const selectedEvents = eventsByDate.get(selectedDate) ?? [];

  function goToPrevMonth() {
    if (currentMonth === 0) {
      setCurrentMonth(11);
      setCurrentYear((y) => y - 1);
    } else setCurrentMonth((m) => m - 1);
  }

  function goToNextMonth() {
    if (currentMonth === 11) {
      setCurrentMonth(0);
      setCurrentYear((y) => y + 1);
    } else setCurrentMonth((m) => m + 1);
  }

  const calendarProps: MiniCalendarProps = {
    year: currentYear,
    month: currentMonth,
    selectedDate,
    eventsByDate,
    onPrevMonth: goToPrevMonth,
    onNextMonth: goToNextMonth,
    onSelectDate: setSelectedDate,
  };

  return (
    <div className="mypage-page">
      <MobileGnb />
      <ApplyGnb variant="simple" />

      {/* ── Desktop ──────────────────────────────────────────────── */}
      <main className="mypage-main">
        <MySupportSidebar activeItemId="schedule" />
        <div className="mypage-content">
          <div className="mypage-greeting">
            <h1 className="mypage-greeting__heading">일정 관리</h1>
            <p className="mypage-greeting__sub">
              진행 중인 케어 일정과 매칭 현황을 확인할 수 있습니다
            </p>
          </div>
          <div className="schedule-desktop__body">
            <MiniCalendar {...calendarProps} />
            <div className="schedule-desktop__cards">
              {selectedEvents.length === 0 ? (
                <p className="schedule-desktop__empty">선택한 날짜에 일정이 없습니다.</p>
              ) : (
                selectedEvents.map((ev) => <ScheduleEventCard key={ev.id} event={ev} />)
              )}
            </div>
          </div>
        </div>
      </main>

      {/* ── Mobile ───────────────────────────────────────────────── */}
      <div className="schedule-mobile">
        <div className="schedule-mobile__heading">
          <h1 className="schedule-mobile__title">일정 관리</h1>
          <p className="schedule-mobile__sub">
            진행 중인 케어 일정과 매칭 현황을 확인할 수 있습니다
          </p>
        </div>
        <div className="schedule-mobile__body">
          <MiniCalendar {...calendarProps} />
          <div className="schedule-mobile__cards">
            {selectedEvents.length === 0 ? (
              <p className="schedule-mobile__empty">선택한 날짜에 일정이 없습니다.</p>
            ) : (
              selectedEvents.map((ev) => <ScheduleEventCard key={ev.id} event={ev} />)
            )}
          </div>
        </div>
      </div>

      <SiteFooter />
    </div>
  );
}
