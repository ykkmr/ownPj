import { useState } from 'react';
import { ApplyGnb } from '@/components/apply/ApplyGnb';
import { MobileGnb } from '@/components/apply/MobileGnb';
import { SiteFooter } from '@/components/apply/SiteFooter';
import { MySupportSidebar } from '@/components/supporter/MySupportSidebar';
import { PhotoUploadModal } from '@/components/supporter/PhotoUploadModal';
import './SupportLogPage.css';

type YesNo = '네' | '아니요';
type ConditionLevel = '안좋음' | '보통' | '좋음';

interface ChipProps {
  label: string;
  selected: boolean;
  onClick: () => void;
}

function Chip({ label, selected, onClick }: ChipProps) {
  return (
    <button
      type="button"
      className={`support-log__chip${selected ? ' support-log__chip--selected' : ''}`}
      onClick={onClick}
    >
      {label}
    </button>
  );
}

function ClockIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="#737373" aria-hidden="true" className="support-log__icon">
      <path d="M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm.5-13H11v6l5.25 3.15.75-1.23-4.5-2.67V7z" />
    </svg>
  );
}

function LocationIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="#737373" aria-hidden="true" className="support-log__icon">
      <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z" />
    </svg>
  );
}

function PlusIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="#737373" aria-hidden="true" className="support-log__plus-icon">
      <path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z" />
    </svg>
  );
}

export default function SupportLogPage() {
  const [meal, setMeal] = useState<YesNo | null>(null);
  const [medication, setMedication] = useState<YesNo | null>(null);
  const [walk, setWalk] = useState<YesNo | null>(null);
  const [condition, setCondition] = useState<ConditionLevel | null>(null);
  const [activityNote, setActivityNote] = useState('');
  const [photoPreview, setPhotoPreview] = useState<string | null>(null);
  const [showPhotoModal, setShowPhotoModal] = useState(false);

  function handlePhotoUpload(file: File) {
    const url = URL.createObjectURL(file);
    setPhotoPreview(url);
  }

  return (
    <div className="mypage-page">
      <MobileGnb />
      <ApplyGnb variant="simple" />
      <main className="mypage-main">
        <MySupportSidebar activeItemId="history" />
        <div className="mypage-content">
          <div className="mypage-greeting">
            <h1 className="mypage-greeting__heading">서포트 기록 작성</h1>
            <p className="mypage-greeting__sub">
              신청, 예정, 완료된 돌봄 이용 내역을 확인할 수 있습니다
            </p>
          </div>

          <div className="support-log__form">
            <section className="support-log__section">
              <h2 className="support-log__section-title">해당 케어 정보</h2>
              <div className="support-log__care-card">
                <div className="support-log__care-header">
                  <span className="support-log__badge support-log__badge--hospital">병원 동행</span>
                  <p className="support-log__care-title">참나무요양병원</p>
                </div>
                <div className="support-log__care-row">
                  <ClockIcon />
                  <span className="support-log__care-text">
                    26.05.02 (토) 오전 10:00 ~ 오후 1시 (3시간)
                  </span>
                </div>
                <div className="support-log__care-row">
                  <LocationIcon />
                  <span className="support-log__care-text">
                    서울특별시 구로구 고척로31길9 (개봉동)
                  </span>
                </div>
              </div>
            </section>

            <section className="support-log__section">
              <h2 className="support-log__section-title">식사 여부</h2>
              <div className="support-log__chips">
                <Chip label="네" selected={meal === '네'} onClick={() => setMeal('네')} />
                <Chip
                  label="아니요"
                  selected={meal === '아니요'}
                  onClick={() => setMeal('아니요')}
                />
              </div>
            </section>

            <section className="support-log__section">
              <h2 className="support-log__section-title">투약 여부</h2>
              <div className="support-log__chips">
                <Chip
                  label="네"
                  selected={medication === '네'}
                  onClick={() => setMedication('네')}
                />
                <Chip
                  label="아니요"
                  selected={medication === '아니요'}
                  onClick={() => setMedication('아니요')}
                />
              </div>
            </section>

            <section className="support-log__section">
              <h2 className="support-log__section-title">산책 여부</h2>
              <div className="support-log__chips">
                <Chip label="네" selected={walk === '네'} onClick={() => setWalk('네')} />
                <Chip
                  label="아니요"
                  selected={walk === '아니요'}
                  onClick={() => setWalk('아니요')}
                />
              </div>
            </section>

            <section className="support-log__section">
              <h2 className="support-log__section-title">컨디션 상태</h2>
              <div className="support-log__chips">
                <Chip
                  label="안좋음"
                  selected={condition === '안좋음'}
                  onClick={() => setCondition('안좋음')}
                />
                <Chip
                  label="보통"
                  selected={condition === '보통'}
                  onClick={() => setCondition('보통')}
                />
                <Chip
                  label="좋음"
                  selected={condition === '좋음'}
                  onClick={() => setCondition('좋음')}
                />
              </div>
            </section>

            <section className="support-log__section">
              <h2 className="support-log__section-title support-log__section-title--lg">
                상세 활동 내용
              </h2>
              <textarea
                className="support-log__textarea"
                placeholder="기록하신 내용은 보호자에게 리포트로 전달되므로 정중하고 상세하게 작성 부탁드립니다."
                value={activityNote}
                onChange={(e) => setActivityNote(e.target.value)}
              />
              <button
                type="button"
                className="support-log__photo-btn"
                onClick={() => setShowPhotoModal(true)}
                aria-label="사진 추가"
              >
                {photoPreview ? (
                  <img
                    src={photoPreview}
                    alt="업로드된 사진"
                    className="support-log__photo-preview"
                  />
                ) : (
                  <PlusIcon />
                )}
              </button>
            </section>
          </div>

          <div className="support-log__actions">
            <button type="button" className="support-log__draft-btn">
              임시 저장
            </button>
            <button type="button" className="support-log__submit-btn">
              작성 완료
            </button>
          </div>
        </div>
      </main>
      {/* ── Mobile layout ────────────────────────────────────────── */}
      <div className="support-log-mobile">
        <div className="support-log-mobile__heading">
          <h1 className="support-log-mobile__title">서포트 기록 작성</h1>
          <p className="support-log-mobile__sub">
            사용자(대상자)의 민감한 사생활 정보나 비하 발언이 포함되지 않도록 유의하여 작성해
            주세요.
          </p>
        </div>

        <div className="support-log-mobile__body">
          <section className="support-log__section">
            <h2 className="support-log__section-title">해당 케어 정보</h2>
            <div className="support-log__care-card">
              <div className="support-log__care-header">
                <span className="support-log__badge support-log__badge--hospital">병원 동행</span>
                <p className="support-log__care-title">참나무요양병원</p>
              </div>
              <div className="support-log__care-row">
                <ClockIcon />
                <span className="support-log__care-text">
                  26.05.02 (토) 오전 10:00 ~ 오후 1시 (3시간)
                </span>
              </div>
              <div className="support-log__care-row">
                <LocationIcon />
                <span className="support-log__care-text">
                  서울특별시 구로구 고척로31길9 (개봉동)
                </span>
              </div>
            </div>
          </section>

          <section className="support-log__section">
            <h2 className="support-log__section-title">식사 여부</h2>
            <div className="support-log__chips">
              <Chip label="네" selected={meal === '네'} onClick={() => setMeal('네')} />
              <Chip label="아니요" selected={meal === '아니요'} onClick={() => setMeal('아니요')} />
            </div>
          </section>

          <section className="support-log__section">
            <h2 className="support-log__section-title">투약 여부</h2>
            <div className="support-log__chips">
              <Chip label="네" selected={medication === '네'} onClick={() => setMedication('네')} />
              <Chip
                label="아니요"
                selected={medication === '아니요'}
                onClick={() => setMedication('아니요')}
              />
            </div>
          </section>

          <section className="support-log__section">
            <h2 className="support-log__section-title">산책 여부</h2>
            <div className="support-log__chips">
              <Chip label="네" selected={walk === '네'} onClick={() => setWalk('네')} />
              <Chip label="아니요" selected={walk === '아니요'} onClick={() => setWalk('아니요')} />
            </div>
          </section>

          <section className="support-log__section">
            <h2 className="support-log__section-title">컨디션 상태</h2>
            <div className="support-log__chips">
              <Chip
                label="안좋음"
                selected={condition === '안좋음'}
                onClick={() => setCondition('안좋음')}
              />
              <Chip
                label="보통"
                selected={condition === '보통'}
                onClick={() => setCondition('보통')}
              />
              <Chip
                label="좋음"
                selected={condition === '좋음'}
                onClick={() => setCondition('좋음')}
              />
            </div>
          </section>

          <section className="support-log__section">
            <h2 className="support-log__section-title support-log__section-title--lg">
              상세 활동 내용
            </h2>
            <textarea
              className="support-log__textarea"
              placeholder="기록하신 내용은 보호자에게 리포트로 전달되므로 정중하고 상세하게 작성 부탁드립니다."
              value={activityNote}
              onChange={(e) => setActivityNote(e.target.value)}
            />
            <button
              type="button"
              className="support-log__photo-btn"
              onClick={() => setShowPhotoModal(true)}
              aria-label="사진 추가"
            >
              {photoPreview ? (
                <img
                  src={photoPreview}
                  alt="업로드된 사진"
                  className="support-log__photo-preview"
                />
              ) : (
                <PlusIcon />
              )}
            </button>
          </section>

          <div className="support-log-mobile__actions">
            <button type="button" className="support-log-mobile__submit">
              작성 완료
            </button>
            <button type="button" className="support-log-mobile__draft">
              임시 저장
            </button>
          </div>
        </div>
      </div>

      <SiteFooter />
      {showPhotoModal && (
        <PhotoUploadModal onUpload={handlePhotoUpload} onClose={() => setShowPhotoModal(false)} />
      )}
    </div>
  );
}
