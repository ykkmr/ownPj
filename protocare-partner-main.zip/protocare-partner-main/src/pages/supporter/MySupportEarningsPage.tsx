import { ApplyGnb } from '@/components/apply/ApplyGnb';
import { SiteFooter } from '@/components/apply/SiteFooter';
import { MySupportSidebar } from '@/components/supporter/MySupportSidebar';
import './MySupportEarningsPage.css';

// ── Types ──────────────────────────────────────────────────────────────────
type PaymentStatus = 'paid' | 'pending';

interface SettlementRecord {
  id: string;
  date: string;
  description: string;
  amount: string;
  status: PaymentStatus;
}

// ── Mock data ──────────────────────────────────────────────────────────────
const MOCK_BALANCE = '2,840,000';
const MOCK_MONTHLY_REVENUE = '2,840,000';
const MOCK_NEXT_DATE = '11월 15일';
const MOCK_EXPECTED_AMOUNT = '1,390,000원';
const MOCK_BANK_NAME = '00은행';
const MOCK_ACCOUNT_NUMBER = '1234-5678-91011';

const MOCK_SETTLEMENTS: SettlementRecord[] = [
  {
    id: '1',
    date: '2025.10.15',
    description: '10월 정산 1차',
    amount: '980,000원',
    status: 'pending',
  },
  { id: '2', date: '2025.09.30', description: '9월 정산 2차', amount: '420,000원', status: 'paid' },
  { id: '3', date: '2025.09.15', description: '9월 정산 1차', amount: '810,000원', status: 'paid' },
  { id: '4', date: '2025.08.31', description: '8월 정산 1차', amount: '290,000원', status: 'paid' },
  { id: '5', date: '2025.07.12', description: '7월 정산 1차', amount: '810,000원', status: 'paid' },
];

const STATUS_LABEL: Record<PaymentStatus, string> = {
  paid: '지급 완료',
  pending: '지급 대기',
};

// ── Icons ──────────────────────────────────────────────────────────────────
function CreditScoreIcon() {
  return (
    <img
      src="/assets/icons/credit_score.svg"
      alt=""
      aria-hidden="true"
      className="earn-icon"
      style={{ filter: 'brightness(0) invert(1)' }}
    />
  );
}

function PaymentsIcon() {
  return <img src="/assets/icons/payments.svg" alt="" aria-hidden="true" className="earn-icon" />;
}

function CalendarClockIcon() {
  return (
    <img src="/assets/icons/calendar_clock.svg" alt="" aria-hidden="true" className="earn-icon" />
  );
}

function ErrorCircleIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="#737373" aria-hidden="true" className="earn-icon--sm">
      <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z" />
    </svg>
  );
}

function WarningIcon() {
  return (
    <img
      src="/assets/icons/warning.svg"
      alt=""
      aria-hidden="true"
      className="earn-icon--sm"
      style={{
        filter:
          'brightness(0) invert(1) invert(47%) sepia(100%) saturate(2478%) hue-rotate(9deg) brightness(101%)',
      }}
    />
  );
}

function AccountBalanceIcon() {
  return (
    <img src="/assets/icons/account_balance.svg" alt="" aria-hidden="true" className="earn-icon" />
  );
}

function DownloadIcon() {
  return (
    <img
      src="/assets/icons/vertical_align_bottom.svg"
      alt=""
      aria-hidden="true"
      className="earn-icon"
      style={{ filter: 'invert(58%) sepia(30%) saturate(700%) hue-rotate(127deg) brightness(95%)' }}
    />
  );
}

function EditIcon() {
  return (
    <img
      src="/assets/icons/edit.svg"
      alt=""
      aria-hidden="true"
      className="earn-icon"
      style={{ filter: 'brightness(0) invert(1) brightness(0.45)' }}
    />
  );
}

function ChevronRightIcon() {
  return (
    <img
      src="/assets/icons/chevron_forward.svg"
      alt=""
      aria-hidden="true"
      className="earn-icon--sm"
    />
  );
}

function CheckIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="#ff1b02" aria-hidden="true" className="earn-icon--sm">
      <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z" />
    </svg>
  );
}

// ── Summary cards ──────────────────────────────────────────────────────────
function BalanceCard() {
  return (
    <div className="earn-card earn-card--green">
      <div className="earn-card__header">
        <CreditScoreIcon />
        <span className="earn-card__title earn-card__title--white">현재 출금 가능 잔액</span>
      </div>
      <div className="earn-card__amount-row">
        <span className="earn-card__amount earn-card__amount--white">{MOCK_BALANCE}</span>
        <span className="earn-card__unit earn-card__unit--white">원</span>
      </div>
      <button type="button" className="earn-withdraw-btn">
        출금 신청하기
      </button>
    </div>
  );
}

function MonthlyRevenueCard() {
  return (
    <div className="earn-card earn-card--border-top">
      <div className="earn-card__header">
        <PaymentsIcon />
        <span className="earn-card__title">이번 달 총 수익</span>
      </div>
      <div className="earn-card__amount-row">
        <span className="earn-card__amount earn-card__amount--green">{MOCK_MONTHLY_REVENUE}</span>
        <span className="earn-card__unit">원</span>
      </div>
      <div className="earn-card__sub-row">
        <CheckIcon />
        <span className="earn-card__sub-text earn-card__sub-text--red">지난 달 대비 0.2% 상승</span>
      </div>
    </div>
  );
}

function NextSettlementCard() {
  return (
    <div className="earn-card earn-card--border-top">
      <div className="earn-card__header">
        <CalendarClockIcon />
        <span className="earn-card__title">다음 정산 예정일</span>
      </div>
      <span className="earn-card__amount earn-card__amount--green">{MOCK_NEXT_DATE}</span>
      <div className="earn-card__sub-row">
        <ErrorCircleIcon />
        <span className="earn-card__sub-text">예상 정산 금액: {MOCK_EXPECTED_AMOUNT}</span>
      </div>
    </div>
  );
}

// ── Pagination ─────────────────────────────────────────────────────────────
function Pagination() {
  return (
    <div className="earn-pagination">
      {[1, 2, 3, 4, 5].map((page) => (
        <button
          key={page}
          type="button"
          className={`earn-pagination__btn${page === 1 ? ' earn-pagination__btn--active' : ''}`}
        >
          {page}
        </button>
      ))}
      <button type="button" className="earn-pagination__arrow" aria-label="다음 페이지">
        <ChevronRightIcon />
      </button>
    </div>
  );
}

// ── Settlement table ───────────────────────────────────────────────────────
function SettlementTable() {
  return (
    <div className="earn-table-section">
      <h2 className="earn-section-title">최근 정산 내역</h2>
      <div className="earn-table">
        <div className="earn-table__head">
          <span className="earn-table__col earn-table__col--date">날짜</span>
          <span className="earn-table__col earn-table__col--desc">내용</span>
          <span className="earn-table__col earn-table__col--amount">금액</span>
          <span className="earn-table__col earn-table__col--status">상태</span>
        </div>
        {MOCK_SETTLEMENTS.map((record) => (
          <div key={record.id} className="earn-table__row">
            <span className="earn-table__col earn-table__col--date">{record.date}</span>
            <span className="earn-table__col earn-table__col--desc">{record.description}</span>
            <span className="earn-table__col earn-table__col--amount">{record.amount}</span>
            <span className={`earn-status-badge earn-status-badge--${record.status}`}>
              {STATUS_LABEL[record.status]}
            </span>
          </div>
        ))}
      </div>
      <Pagination />
    </div>
  );
}

// ── Account card ───────────────────────────────────────────────────────────
function AccountCard() {
  return (
    <div className="earn-calc-card">
      <div className="earn-calc-card__header">
        <h2 className="earn-calc-card__title">정산 계좌 관리</h2>
        <button type="button" className="earn-calc-card__edit-btn" aria-label="계좌 수정">
          <EditIcon />
        </button>
      </div>
      <hr className="earn-calc-card__divider" />
      <div className="earn-calc-card__account-row">
        <div className="earn-account-icon-wrap">
          <AccountBalanceIcon />
        </div>
        <div className="earn-account-info">
          <span className="earn-account-info__bank">{MOCK_BANK_NAME}</span>
          <span className="earn-account-info__number">{MOCK_ACCOUNT_NUMBER}</span>
        </div>
      </div>
    </div>
  );
}

// ── Tax document card ──────────────────────────────────────────────────────
function TaxDocCard() {
  return (
    <div className="earn-calc-card">
      <div className="earn-calc-card__header">
        <h2 className="earn-calc-card__title">세금 관련 문서</h2>
      </div>
      <hr className="earn-calc-card__divider" />
      <div className="earn-calc-card__tax-content">
        <div className="earn-tax-row">
          <WarningIcon />
          <span className="earn-tax-row__label">종합소득세 신고 안내</span>
        </div>
        <p className="earn-tax-desc">
          연간 수익 내역 및 세금 신고에 필요한 증빙 서류를 발급받으실 수 있습니다.
        </p>
        <button type="button" className="earn-download-btn">
          <DownloadIcon />
          <span>문서 발급하기</span>
        </button>
      </div>
    </div>
  );
}

// ── Page root ──────────────────────────────────────────────────────────────
export default function MySupportEarningsPage() {
  return (
    <div className="mypage-page">
      <ApplyGnb variant="simple" />
      <main className="mypage-main">
        <MySupportSidebar activeItemId="earnings" />
        <div className="mypage-content">
          <div className="mypage-greeting">
            <h1 className="mypage-greeting__heading">수익 및 정산 관리</h1>
            <p className="mypage-greeting__sub">
              이번 달의 수익 내역과 다가오는 정산 일정을 확인하세요.
            </p>
          </div>
          <div className="earn-summary-row">
            <BalanceCard />
            <MonthlyRevenueCard />
            <NextSettlementCard />
          </div>
          <div className="earn-main-row">
            <SettlementTable />
            <div className="earn-side-col">
              <AccountCard />
              <TaxDocCard />
            </div>
          </div>
        </div>
      </main>
      <SiteFooter />
    </div>
  );
}
