import { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { ApplyGnb } from '@/components/apply/ApplyGnb';
import { SiteFooter } from '@/components/apply/SiteFooter';
import { MySupportSidebar } from '@/components/supporter/MySupportSidebar';
import './MySupportNoticesPage.css';
import './MySupportInquiryFormPage.css';

// ── Types ──────────────────────────────────────────────────────────────────
type InquiryCategory =
  | '정산/수익'
  | '매칭/취소'
  | '활동 중 문제'
  | '계정/자격'
  | '앱 오류 및 건의'
  | '기타';

const CATEGORIES: InquiryCategory[] = [
  '정산/수익',
  '매칭/취소',
  '활동 중 문제',
  '계정/자격',
  '앱 오류 및 건의',
  '기타',
];

const NOTICE_ITEMS = [
  '활동 취소, 시간 변경, 노쇼 제보는 마이페이지 > 활동 내역에서 즉시 신청하실 수 있습니다.',
  '활동 시간 미준수, 사용자 정보 오기입, 사적 거래 시도, 현장 수칙 미이행 시 서비스 이용 제한 및 정산 페널티가 발생할 수 있습니다.',
  '교체(대체)를 원하시는 활동의 서포터 배정이 이미 완료된 경우, 임의의 일정 변경이나 교체는 불가능합니다.',
  '활동비 정산(추가 수당, 가산금 등) 관련 문의는 반드시 해당 활동 내역(일시/장소)을 선택하여 접수하셔야 정확한 확인이 가능합니다.',
  '1:1 문의 처리 결과는 마이페이지 > 1:1 문의 내역에서 실시간으로 확인하실 수 있습니다.',
  '긴급한 인명 사고나 현장 위급 상황은 1:1 문의 대신 긴급 고객센터(1588-XXXX)를 통해 신고하셔야 가장 빠른 대처가 가능합니다.',
];

// ── Page ───────────────────────────────────────────────────────────────────
export default function MySupportInquiryFormPage() {
  const navigate = useNavigate();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [category, setCategory] = useState<InquiryCategory>('정산/수익');
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [imagePreview, setImagePreview] = useState<string | null>(null);

  const isValid = title.trim().length > 0 && content.trim().length > 0;

  function handleImageChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setImagePreview(URL.createObjectURL(file));
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!isValid) return;
    navigate('/supporter/mysupport/inquiry');
  }

  return (
    <div className="mypage-page">
      <ApplyGnb variant="simple" />
      <main className="mypage-main">
        <MySupportSidebar activeItemId="inquiry" />
        <div className="mypage-content">
          <div className="mypage-greeting">
            <h1 className="mypage-greeting__heading">1:1 문의하기</h1>
            <p className="mypage-greeting__sub">
              활동 중 겪으신 불편함이나 궁금하신 점을 남겨주세요. ProtoCare 매니저가 확인 후 최대한
              빠르게 답변해 드립니다.
            </p>
          </div>

          <form className="inquiry-form" onSubmit={handleSubmit} noValidate>
            <div className="inquiry-form__section">
              <h2 className="inquiry-form__section-title">문의 유형</h2>
              <div className="inquiry-type-chips" role="group" aria-label="문의 유형 선택">
                {CATEGORIES.map((cat) => (
                  <button
                    key={cat}
                    type="button"
                    className={`inquiry-type-chip${category === cat ? ' inquiry-type-chip--active' : ''}`}
                    aria-pressed={category === cat}
                    onClick={() => setCategory(cat)}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            <div className="inquiry-form__section">
              <h2 className="inquiry-form__section-title">제목</h2>
              <input
                type="text"
                className="inquiry-form__input"
                placeholder="제목을 입력해 주세요"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                maxLength={100}
                required
                aria-label="문의 제목"
              />
            </div>

            <div className="inquiry-form__section">
              <h2 className="inquiry-form__section-title">내용</h2>
              <textarea
                className="inquiry-form__textarea"
                placeholder="문의 내용을 입력해 주세요"
                value={content}
                onChange={(e) => setContent(e.target.value)}
                maxLength={2000}
                required
                aria-label="문의 내용"
              />
              <button
                type="button"
                className="inquiry-image-upload"
                onClick={() => fileInputRef.current?.click()}
                aria-label="이미지 첨부"
              >
                {imagePreview ? (
                  <img
                    src={imagePreview}
                    alt="첨부 이미지 미리보기"
                    className="inquiry-image-upload__preview"
                  />
                ) : (
                  <span className="inquiry-image-upload__plus" aria-hidden="true">
                    +
                  </span>
                )}
              </button>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                style={{ display: 'none' }}
                onChange={handleImageChange}
                aria-hidden="true"
              />
            </div>

            <ul className="inquiry-notices">
              {NOTICE_ITEMS.map((notice) => (
                <li key={notice}>{notice}</li>
              ))}
            </ul>

            <div className="inquiry-form__actions">
              <button
                type="button"
                className="inquiry-form__cancel-btn"
                onClick={() => navigate('/supporter/mysupport/inquiry')}
              >
                취소
              </button>
              <button type="submit" className="inquiry-form__submit-btn" disabled={!isValid}>
                작성하기
              </button>
            </div>
          </form>
        </div>
      </main>
      <SiteFooter />
    </div>
  );
}
