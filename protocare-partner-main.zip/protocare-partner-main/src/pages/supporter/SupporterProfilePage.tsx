import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useSupporterProfile, useUpdateSupporterProfile } from '@/hooks/useSupporter';
import {
  PageHeader,
  Card,
  CardBody,
  ListStateView,
  Button,
  Switch,
  Textarea,
} from '@/components/ui';
import { ApplyGnb } from '@/components/apply/ApplyGnb';
import { MobileGnb } from '@/components/apply/MobileGnb';
import { SiteFooter } from '@/components/apply/SiteFooter';
import { toast } from '@/store/toast.store';

export default function SupporterProfilePage() {
  const navigate = useNavigate();
  const { data: profile, isLoading, isError, refetch } = useSupporterProfile();
  const update = useUpdateSupporterProfile();

  const [intro, setIntro] = useState('');
  const [isVisible, setIsVisible] = useState(true);
  const [initialized, setInitialized] = useState(false);

  if (profile && !initialized) {
    setIntro(profile.intro ?? '');
    setIsVisible(profile.isVisible);
    setInitialized(true);
  }

  const handleSave = () => {
    update.mutate(
      { intro, isVisible },
      { onSuccess: () => toast.success('프로필이 저장되었습니다.') },
    );
  };

  return (
    <div className="mypage-page">
      <MobileGnb />
      <ApplyGnb variant="simple" />
      <div className="flex flex-col">
        <PageHeader title="프로필 관리" showBack onBack={() => navigate(-1)} />

        <div className="p-4">
          <ListStateView isLoading={isLoading} isError={isError} onRetry={refetch}>
            {profile && (
              <div className="flex flex-col gap-4">
                <Card>
                  <CardBody className="flex flex-col gap-4">
                    <div>
                      <p className="mb-1 text-sm font-medium text-gray-700">서비스 유형</p>
                      <p className="text-sm text-gray-500">{profile.serviceTypes.join(', ')}</p>
                    </div>
                    <div>
                      <p className="mb-1 text-sm font-medium text-gray-700">활동 지역</p>
                      <p className="text-sm text-gray-500">{profile.activityRegions.join(', ')}</p>
                    </div>
                    <div>
                      <p className="mb-2 text-sm font-medium text-gray-700">자기소개</p>
                      <Textarea
                        value={intro}
                        onChange={(e) => setIntro(e.target.value)}
                        placeholder="자기소개를 입력하세요"
                        rows={4}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <p className="text-sm font-medium text-gray-700">프로필 공개</p>
                      <Switch checked={isVisible} onChange={setIsVisible} />
                    </div>
                  </CardBody>
                </Card>

                <Button onClick={handleSave} disabled={update.isPending}>
                  저장
                </Button>
              </div>
            )}
          </ListStateView>
        </div>
      </div>
      <SiteFooter />
    </div>
  );
}
