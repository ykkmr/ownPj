import { useNavigate, useParams } from 'react-router-dom';
import { useMatching, useStartMatching, useCompleteMatching } from '@/hooks/useMatching';
import { PageHeader, Card, CardBody, ListStateView, Badge, Button } from '@/components/ui';
import { ApplyGnb } from '@/components/apply/ApplyGnb';
import { MobileGnb } from '@/components/apply/MobileGnb';
import { SiteFooter } from '@/components/apply/SiteFooter';

export default function SupporterMatchingDetailPage() {
  const navigate = useNavigate();
  const { id } = useParams<{ id: string }>();
  const matchingId = Number(id);

  const { data: matching, isLoading, isError, refetch } = useMatching(matchingId);
  const start = useStartMatching();
  const complete = useCompleteMatching();

  return (
    <div className="mypage-page">
      <MobileGnb />
      <ApplyGnb variant="simple" />
      <div className="flex flex-col">
        <PageHeader title="매칭 상세" showBack onBack={() => navigate(-1)} />

        <div className="p-4">
          <ListStateView isLoading={isLoading} isError={isError} onRetry={refetch}>
            {matching && (
              <div className="flex flex-col gap-4">
                <Card>
                  <CardBody className="flex flex-col gap-2">
                    <div className="flex items-center justify-between">
                      <p className="font-semibold">매칭 #{matching.id}</p>
                      <Badge>{matching.status}</Badge>
                    </div>
                    <p className="text-sm text-gray-500">
                      매칭일: {matching.matchedAt ? matching.matchedAt.slice(0, 10) : '-'}
                    </p>
                    {matching.startedAt && (
                      <p className="text-sm text-gray-500">
                        시작: {matching.startedAt.slice(0, 10)}
                      </p>
                    )}
                    {matching.completedAt && (
                      <p className="text-sm text-gray-500">
                        완료: {matching.completedAt.slice(0, 10)}
                      </p>
                    )}
                    <p className="font-medium text-blue-600">
                      {matching.totalAmount.toLocaleString()}원
                    </p>
                  </CardBody>
                </Card>

                <div className="flex gap-2">
                  {matching.status === 'MATCHED' && (
                    <Button
                      className="flex-1"
                      onClick={() => start.mutate(matchingId)}
                      disabled={start.isPending}
                    >
                      서비스 시작
                    </Button>
                  )}
                  {matching.status === 'IN_PROGRESS' && (
                    <>
                      <Button
                        variant="outline"
                        className="flex-1"
                        onClick={() => navigate(`/supporter/matchings/${matchingId}/logs`)}
                      >
                        케어 기록
                      </Button>
                      <Button
                        className="flex-1"
                        onClick={() => complete.mutate(matchingId)}
                        disabled={complete.isPending}
                      >
                        서비스 완료
                      </Button>
                    </>
                  )}
                </div>
              </div>
            )}
          </ListStateView>
        </div>
      </div>
      <SiteFooter />
    </div>
  );
}
