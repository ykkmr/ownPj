import { useNavigate } from 'react-router-dom';
import './SupporterApplyFormPage.css';
import './SupporterApplyCompletePage.css';
import { ApplyGnb } from '@/components/apply/ApplyGnb';
import { MobileGnb } from '@/components/apply/MobileGnb';
import { SiteFooter } from '@/components/apply/SiteFooter';

const ASSETS = {
  checkSign: '/assets/icons/check.svg',
  calendarIcon: '/assets/icons/calendar_month.svg',
} as const;

const SCHEDULE_ITEMS = [
  '제출하신 서류의 검토는 영업일 기준 약 3~5일이 소요됩니다.',
  '서류 전형 결과 및 다음 단계 안내는 기재해 주신 연락처로 알림톡(또는 문자)을 통해 개별적으로 전송될 예정입니다.',
  '추가 문의사항이 있으실 경우 고객센터를 이용해 주시기 바랍니다.',
];

export default function SupporterApplyCompletePage() {
  const navigate = useNavigate();

  return (
    <div className="apply-page">
      <ApplyGnb />

      <MobileGnb />

      <main className="complete-body">
        <div className="complete-card">
          <div className="complete-hero">
            <img src={ASSETS.checkSign} alt="완료" className="complete-hero__icon" />
            <h1 className="complete-hero__title">지원서 접수가 완료되었습니다</h1>
            <p className="complete-hero__desc">
              ProtoCare 서포터로 지원해 주셔서 진심으로 감사드립니다.
              <br />
              입력하신 정보는 안전하게 시스템에 저장되었으며, 현재 담당자 검토 상태로
              전환되었습니다.
            </p>
          </div>

          <div className="complete-info">
            <div className="complete-info__heading">
              <img src={ASSETS.calendarIcon} alt="" className="complete-info__icon" />
              <span className="complete-info__label">향후 일정 안내</span>
            </div>
            <ul className="complete-info__list">
              {SCHEDULE_ITEMS.map((item) => (
                <li key={item} className="complete-info__item">
                  {item}
                </li>
              ))}
            </ul>
          </div>

          <div className="complete-actions">
            <button
              type="button"
              className="complete-btn complete-btn--primary"
              onClick={() => navigate('/supporter/home')}
            >
              지원 확인하기
            </button>
            <button
              type="button"
              className="complete-btn complete-btn--secondary"
              onClick={() => navigate('/')}
            >
              메인으로 돌아가기
            </button>
          </div>
        </div>
      </main>

      <SiteFooter />
    </div>
  );
}
