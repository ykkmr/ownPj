import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './SupporterApplyTermsPage.css';
import { ApplyGnb } from '@/components/apply/ApplyGnb';
import { MobileGnb } from '@/components/apply/MobileGnb';
import { SiteFooter } from '@/components/apply/SiteFooter';

// ── Static data ────────────────────────────────────────────────

const ASSETS = {
  arrowForward: '/assets/icons/arrow_forward_ios.svg',
  stepTerms: '/assets/icons/Terms and Conditions.svg',
  stepRegistration: '/assets/icons/Registration.svg',
  stepTrust: '/assets/icons/Trust.svg',
  stepSecurityPass: '/assets/icons/Security Pass.svg',
} as const;

const STEPS = [
  { label: 'STEP 1', desc: '약관 동의', icon: ASSETS.stepTerms },
  { label: 'STEP 2', desc: '정보 입력', icon: ASSETS.stepRegistration },
  { label: 'STEP 3', desc: '케어 성향', icon: ASSETS.stepTrust },
  { label: 'STEP 4', desc: '자격 검증', icon: ASSETS.stepSecurityPass },
];

const TERMS_SERVICE_TEXT = `제1장 총칙

제1조 목적
본 약관은 주식회사 프로토타이(이하 '회사')이 제공하는 '프로토케어' 서비스 및 이에 부수하는 제반 서비스의 이용과 관련하여 회사와 이용자, 회원의 권리, 의무 및 책임사항, 기타 필요한 사항을 규정함을 목적으로 합니다.

제2조 용어의 정의
1. 본 약관에서 사용하는 용어의 정의는 다음과 같습니다.
'이용자'는 본 약관에 따라 홈페이지, 앱을 포함하여 회사가 제공하는 서비스를 이용하는 자를 의미합니다.
'회원'은 본 약관에 따라 이용계약을 체결하고, 회사가 제공하는 서비스를 이용하는 자로서 개인(개인사업자를 포함함) 또는 법인을 의미합니다.
'간병인 회원'은 회사의 알선 서비스를 통해 구인회원과 매칭되고자 하는 자 또는 그 밖의 경로로 회사의 회원으로 가입한 자로서 구인회원에게 간병인 업무를 제공하는 회원을 의미합니다.
'구인회원'은 간병인 업무를 제공받는 환자(이하 '환자') 혹은 그 환자의 보호자, 기타 환자 및/또는 환자의 보호자의 수권을 받아 행위하는 대리인 등의 자로서 간병인 회원을 소개받기 위해 회사의 알선 서비스를 이용하는 회원을 의미합니다.

제3조 약관의 효력 및 변경
1. 회사가 본 약관의 내용을 회사 홈페이지 또는 앱 화면에 게재하거나 기타 방법으로 이용자에게 통지하고, 그 내용에 동의한 이용자가 본 서비스를 이용할 때 본 약관의 효력이 발생합니다.
2. 회사는 필요한 경우 관계 법령을 위반하지 않는 범위에서 본 약관을 변경할 수 있으며, 약관 변경 시에는 적용일자 및 개정사유를 명시하여 현행약관과 함께 공지합니다.

제4조 이용계약의 체결 및 적용
1. 본 서비스를 이용하고자 하는 자가 본 약관의 내용에 대하여 동의를 한 다음 서비스 이용 신청을 하고, 회사가 그 신청에 대해서 승낙함으로써 이용계약이 체결됩니다.

부칙 (2026. 05. 01.)
이 약관은 2026년 05월 01일부터 시행합니다.`;

const TERMS_PRIVACY_TEXT = `개인정보 처리방침

주식회사 프로토타이(이하 '회사')는 이용자의 개인정보를 중요시하며, 「개인정보 보호법」 등 관련 법령을 준수합니다.

1. 수집하는 개인정보 항목
회사는 서비스 제공을 위해 다음의 개인정보를 수집합니다.
- 필수 항목: 이름, 이메일, 휴대폰 번호, 생년월일
- 서비스 이용 과정에서 자동으로 수집되는 정보: 접속 IP, 쿠키, 서비스 이용 기록

2. 개인정보의 수집 및 이용목적
회사는 수집한 개인정보를 다음 목적을 위해 이용합니다.
- 서비스 제공 및 계약 이행
- 회원 관리 및 본인 확인
- 서비스 개선 및 신규 서비스 개발

3. 개인정보의 보유 및 이용 기간
회원 탈퇴 시 즉시 삭제하며, 관련 법령에 따라 보존이 필요한 경우 해당 기간 동안 보유합니다.`;

const TERMS_PATIENT_PRIVACY_TEXT = `환자 회원에 대한 개인정보 제공 동의

서포터로 활동하는 과정에서 케어 서비스 매칭을 위해 의뢰인(환자 또는 보호자)의 다음 개인정보가 제공될 수 있습니다.

제공되는 개인정보 항목:
- 환자 이름, 나이, 성별
- 진료 기록 및 건강 상태 (케어에 필요한 범위 내)
- 주소 또는 병원 위치
- 연락처

개인정보 제공 목적: 케어 서비스 매칭 및 제공
개인정보 보유 기간: 서비스 계약 종료 후 즉시 파기

본 정보는 케어 서비스 제공 목적으로만 사용되며, 무단으로 제3자에게 제공하거나 외부에 유출하는 경우 관련 법령에 따라 처벌받을 수 있습니다.`;

const TERMS_MARKETING_TEXT = `마케팅 정보 수신 동의

회사는 이용자의 동의를 받아 다음과 같은 마케팅 정보를 발송할 수 있습니다.

수신 채널: 이메일, 문자(SMS/MMS), 앱 푸시 알림
수신 내용: 신규 서비스 안내, 케어 활동 기회, 이벤트 및 혜택 정보

동의하지 않으셔도 서비스 이용에 불이익이 없으며, 언제든지 동의를 철회할 수 있습니다.`;

const TERMS_PROFILE_TEXT = `프로필 홍보 활용 동의

서포터 회원의 프로필 정보(활동 분야, 자격 사항, 활동 후기 등)를 다음 목적으로 활용할 수 있습니다.

활용 목적:
- 서비스 홈페이지 및 앱 내 서포터 소개
- 매칭 시스템에서의 프로필 노출
- 프로모션 및 마케팅 자료 활용 (개인 식별 정보 제외)

동의하지 않으셔도 서비스 이용에 불이익이 없으며, 언제든지 동의를 철회할 수 있습니다.`;

type TermKey = 'service' | 'privacy' | 'patientPrivacy' | 'marketing' | 'profilePromo';

type TermItemData = {
  key: TermKey;
  badge: '필수' | '선택';
  title: string;
  content: string;
};

const TERM_ITEMS: TermItemData[] = [
  { key: 'service', badge: '필수', title: '이용약관', content: TERMS_SERVICE_TEXT },
  { key: 'privacy', badge: '필수', title: '개인정보 처리방침', content: TERMS_PRIVACY_TEXT },
  {
    key: 'patientPrivacy',
    badge: '필수',
    title: '환자 회원에 대한 개인정보 제공',
    content: TERMS_PATIENT_PRIVACY_TEXT,
  },
  {
    key: 'marketing',
    badge: '선택',
    title: '마케팅 정보 수신 동의',
    content: TERMS_MARKETING_TEXT,
  },
  {
    key: 'profilePromo',
    badge: '선택',
    title: '프로필 홍보 활용 동의',
    content: TERMS_PROFILE_TEXT,
  },
];

const REQUIRED_KEYS: TermKey[] = ['service', 'privacy', 'patientPrivacy'];

type AgreementState = Record<TermKey, boolean>;

const INITIAL_AGREEMENTS: AgreementState = {
  service: false,
  privacy: false,
  patientPrivacy: false,
  marketing: false,
  profilePromo: false,
};

// ── Sub-components ─────────────────────────────────────────────

function StepIndicator({ activeStep }: { activeStep: number }) {
  return (
    <div className="step-indicator">
      {STEPS.map((step, index) => (
        <div key={step.label} style={{ display: 'contents' }}>
          <div
            className={`step-indicator__step ${
              index === activeStep
                ? 'step-indicator__step--active'
                : 'step-indicator__step--inactive'
            }`}
          >
            <div className="step-indicator__icon-wrap">
              <img src={step.icon} alt="" className="step-indicator__icon" />
            </div>
            <div className="step-indicator__text">
              <span className="step-indicator__label">{step.label}</span>
              <span className="step-indicator__desc">{step.desc}</span>
            </div>
          </div>
          {index < STEPS.length - 1 && (
            <img src={ASSETS.arrowForward} alt="" className="step-indicator__arrow" />
          )}
        </div>
      ))}
    </div>
  );
}

function RadioIcon({ checked }: { checked: boolean }) {
  if (checked) {
    return (
      <svg width="28" height="28" viewBox="0 0 28 28" fill="none" aria-hidden="true">
        <circle cx="14" cy="14" r="11" stroke="#40B39B" strokeWidth="2" fill="none" />
        <circle cx="14" cy="14" r="6" fill="#40B39B" />
      </svg>
    );
  }
  return (
    <svg width="28" height="28" viewBox="0 0 28 28" fill="none" aria-hidden="true">
      <circle cx="14" cy="14" r="11" stroke="#DDDDDD" strokeWidth="2" fill="none" />
    </svg>
  );
}

function ChevronIcon({ up }: { up: boolean }) {
  return (
    <svg
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      aria-hidden="true"
      className={`terms-item__arrow${up ? ' terms-item__arrow--up' : ''}`}
    >
      <path d="M7 10l5 5 5-5z" fill="#121212" />
    </svg>
  );
}

type TermAccordionItemProps = {
  item: TermItemData;
  checked: boolean;
  expanded: boolean;
  onToggleCheck: (e: React.MouseEvent) => void;
  onToggleExpand: () => void;
};

function TermAccordionItem({
  item,
  checked,
  expanded,
  onToggleCheck,
  onToggleExpand,
}: TermAccordionItemProps) {
  return (
    <div className="terms-item">
      <button
        type="button"
        className="terms-item__header"
        onClick={onToggleExpand}
        aria-expanded={expanded}
      >
        <span className="terms-radio" role="radio" aria-checked={checked} onClick={onToggleCheck}>
          <RadioIcon checked={checked} />
        </span>
        <span className="terms-item__badge">{item.badge}</span>
        <span className="terms-item__title">{item.title}</span>
        <ChevronIcon up={expanded} />
      </button>
      {expanded && (
        <div className="terms-item__content">
          <p className="terms-item__content-text">{item.content}</p>
        </div>
      )}
    </div>
  );
}

// ── Page ───────────────────────────────────────────────────────

export default function SupporterApplyTermsPage() {
  const navigate = useNavigate();
  const [agreements, setAgreements] = useState<AgreementState>(INITIAL_AGREEMENTS);
  const [expandedKey, setExpandedKey] = useState<TermKey | null>('service');

  const allChecked = Object.values(agreements).every(Boolean);
  const requiredAllChecked = REQUIRED_KEYS.every((k) => agreements[k]);

  const handleAgreeAll = () => {
    const next = !allChecked;
    setAgreements(
      Object.fromEntries(Object.keys(INITIAL_AGREEMENTS).map((k) => [k, next])) as AgreementState,
    );
  };

  const handleToggleCheck = (key: TermKey) => {
    setAgreements((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  const handleToggleExpand = (key: TermKey) => {
    setExpandedKey((prev) => (prev === key ? null : key));
  };

  const handleNext = () => {
    if (!requiredAllChecked) return;
    navigate('/supporter/apply/form');
  };

  return (
    <div className="terms-page">
      <ApplyGnb />

      <MobileGnb />

      <main className="terms-body">
        <div className="terms-card">
          <div className="terms-title">
            <h1 className="terms-title__heading">서포터 지원</h1>
            <p className="terms-title__sub">
              의료케어 서포터로 활동하기 위한 기본 정보를 입력해 주세요.
              <br />
              정확한 정보 입력은 빠른 매칭에 도움이 됩니다.
            </p>
          </div>

          <StepIndicator activeStep={0} />

          <div className="terms-section">
            <h2 className="terms-section__heading">이용 약관 동의</h2>

            <div className="terms-agree-all">
              <button
                type="button"
                className={`terms-agree-all__btn${allChecked ? ' terms-agree-all__btn--checked' : ''}`}
                onClick={handleAgreeAll}
                aria-pressed={allChecked}
              >
                <span className="terms-radio">
                  <RadioIcon checked={allChecked} />
                </span>
                <span className="terms-agree-all__label">모두 동의</span>
              </button>
              <p className="terms-agree-all__hint">
                필수 및 선택 정보를 한번에 동의하실 수 있습니다.
              </p>
            </div>

            <div className="terms-list">
              <div className="terms-group">
                {TERM_ITEMS.filter((t) => t.badge === '필수').map((item) => (
                  <TermAccordionItem
                    key={item.key}
                    item={item}
                    checked={agreements[item.key]}
                    expanded={expandedKey === item.key}
                    onToggleCheck={(e) => {
                      e.stopPropagation();
                      handleToggleCheck(item.key);
                    }}
                    onToggleExpand={() => handleToggleExpand(item.key)}
                  />
                ))}
              </div>
              <div className="terms-group">
                {TERM_ITEMS.filter((t) => t.badge === '선택').map((item) => (
                  <TermAccordionItem
                    key={item.key}
                    item={item}
                    checked={agreements[item.key]}
                    expanded={expandedKey === item.key}
                    onToggleCheck={(e) => {
                      e.stopPropagation();
                      handleToggleCheck(item.key);
                    }}
                    onToggleExpand={() => handleToggleExpand(item.key)}
                  />
                ))}
              </div>
            </div>
          </div>

          <div className="terms-actions">
            <button
              type="button"
              className="terms-btn-next"
              onClick={handleNext}
              disabled={!requiredAllChecked}
            >
              다음
            </button>
          </div>
        </div>
      </main>

      <SiteFooter />
    </div>
  );
}
