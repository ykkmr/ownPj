import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ApplyGnb } from '@/components/apply/ApplyGnb';
import { SiteFooter } from '@/components/apply/SiteFooter';
import { useUpdatePersonalityTags } from '@/hooks/useSupporter';
import { toast } from '@/store/toast.store';
import type { TagCode } from '@/types/api';
import './SupporterApplyFormPage.css';
import './SupporterApplyTagPage.css';

// ── 태그 정의 ─────────────────────────────────────────────────
const EXPERIENCE_OPTIONS: { code: TagCode; label: string }[] = [
  { code: 'EXPERIENCE_HOSPITAL', label: '병원 동행 경험' },
  { code: 'EXPERIENCE_SENIOR', label: '어르신 돌봄 경험' },
  { code: 'EXPERIENCE_CHILD', label: '아이 돌봄 경험' },
  { code: 'EXPERIENCE_FAMILY', label: '가족 돌봄 경험' },
  { code: 'EXPERIENCE_PROFESSIONAL', label: '전문 돌봄 자격 보유' },
  { code: 'EXPERIENCE_NONE', label: '경험 없음' },
];

const STYLE_OPTIONS: { code: TagCode; label: string }[] = [
  { code: 'STYLE_CALM', label: '차분하고 침착해요' },
  { code: 'STYLE_BRIGHT', label: '밝고 에너지 넘쳐요' },
  { code: 'STYLE_TALKATIVE', label: '대화를 즐겨요' },
  { code: 'STYLE_QUIET', label: '조용하고 안정적이에요' },
  { code: 'STYLE_DETAIL', label: '세심하고 꼼꼼해요' },
];

const ACTIVITY_OPTIONS: { code: TagCode; label: string }[] = [
  { code: 'ACTIVITY_HOSPITAL', label: '병원 동행' },
  { code: 'ACTIVITY_SENIOR', label: '어르신 돌봄' },
  { code: 'ACTIVITY_CHILD', label: '아이 돌봄' },
];

const CONDITION_OPTIONS: { code: TagCode; label: string }[] = [
  { code: 'CONDITION_EMERGENCY', label: '응급 상황 대응' },
  { code: 'CONDITION_NIGHT', label: '야간 활동' },
  { code: 'CONDITION_LONG_DISTANCE', label: '장거리 이동' },
  { code: 'CONDITION_LONG_TERM', label: '장기 케어' },
  { code: 'CONDITION_SIGN_LANGUAGE', label: '수어 가능' },
];

const STEPS = [
  { label: 'STEP 1', desc: '약관 동의', icon: '/assets/icons/Terms and Conditions.svg' },
  { label: 'STEP 2', desc: '정보 입력', icon: '/assets/icons/Registration.svg' },
  { label: 'STEP 3', desc: '케어 성향', icon: '/assets/icons/Trust.svg' },
  { label: 'STEP 4', desc: '자격 검증', icon: '/assets/icons/Security Pass.svg' },
];

// ── 서브 컴포넌트 ─────────────────────────────────────────────
function StepIndicator({ activeStep }: { activeStep: number }) {
  return (
    <div className="step-indicator">
      {STEPS.map((step, index) => (
        <div key={step.label} style={{ display: 'contents' }}>
          <div
            className={`step-indicator__step ${
              index === activeStep
                ? 'step-indicator__step--active'
                : 'step-indicator__step--inactive'
            }`}
          >
            <div className="step-indicator__icon-wrap">
              <img src={step.icon} alt="" className="step-indicator__icon" />
            </div>
            <div className="step-indicator__text">
              <span className="step-indicator__label">{step.label}</span>
              <span className="step-indicator__desc">{step.desc}</span>
            </div>
          </div>
          {index < STEPS.length - 1 && (
            <img
              src="/assets/icons/arrow_forward_ios.svg"
              alt=""
              className="step-indicator__arrow"
            />
          )}
        </div>
      ))}
    </div>
  );
}

function SingleChipGroup({
  label,
  options,
  selected,
  onSelect,
}: {
  label: string;
  options: { code: TagCode; label: string }[];
  selected: TagCode | null;
  onSelect: (code: TagCode) => void;
}) {
  return (
    <div className="tag-group">
      <p className="tag-group__label">{label}</p>
      <div className="tag-chips">
        {options.map((opt) => (
          <button
            key={opt.code}
            type="button"
            className={`tag-chip${selected === opt.code ? ' tag-chip--selected' : ''}`}
            onClick={() => onSelect(opt.code)}
          >
            {opt.label}
          </button>
        ))}
      </div>
    </div>
  );
}

function MultiChipGroup({
  label,
  hint,
  required,
  options,
  selected,
  onToggle,
}: {
  label: string;
  hint?: string;
  required?: boolean;
  options: { code: TagCode; label: string }[];
  selected: TagCode[];
  onToggle: (code: TagCode) => void;
}) {
  return (
    <div className="tag-group">
      <p className="tag-group__label">
        {label}
        {required && <span className="tag-group__required">*</span>}
      </p>
      {hint && <p className="tag-group__hint">{hint}</p>}
      <div className="tag-chips">
        {options.map((opt) => (
          <button
            key={opt.code}
            type="button"
            className={`tag-chip${selected.includes(opt.code) ? ' tag-chip--selected' : ''}`}
            onClick={() => onToggle(opt.code)}
          >
            {opt.label}
          </button>
        ))}
      </div>
    </div>
  );
}

// ── 페이지 ────────────────────────────────────────────────────
export default function SupporterApplyTagPage() {
  const navigate = useNavigate();
  const { mutate: saveTags, isPending } = useUpdatePersonalityTags();

  const [experienceTag, setExperienceTag] = useState<TagCode | null>(null);
  const [styleTag, setStyleTag] = useState<TagCode | null>(null);
  const [activityTags, setActivityTags] = useState<TagCode[]>([]);
  const [conditionTags, setConditionTags] = useState<TagCode[]>([]);

  function toggleMulti(
    list: TagCode[],
    setList: React.Dispatch<React.SetStateAction<TagCode[]>>,
    code: TagCode,
  ) {
    setList(list.includes(code) ? list.filter((c) => c !== code) : [...list, code]);
  }

  function handleSubmit() {
    if (!experienceTag) return toast.danger('경험 유형을 선택해주세요.');
    if (!styleTag) return toast.danger('케어 스타일을 선택해주세요.');
    if (activityTags.length === 0) return toast.danger('활동 분야를 하나 이상 선택해주세요.');

    saveTags(
      { experienceTag, styleTag, activityTags, conditionTags },
      {
        onSuccess: () => navigate('/supporter/apply/certifications'),
        onError: () => toast.danger('저장에 실패했습니다. 다시 시도해주세요.'),
      },
    );
  }

  return (
    <div className="apply-page">
      <ApplyGnb />
      <main className="apply-page__body">
        <div className="apply-page__card">
          <div className="apply-title">
            <h1 className="apply-title__heading">서포터 지원</h1>
            <p className="apply-title__sub">
              나의 케어 성향을 선택해주세요.
              <br />
              매칭 품질을 높이는 데 사용됩니다.
            </p>
          </div>

          <StepIndicator activeStep={2} />

          <div className="apply-form">
            <h2 className="apply-form__section-title">케어 성향 선택</h2>

            <SingleChipGroup
              label="Q1. 돌봄 경험이 있으신가요?"
              options={EXPERIENCE_OPTIONS}
              selected={experienceTag}
              onSelect={setExperienceTag}
            />

            <SingleChipGroup
              label="Q2. 나의 케어 스타일은?"
              options={STYLE_OPTIONS}
              selected={styleTag}
              onSelect={setStyleTag}
            />

            <MultiChipGroup
              label="Q3. 활동하고 싶은 분야는?"
              required
              options={ACTIVITY_OPTIONS}
              selected={activityTags}
              onToggle={(code) => toggleMulti(activityTags, setActivityTags, code)}
            />

            <MultiChipGroup
              label="Q4. 가능한 특수 조건이 있나요?"
              hint="해당하는 항목만 선택해주세요. (선택)"
              options={CONDITION_OPTIONS}
              selected={conditionTags}
              onToggle={(code) => toggleMulti(conditionTags, setConditionTags, code)}
            />
          </div>

          <div className="apply-divider" />

          <div className="apply-actions">
            <button
              type="button"
              className="apply-btn apply-btn--secondary"
              onClick={() => navigate(-1)}
              disabled={isPending}
            >
              이전
            </button>
            <button
              type="button"
              className="apply-btn apply-btn--primary"
              onClick={handleSubmit}
              disabled={isPending}
            >
              {isPending ? '저장 중...' : '다음 단계 →'}
            </button>
          </div>
        </div>
      </main>
      <SiteFooter />
    </div>
  );
}
