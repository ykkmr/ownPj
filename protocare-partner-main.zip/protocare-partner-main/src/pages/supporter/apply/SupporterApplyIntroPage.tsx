import { Navigate } from 'react-router-dom';

export default function SupporterApplyIntroPage() {
  return <Navigate to="/supporter/apply/terms" replace />;
}
