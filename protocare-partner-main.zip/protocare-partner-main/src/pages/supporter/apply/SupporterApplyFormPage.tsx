import { useState, useRef, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import './SupporterApplyFormPage.css';
import { ApplyGnb } from '@/components/apply/ApplyGnb';
import { MobileGnb } from '@/components/apply/MobileGnb';
import { SiteFooter } from '@/components/apply/SiteFooter';

// ── Types ──────────────────────────────────────────────────────

type Gender = 'male' | 'female';

type FormState = {
  name: string;
  birthDate: string;
  gender: Gender | null;
  regionCity: string;
  regionDistrict: string;
  profileImage: File | null;
  intro: string;
};

// ── Static data ────────────────────────────────────────────────

const ASSETS = {
  arrowForward: '/assets/icons/arrow_forward_ios.svg',
  stepTerms: '/assets/icons/Terms and Conditions.svg',
  stepRegistration: '/assets/icons/Registration.svg',
  stepTrust: '/assets/icons/Trust.svg',
  stepSecurityPass: '/assets/icons/Security Pass.svg',
} as const;

const STEPS = [
  { label: 'STEP 1', desc: '약관 동의', icon: ASSETS.stepTerms },
  { label: 'STEP 2', desc: '정보 입력', icon: ASSETS.stepRegistration },
  { label: 'STEP 3', desc: '케어 성향', icon: ASSETS.stepTrust },
  { label: 'STEP 4', desc: '자격 검증', icon: ASSETS.stepSecurityPass },
];

const REGION_CITIES = ['강남구', '서초구', '송파구', '마포구', '용산구', '종로구', '중구'];

const REGION_DISTRICTS: Record<string, string[]> = {
  강남구: ['역삼동', '삼성동', '대치동', '청담동', '논현동'],
  서초구: ['서초동', '반포동', '방배동', '잠원동'],
  송파구: ['잠실동', '석촌동', '가락동', '문정동'],
  마포구: ['합정동', '홍익동', '상암동', '성산동'],
  용산구: ['이태원동', '한남동', '후암동', '청파동'],
  종로구: ['사직동', '청운동', '삼청동', '부암동'],
  중구: ['명동', '을지로', '충무로', '필동'],
};

const MAX_IMAGE_SIZE_BYTES = 5 * 1024 * 1024;

// ── Sub-components ─────────────────────────────────────────────

function StepIndicator({ activeStep }: { activeStep: number }) {
  return (
    <div className="step-indicator">
      {STEPS.map((step, index) => (
        <div key={step.label} style={{ display: 'contents' }}>
          <div
            className={`step-indicator__step ${
              index === activeStep
                ? 'step-indicator__step--active'
                : 'step-indicator__step--inactive'
            }`}
          >
            <div className="step-indicator__icon-wrap">
              <img src={step.icon} alt="" className="step-indicator__icon" />
            </div>
            <div className="step-indicator__text">
              <span className="step-indicator__label">{step.label}</span>
              <span className="step-indicator__desc">{step.desc}</span>
            </div>
          </div>
          {index < STEPS.length - 1 && (
            <img src={ASSETS.arrowForward} alt="" className="step-indicator__arrow" />
          )}
        </div>
      ))}
    </div>
  );
}

type ProfileImageUploadProps = {
  previewUrl: string | null;
  onFileSelect: (file: File) => void;
};

function ProfileImageUpload({ previewUrl, onFileSelect }: ProfileImageUploadProps) {
  const inputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) return;
    if (file.size > MAX_IMAGE_SIZE_BYTES) return;
    onFileSelect(file);
    e.target.value = '';
  };

  return (
    <div
      className="apply-field__image-wrap"
      onClick={() => inputRef.current?.click()}
      role="button"
      aria-label="프로필 이미지 업로드"
      tabIndex={0}
      onKeyDown={(e) => e.key === 'Enter' && inputRef.current?.click()}
    >
      {previewUrl ? (
        <img src={previewUrl} alt="프로필 미리보기" className="apply-field__image-preview" />
      ) : (
        <div className="apply-field__image-placeholder">
          <svg
            className="apply-field__image-add-icon"
            viewBox="0 0 24 24"
            fill="none"
            aria-hidden="true"
          >
            <path d="M19 13H13V19H11V13H5V11H11V5H13V11H19V13Z" fill="currentColor" />
          </svg>
        </div>
      )}
      <input
        ref={inputRef}
        type="file"
        accept="image/*"
        className="apply-field__image-input"
        onChange={handleFileChange}
        aria-hidden="true"
      />
    </div>
  );
}

// ── Page ───────────────────────────────────────────────────────

export default function SupporterApplyFormPage() {
  const navigate = useNavigate();
  const [form, setForm] = useState<FormState>({
    name: '',
    birthDate: '',
    gender: null,
    regionCity: '',
    regionDistrict: '',
    profileImage: null,
    intro: '',
  });
  const [profilePreviewUrl, setProfilePreviewUrl] = useState<string | null>(null);

  const updateField = useCallback(
    <K extends keyof FormState>(key: K, value: FormState[K]) =>
      setForm((prev) => ({ ...prev, [key]: value })),
    [],
  );

  const handleProfileImageSelect = useCallback(
    (file: File) => {
      if (profilePreviewUrl) URL.revokeObjectURL(profilePreviewUrl);
      const url = URL.createObjectURL(file);
      setProfilePreviewUrl(url);
      updateField('profileImage', file);
    },
    [profilePreviewUrl, updateField],
  );

  const handleCityChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setForm((prev) => ({ ...prev, regionCity: e.target.value, regionDistrict: '' }));
  };

  const availableDistricts = form.regionCity ? (REGION_DISTRICTS[form.regionCity] ?? []) : [];

  const isFormValid =
    form.name.trim() !== '' &&
    form.birthDate.length === 8 &&
    form.gender !== null &&
    form.regionCity !== '' &&
    form.intro.trim() !== '';

  const handleNext = () => {
    if (!isFormValid) return;
    navigate('/supporter/apply/exam');
  };

  const handleSaveDraft = () => {
    // TODO: 임시 저장 API 연동
  };

  return (
    <div className="apply-page">
      <ApplyGnb />

      <MobileGnb />

      <main className="apply-page__body">
        <div className="apply-page__card">
          <div className="apply-title">
            <h1 className="apply-title__heading">서포터 지원</h1>
            <p className="apply-title__sub">
              의료케어 서포터로 활동하기 위한 기본 정보를 입력해 주세요.
              <br />
              정확한 정보 입력은 빠른 매칭에 도움이 됩니다.
            </p>
          </div>

          <StepIndicator activeStep={1} />

          <div className="apply-form">
            <h2 className="apply-form__section-title">필수 정보 입력</h2>

            {/* 성함 */}
            <div className="apply-field apply-field--narrow">
              <div className="apply-field__label">
                <span className="apply-field__required">*</span>
                <span className="apply-field__name">성함</span>
              </div>
              <input
                type="text"
                className="apply-field__input apply-field__input--tall"
                placeholder="실명으로 입력해 주세요"
                value={form.name}
                onChange={(e) => updateField('name', e.target.value)}
                autoComplete="name"
              />
            </div>

            {/* 생년월일 */}
            <div className="apply-field apply-field--narrow">
              <div className="apply-field__label">
                <span className="apply-field__required">*</span>
                <span className="apply-field__name">생년월일</span>
              </div>
              <input
                type="text"
                className="apply-field__input apply-field__input--tall"
                placeholder="생년월일 8자리 입력해 주세요"
                value={form.birthDate}
                onChange={(e) => {
                  const digits = e.target.value.replace(/\D/g, '').slice(0, 8);
                  updateField('birthDate', digits);
                }}
                maxLength={8}
                inputMode="numeric"
              />
            </div>

            {/* 성별 */}
            <div className="apply-field">
              <div className="apply-field__label">
                <span className="apply-field__required">*</span>
                <span className="apply-field__name">성별</span>
              </div>
              <div className="apply-chips" role="group" aria-label="성별 선택">
                {(['male', 'female'] as Gender[]).map((g) => (
                  <button
                    key={g}
                    type="button"
                    className={`apply-chip${form.gender === g ? ' apply-chip--selected' : ''}`}
                    onClick={() => updateField('gender', g)}
                    aria-pressed={form.gender === g}
                  >
                    {g === 'male' ? '남자' : '여자'}
                  </button>
                ))}
              </div>
            </div>

            {/* 활동지역 */}
            <div className="apply-field">
              <div className="apply-field__label">
                <span className="apply-field__required">*</span>
                <span className="apply-field__name">활동지역</span>
              </div>
              <div className="apply-dropdowns">
                <select
                  className="apply-dropdown"
                  value={form.regionCity}
                  onChange={handleCityChange}
                  aria-label="시/구 선택"
                >
                  <option value="">시/구 선택</option>
                  {REGION_CITIES.map((city) => (
                    <option key={city} value={city}>
                      {city}
                    </option>
                  ))}
                </select>
                <select
                  className="apply-dropdown"
                  value={form.regionDistrict}
                  onChange={(e) => updateField('regionDistrict', e.target.value)}
                  aria-label="동 선택"
                  disabled={availableDistricts.length === 0}
                >
                  <option value="">동 선택</option>
                  {availableDistricts.map((district) => (
                    <option key={district} value={district}>
                      {district}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* 프로필 이미지 */}
            <div className="apply-field">
              <div className="apply-field__label">
                <span className="apply-field__name">프로필 이미지</span>
              </div>
              <ProfileImageUpload
                previewUrl={profilePreviewUrl}
                onFileSelect={handleProfileImageSelect}
              />
            </div>

            {/* 한 줄 소개 */}
            <div className="apply-field apply-field--narrow">
              <div className="apply-field__label">
                <span className="apply-field__required">*</span>
                <span className="apply-field__name">한 줄 소개</span>
              </div>
              <input
                type="text"
                className="apply-field__input apply-field__input--tall"
                placeholder="ex) 경험은 없지만 성실하게 배우며 책임감 있게 활동하겠습니다"
                value={form.intro}
                onChange={(e) => updateField('intro', e.target.value)}
                maxLength={100}
              />
            </div>
          </div>

          <div className="apply-divider" />

          {/* 액션 버튼 */}
          <div className="apply-actions">
            <button
              type="button"
              className="apply-btn apply-btn--primary"
              onClick={handleNext}
              disabled={!isFormValid}
            >
              다음
            </button>
            <button
              type="button"
              className="apply-btn apply-btn--secondary"
              onClick={handleSaveDraft}
            >
              임시 저장
            </button>
          </div>
        </div>
      </main>

      <SiteFooter />
    </div>
  );
}
