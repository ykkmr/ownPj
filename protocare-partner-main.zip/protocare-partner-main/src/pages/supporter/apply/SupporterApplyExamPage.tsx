import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './SupporterApplyFormPage.css';
import { ApplyGnb } from '@/components/apply/ApplyGnb';
import { MobileGnb } from '@/components/apply/MobileGnb';
import { SiteFooter } from '@/components/apply/SiteFooter';

const ASSETS = {
  arrowForward: '/assets/icons/arrow_forward_ios.svg',
  stepTerms: '/assets/icons/Terms and Conditions.svg',
  stepRegistration: '/assets/icons/Registration.svg',
  stepTrust: '/assets/icons/Trust.svg',
  stepSecurityPass: '/assets/icons/Security Pass.svg',
} as const;

// ── Types ──────────────────────────────────────────────────────────────────
type ExamState = {
  q1: string[];
  q2: string[];
  q3: string[];
  q4: string[];
};

// ── Static data ────────────────────────────────────────────────────────────
const STEPS = [
  { label: 'STEP 1', desc: '약관 동의', icon: ASSETS.stepTerms },
  { label: 'STEP 2', desc: '정보 입력', icon: ASSETS.stepRegistration },
  { label: 'STEP 3', desc: '케어 성향', icon: ASSETS.stepTrust },
  { label: 'STEP 4', desc: '자격 검증', icon: ASSETS.stepSecurityPass },
];

const Q1_OPTIONS = [
  '병원 동행 경험',
  '어르신 돌봄 경험',
  '아이 돌봄 경험',
  '가족/보호자 케어 경험',
  '관련직 경력 보유',
  '경험 없음',
];

const Q2_OPTIONS = [
  '차분하고 안정적인 편',
  '밝고 활발한 편',
  '대화를 잘 이끄는 편',
  '조용히 함께하는 편',
  '세심하게 살피는 편',
];

const Q3_OPTIONS = ['병원 동행', '어르신 돌봄', '아이 돌봄'];

const Q4_OPTIONS = [
  '당일/긴급 요청 가능',
  '야간 활동 가능',
  '장거리 이동 가능',
  '장시간 케어 가능',
  '수화 가능',
];

// ── Sub-components ─────────────────────────────────────────────────────────

function StepIndicator({ activeStep }: { activeStep: number }) {
  return (
    <div className="step-indicator">
      {STEPS.map((step, index) => (
        <div key={step.label} style={{ display: 'contents' }}>
          <div
            className={`step-indicator__step ${
              index === activeStep
                ? 'step-indicator__step--active'
                : 'step-indicator__step--inactive'
            }`}
          >
            <div className="step-indicator__icon-wrap">
              <img src={step.icon} alt="" className="step-indicator__icon" />
            </div>
            <div className="step-indicator__text">
              <span className="step-indicator__label">{step.label}</span>
              <span className="step-indicator__desc">{step.desc}</span>
            </div>
          </div>
          {index < STEPS.length - 1 && (
            <img src={ASSETS.arrowForward} alt="" className="step-indicator__arrow" />
          )}
        </div>
      ))}
    </div>
  );
}

// ── Page ───────────────────────────────────────────────────────────────────
export default function SupporterApplyExamPage() {
  const navigate = useNavigate();
  const [form, setForm] = useState<ExamState>({ q1: [], q2: [], q3: [], q4: [] });

  const toggle = (key: keyof ExamState, value: string) => {
    setForm((prev) => {
      const current = prev[key];
      return {
        ...prev,
        [key]: current.includes(value) ? current.filter((v) => v !== value) : [...current, value],
      };
    });
  };

  const isFormValid = form.q1.length > 0 && form.q2.length > 0 && form.q3.length > 0;

  const handleNext = () => {
    if (!isFormValid) return;
    navigate('/supporter/apply/certifications');
  };

  const handleSaveDraft = () => {
    // TODO: 임시 저장 API 연동
  };

  return (
    <div className="apply-page">
      <ApplyGnb />

      <MobileGnb />

      <main className="apply-page__body">
        <div className="apply-page__card">
          {/* 페이지 제목 */}
          <div className="apply-title">
            <h1 className="apply-title__heading">서포터 지원</h1>
            <p className="apply-title__sub">
              의료케어 서포터로 활동하기 위한 기본 정보를 입력해 주세요.
              <br />
              정확한 정보 입력은 빠른 매칭에 도움이 됩니다.
            </p>
          </div>

          {/* 단계 표시 — STEP 3 활성 */}
          <StepIndicator activeStep={2} />

          {/* 폼 */}
          <div className="apply-form">
            <h2 className="apply-form__section-title">케어 성향</h2>

            {/* Q1 */}
            <div className="apply-field apply-field--gap-lg">
              <div className="apply-field__label">
                <span className="apply-field__required">*</span>
                <span className="apply-field__name">Q1. 어떤 돌봄 경험이 있으신가요?</span>
              </div>
              <div className="apply-chips" role="group" aria-label="돌봄 경험 선택">
                {Q1_OPTIONS.map((opt) => (
                  <button
                    key={opt}
                    type="button"
                    className={`apply-chip${form.q1.includes(opt) ? ' apply-chip--selected' : ''}`}
                    onClick={() => toggle('q1', opt)}
                    aria-pressed={form.q1.includes(opt)}
                  >
                    {opt}
                  </button>
                ))}
              </div>
            </div>

            {/* Q2 */}
            <div className="apply-field apply-field--gap-lg">
              <div className="apply-field__label">
                <span className="apply-field__required">*</span>
                <span className="apply-field__name">Q2. 어떤 방식으로 케어하는 편이신가요?</span>
              </div>
              <div className="apply-chips" role="group" aria-label="케어 방식 선택">
                {Q2_OPTIONS.map((opt) => (
                  <button
                    key={opt}
                    type="button"
                    className={`apply-chip${form.q2.includes(opt) ? ' apply-chip--selected' : ''}`}
                    onClick={() => toggle('q2', opt)}
                    aria-pressed={form.q2.includes(opt)}
                  >
                    {opt}
                  </button>
                ))}
              </div>
            </div>

            {/* Q3 */}
            <div className="apply-field apply-field--gap-lg">
              <div className="apply-field__label">
                <span className="apply-field__required">*</span>
                <span className="apply-field__name">
                  Q3. 어떤 활동을 선호하시나요? (복수 선택 가능)
                </span>
              </div>
              <div className="apply-chips" role="group" aria-label="선호 활동 선택">
                {Q3_OPTIONS.map((opt) => (
                  <button
                    key={opt}
                    type="button"
                    className={`apply-chip${form.q3.includes(opt) ? ' apply-chip--selected' : ''}`}
                    onClick={() => toggle('q3', opt)}
                    aria-pressed={form.q3.includes(opt)}
                  >
                    {opt}
                  </button>
                ))}
              </div>
            </div>

            {/* Q4 — 선택 사항, 별표 없음 */}
            <div className="apply-field apply-field--gap-lg">
              <div className="apply-field__label">
                <span className="apply-field__name">Q4. 특수 조건의 활동이 가능하신가요?</span>
              </div>
              <div className="apply-chips" role="group" aria-label="특수 조건 선택">
                {Q4_OPTIONS.map((opt) => (
                  <button
                    key={opt}
                    type="button"
                    className={`apply-chip${form.q4.includes(opt) ? ' apply-chip--selected' : ''}`}
                    onClick={() => toggle('q4', opt)}
                    aria-pressed={form.q4.includes(opt)}
                  >
                    {opt}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="apply-divider" />

          {/* 액션 버튼 */}
          <div className="apply-actions">
            <button
              type="button"
              className="apply-btn apply-btn--primary"
              onClick={handleNext}
              disabled={!isFormValid}
            >
              다음
            </button>
            <button
              type="button"
              className="apply-btn apply-btn--secondary"
              onClick={handleSaveDraft}
            >
              임시 저장
            </button>
          </div>
        </div>
      </main>

      <SiteFooter />
    </div>
  );
}
