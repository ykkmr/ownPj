import { useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './SupporterApplyFormPage.css';
import './SupporterApplyCertPage.css';
import { ApplyGnb } from '@/components/apply/ApplyGnb';
import { SiteFooter } from '@/components/apply/SiteFooter';
import { supporterApi } from '@/services/api/supporter';
import { toast } from '@/store/toast.store';
import type { CertificationType } from '@/types/api';

const ASSETS = {
  arrowForward: '/assets/icons/arrow_forward_ios.svg',
  stepTerms: '/assets/icons/Terms and Conditions.svg',
  stepRegistration: '/assets/icons/Registration.svg',
  stepTrust: '/assets/icons/Trust.svg',
  stepSecurityPass: '/assets/icons/Security Pass.svg',
  uploadIcon: '/assets/icons/add_photo_alternate.svg',
} as const;

const CERT_TYPE_OPTIONS: { value: CertificationType; label: string }[] = [
  { value: 'SOCIAL_WORKER', label: '사회복지사' },
  { value: 'CARE_WORKER', label: '요양보호사' },
  { value: 'ACTIVITY_SUPPORT_WORKER', label: '활동지원사' },
  { value: 'CHILD_CARE_WORKER', label: '아이돌보미' },
  { value: 'DISABILITY_CARE_WORKER', label: '장애인활동지원사' },
];

// ── Types ──────────────────────────────────────────────────────────────────
type CertState = {
  certFile: File | null;
  certificationType: CertificationType | null;
  crimeFile: File | null;
  sexCrimeConsent: boolean | null;
};

// ── Static data ────────────────────────────────────────────────────────────
const STEPS = [
  { label: 'STEP 1', desc: '약관 동의', icon: ASSETS.stepTerms },
  { label: 'STEP 2', desc: '정보 입력', icon: ASSETS.stepRegistration },
  { label: 'STEP 3', desc: '케어 성향', icon: ASSETS.stepTrust },
  { label: 'STEP 4', desc: '자격 검증', icon: ASSETS.stepSecurityPass },
];

// ── Sub-components ─────────────────────────────────────────────────────────

function StepIndicator({ activeStep }: { activeStep: number }) {
  return (
    <div className="step-indicator">
      {STEPS.map((step, index) => (
        <div key={step.label} style={{ display: 'contents' }}>
          <div
            className={`step-indicator__step ${
              index === activeStep
                ? 'step-indicator__step--active'
                : 'step-indicator__step--inactive'
            }`}
          >
            <div className="step-indicator__icon-wrap">
              <img src={step.icon} alt="" className="step-indicator__icon" />
            </div>
            <div className="step-indicator__text">
              <span className="step-indicator__label">{step.label}</span>
              <span className="step-indicator__desc">{step.desc}</span>
            </div>
          </div>
          {index < STEPS.length - 1 && (
            <img src={ASSETS.arrowForward} alt="" className="step-indicator__arrow" />
          )}
        </div>
      ))}
    </div>
  );
}

function UploadZone({
  id,
  file,
  onFileChange,
}: {
  id: string;
  file: File | null;
  onFileChange: (f: File | null) => void;
}) {
  const inputRef = useRef<HTMLInputElement>(null);

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const dropped = e.dataTransfer.files[0] ?? null;
    onFileChange(dropped);
  };

  return (
    <label
      htmlFor={id}
      className="cert-upload"
      onDragOver={(e) => e.preventDefault()}
      onDrop={handleDrop}
    >
      <input
        id={id}
        ref={inputRef}
        type="file"
        className="cert-upload__input"
        accept="image/*,.pdf"
        onChange={(e) => onFileChange(e.target.files?.[0] ?? null)}
      />
      <div className="cert-upload__icon-wrap">
        <img src={ASSETS.uploadIcon} alt="" className="cert-upload__icon" />
      </div>
      {file ? (
        <p className="cert-upload__filename">{file.name}</p>
      ) : (
        <div className="cert-upload__text">
          <p className="cert-upload__label">클릭하여 파일 선택</p>
          <p className="cert-upload__hint">또는 파일을 이곳으로 드래그하세요</p>
        </div>
      )}
    </label>
  );
}

// ── Page ───────────────────────────────────────────────────────────────────
export default function SupporterApplyCertPage() {
  const navigate = useNavigate();
  const [form, setForm] = useState<CertState>({
    certFile: null,
    certificationType: null,
    crimeFile: null,
    sexCrimeConsent: null,
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async () => {
    if (form.certFile && !form.certificationType) {
      toast.danger('자격증 종류를 선택해주세요.');
      return;
    }

    setIsSubmitting(true);
    try {
      await Promise.all([
        form.certFile && form.certificationType
          ? supporterApi.uploadCertification({
              file: form.certFile,
              certificationType: form.certificationType,
            })
          : null,
        form.crimeFile
          ? supporterApi.uploadCriminalRecord(form.crimeFile, form.sexCrimeConsent ?? undefined)
          : null,
      ]);
      navigate('/supporter/apply/complete');
    } catch {
      toast.danger('파일 업로드에 실패했습니다. 다시 시도해주세요.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleSaveDraft = () => {
    toast.info('임시 저장은 준비 중입니다.');
  };

  return (
    <div className="apply-page">
      <ApplyGnb />

      <main className="apply-page__body">
        <div className="apply-page__card">
          {/* 페이지 제목 */}
          <div className="apply-title">
            <h1 className="apply-title__heading">서포터 지원</h1>
            <p className="apply-title__sub">
              의료케어 서포터로 활동하기 위한 기본 정보를 입력해 주세요.
              <br />
              정확한 정보 입력은 빠른 매칭에 도움이 됩니다.
            </p>
          </div>

          {/* 단계 표시 — STEP 4 활성 */}
          <StepIndicator activeStep={3} />

          {/* 폼 */}
          <div className="apply-form">
            <h2 className="apply-form__section-title">자격 검증</h2>

            {/* 자격증 검증 */}
            <div className="cert-section">
              <h3 className="cert-section__title">자격증 검증 (선택)</h3>
              <select
                className="cert-type-select"
                value={form.certificationType ?? ''}
                onChange={(e) =>
                  setForm((p) => ({
                    ...p,
                    certificationType: (e.target.value as CertificationType) || null,
                  }))
                }
              >
                <option value="">자격증 종류 선택</option>
                {CERT_TYPE_OPTIONS.map((opt) => (
                  <option key={opt.value} value={opt.value}>
                    {opt.label}
                  </option>
                ))}
              </select>
              <UploadZone
                id="cert-file"
                file={form.certFile}
                onFileChange={(f) => setForm((p) => ({ ...p, certFile: f }))}
              />
            </div>

            {/* 범죄 경력 회보서 */}
            <div className="cert-section">
              <div className="cert-section__header">
                <h3 className="cert-section__title">범죄 경력 회보서 (선택)</h3>
                <p className="cert-section__desc">
                  이용자와 보호자에게 더 높은 신뢰를 제공하기 위해 범죄 경력 회보서를 제출하실 수
                  있습니다.
                  <br />
                  제출시 프로필에 &apos;안심 서포터&apos; 배지가 부여됩니다.
                </p>
              </div>
              <UploadZone
                id="crime-file"
                file={form.crimeFile}
                onFileChange={(f) => setForm((p) => ({ ...p, crimeFile: f }))}
              />
            </div>

            {/* 성범죄 이력 조회 동의 */}
            <div className="cert-section">
              <div className="cert-section__header">
                <h3 className="cert-section__title">성범죄 이력 조회 동의 (선택)</h3>
                <p className="cert-section__desc">
                  이용자와 보호자에게 더 높은 신뢰를 제공하기 위해 성범죄 이력 조회에 동의하실 수
                  있습니다.
                  <br />
                  제출시 프로필에 &apos;안심 서포터&apos; 배지가 부여됩니다.
                </p>
              </div>
              <div className="cert-radio-group" role="group" aria-label="성범죄 이력 조회 동의">
                <label className="cert-radio">
                  <input
                    type="radio"
                    name="sexCrimeConsent"
                    value="agree"
                    checked={form.sexCrimeConsent === true}
                    onChange={() => setForm((p) => ({ ...p, sexCrimeConsent: true }))}
                  />
                  <span className="cert-radio__dot" />
                  <span className="cert-radio__text">동의합니다</span>
                </label>
                <label className="cert-radio">
                  <input
                    type="radio"
                    name="sexCrimeConsent"
                    value="disagree"
                    checked={form.sexCrimeConsent === false}
                    onChange={() => setForm((p) => ({ ...p, sexCrimeConsent: false }))}
                  />
                  <span className="cert-radio__dot" />
                  <span className="cert-radio__text">동의하지 않습니다</span>
                </label>
              </div>
            </div>
          </div>

          <div className="apply-divider" />

          {/* 액션 버튼 */}
          <div className="apply-actions">
            <button
              type="button"
              className="apply-btn apply-btn--secondary"
              onClick={handleSaveDraft}
              disabled={isSubmitting}
            >
              임시 저장
            </button>
            <button
              type="button"
              className="apply-btn apply-btn--primary"
              onClick={handleSubmit}
              disabled={isSubmitting}
            >
              {isSubmitting ? '업로드 중...' : '제출하기 →'}
            </button>
          </div>
        </div>
      </main>

      <SiteFooter />
    </div>
  );
}
