import { useState } from 'react';
import { ApplyGnb } from '@/components/apply/ApplyGnb';
import { MobileGnb } from '@/components/apply/MobileGnb';
import { SiteFooter } from '@/components/apply/SiteFooter';
import { MySupportSidebar } from '@/components/supporter/MySupportSidebar';
import './MySupportExplorePage.css';

// ── Types ──────────────────────────────────────────────────────────────────
type CareType = 'hospital' | 'elderly' | 'child';
type FilterChip = 'all' | CareType;

interface CareItem {
  id: string;
  type: CareType;
  title: string;
  schedule: string;
  location: string;
  patientInfo?: string;
  price?: string;
  requests?: string[];
}

// ── Mock data ──────────────────────────────────────────────────────────────
const MOCK_RESULTS: CareItem[] = [
  {
    id: '1',
    type: 'hospital',
    title: '참나무요양병원',
    schedule: '26.05.02 (토) 오전 10:00 ~ 오후 1시 (3시간)',
    location: '서울특별시 구로구 고척로31길9 (개봉동)',
    patientInfo: '여성 / 64세 / 55kg이상 / 160cm이하',
    price: '60,000원',
    requests: ['식사 시 천천히', '정확한 시간 약 복용', '응급시 보호자/병원 즉시 연락'],
  },
  {
    id: '2',
    type: 'elderly',
    title: '구로구 개봉동',
    schedule: '26.05.02 (토) 오전 10:00 ~ 오후 1시 (3시간)',
    location: '서울특별시 구로구 고척로31길9 (개봉동)',
    patientInfo: '여성 / 72세 / 60kg이상 / 155cm이하',
    price: '80,000원',
    requests: ['식사 시 천천히', '정확한 시간 약 복용', '응급시 보호자/병원 즉시 연락'],
  },
  {
    id: '3',
    type: 'child',
    title: '구로구 개봉동',
    schedule: '26.05.02 (토) 오전 10:00 ~ 오후 1시 (3시간)',
    location: '서울특별시 구로구 고척로31길9 (개봉동)',
    patientInfo: '여성 / 8세 / 12kg이상 / 120cm이하',
    price: '60,000원',
    requests: ['식사 시 천천히', '정확한 시간 약 복용', '응급시 보호자/병원 즉시 연락'],
  },
  {
    id: '4',
    type: 'hospital',
    title: '참나무요양병원',
    schedule: '26.05.02 (토) 오전 10:00 ~ 오후 1시 (3시간)',
    location: '서울특별시 구로구 고척로31길9 (개봉동)',
    price: '60,000원',
    requests: ['식사 시 천천히', '정확한 시간 약 복용'],
  },
  {
    id: '5',
    type: 'elderly',
    title: '참나무요양병원',
    schedule: '26.05.02 (토) 오전 10:00 ~ 오후 1시 (3시간)',
    location: '서울특별시 구로구 고척로31길9 (개봉동)',
  },
  {
    id: '6',
    type: 'child',
    title: '참나무요양병원',
    schedule: '26.05.02 (토) 오전 10:00 ~ 오후 1시 (3시간)',
    location: '서울특별시 구로구 고척로31길9 (개봉동)',
  },
  {
    id: '7',
    type: 'elderly',
    title: '참나무요양병원',
    schedule: '26.05.02 (토) 오전 10:00 ~ 오후 1시 (3시간)',
    location: '서울특별시 구로구 고척로31길9 (개봉동)',
  },
  {
    id: '8',
    type: 'hospital',
    title: '참나무요양병원',
    schedule: '26.05.02 (토) 오전 10:00 ~ 오후 1시 (3시간)',
    location: '서울특별시 구로구 고척로31길9 (개봉동)',
  },
  {
    id: '9',
    type: 'elderly',
    title: '참나무요양병원',
    schedule: '26.05.02 (토) 오전 10:00 ~ 오후 1시 (3시간)',
    location: '서울특별시 구로구 고척로31길9 (개봉동)',
  },
];

const MOCK_AI_RECOMMENDATIONS: CareItem[] = [
  {
    id: 'r1',
    type: 'hospital',
    title: '참나무요양병원',
    schedule: '26.05.02 (토) 오전 10:00 ~ 오후 1시 (3시간)',
    location: '서울특별시 구로구 고척로31길9 (개봉동)',
    price: '60,000원',
  },
  {
    id: 'r2',
    type: 'elderly',
    title: '참나무요양병원',
    schedule: '26.05.02 (토) 오전 10:00 ~ 오후 1시 (3시간)',
    location: '서울특별시 구로구 고척로31길9 (개봉동)',
    price: '80,000원',
  },
  {
    id: 'r3',
    type: 'child',
    title: '참나무요양병원',
    schedule: '26.05.02 (토) 오전 10:00 ~ 오후 1시 (3시간)',
    location: '서울특별시 구로구 고척로31길9 (개봉동)',
    price: '60,000원',
  },
  {
    id: 'r4',
    type: 'elderly',
    title: '참나무요양병원',
    schedule: '26.05.02 (토) 오전 10:00 ~ 오후 1시 (3시간)',
    location: '서울특별시 구로구 고척로31길9 (개봉동)',
    price: '70,000원',
  },
];

// ── Badge / chip config ────────────────────────────────────────────────────
const BADGE_CONFIG: Record<CareType, { bg: string; label: string }> = {
  hospital: { bg: '#e1f2ff', label: '병원 동행' },
  elderly: { bg: '#efeeff', label: '어르신 돌봄' },
  child: { bg: '#fff4d3', label: '아이 돌봄' },
};

const CHIP_LABELS: Record<FilterChip, string> = {
  all: '전체',
  hospital: '병원 동행',
  elderly: '어르신 돌봄',
  child: '아이 돌봄',
};

// ── Shared badge ───────────────────────────────────────────────────────────
function CareTypeBadge({ type }: { type: CareType }) {
  const { bg, label } = BADGE_CONFIG[type];
  return (
    <span className="explore-badge" style={{ backgroundColor: bg }}>
      {label}
    </span>
  );
}

// ── Icons (shared desktop + mobile) ───────────────────────────────────────
function IconClock({ className = 'explore-card__icon' }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="#737373" aria-hidden="true">
      <path d="M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm.5-13H11v6l5.25 3.15.75-1.23-4.5-2.67V7z" />
    </svg>
  );
}

function IconLocation({ className = 'explore-card__icon' }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="#737373" aria-hidden="true">
      <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z" />
    </svg>
  );
}

function IconPerson({ className = 'explore-card__icon' }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="#737373" aria-hidden="true">
      <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z" />
    </svg>
  );
}

function IconPrice({ className = 'explore-card__icon' }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="#737373" aria-hidden="true">
      <path d="M21.41 11.58l-9-9C12.05 2.22 11.55 2 11 2H4c-1.1 0-2 .9-2 2v7c0 .55.22 1.05.59 1.42l9 9c.36.36.86.58 1.41.58.55 0 1.05-.22 1.41-.59l7-7c.37-.36.59-.86.59-1.41 0-.55-.23-1.06-.59-1.42zM5.5 7C4.67 7 4 6.33 4 5.5S4.67 4 5.5 4 7 4.67 7 5.5 6.33 7 5.5 7z" />
    </svg>
  );
}

const ARROW_FILTER = 'brightness(0) invert(1) brightness(0.45)';

// ── Desktop ExploreCard ────────────────────────────────────────────────────
function ExploreCard({ item }: { item: CareItem }) {
  return (
    <div className="explore-card">
      <div className="explore-card__header">
        <CareTypeBadge type={item.type} />
        <p className="explore-card__title">{item.title}</p>
      </div>
      <div className="explore-card__info">
        <div className="explore-card__info-row">
          <IconClock />
          <span className="explore-card__info-text">{item.schedule}</span>
        </div>
        <div className="explore-card__info-row">
          <IconLocation />
          <span className="explore-card__info-text">{item.location}</span>
        </div>
      </div>
      <div className="explore-card__footer">
        <button type="button" className="explore-card__detail-btn">
          상세 보기
          <img
            src="/assets/icons/keyboard_arrow_down.svg"
            alt=""
            aria-hidden="true"
            width="24"
            height="24"
            style={{ filter: ARROW_FILTER }}
          />
        </button>
        <button type="button" className="explore-card__apply-btn">
          지원하기
        </button>
      </div>
    </div>
  );
}

// ── Desktop SearchBar ──────────────────────────────────────────────────────
function SearchBar() {
  return (
    <div className="explore-search">
      <div className="explore-search__field">
        <span className="explore-search__label">검색 키워드</span>
        <input type="text" className="explore-search__input" placeholder="입력하세요" />
      </div>
      <div className="explore-search__field">
        <span className="explore-search__label">지역</span>
        <button type="button" className="explore-search__dropdown">
          <span>활동 지역</span>
          <img
            src="/assets/icons/keyboard_arrow_down.svg"
            alt=""
            aria-hidden="true"
            width="24"
            height="24"
            style={{ filter: ARROW_FILTER }}
          />
        </button>
      </div>
      <div className="explore-search__field">
        <span className="explore-search__label">서비스 종류</span>
        <button type="button" className="explore-search__dropdown">
          <span>돌봄 타입</span>
          <img
            src="/assets/icons/keyboard_arrow_down.svg"
            alt=""
            aria-hidden="true"
            width="24"
            height="24"
            style={{ filter: ARROW_FILTER }}
          />
        </button>
      </div>
      <div className="explore-search__field">
        <span className="explore-search__label">날짜</span>
        <button type="button" className="explore-search__dropdown">
          <span>날짜 선택</span>
          <img
            src="/assets/icons/keyboard_arrow_down.svg"
            alt=""
            aria-hidden="true"
            width="24"
            height="24"
            style={{ filter: ARROW_FILTER }}
          />
        </button>
      </div>
      <button type="button" className="explore-search__btn">
        검색
      </button>
    </div>
  );
}

// ── Desktop ResultsSection ─────────────────────────────────────────────────
function ResultsSection() {
  return (
    <section className="explore-results">
      <div className="explore-results__header">
        <div className="explore-results__count-row">
          <h2 className="explore-results__title">검색 결과</h2>
          <span className="explore-results__count">15건</span>
        </div>
        <button type="button" className="explore-sort-btn">
          최신등록순
          <img
            src="/assets/icons/keyboard_arrow_down.svg"
            alt=""
            aria-hidden="true"
            width="24"
            height="24"
            style={{ filter: ARROW_FILTER }}
          />
        </button>
      </div>
      <div className="explore-results__grid">
        {MOCK_RESULTS.map((item) => (
          <ExploreCard key={item.id} item={item} />
        ))}
      </div>
    </section>
  );
}

// ── Desktop AiSection ──────────────────────────────────────────────────────
function AiSection() {
  return (
    <section className="explore-ai">
      <div className="explore-ai__header">
        <h2 className="explore-ai__title">[AI 추천] 이런 돌봄은 어떠세요?</h2>
        <button type="button" className="explore-ai__more">
          추천 더보기
          <img
            src="/assets/icons/arrow_forward_ios.svg"
            alt=""
            aria-hidden="true"
            width="20"
            height="20"
            style={{ filter: ARROW_FILTER }}
          />
        </button>
      </div>
      <div className="explore-ai__cards">
        {MOCK_AI_RECOMMENDATIONS.map((item) => (
          <ExploreCard key={item.id} item={item} />
        ))}
      </div>
    </section>
  );
}

// ── Mobile sub-components ─────────────────────────────────────────────────
function MobileSearchForm() {
  return (
    <div className="m-explore-search">
      <div className="m-explore-search__field">
        <span className="m-explore-search__label">검색 키워드</span>
        <input type="text" className="m-explore-search__input" placeholder="입력하세요" />
      </div>
      <div className="m-explore-search__field">
        <span className="m-explore-search__label">지역</span>
        <button type="button" className="m-explore-search__dropdown">
          <span>활동 지역</span>
          <img
            src="/assets/icons/keyboard_arrow_down.svg"
            alt=""
            aria-hidden="true"
            width="24"
            height="24"
            style={{ filter: ARROW_FILTER }}
          />
        </button>
      </div>
      <button type="button" className="m-explore-search__btn">
        검색
      </button>
    </div>
  );
}

function MobileFilterChips({
  active,
  onChange,
}: {
  active: FilterChip;
  onChange: (chip: FilterChip) => void;
}) {
  const chips: FilterChip[] = ['all', 'hospital', 'elderly', 'child'];
  return (
    <div className="m-explore-chips">
      {chips.map((chip) => (
        <button
          key={chip}
          type="button"
          className={`m-explore-chip${active === chip ? ' m-explore-chip--active' : ''}`}
          onClick={() => onChange(chip)}
        >
          {CHIP_LABELS[chip]}
        </button>
      ))}
    </div>
  );
}

function MobileExploreCard({
  item,
  isOpen,
  onToggle,
}: {
  item: CareItem;
  isOpen: boolean;
  onToggle: () => void;
}) {
  return (
    <div className="m-explore-card">
      <div className="m-explore-card__top">
        <CareTypeBadge type={item.type} />
        <p className="m-explore-card__title">{item.title}</p>
      </div>
      <div className="m-explore-card__info">
        <div className="m-explore-card__info-row">
          <IconClock className="m-explore-card__icon" />
          <span className="m-explore-card__info-text">{item.schedule}</span>
        </div>
        <div className="m-explore-card__info-row">
          <IconLocation className="m-explore-card__icon" />
          <span className="m-explore-card__info-text">{item.location}</span>
        </div>
        {isOpen && (
          <>
            {item.patientInfo && (
              <div className="m-explore-card__info-row">
                <IconPerson className="m-explore-card__icon" />
                <span className="m-explore-card__info-text">{item.patientInfo}</span>
              </div>
            )}
            {item.price && (
              <div className="m-explore-card__info-row">
                <IconPrice className="m-explore-card__icon" />
                <span className="m-explore-card__info-text">{item.price}</span>
              </div>
            )}
            {item.requests && item.requests.length > 0 && (
              <div className="m-explore-card__requests">
                <span className="m-explore-card__req-label">요청 사항</span>
                <ul className="m-explore-card__req-list">
                  {item.requests.map((req) => (
                    <li key={req}>{req}</li>
                  ))}
                </ul>
              </div>
            )}
          </>
        )}
      </div>
      <div className="m-explore-card__footer">
        <button type="button" className="m-explore-card__detail-btn" onClick={onToggle}>
          상세 보기
          <img
            src="/assets/icons/keyboard_arrow_down.svg"
            alt=""
            aria-hidden="true"
            width="24"
            height="24"
            className={`m-explore-card__chevron${isOpen ? ' m-explore-card__chevron--open' : ''}`}
            style={{ filter: ARROW_FILTER }}
          />
        </button>
        <button type="button" className="m-explore-card__apply-btn">
          지원하기
        </button>
      </div>
    </div>
  );
}

function MobileResultsSection() {
  const [activeChip, setActiveChip] = useState<FilterChip>('all');
  const [openCardId, setOpenCardId] = useState<string | null>('1');

  const filtered =
    activeChip === 'all' ? MOCK_RESULTS : MOCK_RESULTS.filter((r) => r.type === activeChip);

  function toggleCard(id: string) {
    setOpenCardId((prev) => (prev === id ? null : id));
  }

  return (
    <section className="m-explore-results">
      <div className="m-explore-results__header">
        <div className="m-explore-results__count-row">
          <span className="m-explore-results__title">검색 결과</span>
          <span className="m-explore-results__count">{filtered.length}건</span>
        </div>
        <button type="button" className="m-explore-sort-btn">
          최신등록순
          <img
            src="/assets/icons/keyboard_arrow_down.svg"
            alt=""
            aria-hidden="true"
            width="24"
            height="24"
            style={{ filter: ARROW_FILTER }}
          />
        </button>
      </div>
      <MobileFilterChips active={activeChip} onChange={setActiveChip} />
      <div className="m-explore-results__list">
        {filtered.map((item) => (
          <MobileExploreCard
            key={item.id}
            item={item}
            isOpen={openCardId === item.id}
            onToggle={() => toggleCard(item.id)}
          />
        ))}
      </div>
    </section>
  );
}

function MobileAiSection() {
  return (
    <section className="m-explore-ai">
      <div className="m-explore-ai__header">
        <h2 className="m-explore-ai__title">이런 돌봄은 어떠세요?</h2>
        <img
          src="/assets/icons/arrow_forward_ios.svg"
          alt=""
          aria-hidden="true"
          width="20"
          height="20"
          style={{ filter: ARROW_FILTER }}
        />
      </div>
      <div className="m-explore-ai__cards">
        {MOCK_AI_RECOMMENDATIONS.map((item) => (
          <div key={item.id} className="m-explore-ai-card">
            <div className="m-explore-card__top">
              <CareTypeBadge type={item.type} />
              <p className="m-explore-card__title">{item.title}</p>
            </div>
            <div className="m-explore-card__info">
              <div className="m-explore-card__info-row">
                <IconClock className="m-explore-card__icon" />
                <span className="m-explore-card__info-text">{item.schedule}</span>
              </div>
              <div className="m-explore-card__info-row">
                <IconLocation className="m-explore-card__icon" />
                <span className="m-explore-card__info-text">{item.location}</span>
              </div>
            </div>
            <div className="m-explore-card__footer">
              <button type="button" className="m-explore-card__apply-btn">
                지원하기
              </button>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

// ── Page ───────────────────────────────────────────────────────────────────
export default function MySupportExplorePage() {
  return (
    <div className="mypage-page">
      <MobileGnb />
      <ApplyGnb variant="simple" />
      <main className="mypage-main">
        <MySupportSidebar activeItemId="explore" />
        <div className="mypage-content">
          <div className="mypage-greeting">
            <h1 className="mypage-greeting__heading">케어 탐색</h1>
            <p className="mypage-greeting__sub">나에게 맞는 돌봄 요청을 찾아 바로 지원해보세요.</p>
          </div>
          <SearchBar />
          <ResultsSection />
          <AiSection />
        </div>
      </main>

      <div className="explore-mobile">
        <div className="m-explore-heading">
          <h1 className="m-explore-heading__title">케어 탐색</h1>
          <p className="m-explore-heading__sub">나에게 맞는 돌봄 요청을 찾아 바로 지원해보세요.</p>
        </div>
        <MobileSearchForm />
        <MobileResultsSection />
        <MobileAiSection />
      </div>

      <SiteFooter />
    </div>
  );
}
