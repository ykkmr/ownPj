import { useState } from 'react';
import { ApplyGnb } from '@/components/apply/ApplyGnb';
import { SiteFooter } from '@/components/apply/SiteFooter';
import { MySupportSidebar } from '@/components/supporter/MySupportSidebar';
import { VerifyCodeModal } from '@/components/auth/VerifyCodeModal';
import './MySupportProfilePage.css';

type VerifyTarget = 'email' | 'phone';

interface SimpleFieldProps {
  label: string;
  type?: string;
  defaultValue: string;
}

function SimpleField({ label, type = 'text', defaultValue }: SimpleFieldProps) {
  return (
    <div className="profile-field">
      <label className="profile-field__label">{label}</label>
      <input
        type={type}
        className="profile-field__input"
        defaultValue={defaultValue}
        autoComplete="off"
      />
    </div>
  );
}

interface VerifiedFieldProps {
  label: string;
  type?: string;
  defaultValue: string;
  isVerified: boolean;
  verifiedLabel: string;
  onRequestVerify: () => void;
}

function VerifiedField({
  label,
  type = 'text',
  defaultValue,
  isVerified,
  verifiedLabel,
  onRequestVerify,
}: VerifiedFieldProps) {
  return (
    <div className="profile-field">
      <label className="profile-field__label">{label}</label>
      <div className="profile-field__row">
        <input
          type={type}
          className="profile-field__input profile-field__input--partial"
          defaultValue={defaultValue}
          autoComplete="off"
        />
        {isVerified ? (
          <button type="button" className="profile-field__status-btn" disabled>
            {verifiedLabel}
          </button>
        ) : (
          <button type="button" className="profile-field__verify-btn" onClick={onRequestVerify}>
            인증하기
          </button>
        )}
      </div>
    </div>
  );
}

export default function MySupportProfilePage() {
  const [verifyTarget, setVerifyTarget] = useState<VerifyTarget | null>(null);
  const [verified, setVerified] = useState({ email: true, phone: true });

  function handleVerifyComplete(_code: string) {
    if (verifyTarget) setVerified((prev) => ({ ...prev, [verifyTarget]: true }));
    setVerifyTarget(null);
  }

  const contactByTarget: Record<VerifyTarget, string> = {
    email: 'kim00@prototie.net',
    phone: '010-1234-5678',
  };

  return (
    <div className="mypage-page">
      <ApplyGnb variant="simple" />
      <main className="mypage-main">
        <MySupportSidebar activeItemId="profile" />
        <div className="mypage-content">
          <div className="mypage-greeting">
            <h1 className="mypage-greeting__heading">내 정보 관리</h1>
            <p className="mypage-greeting__sub">
              파트너님의 소중한 정보는 안전하게 보호됩니다. 원활한 서비스 매칭과 투명한 정산을 위해
              최신 정보를 유지해 주세요.
            </p>
          </div>
          <div className="profile-form">
            <div className="profile-fields">
              <SimpleField label="이름" defaultValue="김이나" />
              <VerifiedField
                label="이메일"
                type="email"
                defaultValue="kim00@prototie.net"
                isVerified={verified.email}
                verifiedLabel="확인 완료"
                onRequestVerify={() => setVerifyTarget('email')}
              />
              <SimpleField label="비밀번호" type="password" defaultValue="Kimmmm~" />
              <VerifiedField
                label="전화번호"
                type="tel"
                defaultValue="010-1234-5678"
                isVerified={verified.phone}
                verifiedLabel="인증 완료"
                onRequestVerify={() => setVerifyTarget('phone')}
              />
            </div>
            <button type="button" className="profile-submit-btn">
              수정 완료
            </button>
          </div>
        </div>
      </main>
      <SiteFooter />

      {verifyTarget && (
        <VerifyCodeModal
          contact={contactByTarget[verifyTarget]}
          onVerify={handleVerifyComplete}
          onClose={() => setVerifyTarget(null)}
        />
      )}
    </div>
  );
}
