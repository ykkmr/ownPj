import { useNavigate } from 'react-router-dom';
import { useSupporterEarnings } from '@/hooks/useSupporter';
import { PageHeader, Card, CardBody, ListStateView } from '@/components/ui';
import { ApplyGnb } from '@/components/apply/ApplyGnb';
import { MobileGnb } from '@/components/apply/MobileGnb';
import { SiteFooter } from '@/components/apply/SiteFooter';

export default function EarningsPage() {
  const navigate = useNavigate();
  const { data, isLoading, isError, refetch } = useSupporterEarnings();

  const fmt = (n: number) => `${n.toLocaleString()}원`;

  return (
    <div className="mypage-page">
      <MobileGnb />
      <ApplyGnb variant="simple" />
      <div className="flex flex-col">
        <PageHeader title="수익 현황" showBack onBack={() => navigate(-1)} />

        <div className="p-4">
          <ListStateView isLoading={isLoading} isError={isError} onRetry={refetch}>
            {data && (
              <div className="flex flex-col gap-3">
                <Card>
                  <CardBody className="flex flex-col gap-3">
                    <div className="flex justify-between">
                      <span className="text-gray-500">이번 달 수익</span>
                      <span className="font-semibold text-blue-600">{fmt(data.thisMonth)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">지난 달 수익</span>
                      <span className="font-medium">{fmt(data.lastMonth)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">총 활동 시간</span>
                      <span className="font-medium">{data.totalHours}시간</span>
                    </div>
                    <div className="flex justify-between border-t border-gray-100 pt-3">
                      <span className="text-gray-500">정산 대기</span>
                      <span className="font-semibold text-orange-500">
                        {fmt(data.pendingSettlement)}
                      </span>
                    </div>
                  </CardBody>
                </Card>
              </div>
            )}
          </ListStateView>
        </div>
      </div>
      <SiteFooter />
    </div>
  );
}
