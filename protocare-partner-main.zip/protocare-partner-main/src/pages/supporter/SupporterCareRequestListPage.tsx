import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useCareRequestList } from '@/hooks/useCareRequest';
import { useApplyCareRequest } from '@/hooks/useCareApplication';
import { PageHeader, Card, CardBody, ListStateView, Badge, Button } from '@/components/ui';
import { ApplyGnb } from '@/components/apply/ApplyGnb';
import { MobileGnb } from '@/components/apply/MobileGnb';
import { SiteFooter } from '@/components/apply/SiteFooter';
import type { CareRequestType } from '@/types';

const TYPE_LABEL: Record<CareRequestType, string> = {
  HOSPITAL: '병원동행',
  ELDERLY: '어르신케어',
  CHILD: '아이돌봄',
};

export default function SupporterCareRequestListPage() {
  const navigate = useNavigate();
  const [page, setPage] = useState(0);
  const { data, isLoading, isError, refetch } = useCareRequestList({ page, size: 10 });
  const apply = useApplyCareRequest();

  return (
    <div className="mypage-page">
      <MobileGnb />
      <ApplyGnb variant="simple" />
      <div className="flex flex-col">
        <PageHeader title="케어요청 목록" showBack onBack={() => navigate(-1)} />

        <div className="p-4">
          <ListStateView
            isLoading={isLoading}
            isError={isError}
            isEmpty={!data?.content.length}
            emptyTitle="현재 요청이 없습니다"
            emptyDescription="새로운 케어요청이 등록되면 알려드립니다"
            onRetry={refetch}
          >
            <div className="flex flex-col gap-3">
              {data?.content.map((req) => (
                <Card key={req.id}>
                  <CardBody>
                    <div className="flex items-start justify-between">
                      <div className="flex flex-col gap-1">
                        <Badge variant="primary">{TYPE_LABEL[req.type]}</Badge>
                        <p className="mt-1 text-sm text-gray-600">
                          {req.startAt.slice(0, 10)} {req.startAt.slice(11, 16)} ~{' '}
                          {req.endAt.slice(11, 16)}
                        </p>
                        {req.from && (
                          <p className="text-sm text-gray-500">
                            {req.from} → {req.to}
                          </p>
                        )}
                        {req.addRequest && (
                          <p className="mt-1 text-sm text-gray-400">{req.addRequest}</p>
                        )}
                      </div>
                      <Button
                        size="sm"
                        onClick={() => apply.mutate({ careRequestId: req.id })}
                        disabled={apply.isPending}
                      >
                        지원
                      </Button>
                    </div>
                  </CardBody>
                </Card>
              ))}
            </div>
          </ListStateView>

          {data && data.totalPages > 1 && (
            <div className="mt-4 flex justify-center gap-2">
              <Button
                size="sm"
                variant="outline"
                disabled={page === 0}
                onClick={() => setPage((p) => p - 1)}
              >
                이전
              </Button>
              <span className="flex items-center text-sm text-gray-500">
                {page + 1} / {data.totalPages}
              </span>
              <Button
                size="sm"
                variant="outline"
                disabled={!data.hasNext}
                onClick={() => setPage((p) => p + 1)}
              >
                다음
              </Button>
            </div>
          )}
        </div>
      </div>
      <SiteFooter />
    </div>
  );
}
