import { useNavigate } from 'react-router-dom';
import { useCertifications } from '@/hooks/useSupporter';
import { PageHeader, Card, CardBody, ListStateView, Badge } from '@/components/ui';
import { ApplyGnb } from '@/components/apply/ApplyGnb';
import { MobileGnb } from '@/components/apply/MobileGnb';
import { SiteFooter } from '@/components/apply/SiteFooter';
import type { CertificationStatus } from '@/types';

const CERT_STATUS_LABEL: Record<CertificationStatus, string> = {
  PENDING: '심사중',
  VERIFIED: '인증완료',
  REJECTED: '반려',
};

const CERT_STATUS_VARIANT: Record<CertificationStatus, 'default' | 'success' | 'danger'> = {
  PENDING: 'default',
  VERIFIED: 'success',
  REJECTED: 'danger',
};

export default function SupporterCertListPage() {
  const navigate = useNavigate();
  const { data, isLoading, isError, refetch } = useCertifications();

  return (
    <div className="mypage-page">
      <MobileGnb />
      <ApplyGnb variant="simple" />
      <div className="flex flex-col">
        <PageHeader title="자격증 목록" showBack onBack={() => navigate(-1)} />

        <div className="p-4">
          <ListStateView
            isLoading={isLoading}
            isError={isError}
            isEmpty={!data?.length}
            emptyTitle="등록된 자격증이 없습니다"
            onRetry={refetch}
          >
            <div className="flex flex-col gap-3">
              {data?.map((cert) => (
                <Card key={cert.id}>
                  <CardBody>
                    <div className="flex items-start justify-between">
                      <div className="flex flex-col gap-1">
                        <p className="font-medium">{cert.certificationTypeName}</p>
                        {cert.issuer && <p className="text-sm text-gray-500">{cert.issuer}</p>}
                        {cert.issuedAt && (
                          <p className="text-sm text-gray-400">발급일: {cert.issuedAt}</p>
                        )}
                        {cert.rejectedReason && (
                          <p className="text-sm text-red-500">{cert.rejectedReason}</p>
                        )}
                      </div>
                      <Badge variant={CERT_STATUS_VARIANT[cert.status]}>
                        {CERT_STATUS_LABEL[cert.status]}
                      </Badge>
                    </div>
                  </CardBody>
                </Card>
              ))}
            </div>
          </ListStateView>
        </div>
      </div>
      <SiteFooter />
    </div>
  );
}
