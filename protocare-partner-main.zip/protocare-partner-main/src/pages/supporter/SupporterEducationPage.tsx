import { useNavigate } from 'react-router-dom';
import { useTrainingList, useUpdateTrainingProgress } from '@/hooks/useSupporter';
import { PageHeader, Card, CardBody, ListStateView, ProgressBar, Button } from '@/components/ui';
import { ApplyGnb } from '@/components/apply/ApplyGnb';
import { MobileGnb } from '@/components/apply/MobileGnb';
import { SiteFooter } from '@/components/apply/SiteFooter';

export default function SupporterEducationPage() {
  const navigate = useNavigate();
  const { data, isLoading, isError, refetch } = useTrainingList();
  const updateProgress = useUpdateTrainingProgress();

  return (
    <div className="mypage-page">
      <MobileGnb />
      <ApplyGnb variant="simple" />
      <div className="flex flex-col">
        <PageHeader title="교육 이력" showBack onBack={() => navigate(-1)} />

        <div className="p-4">
          <ListStateView
            isLoading={isLoading}
            isError={isError}
            isEmpty={!data?.length}
            emptyTitle="교육 내역이 없습니다"
            onRetry={refetch}
          >
            <div className="flex flex-col gap-3">
              {data?.map((item) => (
                <Card key={item.id}>
                  <CardBody className="flex flex-col gap-2">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <p className="font-medium">{item.contentName}</p>
                        <p className="text-sm text-gray-500">{item.contentType}</p>
                      </div>
                      {item.isCompleted ? (
                        <span className="text-sm font-medium text-green-600">완료</span>
                      ) : (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => updateProgress.mutate({ id: item.id, progress: 100 })}
                          disabled={updateProgress.isPending}
                        >
                          완료 처리
                        </Button>
                      )}
                    </div>
                    <ProgressBar value={item.progress} max={100} />
                    <p className="text-right text-xs text-gray-400">{item.progress}%</p>
                  </CardBody>
                </Card>
              ))}
            </div>
          </ListStateView>
        </div>
      </div>
      <SiteFooter />
    </div>
  );
}
