import { useState, useMemo } from 'react';
import { ApplyGnb } from '@/components/apply/ApplyGnb';
import { SiteFooter } from '@/components/apply/SiteFooter';
import { MySupportSidebar } from '@/components/supporter/MySupportSidebar';
import './MySupportNoticesPage.css';
import './MySupportFaqPage.css';

// ── Types ──────────────────────────────────────────────────────────────────
type FaqCategory =
  | '수익 및 정산'
  | '평점 및 리뷰 관리'
  | '매칭 및 스케줄'
  | '활동 중 긴급상황'
  | '케어 전문 교육'
  | '계정 및 권한';

interface FaqItem {
  id: number;
  category: FaqCategory;
  question: string;
  answer: string;
}

// ── Static data ─────────────────────────────────────────────────────────────
const CATEGORIES: FaqCategory[] = [
  '수익 및 정산',
  '평점 및 리뷰 관리',
  '매칭 및 스케줄',
  '활동 중 긴급상황',
  '케어 전문 교육',
  '계정 및 권한',
];

const FAQS: FaqItem[] = [
  {
    id: 1,
    category: '수익 및 정산',
    question: '주말/공휴일 가산금은 기본 시급의 몇 %인가요?',
    answer: `안녕하세요, ProtoCare 운영팀입니다. 주말과 공휴일에도 변함없이 따뜻한 돌봄을 실천해 주시는 파트너님들의 노고에 감사드립니다.

1. 가산금 적용 비율
주말 및 법정 공휴일 활동 시, 해당 서비스 기본 시급에 20% 가산된 금액이 지급됩니다.
• 평일(월~금): 기본 시급 (100%)
• 주말(토, 일): 기본 시급 + 20%
• 공휴일(법정·대체): 기본 시급 + 20%

2. 시간대별 중복 적용 안내
• 심야 가산: 밤 10시(22:00) 이후 활동 시 주말 가산과 별개로 심야 수당(10%)이 추가 합산됩니다.
• 연장 수당: 현장에서 합의된 연장 활동 또한 해당 요일의 가산 비율을 그대로 적용받습니다.

3. 주의사항
• 활동 신청 화면의 '예상 수익'은 이미 가산금이 포함된 금액입니다.
• 정산 기준: 활동 시작 시간을 기준으로 해당 날짜가 공휴일일 경우 가산이 적용됩니다.`,
  },
  {
    id: 2,
    category: '수익 및 정산',
    question: '활동 중 발생한 주차비와 간식비, 정산 청구 방법은?',
    answer:
      '활동 종료 후 앱 내 "활동 일지 → 실비 청구" 메뉴에서 영수증을 첨부하여 청구하실 수 있습니다. 청구 후 2영업일 내 검토 및 승인됩니다.',
  },
  {
    id: 3,
    category: '수익 및 정산',
    question: '정산 금액과 내 계좌 입금액이 다른 이유 (수수료/세금)',
    answer:
      '플랫폼 이용 수수료(활동비의 10%) 및 원천세(3.3%)가 공제된 금액이 입금됩니다. 세부 내역은 마이서포트 → 정산 관리 → 정산 상세에서 확인하실 수 있습니다.',
  },
  {
    id: 4,
    category: '수익 및 정산',
    question: '야간 활동(22시 이후) 시 심야 수당 적용 기준',
    answer:
      '밤 10시(22:00) ~ 다음 날 오전 6시(06:00) 사이 활동에 기본 시급의 10%가 심야 수당으로 추가 지급됩니다. 주말·공휴일 가산금과 중복 적용됩니다.',
  },
  {
    id: 5,
    category: '수익 및 정산',
    question: '활동 연장 시 15분/30분 단위 수당 계산법',
    answer:
      '연장 시간은 15분 단위로 계산됩니다. 예를 들어 기본 시급이 20,000원이라면 15분 연장 시 5,000원이 추가됩니다. 요일 가산율이 동일하게 적용됩니다.',
  },
  {
    id: 6,
    category: '수익 및 정산',
    question: '이번 주 정산 리포트는 어디서 다운로드하나요?',
    answer:
      '마이서포트 → 정산 관리 → 정산 내역 화면 우측 상단의 "리포트 다운로드" 버튼을 클릭하시면 PDF 형식으로 다운로드할 수 있습니다.',
  },
  {
    id: 7,
    category: '수익 및 정산',
    question: "활동 취소 시 지급되는 '노쇼 보상금' 수령 조건",
    answer:
      '의뢰인이 활동 시작 1시간 이내 또는 현장 도착 후 취소한 경우, 서포터에게 활동비의 50%가 노쇼 보상금으로 지급됩니다. 정산은 익주 화요일에 이루어집니다.',
  },
  {
    id: 8,
    category: '수익 및 정산',
    question: '원천징수 영수증 및 종합소득세 신고용 자료 발급 안내',
    answer:
      '매년 1월 말까지 마이서포트 → 정산 관리 → 세금 서류에서 전년도 원천징수 영수증을 PDF로 발급받으실 수 있습니다.',
  },
  {
    id: 9,
    category: '수익 및 정산',
    question: '정산 계좌 변경 시 이번 주 수익부터 바로 적용되나요?',
    answer:
      '계좌 변경은 변경 완료 후 다음 정산 주기(매주 화요일)부터 적용됩니다. 변경 당일이 정산일이라면 기존 계좌로 입금되오니 유의해 주세요.',
  },
  {
    id: 10,
    category: '평점 및 리뷰 관리',
    question: '평점은 어떻게 산정되나요?',
    answer:
      '의뢰인이 활동 종료 후 24시간 내 남긴 별점(1~5점)의 최근 30건 평균으로 산정됩니다. 부당한 평점은 고객센터로 이의신청하실 수 있습니다.',
  },
  {
    id: 11,
    category: '매칭 및 스케줄',
    question: '매칭 수락 후 취소 시 패널티가 있나요?',
    answer:
      '매칭 수락 후 활동 시작 24시간 이전 취소 시 1회 경고, 3회 누적 시 7일간 매칭 제한이 적용됩니다. 불가피한 사유는 고객센터에 문의해 주세요.',
  },
  {
    id: 12,
    category: '활동 중 긴급상황',
    question: '활동 중 의뢰인이 의식을 잃었을 때 어떻게 해야 하나요?',
    answer:
      '즉시 119에 신고하고, 앱 내 긴급 연락 버튼을 눌러 운영팀에 상황을 공유해 주세요. 운영팀이 24시간 대기 중이며 즉각 대응 지원을 제공합니다.',
  },
];

const ITEMS_PER_PAGE = 9;

// ── Sub-components ─────────────────────────────────────────────────────────
interface FaqRowProps {
  item: FaqItem;
  isOpen: boolean;
  onToggle: () => void;
}

function FaqRow({ item, isOpen, onToggle }: FaqRowProps) {
  return (
    <li className="notice-item">
      <button type="button" className="notice-row" onClick={onToggle} aria-expanded={isOpen}>
        <span className="notice-row__category">[{item.category}]</span>
        <span className="notice-row__title">{item.question}</span>
        <img
          src="/assets/icons/keyboard_arrow_down.svg"
          alt=""
          aria-hidden="true"
          className={`notice-row__arrow${isOpen ? ' notice-row__arrow--open' : ''}`}
        />
      </button>
      {isOpen && (
        <div className="faq-body">
          <div className="faq-body__box">{item.answer}</div>
        </div>
      )}
    </li>
  );
}

interface PaginationProps {
  current: number;
  total: number;
  onChange: (page: number) => void;
}

function Pagination({ current, total, onChange }: PaginationProps) {
  if (total <= 1) return null;
  return (
    <nav className="notice-pagination" aria-label="페이지 탐색">
      {Array.from({ length: total }, (_, i) => i + 1).map((page) => (
        <button
          key={page}
          type="button"
          className={`notice-pagination__btn${current === page ? ' notice-pagination__btn--active' : ''}`}
          onClick={() => onChange(page)}
          aria-current={current === page ? 'page' : undefined}
        >
          {page}
        </button>
      ))}
      <button
        type="button"
        className="notice-pagination__next"
        onClick={() => onChange(Math.min(current + 1, total))}
        aria-label="다음 페이지"
        disabled={current === total}
      >
        <img
          src="/assets/icons/arrow_forward_ios.svg"
          alt=""
          aria-hidden="true"
          width={20}
          height={20}
        />
      </button>
    </nav>
  );
}

// ── Page ───────────────────────────────────────────────────────────────────
export default function MySupportFaqPage() {
  const [query, setQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState<FaqCategory>('수익 및 정산');
  const [expandedId, setExpandedId] = useState<number | null>(1);
  const [currentPage, setCurrentPage] = useState(1);

  const filtered = useMemo(() => {
    const byCategory = FAQS.filter((f) => f.category === activeCategory);
    if (!query.trim()) return byCategory;
    const q = query.toLowerCase();
    return byCategory.filter(
      (f) => f.question.toLowerCase().includes(q) || f.answer.toLowerCase().includes(q),
    );
  }, [activeCategory, query]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / ITEMS_PER_PAGE));
  const paginated = filtered.slice(
    (currentPage - 1) * ITEMS_PER_PAGE,
    currentPage * ITEMS_PER_PAGE,
  );

  function handleCategoryChange(category: FaqCategory) {
    setActiveCategory(category);
    setExpandedId(null);
    setCurrentPage(1);
  }

  function handleSearch(value: string) {
    setQuery(value);
    setExpandedId(null);
    setCurrentPage(1);
  }

  function toggleFaq(id: number) {
    setExpandedId((prev) => (prev === id ? null : id));
  }

  return (
    <div className="mypage-page">
      <ApplyGnb variant="simple" />
      <main className="mypage-main">
        <MySupportSidebar activeItemId="faq" />
        <div className="mypage-content">
          <div className="mypage-greeting">
            <h1 className="mypage-greeting__heading">FAQ</h1>
            <p className="mypage-greeting__sub">
              활동 중 궁금한 점이 생기셨나요? 파트너님이 가장 자주 묻는 질문과 답변을
              모아두었습니다.
            </p>
          </div>

          <div className="faq-filter">
            <div className="faq-search">
              <input
                type="search"
                className="faq-search__input"
                placeholder="검색어를 입력하세요"
                value={query}
                onChange={(e) => handleSearch(e.target.value)}
                aria-label="FAQ 검색"
              />
              <img
                src="/assets/icons/search.svg"
                alt=""
                aria-hidden="true"
                className="faq-search__icon"
              />
            </div>

            <div className="faq-chips" role="group" aria-label="카테고리 필터">
              {CATEGORIES.map((category) => (
                <button
                  key={category}
                  type="button"
                  className={`faq-chip${activeCategory === category ? ' faq-chip--active' : ''}`}
                  onClick={() => handleCategoryChange(category)}
                  aria-pressed={activeCategory === category}
                >
                  {category}
                </button>
              ))}
            </div>
          </div>

          <div className="notice-section">
            <ul className="notice-list">
              {paginated.length > 0 ? (
                paginated.map((item) => (
                  <FaqRow
                    key={item.id}
                    item={item}
                    isOpen={expandedId === item.id}
                    onToggle={() => toggleFaq(item.id)}
                  />
                ))
              ) : (
                <li style={{ padding: '24px 12px', color: '#737373', fontSize: '16px' }}>
                  검색 결과가 없습니다.
                </li>
              )}
            </ul>

            <Pagination current={currentPage} total={totalPages} onChange={setCurrentPage} />
          </div>
        </div>
      </main>
      <SiteFooter />
    </div>
  );
}
