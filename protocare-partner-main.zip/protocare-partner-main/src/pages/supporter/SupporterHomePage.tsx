import { useAuthStore } from '@/store/auth.store';
import { useSupporterProfile } from '@/hooks/useSupporter';
import { useCareApplicationList } from '@/hooks/useCareApplication';
import { PageHeader, Card, CardBody, ListStateView, Badge } from '@/components/ui';
import { ApplyGnb } from '@/components/apply/ApplyGnb';
import { MobileGnb } from '@/components/apply/MobileGnb';
import { SiteFooter } from '@/components/apply/SiteFooter';

export default function SupporterHomePage() {
  const user = useAuthStore((s) => s.user);
  const { data: profile } = useSupporterProfile();
  const { data: applications, isLoading, isError, refetch } = useCareApplicationList({ size: 5 });

  return (
    <div className="mypage-page">
      <MobileGnb />
      <ApplyGnb variant="simple" />
      <div className="flex flex-col gap-4 p-4">
        <PageHeader title="홈" />

        <Card>
          <CardBody>
            <p className="text-lg font-semibold">{user?.name ?? '서포터'}님, 안녕하세요</p>
            {profile && (
              <div className="mt-1">
                <Badge variant={profile.status === 'APPROVED' ? 'success' : 'warning'}>
                  {profile.status}
                </Badge>
              </div>
            )}
          </CardBody>
        </Card>

        <section>
          <h2 className="mb-2 font-semibold">최근 지원 현황</h2>
          <ListStateView
            isLoading={isLoading}
            isError={isError}
            isEmpty={!applications?.content.length}
            emptyTitle="지원 내역이 없습니다"
            onRetry={refetch}
          >
            {applications?.content.map((app) => (
              <Card key={app.id} className="mb-2">
                <CardBody className="flex items-center justify-between">
                  <span className="text-sm">케어요청 #{app.careRequestId}</span>
                  <Badge>{app.status}</Badge>
                </CardBody>
              </Card>
            ))}
          </ListStateView>
        </section>
      </div>
      <SiteFooter />
    </div>
  );
}
