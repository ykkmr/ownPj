import { useState } from 'react';
import { ApplyGnb } from '@/components/apply/ApplyGnb';
import { SiteFooter } from '@/components/apply/SiteFooter';
import { MySupportSidebar } from '@/components/supporter/MySupportSidebar';
import './MySupportSchedulePage.css';

// ── Types ──────────────────────────────────────────────────────────────────
type ScheduleStatus = 'matched' | 'matching' | 'completed';
type CareType = '어르신돌봄' | '아이돌봄' | '병원동행';

interface ScheduleDetail {
  id: string;
  careType: CareType;
  location: string;
  time: string;
  address: string;
  status: ScheduleStatus;
}

interface CalendarDay {
  date: number;
  isCurrentMonth: boolean;
}

// ── Mock data (May 2025) ───────────────────────────────────────────────────
const MOCK_BADGES: Record<number, ScheduleStatus[]> = {
  3: ['completed', 'completed'],
  6: ['completed'],
  7: ['completed'],
  9: ['completed'],
  10: ['completed'],
  11: ['completed', 'completed'],
  12: ['completed'],
  14: ['matched', 'matching'],
  15: ['matched'],
  16: ['matched', 'matched'],
  17: ['matched'],
  18: ['matched'],
  22: ['matched', 'matching'],
  24: ['matching', 'matched'],
  25: ['matching'],
  28: ['matching', 'matching'],
  30: ['matching'],
};

const MOCK_DETAILS: Record<number, ScheduleDetail[]> = {
  14: [
    {
      id: '1',
      careType: '어르신돌봄',
      location: '서울특별시 구로구',
      time: '오전 10:00 ~ 오후 6시 (8시간)',
      address: '서울특별시 구로구 고척로31길9 (개봉동)',
      status: 'matched',
    },
    {
      id: '2',
      careType: '아이돌봄',
      location: '서울특별시 구로구',
      time: '오후 6시 ~ 오후 8시 (2시간)',
      address: '서울특별시 구로구 고척로31길9 (개봉동)',
      status: 'matching',
    },
  ],
  15: [
    {
      id: '3',
      careType: '병원동행',
      location: '참나무요양병원',
      time: '오전 10:00 ~ 오후 1시 (3시간)',
      address: '서울특별시 구로구 고척로31길9 (개봉동)',
      status: 'matched',
    },
  ],
};

// ── Calendar utilities ─────────────────────────────────────────────────────
function getDaysInMonth(year: number, month: number): number {
  return new Date(year, month, 0).getDate();
}

function buildCalendarGrid(year: number, month: number): CalendarDay[][] {
  const firstDow = new Date(year, month - 1, 1).getDay(); // 0=Sun
  const daysInMonth = getDaysInMonth(year, month);
  const prevMonthDays = getDaysInMonth(year, month - 1);

  const cells: CalendarDay[] = [];
  for (let i = firstDow - 1; i >= 0; i--) {
    cells.push({ date: prevMonthDays - i, isCurrentMonth: false });
  }
  for (let d = 1; d <= daysInMonth; d++) {
    cells.push({ date: d, isCurrentMonth: true });
  }
  const totalCells = Math.ceil(cells.length / 7) * 7;
  let nextDay = 1;
  while (cells.length < totalCells) {
    cells.push({ date: nextDay++, isCurrentMonth: false });
  }

  const weeks: CalendarDay[][] = [];
  for (let i = 0; i < cells.length; i += 7) {
    weeks.push(cells.slice(i, i + 7));
  }
  return weeks;
}

// ── Config maps ────────────────────────────────────────────────────────────
const STATUS_LABEL: Record<ScheduleStatus, string> = {
  matched: '매칭 완료',
  matching: '매칭 중',
  completed: '활동 완료',
};

const CARE_TYPE_CONFIG: Record<CareType, { label: string; modifier: string }> = {
  어르신돌봄: { label: '어르신 돌봄', modifier: 'sched-care-badge--elderly' },
  아이돌봄: { label: '아이 돌봄', modifier: 'sched-care-badge--child' },
  병원동행: { label: '병원 동행', modifier: 'sched-care-badge--hospital' },
};

const DOW_LABELS = ['일', '월', '화', '수', '목', '금', '토'];
const DOW_COLORS = ['#d32f2f', '#121212', '#121212', '#121212', '#121212', '#121212', '#008cff'];

// ── Icons ──────────────────────────────────────────────────────────────────
function ClockIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="#737373" aria-hidden="true" className="sched-icon">
      <path d="M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm.5-13H11v6l5.25 3.15.75-1.23-4.5-2.67V7z" />
    </svg>
  );
}

function LocationIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="#737373" aria-hidden="true" className="sched-icon">
      <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z" />
    </svg>
  );
}

function ChevronBackIcon() {
  return (
    <img
      src="/assets/icons/chevron_backward.svg"
      alt=""
      aria-hidden="true"
      className="sched-chevron"
    />
  );
}

function ChevronNextIcon() {
  return (
    <img
      src="/assets/icons/chevron_forward.svg"
      alt=""
      aria-hidden="true"
      className="sched-chevron"
    />
  );
}

// ── CalendarCell ───────────────────────────────────────────────────────────
interface CalendarCellProps {
  day: CalendarDay;
  badges: ScheduleStatus[];
  isSelected: boolean;
  onClick: () => void;
}

function CalendarCell({ day, badges, isSelected, onClick }: CalendarCellProps) {
  const cellClass = [
    'sched-cell',
    isSelected && 'sched-cell--selected',
    !day.isCurrentMonth && 'sched-cell--other',
  ]
    .filter(Boolean)
    .join(' ');

  return (
    <div className={cellClass} onClick={day.isCurrentMonth ? onClick : undefined}>
      <span className="sched-cell__date">{day.date}</span>
      <div className="sched-cell__badges">
        {badges.slice(0, 2).map((status, i) => (
          <span key={i} className={`sched-cell-badge sched-cell-badge--${status}`}>
            {STATUS_LABEL[status]}
          </span>
        ))}
      </div>
    </div>
  );
}

// ── ScheduleDetailCard ─────────────────────────────────────────────────────
function ScheduleDetailCard({ detail }: { detail: ScheduleDetail }) {
  const careCfg = CARE_TYPE_CONFIG[detail.careType];
  return (
    <div className={`sched-detail-card sched-detail-card--${detail.status}`}>
      <div className="sched-detail-card__content">
        <div className="sched-detail-card__title-row">
          <span className={`sched-care-badge ${careCfg.modifier}`}>{careCfg.label}</span>
          <span className="sched-detail-card__location">{detail.location}</span>
        </div>
        <div className="sched-detail-card__info-row">
          <ClockIcon />
          <span className="sched-detail-card__info-text">{detail.time}</span>
        </div>
        <div className="sched-detail-card__info-row">
          <LocationIcon />
          <span className="sched-detail-card__info-text">{detail.address}</span>
        </div>
      </div>
      <span className={`sched-status-badge sched-status-badge--${detail.status}`}>
        {STATUS_LABEL[detail.status]}
      </span>
    </div>
  );
}

// ── Page root ──────────────────────────────────────────────────────────────
export default function MySupportSchedulePage() {
  const [year, setYear] = useState(2025);
  const [month, setMonth] = useState(5);
  const [selectedDay, setSelectedDay] = useState<number | null>(14);

  const weeks = buildCalendarGrid(year, month);

  function prevMonth() {
    if (month === 1) {
      setYear((y) => y - 1);
      setMonth(12);
    } else {
      setMonth((m) => m - 1);
    }
    setSelectedDay(null);
  }

  function nextMonth() {
    if (month === 12) {
      setYear((y) => y + 1);
      setMonth(1);
    } else {
      setMonth((m) => m + 1);
    }
    setSelectedDay(null);
  }

  const details = selectedDay !== null ? (MOCK_DETAILS[selectedDay] ?? []) : [];
  const detailTitle =
    selectedDay !== null
      ? (() => {
          const d = new Date(year, month - 1, selectedDay);
          return `${month}월 ${selectedDay}일 (${DOW_LABELS[d.getDay()]}) 상세 일정`;
        })()
      : null;

  return (
    <div className="mypage-page">
      <ApplyGnb variant="simple" />
      <main className="mypage-main">
        <MySupportSidebar activeItemId="schedule" />
        <div className="mypage-content">
          <div className="mypage-greeting">
            <h1 className="mypage-greeting__heading">일정 관리</h1>
            <p className="mypage-greeting__sub">다가오는 돌봄 일정과 매칭 상태를 확인하세요.</p>
          </div>

          <div className="sched-section">
            <div className="sched-calendar">
              <div className="sched-calendar__header">
                <span className="sched-calendar__month-label">
                  {year}년 {month}월
                </span>
                <div className="sched-calendar__nav">
                  <button
                    type="button"
                    className="sched-calendar__nav-btn"
                    onClick={prevMonth}
                    aria-label="이전 달"
                  >
                    <ChevronBackIcon />
                  </button>
                  <button
                    type="button"
                    className="sched-calendar__nav-btn"
                    onClick={nextMonth}
                    aria-label="다음 달"
                  >
                    <ChevronNextIcon />
                  </button>
                </div>
              </div>

              <div className="sched-calendar__legend">
                <span className="sched-legend-badge sched-legend-badge--matched">매칭 완료</span>
                <span className="sched-legend-badge sched-legend-badge--matching">매칭 중</span>
                <span className="sched-legend-badge sched-legend-badge--completed">활동 완료</span>
              </div>

              <div className="sched-calendar__weekdays">
                {DOW_LABELS.map((label, i) => (
                  <div key={label} className="sched-weekday" style={{ color: DOW_COLORS[i] }}>
                    {label}
                  </div>
                ))}
              </div>

              <div className="sched-calendar__grid">
                {weeks.map((week, wi) => (
                  <div key={wi} className="sched-calendar__week">
                    {week.map((day, di) => {
                      const badges = day.isCurrentMonth ? (MOCK_BADGES[day.date] ?? []) : [];
                      const isSelected = day.isCurrentMonth && day.date === selectedDay;
                      return (
                        <CalendarCell
                          key={`${wi}-${di}`}
                          day={day}
                          badges={badges}
                          isSelected={isSelected}
                          onClick={() => setSelectedDay(day.date)}
                        />
                      );
                    })}
                  </div>
                ))}
              </div>
            </div>

            {selectedDay !== null && (
              <div className="sched-detail">
                <h2 className="sched-detail__title">{detailTitle}</h2>
                {details.length > 0 ? (
                  details.map((d) => <ScheduleDetailCard key={d.id} detail={d} />)
                ) : (
                  <p className="sched-detail__empty">이 날의 일정이 없습니다.</p>
                )}
              </div>
            )}
          </div>
        </div>
      </main>
      <SiteFooter />
    </div>
  );
}
