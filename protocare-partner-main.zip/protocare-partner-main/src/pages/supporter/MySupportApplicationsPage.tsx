import { useRef, useState } from 'react';
import { ApplyGnb } from '@/components/apply/ApplyGnb';
import { SiteFooter } from '@/components/apply/SiteFooter';
import { MySupportSidebar } from '@/components/supporter/MySupportSidebar';
import { PhotoUploadModal } from '@/components/supporter/PhotoUploadModal';
import './MySupportApplicationsPage.css';

// ── Types ──────────────────────────────────────────────────────────────────
type Gender = 'male' | 'female';
type ConsentOption = 'agree' | 'disagree';

// ── Icon ───────────────────────────────────────────────────────────────────
function IconAddPhoto() {
  return (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="#a4a4a4" aria-hidden="true">
      <path d="M19 7v2.99s-1.99.01-2 0V7h-3s.01-1.99 0-2h3V2h2v3h3v2h-3zm-3 4V8h-3V5H5C3.9 5 3 5.9 3 7v12c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2v-8h-3zM5 19l3-4 2 3 3-4 4 5H5z" />
    </svg>
  );
}

// ── Sub-components ─────────────────────────────────────────────────────────
function RequiredLabel({ children }: { children: string }) {
  return (
    <div className="app-field__label-row">
      <span className="app-field__required-star">*</span>
      <span className="app-field__label-text">{children}</span>
    </div>
  );
}

function OptionalLabel({ children }: { children: string }) {
  return <p className="app-field__label-text">{children}</p>;
}

interface ChipProps {
  label: string;
  active: boolean;
  onClick: () => void;
}

function Chip({ label, active, onClick }: ChipProps) {
  return (
    <button
      type="button"
      className={`app-chip${active ? ' app-chip--active' : ''}`}
      onClick={onClick}
    >
      {label}
    </button>
  );
}

interface FileUploadAreaProps {
  onFileSelect: (file: File) => void;
  selectedFileName?: string;
}

function FileUploadArea({ onFileSelect, selectedFileName }: FileUploadAreaProps) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [isDragOver, setIsDragOver] = useState(false);

  function handleDrop(e: React.DragEvent) {
    e.preventDefault();
    setIsDragOver(false);
    const file = e.dataTransfer.files[0];
    if (file) onFileSelect(file);
  }

  return (
    <div
      className={`app-upload-area${isDragOver ? ' app-upload-area--over' : ''}`}
      role="button"
      tabIndex={0}
      onClick={() => inputRef.current?.click()}
      onKeyDown={(e) => e.key === 'Enter' && inputRef.current?.click()}
      onDragOver={(e) => {
        e.preventDefault();
        setIsDragOver(true);
      }}
      onDragLeave={() => setIsDragOver(false)}
      onDrop={handleDrop}
    >
      <span className="app-upload-area__icon-circle">
        <IconAddPhoto />
      </span>
      {selectedFileName ? (
        <span className="app-upload-area__filename">{selectedFileName}</span>
      ) : (
        <span className="app-upload-area__hints">
          <span className="app-upload-area__click-text">클릭하여 파일 선택</span>
          <span className="app-upload-area__drag-text">또는 파일을 이곳으로 드래그하세요</span>
        </span>
      )}
      <input
        ref={inputRef}
        type="file"
        accept="image/*,.pdf"
        className="app-upload-area__input"
        onChange={(e) => {
          const file = e.target.files?.[0];
          if (file) onFileSelect(file);
        }}
        onClick={(e) => e.stopPropagation()}
      />
    </div>
  );
}

// ── Chip option data ───────────────────────────────────────────────────────
const Q1_OPTIONS = [
  '병원 동행 경험',
  '어르신 돌봄 경험',
  '아이 돌봄 경험',
  '가족/보호자 케어 경험',
  '관련직 경력 보유',
  '관련 경험 없음',
];
const Q2_OPTIONS = [
  '차분하고 안정적인 편',
  '밝고 활발한 편',
  '대화를 잘 이끄는 편',
  '조용히 함께하는 편',
  '세심하게 살피는 편',
];
const Q3_OPTIONS = ['병원 동행', '어르신 돌봄', '아이돌봄'];
const Q4_OPTIONS = [
  '당일/긴급 요청 가능',
  '야간 활동 가능',
  '장거리 이동 가능',
  '장시간 케어 가능',
  '수화 가능',
];

// ── Page ───────────────────────────────────────────────────────────────────
export default function MySupportApplicationsPage() {
  const [gender, setGender] = useState<Gender>('female');
  const [q1Selected, setQ1Selected] = useState<Set<string>>(new Set(['어르신 돌봄 경험']));
  const [q2Selected, setQ2Selected] = useState<string>('밝고 활발한 편');
  const [q3Selected, setQ3Selected] = useState<Set<string>>(new Set());
  const [q4Selected, setQ4Selected] = useState<Set<string>>(new Set());
  const [consent, setConsent] = useState<ConsentOption | null>(null);
  const [profileImageUrl, setProfileImageUrl] = useState<string | null>(null);
  const [showPhotoModal, setShowPhotoModal] = useState(false);
  const [certFile, setCertFile] = useState<File | null>(null);
  const [criminalFile, setCriminalFile] = useState<File | null>(null);

  function toggleSet(set: Set<string>, value: string): Set<string> {
    const next = new Set(set);
    if (next.has(value)) next.delete(value);
    else next.add(value);
    return next;
  }

  function handlePhotoUpload(file: File) {
    setProfileImageUrl(URL.createObjectURL(file));
  }

  return (
    <div className="mypage-page">
      <ApplyGnb variant="simple" />
      <main className="mypage-main">
        <MySupportSidebar activeItemId="applications" />
        <div className="mypage-content">
          <div className="mypage-greeting">
            <h1 className="mypage-greeting__heading">지원서 관리</h1>
            <p className="mypage-greeting__sub">
              나를 소개하는 첫인상, 지원서를 꼼꼼히 채울수록 사용자들의 선택을 받을 확률이
              높아집니다.
            </p>
          </div>

          <div className="app-form">
            {/* ── 필수 정보 입력 ── */}
            <div className="app-required-section">
              <h2 className="app-section__title">필수 정보 입력</h2>

              <div className="app-field app-field--344">
                <RequiredLabel>성함</RequiredLabel>
                <input type="text" className="app-field__input" defaultValue="김이나" />
              </div>

              <div className="app-field app-field--344">
                <RequiredLabel>생년월일</RequiredLabel>
                <input type="text" className="app-field__input" defaultValue="2000.10.10" />
              </div>

              <div className="app-field">
                <RequiredLabel>성별</RequiredLabel>
                <div className="app-chip-group">
                  <Chip label="남자" active={gender === 'male'} onClick={() => setGender('male')} />
                  <Chip
                    label="여자"
                    active={gender === 'female'}
                    onClick={() => setGender('female')}
                  />
                </div>
              </div>

              <div className="app-field app-field--702">
                <RequiredLabel>활동지역</RequiredLabel>
                <div className="app-region-row">
                  <select className="app-select" defaultValue="강서구">
                    <option>강서구</option>
                  </select>
                  <select className="app-select" defaultValue="공항동">
                    <option>공항동</option>
                  </select>
                </div>
              </div>

              <div className="app-field">
                <OptionalLabel>프로필 이미지</OptionalLabel>
                <div className="app-profile-area">
                  <div className="app-profile-img-wrap">
                    {profileImageUrl ? (
                      <img src={profileImageUrl} alt="프로필 이미지" className="app-profile-img" />
                    ) : (
                      <div className="app-profile-img app-profile-img--placeholder" />
                    )}
                  </div>
                  <button
                    type="button"
                    className="app-profile-upload-btn"
                    onClick={() => setShowPhotoModal(true)}
                  >
                    사진 업로드
                  </button>
                </div>
              </div>

              <div className="app-field app-field--484">
                <RequiredLabel>한 줄 소개</RequiredLabel>
                <input
                  type="text"
                  className="app-field__input"
                  defaultValue="경험은 없지만 성실하게 배우며 책임감 있게 활동하겠습니다"
                />
              </div>
            </div>

            <hr className="app-section-divider" />

            {/* ── 케어 성향 ── */}
            <div className="app-section">
              <h2 className="app-section__title">케어 성향</h2>
              <div className="app-tendency-fields">
                <div className="app-field">
                  <RequiredLabel>Q1. 어떤 돌봄 경험이 있으신가요?</RequiredLabel>
                  <div className="app-chip-group">
                    {Q1_OPTIONS.map((opt) => (
                      <Chip
                        key={opt}
                        label={opt}
                        active={q1Selected.has(opt)}
                        onClick={() => setQ1Selected(toggleSet(q1Selected, opt))}
                      />
                    ))}
                  </div>
                </div>

                <div className="app-field">
                  <RequiredLabel>Q2. 어떤 방식으로 케어하는 편이신가요?</RequiredLabel>
                  <div className="app-chip-group">
                    {Q2_OPTIONS.map((opt) => (
                      <Chip
                        key={opt}
                        label={opt}
                        active={q2Selected === opt}
                        onClick={() => setQ2Selected(opt)}
                      />
                    ))}
                  </div>
                </div>

                <div className="app-field">
                  <RequiredLabel>Q3. 어떤 활동을 선호하시나요? (복수 선택 가능)</RequiredLabel>
                  <div className="app-chip-group">
                    {Q3_OPTIONS.map((opt) => (
                      <Chip
                        key={opt}
                        label={opt}
                        active={q3Selected.has(opt)}
                        onClick={() => setQ3Selected(toggleSet(q3Selected, opt))}
                      />
                    ))}
                  </div>
                </div>

                <div className="app-field">
                  <OptionalLabel>Q4. 특수 조건의 활동이 가능하신가요?</OptionalLabel>
                  <div className="app-chip-group">
                    {Q4_OPTIONS.map((opt) => (
                      <Chip
                        key={opt}
                        label={opt}
                        active={q4Selected.has(opt)}
                        onClick={() => setQ4Selected(toggleSet(q4Selected, opt))}
                      />
                    ))}
                  </div>
                </div>
              </div>
            </div>

            <hr className="app-section-divider" />

            {/* ── 자격 검증 ── */}
            <div className="app-section">
              <h2 className="app-section__title">자격 검증</h2>
              <div className="app-tendency-fields">
                <div className="app-field">
                  <OptionalLabel>자격증 검증 (선택)</OptionalLabel>
                  <FileUploadArea onFileSelect={setCertFile} selectedFileName={certFile?.name} />
                </div>

                <div className="app-field">
                  <div className="app-field__label-col">
                    <OptionalLabel>범죄 경력 회보서 (선택)</OptionalLabel>
                    <p className="app-field__description">
                      이용자와 보호자에게 더 높은 신뢰를 제공하기 위해 범죄 경력 회보서를 제출하실
                      수 있습니다.
                      <br />
                      제출시 프로필에 '안심 서포터' 배지가 부여됩니다.
                    </p>
                  </div>
                  <FileUploadArea
                    onFileSelect={setCriminalFile}
                    selectedFileName={criminalFile?.name}
                  />
                </div>

                <div className="app-field">
                  <div className="app-field__label-col">
                    <OptionalLabel>성범죄 이력 조회 동의 (선택)</OptionalLabel>
                    <p className="app-field__description">
                      이용자와 보호자에게 더 높은 신뢰를 제공하기 위해 성범죄 이력 조회에 동의하실
                      수 있습니다.
                      <br />
                      제출시 프로필에 '안심 서포터' 배지가 부여됩니다.
                    </p>
                  </div>
                  <div className="app-radio-group">
                    <label className="app-radio-option">
                      <input
                        type="radio"
                        name="consent"
                        value="agree"
                        checked={consent === 'agree'}
                        onChange={() => setConsent('agree')}
                        className="app-radio-option__input"
                      />
                      <span className="app-radio-option__label">동의합니다</span>
                    </label>
                    <label className="app-radio-option">
                      <input
                        type="radio"
                        name="consent"
                        value="disagree"
                        checked={consent === 'disagree'}
                        onChange={() => setConsent('disagree')}
                        className="app-radio-option__input"
                      />
                      <span className="app-radio-option__label">동의하지 않습니다</span>
                    </label>
                  </div>
                </div>
              </div>
            </div>

            {/* ── 하단 버튼 ── */}
            <div className="app-actions">
              <button type="button" className="app-actions__btn app-actions__btn--secondary">
                미리보기
              </button>
              <button type="button" className="app-actions__btn app-actions__btn--primary">
                수정 완료
              </button>
            </div>
          </div>
        </div>
      </main>
      <SiteFooter />

      {showPhotoModal && (
        <PhotoUploadModal onUpload={handlePhotoUpload} onClose={() => setShowPhotoModal(false)} />
      )}
    </div>
  );
}
