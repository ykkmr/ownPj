import { useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useCareLogs, useCreateCareLog } from '@/hooks/useMatching';
import { PageHeader, Card, CardBody, ListStateView, Button, Textarea } from '@/components/ui';
import { ApplyGnb } from '@/components/apply/ApplyGnb';
import { MobileGnb } from '@/components/apply/MobileGnb';
import { SiteFooter } from '@/components/apply/SiteFooter';
import type { CareLogType } from '@/types';

const LOG_TYPES: { value: CareLogType; label: string }[] = [
  { value: 'MEAL', label: '식사' },
  { value: 'BATH', label: '목욕' },
  { value: 'PHOTO', label: '사진' },
  { value: 'MEMO', label: '메모' },
  { value: 'OTHER', label: '기타' },
];

export default function CareLogPage() {
  const navigate = useNavigate();
  const { id } = useParams<{ id: string }>();
  const matchingId = Number(id);

  const { data, isLoading, isError, refetch } = useCareLogs(matchingId);
  const createLog = useCreateCareLog(matchingId);

  const [type, setType] = useState<CareLogType>('MEMO');
  const [content, setContent] = useState('');

  const handleSubmit = () => {
    if (!content.trim()) return;
    createLog.mutate({ type, content }, { onSuccess: () => setContent('') });
  };

  return (
    <div className="mypage-page">
      <MobileGnb />
      <ApplyGnb variant="simple" />
      <div className="flex flex-col">
        <PageHeader title="케어 기록" showBack onBack={() => navigate(-1)} />

        <div className="flex flex-col gap-4 p-4">
          <Card>
            <CardBody className="flex flex-col gap-3">
              <p className="font-semibold">기록 추가</p>
              <div className="flex flex-wrap gap-2">
                {LOG_TYPES.map((t) => (
                  <button
                    key={t.value}
                    type="button"
                    onClick={() => setType(t.value)}
                    className={`rounded-full px-3 py-1 text-sm ${
                      type === t.value ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-600'
                    }`}
                  >
                    {t.label}
                  </button>
                ))}
              </div>
              <Textarea
                value={content}
                onChange={(e) => setContent(e.target.value)}
                placeholder="케어 내용을 입력하세요"
                rows={3}
              />
              <Button onClick={handleSubmit} disabled={createLog.isPending || !content.trim()}>
                등록
              </Button>
            </CardBody>
          </Card>

          <section>
            <p className="mb-2 font-semibold">기록 목록</p>
            <ListStateView
              isLoading={isLoading}
              isError={isError}
              isEmpty={!data?.content.length}
              emptyTitle="기록이 없습니다"
              onRetry={refetch}
            >
              <div className="flex flex-col gap-2">
                {data?.content.map((log) => (
                  <Card key={log.id}>
                    <CardBody>
                      <div className="flex items-start justify-between">
                        <div>
                          <span className="text-xs font-medium text-blue-600">{log.type}</span>
                          <p className="mt-1 text-sm">{log.content}</p>
                        </div>
                        <span className="text-xs text-gray-400">
                          {log.recordedAt.slice(11, 16)}
                        </span>
                      </div>
                    </CardBody>
                  </Card>
                ))}
              </div>
            </ListStateView>
          </section>
        </div>
      </div>
      <SiteFooter />
    </div>
  );
}
