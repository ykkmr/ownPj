import { Fragment } from 'react';
import { useNavigate } from 'react-router-dom';
import { PublicGnb } from '@/components/common/PublicGnb';
import './OnboardingPage.css';

const ASSETS = {
  social1: '/assets/icons/Social link 1.svg',
  social2: '/assets/icons/Social link 2.svg',
  social3: '/assets/icons/Social link 3.svg',
  heroLogin: '/assets/icons/image 53.png',
  heroSignup: '/assets/icons/image 52.png',
  timeIcon: '/assets/icons/time.png',
  moneyIcon: '/assets/icons/stack of money.png',
  rocketIcon: '/assets/icons/rocket.png',
  hospitalCare: 'https://www.figma.com/api/mcp/asset/0ae14a21-69d6-4c46-8fc9-345ec77b300b',
  elderlyCare: 'https://www.figma.com/api/mcp/asset/0cda1bde-158c-4c5c-8211-d8a3699a88d9',
  childCare: 'https://www.figma.com/api/mcp/asset/6ebcaa98-08bf-4505-aa6f-28c81fbf26df',
  interviewThumb: 'https://www.figma.com/api/mcp/asset/faf9d808-3d45-4bcd-affd-3ade071be62c',
} as const;

type GoalCard = { icon: string; title: string; description: string };
type ServiceRow = {
  image: string;
  imageAlt: string;
  title: string;
  summary: string;
  detail: string;
  reversed: boolean;
};
type InterviewCard = { date: string; title: string; body: string };
type FooterNavColumn = { heading: string; items: string[] };

const GOAL_CARDS: GoalCard[] = [
  {
    icon: ASSETS.timeIcon,
    title: '유연한 활동',
    description: '내가 원하는 시간과 장소에서 자유롭게 케어 일정을 관리합니다.',
  },
  {
    icon: ASSETS.moneyIcon,
    title: '합당한 보상',
    description: '전문성에 걸맞은 안정적인 수익과 투명한 정산 시스템을 제공합니다.',
  },
  {
    icon: ASSETS.rocketIcon,
    title: '성장의 기회',
    description: '단순한 일을 넘어, 누군가의 삶에 기여하며 케어 전문가로 성장합니다.',
  },
];

const SERVICE_ROWS: ServiceRow[] = [
  {
    image: ASSETS.hospitalCare,
    imageAlt: '병원 동행 서비스',
    title: '병원 동행',
    summary:
      '단순한 이동 지원을 넘어, 보호자의 눈과 귀가 되어 진료 과정을 꼼꼼하게 기록하고 전달하는 전문적인 역할을 수행합니다.',
    detail: '접수 및 수납 대행, 진료 시 의사 소견 메모, 처방전 수령 및 약국 동행, 자택 귀가 안내',
    reversed: false,
  },
  {
    image: ASSETS.elderlyCare,
    imageAlt: '어르신 돌봄 서비스',
    title: '어르신 돌봄',
    summary:
      '어르신의 소중한 일상을 지키는 동반자로서, 전문적인 케어 스킬을 통해 가족의 빈자리를 든든하게 채우는 가치 있는 활동입니다.',
    detail: '식사 보조 및 투약 확인, 산책 동행, 인지 활동 지원, 건강 상태 모니터링 기록',
    reversed: true,
  },
  {
    image: ASSETS.childCare,
    imageAlt: '아이 돌봄 서비스',
    title: '아이 돌봄',
    summary:
      '아이의 눈높이에서 안전하게 소통하며, 부모님이 안심하고 일상에 집중할 수 있도록 아이의 성장 시간을 함께 책임집니다.',
    detail: '등하원 지도, 실내 놀이 및 독서 활동, 간식 챙기기, 아이의 활동 피드백 작성',
    reversed: false,
  },
];

const INTERVIEW_CARDS: InterviewCard[] = [
  {
    date: '2025.12.16',
    title: '은퇴 후 찾은 제2의 월급, 매일 뿌듯함을 느낍니다.',
    body: '평범한 전업주부에서 월 150만 원 수익을 올리는 베테랑 서포터가 된 김지영 님. 그녀가 말하는 ProtoCare만의 매칭 시스템과 수익 노하우를 공개합니다.',
  },
  {
    date: '2025.12.16',
    title: '은퇴 후 찾은 제2의 월급, 매일 뿌듯함을 느낍니다.',
    body: '평범한 전업주부에서 월 150만 원 수익을 올리는 베테랑 서포터가 된 김지영 님. 그녀가 말하는 ProtoCare만의 매칭 시스템과 수익 노하우를 공개합니다.',
  },
  {
    date: '2025.12.16',
    title: '은퇴 후 찾은 제2의 월급, 매일 뿌듯함을 느낍니다.',
    body: '평범한 전업주부에서 월 150만 원 수익을 올리는 베테랑 서포터가 된 김지영 님. 그녀가 말하는 ProtoCare만의 매칭 시스템과 수익 노하우를 공개합니다.',
  },
];

const FOOTER_NAV: FooterNavColumn[] = [
  {
    heading: '서비스 소개',
    items: ['분야별 소개', '수익 구조와 혜택', '서포터들의 이야기'],
  },
  { heading: '지원 가이드', items: ['등록 절차', '지원 자격 요건'] },
  { heading: '케어 활동 찾기', items: ['케어 활동 찾기'] },
  { heading: '마이 서포트', items: ['케어 관리', '계정 설정', '고객센터'] },
];

function HeroSection() {
  const navigate = useNavigate();

  return (
    <section className="hero">
      <div className="hero__banner" aria-hidden="true" />
      <div className="hero__panels">
        <div
          className="hero__panel hero__panel--login"
          onClick={() => navigate('/login')}
          role="button"
          tabIndex={0}
        >
          <div className="hero__text-group">
            <p className="hero__eyebrow hero__eyebrow--green">이미 활동 중이신가요?</p>
            <h1 className="hero__title hero__title--desktop">오늘도 이어가는 따뜻한 케어</h1>
            <p className="hero__title hero__title--mobile">서포트 모드로 가기</p>
            <p className="hero__subtitle">
              기다리고 있는 새로운 요청을 확인하고
              <br />
              파트너님의 가치를 증명하세요.
            </p>
          </div>
          <button
            className="hero__cta hero__cta--green"
            onClick={(e) => {
              e.stopPropagation();
              navigate('/login');
            }}
          >
            서포터 로그인 →
          </button>
          <div className="hero__ellipse" aria-hidden="true" />
          <div className="hero__person hero__person--login">
            <img src={ASSETS.heroLogin} alt="활동 중인 서포터" />
          </div>
        </div>

        <div
          className="hero__panel hero__panel--signup"
          onClick={() => navigate('/supporter/apply')}
          role="button"
          tabIndex={0}
        >
          <div className="hero__text-group">
            <p className="hero__eyebrow hero__eyebrow--orange">처음이신가요?</p>
            <h1 className="hero__title hero__title--desktop">바로 시작할 수 있는 케어 활동</h1>
            <p className="hero__title hero__title--mobile">서포터 지원하기</p>
            <p className="hero__subtitle">
              유연한 일정으로 원하는 만큼
              <br />
              수익과 보람을 동시에 얻으세요.
            </p>
          </div>
          <button
            className="hero__cta hero__cta--orange"
            onClick={(e) => {
              e.stopPropagation();
              navigate('/supporter/apply');
            }}
          >
            서포터 시작하기 →
          </button>
          <div className="hero__ellipse" aria-hidden="true" />
          <div className="hero__person hero__person--signup">
            <img src={ASSETS.heroSignup} alt="새로운 서포터" />
          </div>
        </div>
      </div>
    </section>
  );
}

function ServiceOverview() {
  return (
    <section className="service-overview">
      <p className="section-tag">Service Overview</p>
      <h2 className="section-title-lg">비어있는 일상을 채우는 든든한 파트너</h2>
      <p className="section-body">
        원하는 시간에 병원동행·돌봄 활동을 하며 의미 있는 경험과 수익을 만들 수 있습니다
      </p>
    </section>
  );
}

function GoalSection() {
  return (
    <section className="goal-section">
      <div className="goal-section__header">
        <p className="section-tag">Goal</p>
        <h2 className="section-title-md">
          신뢰를 더하는 전문성으로,
          <br />
          케어의 새로운 기준을 만듭니다
        </h2>
      </div>

      <div className="goal-cards">
        {GOAL_CARDS.map((card, index) => (
          <Fragment key={card.title}>
            {index > 0 && (
              <span className="goal-separator" aria-hidden="true">
                +
              </span>
            )}
            <div className="goal-card">
              <div className="goal-card__icon">
                <img src={card.icon} alt="" />
              </div>
              <div className="goal-card__text">
                <p className="goal-card__title">{card.title}</p>
                <p className="goal-card__desc">{card.description}</p>
              </div>
            </div>
          </Fragment>
        ))}
      </div>
    </section>
  );
}

function ServicesSection() {
  return (
    <section className="services-section">
      <div className="services-section__header">
        <p className="section-tag">Services</p>
        <h2 className="section-title-md">일상 속 돌봄 서비스 3가지</h2>
      </div>

      {SERVICE_ROWS.map((service) => (
        <div
          key={service.title}
          className={`service-row${service.reversed ? ' service-row--alt' : ''}`}
        >
          {service.reversed ? (
            <>
              <div className="service-row__text">
                <h3 className="service-row__title">{service.title}</h3>
                <p className="service-row__desc">{service.summary}</p>
                <p className="service-row__desc">{service.detail}</p>
              </div>
              <img src={service.image} alt={service.imageAlt} className="service-row__image" />
            </>
          ) : (
            <>
              <img src={service.image} alt={service.imageAlt} className="service-row__image" />
              <div className="service-row__text">
                <h3 className="service-row__title">{service.title}</h3>
                <p className="service-row__desc">{service.summary}</p>
                <p className="service-row__desc">{service.detail}</p>
              </div>
            </>
          )}
        </div>
      ))}
    </section>
  );
}

function EarningsSection() {
  return (
    <section className="earnings-section">
      <div className="earnings-section__header">
        <p className="section-tag">Earnings</p>
        <h2 className="section-title-md">수익 구조와 혜택</h2>
      </div>
      <div className="earnings-placeholder" />
    </section>
  );
}

function StoriesSection() {
  return (
    <section className="stories-section">
      <div className="stories-section__header">
        <p className="section-tag">Stories</p>
        <h2 className="section-title-md">서포터들의 이야기</h2>
      </div>
      <div className="interview-cards">
        {INTERVIEW_CARDS.map((card, i) => (
          <article key={i} className="interview-card">
            <img
              src={ASSETS.interviewThumb}
              alt="서포터 인터뷰"
              className="interview-card__thumb"
            />
            <div className="interview-card__meta">
              <span className="interview-card__label">서포터 인터뷰</span>
              <span className="interview-card__date">{card.date}</span>
            </div>
            <p className="interview-card__title">{card.title}</p>
            <p className="interview-card__body">{card.body}</p>
          </article>
        ))}
      </div>
      <button type="button" className="more-btn">
        더보기
      </button>
    </section>
  );
}

function Footer() {
  return (
    <footer className="footer">
      <div className="footer__inner">
        <div className="footer__brand">
          <div className="footer__info">
            <div className="footer__logo" aria-label="ProtoCare 로고" />
            <address className="footer__address">
              {
                '(주)프로토타이\n서울시 강남구 역삼로 114 현죽빌딩 8층\n\n대표 : 박승현\n사업자등록번호 : 589-86-03334\n통신판매업신고번호 : 제2025-서울강남-03320호'
              }
            </address>
            <div className="footer__links">
              <button type="button" className="footer__link">
                개인정보 처리방침
              </button>
              <button type="button" className="footer__link">
                이용약관
              </button>
              <button type="button" className="footer__link">
                공지사항
              </button>
            </div>
          </div>

          <nav className="footer__socials" aria-label="소셜 미디어">
            <button type="button" className="footer__social-btn" aria-label="Instagram">
              <img src={ASSETS.social1} alt="" />
            </button>
            <button type="button" className="footer__social-btn" aria-label="LinkedIn">
              <img src={ASSETS.social2} alt="" />
            </button>
            <button type="button" className="footer__social-btn" aria-label="X (Twitter)">
              <img src={ASSETS.social3} alt="" />
            </button>
          </nav>
        </div>

        <nav className="footer__nav" aria-label="푸터 네비게이션">
          {FOOTER_NAV.map((col) => (
            <div key={col.heading} className="footer__nav-col">
              <p className="footer__nav-heading">{col.heading}</p>
              {col.items.map((item) => (
                <button key={item} type="button" className="footer__nav-item">
                  {item}
                </button>
              ))}
            </div>
          ))}
        </nav>
      </div>
    </footer>
  );
}

export default function OnboardingPage() {
  return (
    <div className="onboarding-page">
      <PublicGnb />
      <HeroSection />
      <ServiceOverview />
      <GoalSection />
      <ServicesSection />
      <EarningsSection />
      <StoriesSection />
      <Footer />
    </div>
  );
}
