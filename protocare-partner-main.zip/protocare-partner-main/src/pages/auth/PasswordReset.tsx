import { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { FormField, Input, Button } from '@/components/ui';
import { PublicGnb } from '@/components/common/PublicGnb'; 
import { SiteFooter } from '@/components/apply/SiteFooter'; 

export const PasswordReset = () => {
  const navigate = useNavigate();
  const location = useLocation();

  // 이전 단계에서 넘어온 아이디 (없으면 예시 아이디)
  const userId = location.state?.userId || 'User260101';
  const MINT_COLOR = '#47c7ac';

  const [form, setForm] = useState({
    newPassword: '',
    confirmPassword: '',
  });

  const handleReset = () => {
    if (!form.newPassword || form.newPassword !== form.confirmPassword) {
      alert('비밀번호가 일치하지 않습니다.');
      return;
    }
    console.log('비밀번호 변경 시도:', form);
    // 성공 후 처리 로직...
  };

  return (
    <div className="min-h-screen flex flex-col bg-white">
      {/* 1. 상단 GNB (모바일/PC 대응) */}
      <PublicGnb />

      <main className="flex-1 max-w-3xl mx-auto w-full px-6 py-12 md:py-24">
        
        {/* 중앙 타이틀 세션 */}
        <div className="text-center mb-10 md:mb-12 border-b border-gray-100 pb-8 md:pb-10">
          <h1 className="text-[22px] md:text-[28px] font-bold text-gray-900 mb-3">
            비밀번호 재설정
          </h1>
          <p className="text-[14px] md:text-[15px] text-gray-400">
            안전한 서비스 이용을 위해 새 비밀번호를 입력해 주세요.
          </p>
        </div>

        {/* 재설정 폼 (중앙 정렬) */}
        <div className="max-w-md mx-auto space-y-6 md:space-y-8">
          
          {/* 아이디 표시 (수정 불가) */}
          <FormField label="아이디" className="font-bold text-gray-900 text-[14px] md:text-[15px]">
            <div className="w-full h-[52px] md:h-[54px] px-4 flex items-center border border-gray-200 rounded-lg bg-white text-gray-900 font-bold text-[15px]">
              {userId}
            </div>
          </FormField>

          {/* 새 비밀번호 입력 */}
          <FormField label="비밀번호" className="font-bold text-gray-900 text-[14px] md:text-[15px]">
            <Input
              type="password"
              placeholder="비밀번호 입력"
              value={form.newPassword}
              onChange={(e) => setForm({ ...form, newPassword: e.target.value })}
              className="h-[52px] md:h-[54px] border-gray-200 rounded-lg"
            />
          </FormField>

          {/* 새 비밀번호 확인 */}
          <FormField label="새 비밀번호 확인" className="font-bold text-gray-900 text-[14px] md:text-[15px]">
            <Input
              type="password"
              placeholder="비밀번호 재입력"
              value={form.confirmPassword}
              onChange={(e) => setForm({ ...form, confirmPassword: e.target.value })}
              className="h-[52px] md:h-[54px] border-gray-200 rounded-lg"
            />
          </FormField>

          {/* 반응형 버튼 레이아웃 */}
          {/* 모바일(기본): flex-col (변경이 위로) / PC(md 이상): flex-row-reverse (가로 배치, 변경이 오른쪽) */}
          <div className="flex flex-col md:flex-row-reverse gap-3 md:gap-4 pt-6">
            
            {/* 변경 버튼 (모바일: 위 / PC: 오른쪽) */}
            <Button
              onClick={handleReset}
              className="w-full md:flex-1 h-[54px] text-white font-bold rounded-lg border-none"
              style={{ backgroundColor: MINT_COLOR }}
            >
              변경
            </Button>

            {/* 취소 버튼 (모바일: 아래 / PC: 왼쪽) */}
            <Button
              onClick={() => navigate(-1)}
              className="w-full md:flex-1 h-[54px] bg-white font-bold rounded-lg border"
              style={{ borderColor: MINT_COLOR, color: MINT_COLOR }}
            >
              취소
            </Button>
            
          </div>

        </div>
      </main>

      <SiteFooter />
    </div>
  );
};