import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { FormField, Input, Button } from '@/components/ui';
import { PublicGnb } from '@/components/common/PublicGnb';
import { SiteFooter } from '@/components/apply/SiteFooter';

export const FindAccount = () => {
  const navigate = useNavigate();
  // 모바일 전용 탭 상태 ('id' 또는 'password')
  const [activeTab, setActiveTab] = useState<'id' | 'password'>('id');

  // 폼 상태 관리
  const [idForm, setIdForm] = useState({ phone: '', name: '' });
  const [pwForm, setPwForm] = useState({ email: '', phone: '', name: '' });

  const MINT_COLOR = '#47c7ac';

  return (
    <div className="min-h-screen flex flex-col bg-white">
      <PublicGnb />

      <main className="flex-1 max-w-6xl mx-auto w-full px-6 py-10 md:py-20">
        {/* 상단 타이틀 세션 */}
        <div className="text-center mb-10 md:mb-16 border-b border-gray-100 pb-8 md:pb-12">
          <h1 className="text-[24px] md:text-[28px] font-bold text-gray-900 mb-3">
            아이디 / 비밀번호 찾기
          </h1>
          <p className="text-[14px] md:text-[15px] text-gray-400">
            회원님의 소중한 계정 보호를 위해 본인 확인 절차를 진행합니다.
          </p>
        </div>

        {/* 📱 모바일 전용 탭 (md 미만에서만 노출) */}
        <div className="flex md:hidden border-b border-gray-200 mb-10">
          <button
            className={`flex-1 py-3 text-[15px] font-bold transition-all ${
              activeTab === 'id' ? 'text-[#47c7ac] border-b-2 border-[#47c7ac]' : 'text-gray-300'
            }`}
            onClick={() => setActiveTab('id')}
          >
            아이디 찾기
          </button>
          <button
            className={`flex-1 py-3 text-[15px] font-bold transition-all ${
              activeTab === 'password' ? 'text-[#47c7ac] border-b-2 border-[#47c7ac]' : 'text-gray-300'
            }`}
            onClick={() => setActiveTab('password')}
          >
            비밀번호 찾기
          </button>
        </div>

        {/* 💻 데스크탑: 2단 레이아웃 / 📱 모바일: 선택된 탭만 노출 */}
        <div className="flex flex-col md:flex-row gap-10 md:gap-16 lg:gap-24">
          
          {/* ---- [아이디 찾기 섹션] ---- */}
          <section className={`flex-1 space-y-8 ${activeTab === 'password' ? 'hidden md:block' : 'block'}`}>
            <h2 className="hidden md:block text-[20px] font-bold text-gray-900">아이디 찾기</h2>
            <div className="space-y-6">
              <FormField label="전화번호" className="font-bold text-gray-800">
                <Input
                  placeholder="전화번호 입력"
                  value={idForm.phone}
                  onChange={(e) => setIdForm({ ...idForm, phone: e.target.value })}
                  className="h-12 border-gray-200"
                />
              </FormField>
              <FormField label="이름" className="font-bold text-gray-800">
                <Input
                  placeholder="이름 입력"
                  value={idForm.name}
                  onChange={(e) => setIdForm({ ...idForm, name: e.target.value })}
                  className="h-12 border-gray-200"
                />
              </FormField>
              <Button 
                onClick={() => navigate('/find-account/complete')}
                className="w-full h-[52px] text-white font-bold rounded-md border-none"
                style={{ backgroundColor: MINT_COLOR }}
              >
                다음
              </Button>
            </div>
          </section>

          {/* 중앙 구분선 (데스크탑 전용) */}
          <div className="hidden md:block w-px bg-gray-100 mt-8"></div>

          {/* ---- [비밀번호 찾기 섹션] ---- */}
          <section className={`flex-1 space-y-8 ${activeTab === 'id' ? 'hidden md:block' : 'block'}`}>
            <h2 className="hidden md:block text-[20px] font-bold text-gray-900">비밀번호 찾기</h2>
            <div className="space-y-6">
              <FormField label="이메일" className="font-bold text-gray-800">
                <Input
                  placeholder="이메일 입력"
                  value={pwForm.email}
                  onChange={(e) => setPwForm({ ...pwForm, email: e.target.value })}
                  className="h-12 border-gray-200"
                />
              </FormField>
              <FormField label="전화번호" className="font-bold text-gray-800">
                <Input
                  placeholder="전화번호 입력"
                  value={pwForm.phone}
                  onChange={(e) => setPwForm({ ...pwForm, phone: e.target.value })}
                  className="h-12 border-gray-200"
                />
              </FormField>
              <FormField label="이름" className="font-bold text-gray-800">
                <Input
                  placeholder="이름 입력"
                  value={pwForm.name}
                  onChange={(e) => setPwForm({ ...pwForm, name: e.target.value })}
                  className="h-12 border-gray-200"
                />
              </FormField>
              <Button 
                onClick={() => navigate('/password-reset')}
                className="w-full h-[52px] text-white font-bold rounded-md border-none"
                style={{ backgroundColor: MINT_COLOR }}
              >
                다음
              </Button>
            </div>
          </section>

        </div>
      </main>

      <SiteFooter />
    </div>
  );
};