import { useNavigate, useLocation } from 'react-router-dom';
import { Button } from '@/components/ui';
import { PublicGnb } from '@/components/common/PublicGnb'; 
import { SiteFooter } from '@/components/apply/SiteFooter'; 

export const FindIdComplete = () => {
  const navigate = useNavigate();
  const location = useLocation();

  // 서버에서 받은 아이디, 없으면 테스트용 아이디
  const foundId = location.state?.foundId || 'User260101';
  const MINT_COLOR = '#47c7ac';

  return (
    <div className="min-h-screen flex flex-col bg-white">
      {/* 1. 상단 GNB (내부적으로 모바일/PC 대응이 되어있다고 가정) */}
      <PublicGnb />

      {/* 2. 메인 컨텐츠 영역 */}
      <main className="flex-1 max-w-3xl mx-auto w-full px-6 py-12 md:py-24">
        
        {/* 상단 타이틀 세션 */}
        <div className="text-center mb-10 md:mb-12 border-b border-gray-100 pb-8 md:pb-10">
          <h1 className="text-[22px] md:text-[28px] font-bold text-gray-900 mb-3">
            아이디 찾기 완료
          </h1>
          <p className="text-[14px] md:text-[15px] text-gray-400">
            입력하신 정보와 일치하는 아이디를 찾았습니다.
          </p>
        </div>

        {/* 결과 박스 및 버튼 (중앙 정렬) */}
        <div className="max-w-md mx-auto space-y-8">
          
          {/* 찾은 아이디 표시 박스 */}
          <div className="space-y-2">
            <label className="block text-[14px] md:text-[15px] font-bold text-gray-900">
              아이디
            </label>
            <div className="w-full h-[52px] md:h-[54px] px-4 flex items-center border border-gray-200 rounded-lg bg-white text-gray-900 font-bold text-[15px]">
              {foundId}
            </div>
          </div>

          {/* 3.반응형 버튼 레이아웃 */}
          {/* 모바일(기본): flex-col-reverse (로그인이 위로) / PC(md 이상): flex-row (가로 배치) */}
          <div className="flex flex-col-reverse md:flex-row gap-3 md:gap-4 mt-8">
            
            {/* 비밀번호 찾기 (모바일: 아래 / PC: 왼쪽) */}
            <Button
              onClick={() => navigate('/find-account')} 
              className="w-full md:flex-1 h-[54px] bg-white font-bold rounded-lg border transition-colors"
              style={{ borderColor: MINT_COLOR, color: MINT_COLOR }}
            >
              비밀번호 찾기
            </Button>
            
            {/* 로그인하러 가기 (모바일: 위 / PC: 오른쪽) */}
            <Button
              onClick={() => navigate('/login')}
              className="w-full md:flex-1 h-[54px] text-white font-bold rounded-lg border-none transition-colors"
              style={{ backgroundColor: MINT_COLOR }}
            >
              로그인하러 가기
            </Button>
          </div>

        </div>
      </main>

      {/* PC에서만 보이거나 모바일에서 간소화되는 푸터 */}
      <SiteFooter />
    </div>
  );
};