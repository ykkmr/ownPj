import { useNavigate } from 'react-router-dom';
import { ROUTES } from '@/constants/routes';
import { toast } from '@/store/toast.store';
import { getErrorMessage } from '@/utils/errorHandler';
import { Card, Badge, Button, Avatar } from '@/components/ui'; 
import { Calendar, DollarSign, ClipboardList, ChevronRight } from 'lucide-react'; // 아이콘 라이브러리

export const HomePage = () => {
  const navigate = useNavigate();

  const handleLogout = async () => {
    try {
      navigate(ROUTES.login, { replace: true });
    } catch (error) {
      toast.danger(getErrorMessage(error, '로그아웃 중 문제가 발생했습니다.'));
    }
  };

  return (
    <main className="min-h-screen bg-gray-50 pb-20">
      {/* 1. 상단 프로필 영역 */}
      <section className="bg-white px-6 py-8 shadow-sm">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Avatar size="lg" name="Guest" />
            <div>
              <h2 className="text-xl font-bold text-gray-900">
                게스트
              </h2>
              <p className="text-sm text-gray-500">오늘도 따뜻한 하루 되세요!</p>
            </div>
          </div>
          <button onClick={handleLogout} className="text-sm text-gray-400 underline">로그아웃</button>
        </div>
      </section>

      <div className="p-6 space-y-6">
        {/* 2. 핵심 요약 카드 (수익/활동시간) */}
        <div className="grid grid-cols-2 gap-4">
          <Card className="p-4 flex flex-col gap-2">
            <div className="flex items-center gap-2 text-blue-600">
              <DollarSign size={18} />
              <span className="text-xs font-semibold">이번 달 수익</span>
            </div>
            <p className="text-lg font-bold">1,240,500원</p>
          </Card>
          <Card className="p-4 flex flex-col gap-2">
            <div className="flex items-center gap-2 text-green-600">
              <ClipboardList size={18} />
              <span className="text-xs font-semibold">활동 시간</span>
            </div>
            <p className="text-lg font-bold">48시간</p>
          </Card>
        </div>

        {/* 3. 오늘 일정 (컬러 코딩 적용) */}
        <section className="space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-gray-800 flex items-center gap-2">
              <Calendar size={20} className="text-blue-500" /> 오늘의 일정
            </h3>
            <button className="text-xs text-gray-400 flex items-center">
              전체보기 <ChevronRight size={14} />
            </button>
          </div>
          
          {/* 매칭 완료 일정 (파란색) */}
          <Card className="p-4 border-l-4 border-blue-500">
            <div className="flex justify-between items-start mb-2">
              <Badge variant="info">매칭 완료</Badge>
              <span className="text-sm text-gray-500">14:00 ~ 16:00</span>
            </div>
            <h4 className="font-semibold text-gray-900">김*순 어르신 병원 동행</h4>
            <p className="text-xs text-gray-500 mt-1">서울 마포구 ...</p>
          </Card>

          {/* 매칭 중 일정 (노란색) */}
          <Card className="p-4 border-l-4 border-yellow-400">
            <div className="flex justify-between items-start mb-2">
              <Badge variant="warning">매칭 중</Badge>
              <span className="text-sm text-gray-500">18:00 ~ 20:00</span>
            </div>
            <h4 className="font-semibold text-gray-900">이*아 아동 하교 도움</h4>
          </Card>
        </section>

        {/* 4. 바로가기 버튼들 */}
        <section className="grid grid-cols-1 gap-3">
          <Button variant="outline" className="justify-between h-16 px-6">
            <span>파트너 교육 이수하기</span>
            <Badge>진행중</Badge>
          </Button>
          <Button variant="outline" className="justify-between h-16 px-6" onClick={() => navigate('/mypage')}>
            <span>내 정보 / 정산 계좌 관리</span>
            <ChevronRight size={20} />
          </Button>
        </section>
      </div>
    </main>
  );
};