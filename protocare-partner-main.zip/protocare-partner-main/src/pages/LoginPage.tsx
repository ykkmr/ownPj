import { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { supporterApi } from '@/services/api/supporter';
import { useAuthStore } from '@/store/auth.store';
import { toast } from '@/store/toast.store';
import { AppError, ValidationError } from '@/services/api/errors';
import './LoginPage.css';
import { PublicGnb } from '@/components/common/PublicGnb';
import { MobileGnb } from '@/components/apply/MobileGnb';
import { SiteFooter } from '@/components/apply/SiteFooter';

export const LoginPage = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [form, setForm] = useState({ email: '', password: '' });
  const [loading, setLoading] = useState(false);

  const handleDevLogin = () => {
    useAuthStore
      .getState()
      .login(
        { id: '1', name: '김서포터', role: 'SUPPORTER', email: 'dev@protocare.kr' },
        'dev-token',
      );
    navigate('/', { replace: true });
  };

  const handleChange = (field: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement>) => {
    setForm((prev) => ({ ...prev, [field]: e.target.value }));
  };

  const handleLogin = async (e?: React.FormEvent) => {
    e?.preventDefault();
    setLoading(true);
    try {
      const { user } = await supporterApi.login(form);
      toast.success(`${user.name} 서포터님, 환영합니다!`);
      const searchParams = new URLSearchParams(location.search);
      const nextPath = searchParams.get('next') || '/';
      navigate(decodeURIComponent(nextPath), { replace: true });
    } catch (error) {
      if (error instanceof ValidationError) {
        toast.danger(error.message || '입력 정보를 확인해주세요.');
      } else if (error instanceof AppError) {
        toast.danger(error.message);
      } else {
        toast.danger('로그인 처리 중 알 수 없는 에러가 발생했습니다.');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="login-page">
      <PublicGnb />

      <MobileGnb />

      <main className="login-body">
        <div className="login-card">
          <div className="login-title">
            <h1 className="login-title__heading">로그인</h1>
            <p className="login-title__sub">로그인 또는 회원가입 후 이용해주세요</p>
          </div>

          <form id="login-form" className="login-form" onSubmit={handleLogin} noValidate>
            <div className="login-field">
              <label className="login-field__label" htmlFor="login-email">
                이메일
              </label>
              <input
                id="login-email"
                type="text"
                className="login-field__input"
                placeholder="이메일 입력"
                value={form.email}
                onChange={handleChange('email')}
                disabled={loading}
                autoComplete="username"
              />
            </div>
            <div className="login-field">
              <label className="login-field__label" htmlFor="login-password">
                비밀번호
              </label>
              <input
                id="login-password"
                type="password"
                className="login-field__input"
                placeholder="비밀번호 입력"
                value={form.password}
                onChange={handleChange('password')}
                disabled={loading}
                autoComplete="current-password"
              />
            </div>
          </form>

          <div className="login-actions">
            <div className="login-actions__btns">
              <button
                type="submit"
                form="login-form"
                className="login-btn login-btn--primary"
                disabled={loading}
              >
                {loading ? '로그인 중...' : '로그인'}
              </button>
              <button
                type="button"
                className="login-btn login-btn--secondary"
                onClick={() => navigate('/signup/step1')}
                disabled={loading}
              >
                회원가입
              </button>
            </div>
            <button
              type="button"
              className="login-link--find"
              onClick={() => navigate('/find-account')}
            >
              아이디/비밀번호 찾기
            </button>
          </div>

          {import.meta.env.DEV && (
            <button
              type="button"
              onClick={handleDevLogin}
              style={{
                marginTop: '16px',
                width: '100%',
                height: '40px',
                background: '#f0faf8',
                border: '1px dashed #40b39b',
                borderRadius: '8px',
                color: '#40b39b',
                fontSize: '13px',
                fontWeight: 600,
                cursor: 'pointer',
                fontFamily: 'inherit',
              }}
            >
              🛠 개발 전용 로그인 (API 없이)
            </button>
          )}
        </div>
      </main>

      <SiteFooter />
    </div>
  );
};
