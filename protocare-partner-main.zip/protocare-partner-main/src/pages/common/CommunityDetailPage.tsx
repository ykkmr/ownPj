import { useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useCommunityPost, useComments, useCreateComment } from '@/hooks/useCommunity';
import { PageHeader, Card, CardBody, ListStateView, Button, Textarea } from '@/components/ui';
import { ApplyGnb } from '@/components/apply/ApplyGnb';
import { MobileGnb } from '@/components/apply/MobileGnb';
import { SiteFooter } from '@/components/apply/SiteFooter';

export default function CommunityDetailPage() {
  const navigate = useNavigate();
  const { id } = useParams<{ id: string }>();
  const postId = Number(id);

  const { data: post, isLoading: postLoading, isError: postError } = useCommunityPost(postId);
  const { data: comments, isLoading: commentsLoading, refetch } = useComments(postId);
  const createComment = useCreateComment(postId);

  const [comment, setComment] = useState('');

  const handleSubmit = () => {
    if (!comment.trim()) return;
    createComment.mutate({ content: comment }, { onSuccess: () => setComment('') });
  };

  return (
    <div className="mypage-page">
      <MobileGnb />
      <ApplyGnb variant="simple" />
      <div className="flex flex-col">
        <PageHeader title="게시글" showBack onBack={() => navigate(-1)} />

        <div className="flex flex-col gap-4 p-4">
          <ListStateView isLoading={postLoading} isError={postError}>
            {post && (
              <Card>
                <CardBody className="flex flex-col gap-2">
                  <p className="text-lg font-semibold">{post.title}</p>
                  <div className="flex items-center gap-3 text-xs text-gray-400">
                    <span>{post.isAnonymous ? '익명' : '작성자'}</span>
                    <span>조회 {post.viewCount}</span>
                    <span>{post.createdAt.slice(0, 10)}</span>
                  </div>
                  <p className="mt-2 text-sm leading-relaxed text-gray-700">{post.content}</p>
                </CardBody>
              </Card>
            )}
          </ListStateView>

          <section>
            <p className="mb-2 font-semibold">댓글 {comments?.length ?? 0}개</p>
            <ListStateView
              isLoading={commentsLoading}
              isEmpty={!comments?.length}
              emptyTitle="댓글이 없습니다"
              onRetry={refetch}
            >
              <div className="flex flex-col gap-2">
                {comments?.map((c) => (
                  <Card key={c.id}>
                    <CardBody>
                      <p className="text-sm">{c.content}</p>
                      <p className="mt-1 text-xs text-gray-400">{c.createdAt.slice(0, 10)}</p>
                    </CardBody>
                  </Card>
                ))}
              </div>
            </ListStateView>
          </section>

          <Card>
            <CardBody className="flex flex-col gap-2">
              <Textarea
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                placeholder="댓글을 입력하세요"
                rows={2}
              />
              <Button
                size="sm"
                onClick={handleSubmit}
                disabled={createComment.isPending || !comment.trim()}
              >
                등록
              </Button>
            </CardBody>
          </Card>
        </div>
      </div>
      <SiteFooter />
    </div>
  );
}
