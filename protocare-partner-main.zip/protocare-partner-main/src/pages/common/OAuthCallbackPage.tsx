import { useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supporterAuthService } from '@/services/api/auth.service';
import { toast } from '@/store/toast.store';
import type { OAuthProvider } from '@/services/api/oauth.service';
import { ROUTES } from '@/constants/routes';

export default function OAuthCallbackPage() {
  const { provider } = useParams<{ provider: string }>();
  const navigate = useNavigate();

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const code = params.get('code');
    const error = params.get('error');

    if (error || !code || !provider) {
      toast.danger('소셜 로그인이 취소되었습니다.');
      navigate(ROUTES.login, { replace: true });
      return;
    }

    const providerKey = provider.toUpperCase() as OAuthProvider;

    supporterAuthService
      .socialLogin(providerKey, code)
      .then((user) => {
        toast.success(`${user.name} 서포터님, 환영합니다!`);
        navigate(ROUTES.app, { replace: true });
      })
      .catch((err: unknown) => {
        const axiosErr = err as { response?: { data?: { message?: string } } };
        toast.danger(axiosErr?.response?.data?.message ?? '소셜 로그인에 실패했습니다.');
        navigate(ROUTES.login, { replace: true });
      });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div
      style={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        height: '100vh',
        color: '#666',
      }}
    >
      <p>로그인 처리 중...</p>
    </div>
  );
}
