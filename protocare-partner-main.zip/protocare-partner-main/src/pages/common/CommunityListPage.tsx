import { useNavigate } from 'react-router-dom';
import { useCommunityPosts } from '@/hooks/useCommunity';
import { PageHeader, Card, CardBody, ListStateView, Button } from '@/components/ui';
import { ApplyGnb } from '@/components/apply/ApplyGnb';
import { MobileGnb } from '@/components/apply/MobileGnb';
import { SiteFooter } from '@/components/apply/SiteFooter';

export default function CommunityListPage() {
  const navigate = useNavigate();
  const { data, isLoading, isError, refetch } = useCommunityPosts();

  return (
    <div className="mypage-page">
      <MobileGnb />
      <ApplyGnb variant="simple" />
      <div className="flex flex-col">
        <PageHeader
          title="커뮤니티"
          right={
            <Button size="sm" onClick={() => navigate('/community/new')}>
              글쓰기
            </Button>
          }
        />

        <div className="p-4">
          <ListStateView
            isLoading={isLoading}
            isError={isError}
            isEmpty={!data?.content.length}
            emptyTitle="게시글이 없습니다"
            onRetry={refetch}
          >
            <div className="flex flex-col gap-3">
              {data?.content.map((post) => (
                <Card
                  key={post.id}
                  className="cursor-pointer active:bg-gray-50"
                  onClick={() => navigate(`/community/${post.id}`)}
                >
                  <CardBody>
                    <p className="font-medium">{post.title}</p>
                    <div className="mt-1 flex items-center gap-3 text-xs text-gray-400">
                      <span>{post.isAnonymous ? '익명' : '작성자'}</span>
                      <span>조회 {post.viewCount}</span>
                      <span>{post.createdAt.slice(0, 10)}</span>
                    </div>
                  </CardBody>
                </Card>
              ))}
            </div>
          </ListStateView>
        </div>
      </div>
      <SiteFooter />
    </div>
  );
}
