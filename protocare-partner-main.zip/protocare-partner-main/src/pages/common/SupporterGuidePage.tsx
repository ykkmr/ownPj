import React from 'react';
import { useNavigate } from 'react-router-dom';
import { PublicGnb } from '@/components/common/PublicGnb';
import { MobileGnb } from '@/components/apply/MobileGnb';
import { SiteFooter } from '@/components/apply/SiteFooter';
import './SupporterGuidePage.css';

const ASSETS = {
  stepOnline:
    '/assets/icons/approved resume with checkmark for HR screening and candidate selection.png',
  stepSearch: '/assets/icons/search_activity.svg',
  stepInterview: '/assets/icons/87666531515845622af634590f505512cbe80043.png',
  stepComplete: '/assets/icons/83bfdf93a30b7d023ed48343f11651cdcb950056.png',
  arrow: '/assets/icons/arrow_drop_down_circle.svg',
  proIcon: '/assets/icons/image 52.png',
  generalIcon: '/assets/icons/image 53.png',
} as const;

// ── Static data ────────────────────────────────────────────────────────────
const STEPS = [
  {
    step: 1,
    img: ASSETS.stepOnline,
    title: '온라인 지원',
    desc: '공식 홈페이지를 통해 기본 인적사항 및 자격 증명 서류를 제출합니다.',
  },
  {
    step: 2,
    img: ASSETS.stepSearch,
    title: '서류 심사',
    desc: '제출된 서류를 바탕으로 자격 요건 및 결격 사유를 검토합니다.',
  },
  {
    step: 3,
    img: ASSETS.stepInterview,
    title: '대면/화상 면접',
    desc: '전문성 및 서비스 마인드를 확인하기 위한 인터뷰를 진행합니다.',
  },
  {
    step: 4,
    img: ASSETS.stepComplete,
    title: '서포터 등록 완료',
    desc: '최종 합격 후 서포터 행동 매뉴얼을 이수하셔야 정식 서포터로 활동 가능합니다.',
  },
] as const;

const PRO_CERTS = [
  '간호사 면허증 소지자',
  '간호조무사 자격증 소지자',
  '요양보호사 자격증 소지자 (1급 우대)',
] as const;

const PRO_COMMON = [
  '자격 취득 후 관련 업무 경력 1년 이상 우대',
  '최근 1년 이내 보수교육 이수 완료자',
] as const;

const GENERAL_REQUIRED = [
  '이용자에 대한 공감 능력과 서비스 마인드를 갖춘 자',
  "당사에서 제공하는 '케어 서포터 기본 교육' 이수 가능자",
] as const;

const GENERAL_PREFERRED = [
  '병원 동행 매니저, 장애인 활동 지원사 등 유사 경력자',
  '응급처치(CPR) 교육 이수 소지자',
] as const;

// ── Sub-components ─────────────────────────────────────────────────────────

function CheckIcon() {
  return (
    <svg className="guide-check-item__icon" viewBox="0 0 24 24" fill="#47c7ac" aria-hidden="true">
      <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z" />
    </svg>
  );
}

function HeroSection() {
  const navigate = useNavigate();
  return (
    <section className="guide-hero">
      <div className="guide-hero__text-group">
        <p className="guide-hero__label">Join Our Team</p>
        <h1 className="guide-hero__title">{'ProtoCare 서포터\n지원 안내 및 자격 요건'}</h1>
        <p className="guide-hero__subtitle">
          이용자와 보호자에게 따뜻한 돌봄을 제공할 전문적이고 공감 능력있는 서포터님을 모십니다.
          <br />
          명확한 자격 요건과 투명한 절차를 통해 여러분의 새로운 시작을 지원합니다.
        </p>
      </div>
      <button
        type="button"
        className="guide-hero__cta"
        onClick={() => navigate('/supporter/apply')}
      >
        지원하기
      </button>
    </section>
  );
}

function ProcessSection() {
  return (
    <section className="guide-section">
      <div className="guide-section__header">
        <h2 className="guide-section__heading">등록 절차 안내</h2>
        <p className="guide-section__subheading">지원 접수부터 서포터 등록 완료까지의 과정</p>
      </div>
      <div className="guide-steps">
        {STEPS.map((step, idx) => (
          <React.Fragment key={step.step}>
            <div className="guide-step">
              <img src={step.img} alt="" className="guide-step__img" />
              <div className="guide-step__body">
                <p className="guide-step__number">
                  {step.step}. {step.title}
                </p>
                <p className="guide-step__desc">{step.desc}</p>
              </div>
            </div>
            {idx < STEPS.length - 1 && (
              <img src={ASSETS.arrow} alt="" className="guide-step-arrow" aria-hidden="true" />
            )}
          </React.Fragment>
        ))}
      </div>
    </section>
  );
}

function QualificationSection() {
  return (
    <section className="guide-section guide-section--alt">
      <div className="guide-section__header">
        <h2 className="guide-section__heading">지원 자격 요건</h2>
        <p className="guide-section__subheading">지원 접수부터 서포터 등록 완료까지의 과정</p>
      </div>
      <div className="guide-quals">
        <div className="guide-qual-card guide-qual-card--pro">
          <div className="guide-qual-card__header">
            <img src={ASSETS.proIcon} alt="" className="guide-qual-card__icon" />
            <p className="guide-qual-card__title">전문직 서포터</p>
          </div>
          <div className="guide-qual-group">
            <p className="guide-qual-group__label">필수 자격증 (택1)</p>
            <div className="guide-check-list">
              {PRO_CERTS.map((cert) => (
                <div key={cert} className="guide-check-item">
                  <CheckIcon />
                  <span className="guide-check-item__text">{cert}</span>
                </div>
              ))}
            </div>
          </div>
          <div className="guide-qual-group">
            <p className="guide-qual-group__label">공통 요건</p>
            <ul className="guide-bullet-list">
              {PRO_COMMON.map((item) => (
                <li key={item} className="guide-bullet-item">
                  {item}
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="guide-qual-card guide-qual-card--general">
          <div className="guide-qual-card__header">
            <img src={ASSETS.generalIcon} alt="" className="guide-qual-card__icon" />
            <p className="guide-qual-card__title">일반 서포터 (비전문직)</p>
          </div>
          <div className="guide-qual-group">
            <p className="guide-qual-group__label">필수 요건</p>
            <div className="guide-check-list">
              {GENERAL_REQUIRED.map((item) => (
                <div key={item} className="guide-check-item">
                  <CheckIcon />
                  <span className="guide-check-item__text">{item}</span>
                </div>
              ))}
            </div>
          </div>
          <div className="guide-qual-group">
            <p className="guide-qual-group__label">우대 사항</p>
            <ul className="guide-bullet-list">
              {GENERAL_PREFERRED.map((item) => (
                <li key={item} className="guide-bullet-item">
                  {item}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
}

// ── Page ───────────────────────────────────────────────────────────────────
export default function SupporterGuidePage() {
  return (
    <div className="guide-page">
      <MobileGnb />
      <PublicGnb activeNav="지원가이드" />
      <main className="guide-main">
        <HeroSection />
        <ProcessSection />
        <QualificationSection />
      </main>
      <SiteFooter />
    </div>
  );
}
