import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useCreatePost } from '@/hooks/useCommunity';
import { PageHeader, Card, CardBody, Button, Input, Textarea, Switch } from '@/components/ui';
import { ApplyGnb } from '@/components/apply/ApplyGnb';
import { MobileGnb } from '@/components/apply/MobileGnb';
import { SiteFooter } from '@/components/apply/SiteFooter';
import { toast } from '@/store/toast.store';

export default function CommunityNewPage() {
  const navigate = useNavigate();
  const createPost = useCreatePost();

  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [isAnonymous, setIsAnonymous] = useState(false);

  const handleSubmit = () => {
    if (!title.trim() || !content.trim()) {
      toast.danger('제목과 내용을 입력해주세요.');
      return;
    }
    createPost.mutate(
      { title, content, isAnonymous },
      {
        onSuccess: () => {
          toast.success('게시글이 등록되었습니다.');
          navigate('/community');
        },
      },
    );
  };

  return (
    <div className="mypage-page">
      <MobileGnb />
      <ApplyGnb variant="simple" />
      <div className="flex flex-col">
        <PageHeader title="글쓰기" showBack onBack={() => navigate(-1)} />

        <div className="p-4">
          <Card>
            <CardBody className="flex flex-col gap-4">
              <div>
                <p className="mb-1 text-sm font-medium text-gray-700">제목</p>
                <Input
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="제목을 입력하세요"
                />
              </div>
              <div>
                <p className="mb-1 text-sm font-medium text-gray-700">내용</p>
                <Textarea
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  placeholder="내용을 입력하세요"
                  rows={8}
                />
              </div>
              <div className="flex items-center justify-between">
                <p className="text-sm font-medium text-gray-700">익명으로 작성</p>
                <Switch checked={isAnonymous} onChange={setIsAnonymous} />
              </div>
              <Button onClick={handleSubmit} disabled={createPost.isPending}>
                등록
              </Button>
            </CardBody>
          </Card>
        </div>
      </div>
      <SiteFooter />
    </div>
  );
}
