import { useState, useMemo } from 'react';
import { ApplyGnb } from '@/components/apply/ApplyGnb';
import { MobileGnb } from '@/components/apply/MobileGnb';
import { SiteFooter } from '@/components/apply/SiteFooter';
import './FaqPage.css';

// ── Types ──────────────────────────────────────────────────────────────────
type FaqCategory =
  | '가입 및 승인'
  | '이용 방법'
  | '수익과 정산'
  | '사고 및 안전 대처'
  | '자격 및 교육';

interface FaqItem {
  id: number;
  category: FaqCategory;
  question: string;
  answer: string;
}

// ── Static data ─────────────────────────────────────────────────────────────
const CATEGORIES: FaqCategory[] = [
  '가입 및 승인',
  '이용 방법',
  '수익과 정산',
  '사고 및 안전 대처',
  '자격 및 교육',
];

const FAQS: FaqItem[] = [
  {
    id: 1,
    category: '가입 및 승인',
    question: '서포터 가입 시 반드시 제출해야 하는 서류는 무엇인가요?',
    answer: `안녕하세요, ProtoCare입니다! \n안전하고 신뢰할 수 있는 케어 환경을 위해 서포터 가입 시 몇 가지 필수 서류 확인 절차를 거치고 있습니다.\n아래 리스트를 확인하여 미리 준비해 주시면 더 빠른 승인이 가능합니다.\n\n1. 필수 제출 서류 (공통)\n모든 파트너님이 반드시 등록해주셔야 하는 항목입니다.\n• 본인 확인 서류: 주민등록증, 운전면허증, 여권 중 1종 (사진 촬영본)\n• 본인 명의 계좌 정보: 활동비 정산을 위한 은행명 및 계좌번호\n\n2. 선택 제출 서류 (해당자)\n등록 시 매칭 확률이 높아지고 전문 배지가 부여됩니다.\n• 전문 자격증: 요양보호사, 간호사, 간호조무사, 사회복지사 등 관련 자격증\n• 범죄경력서: 해당 기관에서 별도 서류를 발급 받아 파일 제출\n• 기타 수료증: 응급처치 교육, 치매 교육 등 관련 기관 이수증\n\n3. 서류 등록 시 유의사항\n• 사진 품질: 빛 반사가 심하거나 글자가 흐릿하면 반려될 수 있으니 밝은 곳에서 정확히 촬영해 주세요.\n• 유효 기간: 자격증이나 신분증은 유효 기간이 만료되지 않은 것이어야 합니다.\n• 개인정보 보호: 주민등록번호 뒷자리는 가리고 촬영하셔도 무방합니다. (시스템에서 자동 마스킹 처리 지원)`,
  },
  {
    id: 2,
    category: '가입 및 승인',
    question: '자격증이 없는 일반인도 서포터 심사를 통과할 수 있나요?',
    answer:
      '네, 자격증이 없어도 서포터 활동이 가능합니다. 다만 자격증 보유 시 더 많은 케어 유형에 매칭될 수 있으며, 활동비 기준도 높아집니다. 모든 파트너님은 가입 시 기본 역량 검사를 통과해야 합니다.',
  },
  {
    id: 3,
    category: '가입 및 승인',
    question: '서류 제출 후 최종 승인까지 보통 며칠이 소요되나요?',
    answer:
      '서류 제출 완료 후 영업일 기준 평균 1~3일 이내에 승인 결과가 안내됩니다. 서류가 불명확하거나 추가 확인이 필요한 경우 최대 5영업일이 소요될 수 있습니다.',
  },
  {
    id: 4,
    category: '가입 및 승인',
    question: '범죄경력조회 동의는 활동을 위해 왜 필수인가요?',
    answer:
      '취약계층인 시니어·장애인 대상 케어 서비스 특성상, 이용자의 안전을 최우선으로 보호하기 위해 법적으로 요구됩니다. 조회 결과는 심사 목적으로만 활용되며 안전하게 관리됩니다.',
  },
  {
    id: 5,
    category: '가입 및 승인',
    question: '프로필 사진을 등록할 때 주의해야 할 규정이 있나요? (셀카, 마스크 등)',
    answer:
      '프로필 사진은 얼굴이 명확히 식별되어야 합니다. 마스크, 선글라스 착용 사진, 단체 사진, 캐릭터·풍경 이미지는 반려될 수 있습니다. 밝은 곳에서 정면을 바라보는 단독 사진을 권장합니다.',
  },
  {
    id: 6,
    category: '가입 및 승인',
    question: '승인이 반려되었다는 알림을 받았는데, 사유를 어디서 확인하죠?',
    answer:
      '앱 내 마이서포트 → 지원서 관리 → 반려 내역에서 사유를 확인하실 수 있습니다. 사유에 따라 서류를 보완하여 재제출하시면 재심사가 진행됩니다.',
  },
  {
    id: 7,
    category: '가입 및 승인',
    question: '휴대폰 본인 인증 단계에서 자꾸 오류가 나요.',
    answer:
      '이름, 생년월일, 통신사 정보가 본인 명의와 일치하는지 확인해 주세요. 알뜰폰(MVNO) 사용 시 제휴 통신사를 선택해야 합니다. 문제가 지속되면 1:1 문의를 통해 접수해 주세요.',
  },
  {
    id: 8,
    category: '가입 및 승인',
    question: '외국인 서포터도 가입이 가능한가요? (비자 종류 등)',
    answer:
      '취업활동이 가능한 비자(E-6, F-2, F-4, F-5, H-2 등)를 보유하신 분은 가입 가능합니다. 외국인등록증과 비자 관련 서류를 함께 제출해 주세요.',
  },
  {
    id: 9,
    category: '가입 및 승인',
    question: '가입 시 등록한 경력 사항이 승인 결과에 큰 영향을 미치나요?',
    answer:
      '경력은 심사 시 참고 자료로 활용되며, 관련 자격증이나 실무 경험이 있을수록 매칭 우선순위와 활동비 기준에 유리하게 작용합니다. 단, 필수 조건은 아닙니다.',
  },
  {
    id: 10,
    category: '이용 방법',
    question: '케어 활동은 어떤 방식으로 매칭되나요?',
    answer:
      '의뢰인이 케어 요청을 올리면, 조건에 맞는 서포터에게 알림이 발송됩니다. 서포터가 지원하면 의뢰인이 프로필을 확인 후 최종 선택합니다. 매칭 완료 후 양측 모두에게 확정 알림이 전송됩니다.',
  },
  {
    id: 11,
    category: '이용 방법',
    question: '활동 일지는 언제까지 제출해야 하나요?',
    answer:
      '활동 종료 후 24시간 이내에 앱 내 활동 일지를 작성·제출해 주셔야 합니다. 미제출 시 정산이 지연될 수 있으며, 3회 이상 누락 시 서비스 이용이 제한될 수 있습니다.',
  },
  {
    id: 12,
    category: '수익과 정산',
    question: '주말/공휴일 가산금은 기본 시급의 몇 %인가요?',
    answer:
      '주말 및 법정 공휴일 활동 시, 해당 서비스 기본 시급에 20% 가산된 금액이 지급됩니다.\n• 평일(월~금): 기본 시급 (100%)\n• 주말(토, 일): 기본 시급 + 20%\n• 공휴일(법정·대체): 기본 시급 + 20%',
  },
  {
    id: 13,
    category: '수익과 정산',
    question: '정산은 언제 이루어지나요?',
    answer:
      '정산은 매주 화요일에 이루어지며, 전주 완료된 활동에 대한 금액이 등록된 계좌로 입금됩니다. 공휴일의 경우 다음 영업일로 순연됩니다.',
  },
  {
    id: 14,
    category: '사고 및 안전 대처',
    question: '활동 중 의뢰인이 의식을 잃었을 때 어떻게 해야 하나요?',
    answer:
      '즉시 119에 신고하고, 앱 내 긴급 연락 버튼을 눌러 운영팀에 상황을 공유해 주세요. 운영팀이 24시간 대기 중이며 즉각 대응 지원을 제공합니다.',
  },
  {
    id: 15,
    category: '사고 및 안전 대처',
    question: '활동 중 발생한 사고는 어떻게 신고하나요?',
    answer:
      '앱 내 마이서포트 → 활동 내역 → 해당 활동 → 사고 신고 버튼을 통해 접수해 주세요. 접수 후 영업일 기준 2일 이내에 담당 매니저가 연락드립니다.',
  },
  {
    id: 16,
    category: '자격 및 교육',
    question: '서포터 교육은 어디서 받을 수 있나요?',
    answer:
      '마이서포트 → 케어 전문 교육 탭에서 온라인 교육 콘텐츠를 수강하실 수 있습니다. 기초 교육 이수 후 더 다양한 케어 유형에 지원할 수 있는 자격이 부여됩니다.',
  },
  {
    id: 17,
    category: '자격 및 교육',
    question: '요양보호사 자격증 취득 후 프로필에 반영하는 방법은?',
    answer:
      '마이서포트 → 내 정보 관리 → 자격증 탭에서 자격증 사진을 첨부하여 등록하실 수 있습니다. 검토는 영업일 기준 1~2일 소요되며, 승인 완료 후 프로필에 자동 반영됩니다.',
  },
];

const ITEMS_PER_PAGE = 9;

// ── Sub-components ─────────────────────────────────────────────────────────
interface FaqRowProps {
  item: FaqItem;
  isOpen: boolean;
  onToggle: () => void;
}

function FaqRow({ item, isOpen, onToggle }: FaqRowProps) {
  return (
    <li className="faq-item">
      <button type="button" className="faq-row" onClick={onToggle} aria-expanded={isOpen}>
        <span className="faq-row__category">[{item.category}]</span>
        <span className="faq-row__title">{item.question}</span>
        <img
          src="/assets/icons/keyboard_arrow_down.svg"
          alt=""
          aria-hidden="true"
          className={`faq-row__arrow${isOpen ? ' faq-row__arrow--open' : ''}`}
        />
      </button>
      {isOpen && (
        <div className="faq-answer">
          <div className="faq-answer__box">{item.answer}</div>
        </div>
      )}
    </li>
  );
}

interface PaginationProps {
  current: number;
  total: number;
  onChange: (page: number) => void;
}

function Pagination({ current, total, onChange }: PaginationProps) {
  if (total <= 1) return null;
  return (
    <nav className="faq-pagination" aria-label="페이지 탐색">
      {Array.from({ length: total }, (_, i) => i + 1).map((page) => (
        <button
          key={page}
          type="button"
          className={`faq-pagination__btn${current === page ? ' faq-pagination__btn--active' : ''}`}
          onClick={() => onChange(page)}
          aria-current={current === page ? 'page' : undefined}
        >
          {page}
        </button>
      ))}
      <button
        type="button"
        className="faq-pagination__next"
        onClick={() => onChange(Math.min(current + 1, total))}
        aria-label="다음 페이지"
        disabled={current === total}
      >
        <img
          src="/assets/icons/arrow_forward_ios.svg"
          alt=""
          aria-hidden="true"
          width={20}
          height={20}
        />
      </button>
    </nav>
  );
}

// ── Page ───────────────────────────────────────────────────────────────────
export default function FaqPage() {
  const [query, setQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState<FaqCategory>('가입 및 승인');
  const [expandedId, setExpandedId] = useState<number | null>(1);
  const [currentPage, setCurrentPage] = useState(1);

  const filtered = useMemo(() => {
    const byCategory = FAQS.filter((f) => f.category === activeCategory);
    if (!query.trim()) return byCategory;
    const q = query.toLowerCase();
    return byCategory.filter(
      (f) => f.question.toLowerCase().includes(q) || f.answer.toLowerCase().includes(q),
    );
  }, [activeCategory, query]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / ITEMS_PER_PAGE));
  const paginated = filtered.slice(
    (currentPage - 1) * ITEMS_PER_PAGE,
    currentPage * ITEMS_PER_PAGE,
  );

  function handleCategoryChange(category: FaqCategory) {
    setActiveCategory(category);
    setExpandedId(null);
    setCurrentPage(1);
  }

  function handleSearch(value: string) {
    setQuery(value);
    setExpandedId(null);
    setCurrentPage(1);
  }

  function toggleFaq(id: number) {
    setExpandedId((prev) => (prev === id ? null : id));
  }

  return (
    <div className="faq-page">
      <MobileGnb />
      <ApplyGnb variant="full" activeItem="faq" />

      <section className="faq-hero">
        <div className="faq-hero__inner">
          <div className="faq-hero__text">
            <p className="faq-hero__badge">FAQ</p>
            <h1 className="faq-hero__title">자주 묻는 질문</h1>
            <p className="faq-hero__subtitle">
              찾으시는 키워드를 검색하시거나 아래 카테고리를 선택하여 궁금증을 빠르게 해결하세요.
            </p>
          </div>
          <div className="faq-search">
            <input
              type="search"
              className="faq-search__input"
              placeholder="검색어를 입력하세요"
              value={query}
              onChange={(e) => handleSearch(e.target.value)}
              aria-label="FAQ 검색"
            />
            <img
              src="/assets/icons/search.svg"
              alt=""
              aria-hidden="true"
              className="faq-search__icon"
            />
          </div>
        </div>
      </section>

      <main className="faq-body">
        <div className="faq-chips" role="group" aria-label="카테고리 필터">
          {CATEGORIES.map((category) => (
            <button
              key={category}
              type="button"
              className={`faq-chip${activeCategory === category ? ' faq-chip--active' : ''}`}
              onClick={() => handleCategoryChange(category)}
              aria-pressed={activeCategory === category}
            >
              {category}
            </button>
          ))}
        </div>

        <ul className="faq-list">
          {paginated.length > 0 ? (
            paginated.map((item) => (
              <FaqRow
                key={item.id}
                item={item}
                isOpen={expandedId === item.id}
                onToggle={() => toggleFaq(item.id)}
              />
            ))
          ) : (
            <li style={{ padding: '24px 12px', color: '#737373', fontSize: '16px' }}>
              검색 결과가 없습니다.
            </li>
          )}
        </ul>

        <Pagination current={currentPage} total={totalPages} onChange={setCurrentPage} />
      </main>

      <SiteFooter />
    </div>
  );
}
