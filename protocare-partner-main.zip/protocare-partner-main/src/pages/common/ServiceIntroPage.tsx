import { PublicGnb } from '@/components/common/PublicGnb';
import { MobileGnb } from '@/components/apply/MobileGnb';
import { SiteFooter } from '@/components/apply/SiteFooter';
import './ServiceIntroPage.css';

const ASSETS = {
  timeIcon: '/assets/icons/time.png',
  moneyIcon: '/assets/icons/stack of money.png',
  rocketIcon: '/assets/icons/rocket.png',
  hospitalImg: '/assets/images/8d890452-e969-425b-be87-5a64a709563f.png',
  elderlyImg: '/assets/images/e8b1b5e2-0f4e-4327-8f6a-29e180530982.png',
  childImg: '/assets/images/950c0832-d765-4108-ab88-a0ec9d2e11e7.png',
  storiesImg: '/assets/images/24bf1278-e003-4838-93e8-2e106f4ac9c8.png',
} as const;

const GOAL_CARDS = [
  {
    icon: ASSETS.timeIcon,
    alt: '시계',
    title: '유연한 활동',
    desc: '내가 원하는 시간과 장소에서 자유롭게 케어 일정을 관리합니다.',
  },
  {
    icon: ASSETS.moneyIcon,
    alt: '수익',
    title: '합당한 보상',
    desc: '전문성에 걸맞은 안정적인 수익과 투명한 정산 시스템을 제공합니다.',
  },
  {
    icon: ASSETS.rocketIcon,
    alt: '로켓',
    title: '성장의 기회',
    desc: '단순한 일을 넘어, 누군가의 삶에 기여하며 케어 전문가로 성장합니다.',
  },
] as const;

const SERVICES = [
  {
    img: ASSETS.hospitalImg,
    alt: '병원 동행',
    title: '병원 동행',
    desc: '단순한 이동 지원을 넘어, 보호자의 눈과 귀가 되어 진료 과정을 꼼꼼하게 기록하고 전달하는 전문적인 역할을 수행합니다.',
    detail: '접수 및 수납 대행, 진료 시 의사 소견 메모, 처방전 수령 및 약국 동행, 자택 귀가 안내',
    shaded: true,
  },
  {
    img: ASSETS.elderlyImg,
    alt: '어르신 돌봄',
    title: '어르신 돌봄',
    desc: '어르신의 소중한 일상을 지키는 동반자로서, 전문적인 케어 스킬을 통해 가족의 빈자리를 든든하게 채우는 가치 있는 활동입니다.',
    detail: '식사 보조 및 투약 확인, 산책 동행, 인지 활동 지원, 건강 상태 모니터링 기록',
    shaded: false,
  },
  {
    img: ASSETS.childImg,
    alt: '아이 돌봄',
    title: '아이 돌봄',
    desc: '아이의 눈높이에서 안전하게 소통하며, 부모님이 안심하고 일상에 집중할 수 있도록 아이의 성장 시간을 함께 책임집니다.',
    detail: '등하원 지도, 실내 놀이 및 독서 활동, 간식 챙기기, 아이의 활동 피드백 작성',
    shaded: true,
  },
] as const;

const INTERVIEW_STORIES = [
  {
    date: '2025.12.16',
    title: '은퇴 후 찾은 제2의 월급, 매일 뿌듯함을 느낍니다.',
    body: '평범한 전업주부에서 월 150만 원 수익을 올리는 베테랑 서포터가 된 김지영 님. 그녀가 말하는 ProtoCare만의 매칭 시스템과 수익 노하우를 공개합니다.',
  },
  {
    date: '2025.11.20',
    title: '하루 3시간으로 시작한 부업, 이제는 본업이 됐어요.',
    body: '평범한 전업주부에서 월 150만 원 수익을 올리는 베테랑 서포터가 된 김지영 님. 그녀가 말하는 ProtoCare만의 매칭 시스템과 수익 노하우를 공개합니다.',
  },
  {
    date: '2025.10.05',
    title: '누군가의 일상을 돕는다는 게 이렇게 보람찰 줄이야.',
    body: '평범한 전업주부에서 월 150만 원 수익을 올리는 베테랑 서포터가 된 김지영 님. 그녀가 말하는 ProtoCare만의 매칭 시스템과 수익 노하우를 공개합니다.',
  },
] as const;

// ── Sub-components ─────────────────────────────────────────────────────────

function HeroSection() {
  return (
    <section className="svc-hero">
      <p className="svc-hero__label">Service Overview</p>
      <h1 className="svc-hero__title">비어있는 일상을 채우는 든든한 파트너</h1>
      <p className="svc-hero__subtitle">
        원하는 시간에 병원동행·돌봄 활동을 하며
        <br />
        의미 있는 경험과 수익을 만들 수 있습니다
      </p>
    </section>
  );
}

function GoalSection() {
  return (
    <section className="svc-section svc-section--padded">
      <div className="svc-section__header">
        <span className="svc-section__label">Goal</span>
        <h2 className="svc-section__heading">
          {'신뢰를 더하는 전문성으로,\n케어의 새로운 기준을 만듭니다'}
        </h2>
      </div>
      <div className="svc-goal-cards">
        {GOAL_CARDS.map((card) => (
          <div key={card.title} className="svc-goal-card">
            <div className="svc-goal-card__icon-wrap">
              <img src={card.icon} alt={card.alt} className="svc-goal-card__icon" />
            </div>
            <div className="svc-goal-card__body">
              <p className="svc-goal-card__title">{card.title}</p>
              <p className="svc-goal-card__desc">{card.desc}</p>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

function ServicesSection() {
  return (
    <section className="svc-section">
      <div className="svc-section__header">
        <span className="svc-section__label">Services</span>
        <h2 className="svc-section__heading">일상 속 돌봄 서비스 3가지</h2>
      </div>
      <div className="svc-services-list">
        {SERVICES.map((svc) => (
          <div
            key={svc.title}
            className={`svc-service-card${svc.shaded ? ' svc-service-card--shaded' : ''}`}
          >
            <img src={svc.img} alt={svc.alt} className="svc-service-card__img" />
            <div className="svc-service-card__content">
              <h3 className="svc-service-card__title">{svc.title}</h3>
              <p className="svc-service-card__desc">{svc.desc}</p>
              <p className="svc-service-card__detail">{svc.detail}</p>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

function EarningsSection() {
  return (
    <section className="svc-section svc-section--padded">
      <div className="svc-section__header">
        <span className="svc-section__label">Earnings</span>
        <h2 className="svc-section__heading">수익 구조와 혜택</h2>
      </div>
      <div className="svc-earnings-placeholder" aria-label="수익 구조 이미지 준비 중" />
    </section>
  );
}

type InterviewCardProps = {
  imgSrc: string;
  date: string;
  title: string;
  body: string;
};

function InterviewCard({ imgSrc, date, title, body }: InterviewCardProps) {
  return (
    <article className="svc-interview-card">
      <img src={imgSrc} alt="" className="svc-interview-card__img" />
      <div className="svc-interview-card__meta">
        <span className="svc-interview-card__tag">서포터 인터뷰</span>
        <span className="svc-interview-card__date">{date}</span>
      </div>
      <h3 className="svc-interview-card__title">{title}</h3>
      <p className="svc-interview-card__body">{body}</p>
    </article>
  );
}

function StoriesSection() {
  return (
    <section className="svc-section svc-section--padded">
      <div className="svc-section__header">
        <span className="svc-section__label">Stories</span>
        <h2 className="svc-section__heading">서포터들의 이야기</h2>
      </div>
      <div className="svc-stories-list">
        {INTERVIEW_STORIES.map((story) => (
          <InterviewCard
            key={story.title}
            imgSrc={ASSETS.storiesImg}
            date={story.date}
            title={story.title}
            body={story.body}
          />
        ))}
      </div>
      <button type="button" className="svc-btn-more">
        더보기
      </button>
    </section>
  );
}

// ── Page ───────────────────────────────────────────────────────────────────
export default function ServiceIntroPage() {
  return (
    <div className="svc-page">
      <PublicGnb activeNav="서비스 소개" />
      <MobileGnb />
      <main>
        <HeroSection />
        <GoalSection />
        <ServicesSection />
        <EarningsSection />
        <StoriesSection />
      </main>
      <SiteFooter />
    </div>
  );
}
