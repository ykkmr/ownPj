// TODO: UI 디자인 확정 후 구현
export default function SettingsPage() {
  return <div>SettingsPage</div>;
}
