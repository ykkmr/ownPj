import { PublicGnb } from '@/components/common/PublicGnb';
import { SignupTermsForm } from '@/components/auth/SignupTermsForm';

export default function SignupPage() {
  return (
    <div className="terms-page">
      <PublicGnb />
      <div className="terms-page__content">
        <SignupTermsForm />
      </div>
    </div>
  );
}
