import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useNotificationConfigs, useUpdateNotificationConfigs } from '@/hooks/useSupporter';
import { ApplyGnb } from '@/components/apply/ApplyGnb';
import { MobileGnb } from '@/components/apply/MobileGnb';
import { SiteFooter } from '@/components/apply/SiteFooter';
import { toast } from '@/store/toast.store';
import type { NotificationConfig } from '@/types/api';

function Toggle({
  checked,
  onChange,
  label,
}: {
  checked: boolean;
  onChange: (v: boolean) => void;
  label: string;
}) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={label}
      className={`notif-toggle${checked ? ' notif-toggle--on' : ''}`}
      onClick={() => onChange(!checked)}
    >
      <span className="notif-toggle__knob" />
    </button>
  );
}

const NOTIFICATION_ITEMS: { apiKey: keyof NotificationConfig; label: string }[] = [
  { apiKey: 'customActivityEnabled', label: '맞춤 활동 알림' },
  { apiKey: 'activityScheduleEnabled', label: '활동 및 스케줄 알림' },
  { apiKey: 'incomeSettlementEnabled', label: '수익 및 정산 알림' },
  { apiKey: 'serviceGuideEnabled', label: '서비스 가이드 및 공지 알림' },
];

const DEFAULT_CONFIG: NotificationConfig = {
  customActivityEnabled: true,
  activityScheduleEnabled: true,
  incomeSettlementEnabled: true,
  serviceGuideEnabled: false,
};

export default function NotificationSettingPage() {
  const navigate = useNavigate();
  const { data: serverConfig, isLoading } = useNotificationConfigs();
  const { mutate: saveConfig } = useUpdateNotificationConfigs();
  const [localConfig, setLocalConfig] = useState<NotificationConfig>(DEFAULT_CONFIG);

  useEffect(() => {
    if (serverConfig) setLocalConfig(serverConfig);
  }, [serverConfig]);

  function handleChange(apiKey: keyof NotificationConfig, value: boolean) {
    const updated = { ...localConfig, [apiKey]: value };
    setLocalConfig(updated);
    saveConfig(updated, {
      onError: () => {
        setLocalConfig(localConfig);
        toast.danger('알림 설정 저장에 실패했습니다.');
      },
    });
  }

  return (
    <div className="mypage-page">
      <MobileGnb />
      <ApplyGnb variant="simple" />
      <div
        style={{ minHeight: '100vh', background: '#fff', fontFamily: "'Pretendard', sans-serif" }}
      >
        <header
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: 12,
            padding: '16px 20px',
            borderBottom: '1px solid #eee',
          }}
        >
          <button
            type="button"
            onClick={() => navigate(-1)}
            style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 4 }}
            aria-label="뒤로가기"
          >
            <svg viewBox="0 0 24 24" width="24" height="24" fill="#121212">
              <path d="M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z" />
            </svg>
          </button>
          <h1 style={{ fontSize: 18, fontWeight: 600, color: '#121212', margin: 0 }}>알림 설정</h1>
        </header>

        <main style={{ padding: '24px 20px', maxWidth: 600, margin: '0 auto' }}>
          <p style={{ fontSize: 14, color: '#a4a4a4', marginBottom: 32 }}>
            새로운 케어 요청과 수익이 되는 기회들을 놓치지 않도록 알림을 설정하세요.
          </p>

          {isLoading ? (
            <p style={{ color: '#a4a4a4', fontSize: 14 }}>불러오는 중...</p>
          ) : (
            <div>
              {NOTIFICATION_ITEMS.map(({ apiKey, label }) => (
                <div
                  key={apiKey}
                  style={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    padding: '20px 0',
                    borderBottom: '1px solid #f0f0f0',
                  }}
                >
                  <span style={{ fontSize: 15, color: '#121212', fontWeight: 500 }}>{label}</span>
                  <Toggle
                    checked={localConfig[apiKey]}
                    onChange={(value) => handleChange(apiKey, value)}
                    label={label}
                  />
                </div>
              ))}
            </div>
          )}
        </main>
      </div>
      <SiteFooter />
    </div>
  );
}
