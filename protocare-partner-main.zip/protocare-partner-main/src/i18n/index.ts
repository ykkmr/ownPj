import { createContext, useContext, type ReactNode, createElement } from 'react';
import { ko, type TextDictionary } from './ko';

type SupportedLocale = 'ko';

const DICTIONARIES: Record<SupportedLocale, TextDictionary> = { ko };

interface I18nContextValue {
  locale: SupportedLocale;
  text: TextDictionary;
}

const I18nContext = createContext<I18nContextValue>({
  locale: 'ko',
  text: ko,
});

interface I18nProviderProps {
  locale?: SupportedLocale;
  children: ReactNode;
}

/**
 * 다국어 Provider. 기본값은 한국어이므로 생략해도 동작합니다.
 * 로케일 전환이 필요한 경우에만 앱 루트에 마운트합니다.
 */
export const I18nProvider = ({ locale = 'ko', children }: I18nProviderProps) =>
  createElement(I18nContext.Provider, { value: { locale, text: DICTIONARIES[locale] } }, children);

/**
 * 텍스트 딕셔너리와 보간 함수를 반환하는 훅.
 *
 * @example
 * const { text, t } = useText();
 * <p>{text.auth.login}</p>
 * <p>{t(text.auth.welcome, { name: '홍길동' })}</p> // → "홍길동님, 환영합니다!"
 */
export const useText = () => {
  const { text } = useContext(I18nContext);

  /**
   * 템플릿 문자열에서 {{key}} 플레이스홀더를 치환합니다.
   * PHI 포함 가능성이 있는 변수는 서버 렌더링 전 마스킹 처리 후 전달하세요.
   */
  const t = (template: string, vars: Record<string, string>): string =>
    Object.entries(vars).reduce(
      (acc, [key, value]) => acc.replace(new RegExp(`\\{\\{${key}\\}\\}`, 'g'), value),
      template
    );

  return { text, t };
};