/**
 * 한국어 텍스트 딕셔너리.
 * 서비스 문구를 변경할 때는 이 파일만 수정합니다.
 * 글로벌 진출 시 en.ts, ja.ts 등 동일 구조의 파일을 추가합니다.
 */
export const ko = {
  common: {
    confirm: '확인',
    cancel: '취소',
    close: '닫기',
    back: '뒤로가기',
    save: '저장',
    delete: '삭제',
    edit: '수정',
    loading: '불러오는 중...',
    retry: '다시 시도',
    error: '오류가 발생했습니다.',
    required: '필수 입력 항목입니다.',
    seeAll: '전체보기',
  },

  auth: {
    login: '로그인',
    logout: '로그아웃',
    signup: '회원가입',
    id: '아이디',
    password: '비밀번호',
    passwordConfirm: '비밀번호 확인',
    name: '이름',
    email: '이메일',
    phone: '휴대폰 번호',
    verificationCode: '인증번호',
    requestCode: '인증요청',
    verifyComplete: '인증 완료',
    noAccount: '아직 계정이 없으신가요?',
    signupCta: '서포터 회원가입하기',
    loginTitle: '서포터 로그인',
    signupTitle: '회원가입',
    infoInputTitle: '정보 입력',
    signupCompleteTitle: '가입 완료',
    welcome: '{{name}}님, 환영합니다!',
    welcomeDesc: '이제 서포터로서 환자분들께 따뜻한 동행을 선사하실 수 있습니다.',
    codeSent: '인증번호가 발송되었습니다.',
    codeError: '발송 실패. 번호를 확인해 주세요.',
    verifySuccess: '인증에 성공했습니다.',
    logoutError: '로그아웃 중 문제가 발생했습니다.',
  },

  validation: {
    required: '{{field}}을(를) 입력해 주세요.',
    emailFormat: '올바른 이메일 형식이 아닙니다.',
    minLength: '{{min}}자리 이상 입력해 주세요.',
    passwordMismatch: '비밀번호가 일치하지 않습니다.',
    phoneFormat: '올바른 휴대폰 번호 형식이 아닙니다.',
    checkForm: '입력 정보를 다시 확인해 주세요.',
  },

  network: {
    offline: '오프라인 상태입니다. 인터넷 연결을 확인해 주세요.',
    restored: '인터넷 연결이 복구되었습니다.',
  },

  permission: {
    denied: '접근 권한이 없습니다.',
    loginRequired: '로그인이 필요한 서비스입니다.',
  },

  home: {
    greeting: '{{name}} 서포터님',
    subGreeting: '오늘도 따뜻한 하루 되세요!',
    monthlyEarnings: '이번 달 수익',
    activeHours: '활동 시간',
    todaySchedule: '오늘의 일정',
    matched: '매칭 완료',
    matching: '매칭 중',
    educationCta: '파트너 교육 이수하기',
    myInfoCta: '내 정보 / 정산 계좌 관리',
    guest: '게스트',
  },

  errors: {
    generic: '알 수 없는 오류가 발생했습니다.',
    network: '네트워크 연결을 확인해 주세요.',
    unauthorized: '인증이 만료되었습니다. 다시 로그인해 주세요.',
    forbidden: '접근 권한이 없습니다.',
    notFound: '요청하신 정보를 찾을 수 없습니다.',
    serverError: '서버에 일시적인 문제가 발생했습니다. 잠시 후 다시 시도해 주세요.',
  },
} as const;

export type TextDictionary = typeof ko;