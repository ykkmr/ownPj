import { useState, useEffect } from 'react';

/**
 * 값이 변경된 후 delayMs 동안 추가 변경이 없으면 업데이트된 값을 반환.
 * 검색 입력 디바운싱, API 호출 빈도 제한 등에 사용.
 * @example
 *   const debouncedSearch = useDebounce(searchTerm, 300);
 *   useEffect(() => { fetchResults(debouncedSearch); }, [debouncedSearch]);
 */
export const useDebounce = <T>(value: T, delayMs = 300): T => {
  const [debounced, setDebounced] = useState<T>(value);

  useEffect(() => {
    const timer = setTimeout(() => setDebounced(value), delayMs);
    return () => clearTimeout(timer);
  }, [value, delayMs]);

  return debounced;
};
