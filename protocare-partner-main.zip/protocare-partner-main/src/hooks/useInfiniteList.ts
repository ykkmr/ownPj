import { useEffect, useMemo } from 'react';
import { useInfiniteQuery, type QueryKey } from '@tanstack/react-query';
import { useIntersectionObserver } from './useIntersectionObserver';

/** PaginatedResponse<T>.data 에서 무한 스크롤에 필요한 최소 필드 */
interface PageSlice<T> {
  content: T[];
  hasNext: boolean;
  page: number;
}

interface UseInfiniteListOptions<T> {
  queryKey: QueryKey;
  /** { page: 0-indexed, size } 를 받아 한 페이지 데이터를 반환하는 함수 */
  queryFn: (params: { page: number; size: number }) => Promise<PageSlice<T>>;
  /** 페이지당 항목 수 (기본값: 20) */
  size?: number;
  enabled?: boolean;
}

interface UseInfiniteListResult<T> {
  /** 전체 페이지의 content를 단일 배열로 합친 결과 */
  items: T[];
  /** 무한 스크롤 트리거용 sentinel ref — 리스트 맨 아래 빈 div에 연결 */
  sentinelRef: React.RefObject<HTMLDivElement | null>;
  hasNextPage: boolean;
  isFetchingNextPage: boolean;
  isLoading: boolean;
  isError: boolean;
  error: Error | null;
}

/**
 * useInfiniteQuery + useIntersectionObserver를 합성한 무한 스크롤 훅.
 * sentinel div가 뷰포트에 진입하면 자동으로 다음 페이지를 요청.
 *
 * @example
 *   const { items, sentinelRef, isFetchingNextPage } = useInfiniteList({
 *     queryKey: COMMUNITY_KEYS.list(filters),
 *     queryFn: ({ page, size }) => communityApi.getPosts({ page, size }),
 *   });
 *   return (
 *     <>
 *       {items.map((post) => <PostCard key={post.id} post={post} />)}
 *       <div ref={sentinelRef} />
 *       {isFetchingNextPage && <Spinner />}
 *     </>
 *   );
 */
export const useInfiniteList = <T>({
  queryKey,
  queryFn,
  size = 20,
  enabled = true,
}: UseInfiniteListOptions<T>): UseInfiniteListResult<T> => {
  const { data, fetchNextPage, hasNextPage, isFetchingNextPage, isLoading, isError, error } =
    useInfiniteQuery({
      queryKey,
      queryFn: ({ pageParam }) => queryFn({ page: Number(pageParam), size }),
      initialPageParam: 0,
      getNextPageParam: (lastPage: PageSlice<T>) =>
        lastPage.hasNext ? lastPage.page + 1 : undefined,
      enabled,
    });

  const [sentinelRef, isSentinelVisible] = useIntersectionObserver<HTMLDivElement>({
    threshold: 0.1,
  });

  useEffect(() => {
    if (isSentinelVisible && hasNextPage && !isFetchingNextPage) {
      fetchNextPage();
    }
  }, [isSentinelVisible, hasNextPage, isFetchingNextPage, fetchNextPage]);

  const items = useMemo(() => data?.pages.flatMap((page) => page.content) ?? [], [data]);

  return {
    items,
    sentinelRef,
    hasNextPage,
    isFetchingNextPage,
    isLoading,
    isError,
    error: error as Error | null,
  };
};
