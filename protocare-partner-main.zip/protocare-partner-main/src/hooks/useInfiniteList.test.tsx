// @vitest-environment jsdom
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { renderHook, waitFor } from '@testing-library/react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import React from 'react';
import { useInfiniteList } from './useInfiniteList';

// vi.fn() 화살표 함수는 new로 생성 불가 → class mock 사용
beforeEach(() => {
  class MockIntersectionObserver {
    observe = vi.fn();
    disconnect = vi.fn();
    unobserve = vi.fn();
    constructor(_cb: unknown) {}
  }
  vi.stubGlobal('IntersectionObserver', MockIntersectionObserver);
});

const makeWrapper = () => {
  const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
  const Wrapper = ({ children }: { children: React.ReactNode }) =>
    React.createElement(QueryClientProvider, { client: qc }, children);
  return Wrapper;
};

const makePage = (content: number[], hasNext: boolean, page: number) => ({
  content,
  hasNext,
  page,
});

describe('useInfiniteList', () => {
  it('초기 로딩 중 items는 빈 배열, isLoading=true', () => {
    const queryFn = vi.fn(
      () => new Promise<{ content: number[]; hasNext: boolean; page: number }>(() => {}),
    );
    const { result } = renderHook(() => useInfiniteList({ queryKey: ['test-loading'], queryFn }), {
      wrapper: makeWrapper(),
    });
    expect(result.current.items).toEqual([]);
    expect(result.current.isLoading).toBe(true);
  });

  it('페이지 content를 단일 배열로 평탄화', async () => {
    const queryFn = vi.fn().mockResolvedValue(makePage([10, 20, 30], false, 0));
    const { result } = renderHook(() => useInfiniteList({ queryKey: ['test-flat'], queryFn }), {
      wrapper: makeWrapper(),
    });
    await waitFor(() => expect(result.current.items).toHaveLength(3));
    expect(result.current.items).toEqual([10, 20, 30]);
  });

  it('hasNext=false이면 hasNextPage=false', async () => {
    const queryFn = vi.fn().mockResolvedValue(makePage([1], false, 0));
    const { result } = renderHook(() => useInfiniteList({ queryKey: ['test-no-next'], queryFn }), {
      wrapper: makeWrapper(),
    });
    await waitFor(() => expect(result.current.isLoading).toBe(false));
    expect(result.current.hasNextPage).toBe(false);
  });

  it('hasNext=true이면 hasNextPage=true', async () => {
    const queryFn = vi.fn().mockResolvedValue(makePage([1], true, 0));
    const { result } = renderHook(() => useInfiniteList({ queryKey: ['test-has-next'], queryFn }), {
      wrapper: makeWrapper(),
    });
    await waitFor(() => expect(result.current.isLoading).toBe(false));
    expect(result.current.hasNextPage).toBe(true);
  });

  it('queryFn 오류 시 isError=true, error 반환', async () => {
    const queryFn = vi.fn().mockRejectedValue(new Error('fetch failed'));
    const { result } = renderHook(() => useInfiniteList({ queryKey: ['test-error'], queryFn }), {
      wrapper: makeWrapper(),
    });
    await waitFor(() => expect(result.current.isError).toBe(true));
    expect(result.current.error?.message).toBe('fetch failed');
  });

  it('enabled=false이면 queryFn 미호출', () => {
    const queryFn = vi.fn();
    renderHook(() => useInfiniteList({ queryKey: ['test-disabled'], queryFn, enabled: false }), {
      wrapper: makeWrapper(),
    });
    expect(queryFn).not.toHaveBeenCalled();
  });

  it('queryFn에 { page: 0, size } 형태로 첫 페이지 요청', async () => {
    const queryFn = vi.fn().mockResolvedValue(makePage([], false, 0));
    renderHook(() => useInfiniteList({ queryKey: ['test-params'], queryFn, size: 15 }), {
      wrapper: makeWrapper(),
    });
    await waitFor(() => expect(queryFn).toHaveBeenCalled());
    expect(queryFn).toHaveBeenCalledWith({ page: 0, size: 15 });
  });

  it('sentinelRef가 HTMLDivElement ref 형태로 반환', () => {
    const queryFn = vi.fn(
      () => new Promise<{ content: number[]; hasNext: boolean; page: number }>(() => {}),
    );
    const { result } = renderHook(() => useInfiniteList({ queryKey: ['test-sentinel'], queryFn }), {
      wrapper: makeWrapper(),
    });
    expect(result.current.sentinelRef).toHaveProperty('current');
  });
});
