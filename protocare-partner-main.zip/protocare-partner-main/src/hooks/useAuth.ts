import { useMutation } from '@tanstack/react-query';
import {
  mobileAuthService,
  authService,
  type SupporterSignupPayload,
} from '@/services/api/auth.service';
import { toast } from '@/store/toast.store';
import { useNavigate } from 'react-router-dom';
import { useEffect, useState } from 'react';

const SMS_COOLDOWN_SECONDS = 60;

export const useAuthActions = () => {
  const [timeLeft, setTimeLeft] = useState(0);

  useEffect(() => {
    if (timeLeft <= 0) return;
    const timerId = setInterval(() => setTimeLeft((prev) => prev - 1), 1000);
    return () => clearInterval(timerId);
  }, [timeLeft]);

  const sendCodeMutation = useMutation({
    mutationFn: (phoneNumber: string) => mobileAuthService.sendSms(phoneNumber, 'SIGNUP'),
    onSuccess: () => {
      toast.success('인증번호가 발송되었습니다. (60초 내 입력)');
      setTimeLeft(SMS_COOLDOWN_SECONDS);
    },
    onError: (err: any) => {
      toast.danger(err.response?.data?.message || 'SMS 발송에 실패했습니다.');
    },
  });

  const verifyCodeMutation = useMutation({
    mutationFn: (payload: { phoneNumber: string; code: string }) =>
      mobileAuthService.verifySms(payload.phoneNumber, 'SIGNUP', payload.code),
    onSuccess: () => {
      toast.success('인증이 완료되었습니다.');
      setTimeLeft(0);
    },
    onError: (err: any) => {
      toast.danger(err.response?.data?.message || '인증번호가 올바르지 않습니다.');
    },
  });

  return {
    handleSendCode: (phoneNumber: string) => sendCodeMutation.mutate(phoneNumber),
    verifyCode: verifyCodeMutation,
    timeLeft,
    isSending: sendCodeMutation.isPending,
    isVerifying: verifyCodeMutation.isPending,
  };
};

export const useSignup = () => {
  const navigate = useNavigate();

  return useMutation({
    mutationFn: (payload: SupporterSignupPayload) => authService.signup(payload),
    onSuccess: () => {
      toast.success('가입이 완료되었습니다. 로그인을 진행해주세요.');
      navigate('/login', { replace: true });
    },
    onError: (err: any) => {
      const fieldErrors = err.response?.data?.fieldErrors as
        | Array<{ field: string; message: string }>
        | undefined;
      const firstFieldError = fieldErrors?.[0]?.message;
      toast.danger(
        firstFieldError || err.response?.data?.message || '회원가입 처리 중 오류가 발생했습니다.',
      );
    },
  });
};
