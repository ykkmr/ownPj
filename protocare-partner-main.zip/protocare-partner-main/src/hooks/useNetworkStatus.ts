import { useEffect, useState } from 'react';

export interface NetworkStatus {
  isOnline: boolean;
}

/**
 * 브라우저 온라인/오프라인 상태를 구독하는 훅.
 * navigator.onLine 초기값 + online/offline 이벤트로 실시간 반영합니다.
 */
export const useNetworkStatus = (): NetworkStatus => {
  const [isOnline, setIsOnline] = useState(() => navigator.onLine);

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  return { isOnline };
};