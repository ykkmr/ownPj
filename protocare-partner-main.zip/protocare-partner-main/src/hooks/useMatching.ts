import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { matchingApi } from '@/services/api/matching';
import type {
  MatchingListParams,
  CareLogListParams,
  CreateCareLogBody,
} from '@/services/api/matching';

export const MATCHING_KEYS = {
  all: ['matchings'] as const,
  list: (params?: MatchingListParams) => [...MATCHING_KEYS.all, 'list', params] as const,
  detail: (id: number) => [...MATCHING_KEYS.all, 'detail', id] as const,
  schedules: (id: number) => [...MATCHING_KEYS.all, 'schedules', id] as const,
  logs: (id: number, params?: CareLogListParams) =>
    [...MATCHING_KEYS.all, 'logs', id, params] as const,
};

export const useMatchingList = (params?: MatchingListParams) =>
  useQuery({
    queryKey: MATCHING_KEYS.list(params),
    queryFn: () => matchingApi.getList(params),
  });

export const useMatching = (id: number) =>
  useQuery({
    queryKey: MATCHING_KEYS.detail(id),
    queryFn: () => matchingApi.getOne(id),
    enabled: !!id,
  });

export const useMatchingSchedules = (id: number) =>
  useQuery({
    queryKey: MATCHING_KEYS.schedules(id),
    queryFn: () => matchingApi.getSchedules(id),
    enabled: !!id,
  });

export const useCareLogs = (id: number, params?: CareLogListParams) =>
  useQuery({
    queryKey: MATCHING_KEYS.logs(id, params),
    queryFn: () => matchingApi.getLogs(id, params),
    enabled: !!id,
  });

export const useCreateCareLog = (matchingId: number) => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (body: CreateCareLogBody) => matchingApi.createLog(matchingId, body),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: MATCHING_KEYS.logs(matchingId) });
    },
  });
};

export const useStartMatching = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (id: number) => matchingApi.start(id),
    onSuccess: (_, id) => {
      queryClient.invalidateQueries({ queryKey: MATCHING_KEYS.detail(id) });
      queryClient.invalidateQueries({ queryKey: MATCHING_KEYS.list() });
    },
  });
};

export const useCompleteMatching = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (id: number) => matchingApi.complete(id),
    onSuccess: (_, id) => {
      queryClient.invalidateQueries({ queryKey: MATCHING_KEYS.detail(id) });
      queryClient.invalidateQueries({ queryKey: MATCHING_KEYS.list() });
    },
  });
};
