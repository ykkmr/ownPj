import { useEffect } from 'react';
import { useAuthStore } from '@/store/auth.store';
import { ROUTES } from '@/constants/routes';

const SESSION_TIMEOUT_MS = 15 * 60 * 1_000;
const ACTIVITY_EVENTS = ['mousemove', 'keydown', 'click', 'touchstart', 'scroll'] as const;

export const useSessionTimeout = (): void => {
  const isAuthenticated = useAuthStore((s) => s.isAuthenticated);
  const logout = useAuthStore((s) => s.logout);

  useEffect(() => {
    if (!isAuthenticated) return;

    let timeoutId: ReturnType<typeof setTimeout>;

    const resetTimeout = () => {
      clearTimeout(timeoutId);
      timeoutId = setTimeout(() => {
        logout();
        window.location.assign(`${ROUTES.login}?reason=session_expired`);
      }, SESSION_TIMEOUT_MS);
    };

    ACTIVITY_EVENTS.forEach((event) => {
      window.addEventListener(event, resetTimeout, { passive: true });
    });
    resetTimeout();

    return () => {
      clearTimeout(timeoutId);
      ACTIVITY_EVENTS.forEach((event) => {
        window.removeEventListener(event, resetTimeout);
      });
    };
  }, [isAuthenticated, logout]);
};
