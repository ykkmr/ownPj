import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supporterApplicationApi } from '@/services/api/supporterApplication';
import type { SaveCareTypeBody } from '@/services/api/supporterApplication';
import type { BasicInfoRequest, CertificationType, TermsRequest } from '@/types/api';

export const APPLICATION_KEYS = {
  all: ['supporterApplication'] as const,
  overview: () => [...APPLICATION_KEYS.all, 'overview'] as const,
  terms: () => [...APPLICATION_KEYS.all, 'terms'] as const,
  basicInfo: () => [...APPLICATION_KEYS.all, 'basicInfo'] as const,
  careType: () => [...APPLICATION_KEYS.all, 'careType'] as const,
  qualifications: () => [...APPLICATION_KEYS.all, 'qualifications'] as const,
};

export const useApplicationOverview = () =>
  useQuery({
    queryKey: APPLICATION_KEYS.overview(),
    queryFn: () => supporterApplicationApi.getOverview(),
  });

export const useInitApplication = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: () => supporterApplicationApi.init(),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: APPLICATION_KEYS.overview() });
    },
  });
};

export const useApplicationTerms = () =>
  useQuery({
    queryKey: APPLICATION_KEYS.terms(),
    queryFn: () => supporterApplicationApi.getTerms(),
  });

export const useSaveTerms = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (body: TermsRequest) => supporterApplicationApi.saveTerms(body),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: APPLICATION_KEYS.terms() });
      queryClient.invalidateQueries({ queryKey: APPLICATION_KEYS.overview() });
    },
  });
};

export const useApplicationBasicInfo = () =>
  useQuery({
    queryKey: APPLICATION_KEYS.basicInfo(),
    queryFn: () => supporterApplicationApi.getBasicInfo(),
  });

export const useUpdateBasicInfo = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (body: BasicInfoRequest) => supporterApplicationApi.updateBasicInfo(body),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: APPLICATION_KEYS.basicInfo() });
      queryClient.invalidateQueries({ queryKey: APPLICATION_KEYS.overview() });
    },
  });
};

export const useUploadProfileImage = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (file: File) => supporterApplicationApi.uploadProfileImage(file),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: APPLICATION_KEYS.basicInfo() });
    },
  });
};

export const useApplicationCareType = () =>
  useQuery({
    queryKey: APPLICATION_KEYS.careType(),
    queryFn: () => supporterApplicationApi.getCareType(),
  });

export const useUpdateCareType = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (body: SaveCareTypeBody) => supporterApplicationApi.updateCareType(body),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: APPLICATION_KEYS.careType() });
      queryClient.invalidateQueries({ queryKey: APPLICATION_KEYS.overview() });
    },
  });
};

export const useApplicationQualifications = () =>
  useQuery({
    queryKey: APPLICATION_KEYS.qualifications(),
    queryFn: () => supporterApplicationApi.getQualifications(),
  });

export const useUploadApplicationCertification = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (body: {
      file: File;
      certificationType: CertificationType;
      certificationNumber?: string;
      issuer?: string;
      issuedAt?: string;
    }) => supporterApplicationApi.uploadCertification(body),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: APPLICATION_KEYS.qualifications() });
      queryClient.invalidateQueries({ queryKey: APPLICATION_KEYS.overview() });
    },
  });
};

export const useUploadApplicationCriminalRecord = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({
      file,
      sexCrimeConsentAgreed,
    }: {
      file: File;
      sexCrimeConsentAgreed?: boolean;
    }) => supporterApplicationApi.uploadCriminalRecord(file, sexCrimeConsentAgreed),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: APPLICATION_KEYS.qualifications() });
      queryClient.invalidateQueries({ queryKey: APPLICATION_KEYS.overview() });
    },
  });
};

export const useSubmitApplication = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: () => supporterApplicationApi.submit(),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: APPLICATION_KEYS.overview() });
    },
  });
};
