import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supporterApi } from '@/services/api/supporter';
import type {
  UpdateSupporterProfileBody,
  CertificationUploadBody,
  SaveTagsBody,
} from '@/services/api/supporter';
import type { NotificationConfig } from '@/types/api';

export type { CertificationUploadBody as UploadCertificationBody };

export const SUPPORTER_KEYS = {
  all: ['supporter'] as const,
  profile: () => [...SUPPORTER_KEYS.all, 'profile'] as const,
  certifications: () => [...SUPPORTER_KEYS.all, 'certifications'] as const,
  earnings: () => [...SUPPORTER_KEYS.all, 'earnings'] as const,
  training: () => [...SUPPORTER_KEYS.all, 'training'] as const,
};

export const useSupporterProfile = () =>
  useQuery({
    queryKey: SUPPORTER_KEYS.profile(),
    queryFn: () => supporterApi.getProfile(),
  });

export const useUpdateSupporterProfile = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (body: UpdateSupporterProfileBody) => supporterApi.updateProfile(body),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: SUPPORTER_KEYS.profile() });
    },
  });
};

export const useCertifications = () =>
  useQuery({
    queryKey: SUPPORTER_KEYS.certifications(),
    queryFn: () => supporterApi.getCertifications(),
  });

export const useUploadCertification = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (body: CertificationUploadBody) => supporterApi.uploadCertification(body),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: SUPPORTER_KEYS.certifications() });
    },
  });
};

export const useSupporterEarnings = () =>
  useQuery({
    queryKey: SUPPORTER_KEYS.earnings(),
    queryFn: () => supporterApi.getEarnings(),
  });

export const useTrainingList = () =>
  useQuery({
    queryKey: SUPPORTER_KEYS.training(),
    queryFn: () => supporterApi.getTraining(),
  });

export const useUpdateTrainingProgress = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, progress }: { id: number; progress: number }) =>
      supporterApi.updateTrainingProgress(id, progress),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: SUPPORTER_KEYS.training() });
    },
  });
};

// ── Personality Tags ──────────────────────────────────────────
export const usePersonalityTags = () =>
  useQuery({
    queryKey: [...SUPPORTER_KEYS.all, 'personality-tags'] as const,
    queryFn: () => supporterApi.getPersonalityTags(),
  });

export const useUpdatePersonalityTags = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (body: SaveTagsBody) => supporterApi.updatePersonalityTags(body),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [...SUPPORTER_KEYS.all, 'personality-tags'] });
    },
  });
};

// ── Notification Configs ──────────────────────────────────────
export const useNotificationConfigs = () =>
  useQuery({
    queryKey: [...SUPPORTER_KEYS.all, 'notification-configs'] as const,
    queryFn: () => supporterApi.getNotificationConfigs(),
  });

export const useUpdateNotificationConfigs = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (body: NotificationConfig) => supporterApi.updateNotificationConfigs(body),
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: [...SUPPORTER_KEYS.all, 'notification-configs'],
      });
    },
  });
};

// ── Certification verify ──────────────────────────────────────
export const useVerifyCertification = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (certId: number) => supporterApi.verifyCertification(certId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: SUPPORTER_KEYS.certifications() });
    },
  });
};

// ── Criminal Record ───────────────────────────────────────────
export const useUploadCriminalRecord = () =>
  useMutation({
    mutationFn: ({
      file,
      sexCrimeConsentAgreed,
    }: {
      file: File;
      sexCrimeConsentAgreed?: boolean;
    }) => supporterApi.uploadCriminalRecord(file, sexCrimeConsentAgreed),
  });
