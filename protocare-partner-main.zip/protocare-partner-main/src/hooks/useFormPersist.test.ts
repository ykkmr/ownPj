// @vitest-environment jsdom
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { renderHook, act } from '@testing-library/react';
import { z } from 'zod';
import { useFormPersist } from './useFormPersist';

const KEY = 'test-form-persist';

describe('useFormPersist', () => {
  beforeEach(() => {
    vi.useFakeTimers();
    sessionStorage.clear();
  });
  afterEach(() => vi.useRealTimers());

  it('저장된 draft가 없으면 setValue 미호출', () => {
    const setValue = vi.fn();
    renderHook(() => useFormPersist({ key: KEY, watch: { email: '' }, setValue }));
    expect(setValue).not.toHaveBeenCalled();
  });

  it('저장된 draft가 있으면 마운트 시 복원', () => {
    sessionStorage.setItem(KEY, JSON.stringify({ email: 'saved@test.com' }));
    const setValue = vi.fn();
    renderHook(() => useFormPersist({ key: KEY, watch: { email: '' }, setValue }));
    expect(setValue).toHaveBeenCalledWith({ email: 'saved@test.com' });
  });

  it('throttle(100ms) 후 최신 watch 값 저장', () => {
    const { rerender } = renderHook(
      ({ watch }) => useFormPersist({ key: KEY, watch, setValue: vi.fn() }),
      { initialProps: { watch: { email: 'first@test.com' } } },
    );

    act(() => vi.advanceTimersByTime(100));
    expect(JSON.parse(sessionStorage.getItem(KEY)!)).toEqual({ email: 'first@test.com' });

    rerender({ watch: { email: 'second@test.com' } });
    expect(JSON.parse(sessionStorage.getItem(KEY)!)).toEqual({ email: 'first@test.com' });

    act(() => vi.advanceTimersByTime(100));
    expect(JSON.parse(sessionStorage.getItem(KEY)!)).toEqual({ email: 'second@test.com' });
  });

  it('연속 변경 시 마지막 값만 저장 (debounce 효과)', () => {
    const { rerender } = renderHook(
      ({ watch }) => useFormPersist({ key: KEY, watch, setValue: vi.fn() }),
      { initialProps: { watch: { email: 'a@test.com' } } },
    );

    rerender({ watch: { email: 'b@test.com' } });
    act(() => vi.advanceTimersByTime(50));
    rerender({ watch: { email: 'c@test.com' } });
    act(() => vi.advanceTimersByTime(100));

    expect(JSON.parse(sessionStorage.getItem(KEY)!)).toEqual({ email: 'c@test.com' });
  });

  it('sensitiveFields는 저장에서 제외 (PHI 보호)', () => {
    renderHook(() =>
      useFormPersist({
        key: KEY,
        watch: { email: 'user@test.com', password: 'secret123' },
        setValue: vi.fn(),
        sensitiveFields: ['password'],
      }),
    );
    act(() => vi.advanceTimersByTime(100));
    const saved = JSON.parse(sessionStorage.getItem(KEY)!);
    expect(saved.email).toBe('user@test.com');
    expect(saved.password).toBeUndefined();
  });

  it('clearDraft는 sessionStorage에서 항목 삭제', () => {
    sessionStorage.setItem(KEY, JSON.stringify({ email: 'x@y.com' }));
    const { result } = renderHook(() =>
      useFormPersist({ key: KEY, watch: { email: '' }, setValue: vi.fn() }),
    );
    act(() => result.current.clearDraft());
    expect(sessionStorage.getItem(KEY)).toBeNull();
  });

  it('JSON 파싱 실패 시 draft 삭제 후 setValue 미호출', () => {
    sessionStorage.setItem(KEY, 'not-valid-json{{');
    const setValue = vi.fn();
    renderHook(() => useFormPersist({ key: KEY, watch: { email: '' }, setValue }));
    expect(setValue).not.toHaveBeenCalled();
    expect(sessionStorage.getItem(KEY)).toBeNull();
  });

  it('schema 검증 실패 시 draft 삭제 후 setValue 미호출', () => {
    sessionStorage.setItem(KEY, JSON.stringify({ email: 'not-an-email', password: 'short' }));
    const setValue = vi.fn();
    const schema = z.object({ email: z.string().email(), password: z.string().min(8) });
    renderHook(() =>
      useFormPersist({ key: KEY, watch: { email: '', password: '' }, setValue, schema }),
    );
    expect(setValue).not.toHaveBeenCalled();
    expect(sessionStorage.getItem(KEY)).toBeNull();
  });

  it('schema 검증 통과 시 파싱된 값으로 복원', () => {
    sessionStorage.setItem(KEY, JSON.stringify({ email: 'valid@test.com', password: 'longpass1' }));
    const setValue = vi.fn();
    const schema = z.object({ email: z.string().email(), password: z.string().min(8) });
    renderHook(() =>
      useFormPersist({ key: KEY, watch: { email: '', password: '' }, setValue, schema }),
    );
    expect(setValue).toHaveBeenCalledWith({ email: 'valid@test.com', password: 'longpass1' });
  });

  it('언마운트 시 보류 중인 타이머 취소', () => {
    const setItemSpy = vi.spyOn(Storage.prototype, 'setItem');
    const { unmount } = renderHook(() =>
      useFormPersist({ key: KEY, watch: { email: 'a@test.com' }, setValue: vi.fn() }),
    );
    unmount();
    act(() => vi.advanceTimersByTime(200));
    expect(setItemSpy).not.toHaveBeenCalled();
    setItemSpy.mockRestore();
  });
});
