import { useMemo } from 'react';

export interface RawPrescriptionData {
  rawText?: string | null;
  medications?: Array<{
    name?: string;
    dosage?: string;
    frequency?: string;
    duration?: string;
    notes?: string;
  }> | null;
  warnings?: string[] | null;
  summary?: string | null;
}

export interface ParsedMedication {
  name: string;
  dosage: string;
  frequency: string;
  duration: string;
  notes: string;
}

export interface ParsedPrescription {
  medications: ParsedMedication[];
  warnings: string[];
  summary: string;
  isEmpty: boolean;
}

const normalizeMedication = (
  raw: NonNullable<RawPrescriptionData['medications']>[number],
): ParsedMedication => ({
  name: raw.name ?? '알 수 없음',
  dosage: raw.dosage ?? '-',
  frequency: raw.frequency ?? '-',
  duration: raw.duration ?? '-',
  notes: raw.notes ?? '',
});

/**
 * AI 분석 응답(RawPrescriptionData)을 UI 표시용 구조로 정규화.
 * null/undefined 필드를 안전한 기본값으로 채워 컴포넌트가 방어 코드를 쓸 필요 없도록 함.
 */
export const usePrescriptionParser = (
  data: RawPrescriptionData | null | undefined,
): ParsedPrescription => {
  return useMemo(() => {
    if (!data) {
      return { medications: [], warnings: [], summary: '', isEmpty: true };
    }

    const medications = (data.medications ?? []).map(normalizeMedication);
    const warnings = (data.warnings ?? []).filter(Boolean);
    const summary = data.summary ?? data.rawText ?? '';

    return {
      medications,
      warnings,
      summary,
      isEmpty: medications.length === 0 && warnings.length === 0 && !summary,
    };
  }, [data]);
};
