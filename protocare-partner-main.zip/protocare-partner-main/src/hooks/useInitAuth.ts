import { useEffect, useRef, useState } from 'react';
import { authService } from '@/services/api/auth.service';
import { tokenStorage } from '@/services/api/tokenStorage';
import { useAuthStore } from '@/store/auth.store';
import { UnauthorizedError } from '@/services/api/errors';
import { AuthUser } from '@/types/domain';

/**
 * 앱 최초 마운트 시 세션 복구.
 * - Access Token은 인메모리 → 새로고침 시 소멸
 * - getMe() 호출 시 401이면 Axios 인터셉터가 /auth/refresh(HttpOnly 쿠키)로 자동 재발급
 * - Refresh Token도 없으면 미인증 상태 유지 (로그인 페이지 이동은 RequireAuth가 담당)
 */

export const useInitAuth = (): { isInitializing: boolean } => {
  const [isInitializing, setIsInitializing] = useState(true);
  const login = useAuthStore((s) => s.login);
  const didRun = useRef(false);

  useEffect(() => {
    if (didRun.current) return;
    didRun.current = true;

    authService
      .getMe()
.then((user) => {
  const token = tokenStorage.get();
  // user 객체를 AuthUser 타입으로 강제 형변환하여 전달
  if (token) login(user as AuthUser, token); 
})
      .catch((error: unknown) => {
        if (error instanceof UnauthorizedError) return;
        console.warn('[useInitAuth] 세션 복구 불가:', error);
      })
      .finally(() => {
        setIsInitializing(false);
      });
  }, [login]);

  return { isInitializing };
};
