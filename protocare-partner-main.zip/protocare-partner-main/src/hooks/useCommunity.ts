import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { communityApi } from '@/services/api/community';
import type {
  CommunityPostListParams,
  CreatePostBody,
  CreateCommentBody,
} from '@/services/api/community';
import type { CommunityComment } from '@/types';

export const COMMUNITY_KEYS = {
  all: ['community'] as const,
  posts: (params?: CommunityPostListParams) => [...COMMUNITY_KEYS.all, 'posts', params] as const,
  post: (id: number) => [...COMMUNITY_KEYS.all, 'post', id] as const,
  comments: (postId: number) => [...COMMUNITY_KEYS.all, 'comments', postId] as const,
};

export const useCommunityPosts = (params?: CommunityPostListParams) =>
  useQuery({
    queryKey: COMMUNITY_KEYS.posts(params),
    queryFn: () => communityApi.getPosts(params),
  });

export const useCommunityPost = (id: number) =>
  useQuery({
    queryKey: COMMUNITY_KEYS.post(id),
    queryFn: () => communityApi.getPost(id),
    enabled: !!id,
  });

export const useCreatePost = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (body: CreatePostBody) => communityApi.createPost(body),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: COMMUNITY_KEYS.posts() });
    },
  });
};

export const useComments = (postId: number) =>
  useQuery({
    queryKey: COMMUNITY_KEYS.comments(postId),
    queryFn: () => communityApi.getComments(postId),
    enabled: !!postId,
  });

export const useCreateComment = (postId: number) => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (body: CreateCommentBody) => communityApi.createComment(postId, body),
    onMutate: async (body) => {
      await queryClient.cancelQueries({ queryKey: COMMUNITY_KEYS.comments(postId) });
      const previous = queryClient.getQueryData<CommunityComment[]>(
        COMMUNITY_KEYS.comments(postId),
      );

      const optimistic: CommunityComment = {
        id: Date.now(),
        postId,
        parentId: body.parentId ?? null,
        content: body.content,
        authorId: -1,
        isAnonymous: false,
        likeCount: 0,
        createdAt: new Date().toISOString(),
        updatedAt: null,
        createdBy: -1,
        updatedBy: null,
      };

      queryClient.setQueryData<CommunityComment[]>(COMMUNITY_KEYS.comments(postId), (old = []) => [
        ...old,
        optimistic,
      ]);

      return { previous };
    },
    onError: (_err, _body, context) => {
      queryClient.setQueryData(COMMUNITY_KEYS.comments(postId), context?.previous);
    },
    onSettled: () => {
      queryClient.invalidateQueries({ queryKey: COMMUNITY_KEYS.comments(postId) });
    },
  });
};
