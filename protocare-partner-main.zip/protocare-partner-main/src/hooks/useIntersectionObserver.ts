import { useEffect, useMemo, useRef, useState } from 'react';

interface UseIntersectionObserverOptions extends IntersectionObserverInit {
  /** true이면 최초 노출 후 observer를 해제해 불필요한 재계산 방지 */
  freezeOnceVisible?: boolean;
}

/**
 * IntersectionObserver를 React ref에 연결해 뷰포트 진입 여부를 반환.
 * 무한 스크롤 트리거, 지연 로딩 등에 사용.
 *
 * 주의: options 객체는 컴포넌트 외부 또는 useMemo로 안정화할 것.
 * threshold를 배열로 넘길 경우 반드시 useMemo로 감싸야 무한 재연결 방지.
 *
 * @example
 *   const [sentinelRef, isVisible] = useIntersectionObserver<HTMLDivElement>({ threshold: 0.1 });
 *   useEffect(() => { if (isVisible) fetchNextPage(); }, [isVisible]);
 *   return <div ref={sentinelRef} />;
 */
export const useIntersectionObserver = <T extends Element = Element>(
  options: UseIntersectionObserverOptions = {},
): [React.RefObject<T | null>, boolean] => {
  const { freezeOnceVisible = false, root, rootMargin, threshold } = options;
  const ref = useRef<T>(null);
  const [isIntersecting, setIsIntersecting] = useState(false);

  // threshold 배열의 참조 동일성 문제 해결: 값이 같으면 재연결하지 않음
  // eslint-disable-next-line react-hooks/exhaustive-deps
  const thresholdKey = useMemo(() => JSON.stringify(threshold), [threshold]);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  const stableThreshold = useMemo(() => threshold, [thresholdKey]);

  useEffect(() => {
    const element = ref.current;
    if (!element) return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        const visible = entry!.isIntersecting;
        setIsIntersecting(visible);
        if (visible && freezeOnceVisible) observer.disconnect();
      },
      { root, rootMargin, threshold: stableThreshold },
    );

    observer.observe(element);
    return () => observer.disconnect();
  }, [freezeOnceVisible, root, rootMargin, stableThreshold]);

  return [ref, isIntersecting];
};
