import { useEffect, useCallback, useRef } from 'react';
import type { ZodType } from 'zod';

const THROTTLE_MS = 100;

interface UseFormPersistOptions<T> {
  key: string;
  watch: T;
  setValue: (values: T) => void;
  /**
   * sessionStorage에 저장하지 않을 최상위 키 목록 (PHI 보호).
   * ⚠️ 최상위 키만 적용됨 — 중첩 PHI(예: `{ patient: { ssn } }`)는
   * 해당 최상위 키 전체를 포함할 것: `sensitiveFields: ['patient']`
   */
  sensitiveFields?: (keyof T)[];
  /**
   * 복원 시 구조 검증용 Zod 스키마.
   * 스키마 검증 실패 시 저장된 draft를 자동 삭제 — API 변경 후 구 데이터 오염 방지.
   */
  schema?: ZodType<T>;
}

interface UseFormPersistResult {
  clearDraft: () => void;
}

export const useFormPersist = <T extends Record<string, unknown>>({
  key,
  watch,
  setValue,
  sensitiveFields = [],
  schema,
}: UseFormPersistOptions<T>): UseFormPersistResult => {
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  // 인라인 배열·객체로 전달해도 항상 최신 값을 참조 — PHI 누출 방지 / 스키마 변경 대응
  const sensitiveFieldsRef = useRef(sensitiveFields);
  const schemaRef = useRef(schema);
  useEffect(() => {
    sensitiveFieldsRef.current = sensitiveFields;
    schemaRef.current = schema;
  });

  useEffect(() => {
    const saved = sessionStorage.getItem(key);
    if (!saved) return;
    try {
      const parsed = JSON.parse(saved);
      const currentSchema = schemaRef.current;
      if (currentSchema) {
        // 스키마 검증 실패 시 draft 삭제 — API 변경 후 구 데이터 오염 방지
        const result = currentSchema.safeParse(parsed);
        if (!result.success) {
          sessionStorage.removeItem(key);
          return;
        }
        setValue(result.data);
      } else {
        setValue(parsed as T);
      }
    } catch {
      sessionStorage.removeItem(key);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key]);

  useEffect(() => {
    if (timerRef.current) clearTimeout(timerRef.current);

    timerRef.current = setTimeout(() => {
      const safeData = { ...watch };
      sensitiveFieldsRef.current.forEach((field) => delete safeData[field]);
      sessionStorage.setItem(key, JSON.stringify(safeData));
    }, THROTTLE_MS);

    return () => {
      if (timerRef.current) {
        clearTimeout(timerRef.current);
        timerRef.current = null;
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key, watch]);

  const clearDraft = useCallback(() => {
    sessionStorage.removeItem(key);
  }, [key]);

  return { clearDraft };
};
