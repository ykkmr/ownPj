import { useAuthStore } from '@/store/auth.store';
import { ROLE_PERMISSIONS, type PermissionCode, type UserRole } from '@/types/domain';

interface UsePermissionReturn {
  role: UserRole | null;
  hasPermission: (code: PermissionCode) => boolean;
  hasAnyPermission: (codes: PermissionCode[]) => boolean;
  hasRole: (role: UserRole) => boolean;
}

/**
 * 현재 사용자의 역할과 권한을 확인하는 훅.
 * UI 레이어에서만 사용합니다 — 실제 데이터 접근 제어는 서버에서 수행합니다.
 */
export const usePermission = (): UsePermissionReturn => {
  const user = useAuthStore((s) => s.user);

  const hasPermission = (code: PermissionCode): boolean => {
    // return ROLE_PERMISSIONS[user.role]?.includes(code) ?? false;
    if (!user) return false;
    return ROLE_PERMISSIONS[user.role as UserRole]?.includes(code) ?? false;
  };

  const hasAnyPermission = (codes: PermissionCode[]): boolean =>
    codes.some(hasPermission);

  const hasRole = (role: UserRole): boolean => user?.role === role;

  return {
    role: user?.role ?? null,
    hasPermission,
    hasAnyPermission,
    hasRole,
  };
};