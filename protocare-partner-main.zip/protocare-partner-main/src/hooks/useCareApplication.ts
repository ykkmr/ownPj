import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { careApplicationApi } from '@/services/api/careApplication';
import type {
  CareApplicationListParams,
  ApplyCareRequestBody,
} from '@/services/api/careApplication';
import type { CareApplication, PaginatedResponse } from '@/types';
import { CARE_REQUEST_KEYS } from './useCareRequest';

type ApplicationPage = PaginatedResponse<CareApplication>['data'];

export const CARE_APPLICATION_KEYS = {
  all: ['care-applications'] as const,
  list: (params?: CareApplicationListParams) =>
    [...CARE_APPLICATION_KEYS.all, 'list', params] as const,
};

export const useCareApplicationList = (params?: CareApplicationListParams) =>
  useQuery({
    queryKey: CARE_APPLICATION_KEYS.list(params),
    queryFn: () => careApplicationApi.getList(params),
  });

export const useApplyCareRequest = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ careRequestId, body }: { careRequestId: number; body?: ApplyCareRequestBody }) =>
      careApplicationApi.apply(careRequestId, body),
    onMutate: async ({ careRequestId }) => {
      await queryClient.cancelQueries({ queryKey: CARE_APPLICATION_KEYS.all });

      // 파라미터 유무 관계없이 모든 목록 캐시 스냅샷 (SupporterHomePage의 { size: 5 } 포함)
      const snapshots = queryClient.getQueriesData<ApplicationPage>({
        queryKey: CARE_APPLICATION_KEYS.all,
      });

      const optimistic: CareApplication = {
        id: Date.now(),
        careRequestId,
        supporterId: -1,
        status: 'PENDING',
        message: null,
        appliedAt: new Date().toISOString(),
        acceptedAt: null,
        rejectedAt: null,
        rejectedReason: null,
        createdAt: new Date().toISOString(),
        updatedAt: null,
        createdBy: -1,
        updatedBy: null,
      };

      queryClient.setQueriesData<ApplicationPage>(
        { queryKey: CARE_APPLICATION_KEYS.all },
        (old) => {
          if (!old) return old;
          return { ...old, content: [optimistic, ...old.content] };
        },
      );

      return { snapshots };
    },
    onError: (_err, _vars, context) => {
      context?.snapshots.forEach(([key, data]) => {
        queryClient.setQueryData(key, data);
      });
    },
    onSettled: () => {
      queryClient.invalidateQueries({ queryKey: CARE_APPLICATION_KEYS.all });
      queryClient.invalidateQueries({ queryKey: CARE_REQUEST_KEYS.all });
    },
  });
};

export const useCancelCareApplication = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (id: number) => careApplicationApi.cancel(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: CARE_APPLICATION_KEYS.all });
    },
  });
};
