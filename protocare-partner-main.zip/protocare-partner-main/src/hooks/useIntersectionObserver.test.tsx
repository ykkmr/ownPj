// @vitest-environment jsdom
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, act } from '@testing-library/react';
import { useIntersectionObserver } from './useIntersectionObserver';

type ObserverCallback = (
  entries: Partial<IntersectionObserverEntry>[],
  observer: IntersectionObserver,
) => void;

let lastCallback: ObserverCallback | null = null;
let observeMock: ReturnType<typeof vi.fn>;
let disconnectMock: ReturnType<typeof vi.fn>;

beforeEach(() => {
  observeMock = vi.fn();
  disconnectMock = vi.fn();
  lastCallback = null;

  // vi.fn() 화살표 함수는 new로 생성 불가 → class mock 사용
  class MockIntersectionObserver {
    observe = observeMock;
    disconnect = disconnectMock;
    unobserve = vi.fn();
    constructor(cb: ObserverCallback) {
      lastCallback = cb;
    }
  }
  vi.stubGlobal('IntersectionObserver', MockIntersectionObserver);
});

type ProbeOptions = Parameters<typeof useIntersectionObserver>[0];

const Probe = ({ options }: { options?: ProbeOptions }) => {
  const [ref, isIntersecting] = useIntersectionObserver<HTMLDivElement>(options);
  return <div ref={ref} data-testid="sentinel" data-intersecting={String(isIntersecting)} />;
};

describe('useIntersectionObserver', () => {
  it('초기 상태는 isIntersecting=false', () => {
    const { getByTestId } = render(<Probe />);
    expect(getByTestId('sentinel').dataset.intersecting).toBe('false');
  });

  it('엘리먼트를 observe에 등록', () => {
    const { getByTestId } = render(<Probe />);
    expect(observeMock).toHaveBeenCalledWith(getByTestId('sentinel'));
  });

  it('교차 이벤트 발생 시 isIntersecting=true', () => {
    const { getByTestId } = render(<Probe />);
    act(() => {
      lastCallback?.(
        [{ isIntersecting: true } as IntersectionObserverEntry],
        {} as IntersectionObserver,
      );
    });
    expect(getByTestId('sentinel').dataset.intersecting).toBe('true');
  });

  it('교차 해제 시 isIntersecting=false로 복귀', () => {
    const { getByTestId } = render(<Probe />);
    act(() => {
      lastCallback?.(
        [{ isIntersecting: true } as IntersectionObserverEntry],
        {} as IntersectionObserver,
      );
    });
    act(() => {
      lastCallback?.(
        [{ isIntersecting: false } as IntersectionObserverEntry],
        {} as IntersectionObserver,
      );
    });
    expect(getByTestId('sentinel').dataset.intersecting).toBe('false');
  });

  it('freezeOnceVisible=true이면 최초 교차 후 disconnect', () => {
    render(<Probe options={{ freezeOnceVisible: true }} />);
    act(() => {
      lastCallback?.(
        [{ isIntersecting: true } as IntersectionObserverEntry],
        {} as IntersectionObserver,
      );
    });
    expect(disconnectMock).toHaveBeenCalledTimes(1);
  });

  it('freezeOnceVisible=true이면 disconnect 후 추가 콜백이 와도 재호출 없음', () => {
    render(<Probe options={{ freezeOnceVisible: true }} />);
    act(() => {
      lastCallback?.(
        [{ isIntersecting: true } as IntersectionObserverEntry],
        {} as IntersectionObserver,
      );
    });
    act(() => {
      lastCallback?.(
        [{ isIntersecting: false } as IntersectionObserverEntry],
        {} as IntersectionObserver,
      );
    });
    expect(disconnectMock).toHaveBeenCalledTimes(1);
  });

  it('언마운트 시 observer disconnect', () => {
    const { unmount } = render(<Probe />);
    unmount();
    expect(disconnectMock).toHaveBeenCalled();
  });
});
