import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { careRequestApi } from '@/services/api/careRequest';
import type { CareRequestListParams, CreateCareRequestBody } from '@/services/api/careRequest';

export const CARE_REQUEST_KEYS = {
  all: ['care-requests'] as const,
  list: (params?: CareRequestListParams) => [...CARE_REQUEST_KEYS.all, 'list', params] as const,
  detail: (id: number) => [...CARE_REQUEST_KEYS.all, 'detail', id] as const,
};

export const useCareRequestList = (params?: CareRequestListParams) =>
  useQuery({
    queryKey: CARE_REQUEST_KEYS.list(params),
    queryFn: () => careRequestApi.getList(params),
  });

export const useCareRequest = (id: number) =>
  useQuery({
    queryKey: CARE_REQUEST_KEYS.detail(id),
    queryFn: () => careRequestApi.getOne(id),
    enabled: !!id,
  });

export const useCreateCareRequest = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (body: CreateCareRequestBody) => careRequestApi.create(body),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: CARE_REQUEST_KEYS.all });
    },
  });
};

export const useCancelCareRequest = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (id: number) => careRequestApi.cancel(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: CARE_REQUEST_KEYS.all });
    },
  });
};
