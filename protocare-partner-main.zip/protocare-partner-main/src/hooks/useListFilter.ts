import { useCallback, useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';

export interface ListFilter {
  search: string;
  status: string;
  startDate: string;
  endDate: string;
  page: number;
}

const DEFAULT_FILTER: ListFilter = {
  search: '',
  status: '',
  startDate: '',
  endDate: '',
  page: 1,
};

interface UseListFilterReturn {
  filter: ListFilter;
  setSearch: (value: string) => void;
  setStatus: (value: string) => void;
  setDateRange: (start: string, end: string) => void;
  setPage: (page: number) => void;
  reset: () => void;
  /** TanStack Query 등에서 queryKey 배열로 그대로 사용할 수 있는 객체 */
  queryParams: Record<string, string>;
}

/**
 * URL Query String 과 동기화되는 리스트 필터 상태 관리 훅.
 * 필터가 변경되면 URL 이 즉시 업데이트되어 뒤로가기·북마크·공유가 가능합니다.
 *
 * @example
 * const { filter, setSearch, setStatus } = useListFilter();
 * // 검색어 → ?q=홍길동
 * // 상태 → ?status=DONE
 */
export const useListFilter = (): UseListFilterReturn => {
  const [searchParams, setSearchParams] = useSearchParams();

  const filter: ListFilter = useMemo(
    () => ({
      search: searchParams.get('q') ?? DEFAULT_FILTER.search,
      status: searchParams.get('status') ?? DEFAULT_FILTER.status,
      startDate: searchParams.get('startDate') ?? DEFAULT_FILTER.startDate,
      endDate: searchParams.get('endDate') ?? DEFAULT_FILTER.endDate,
      page: Number(searchParams.get('page') ?? DEFAULT_FILTER.page),
    }),
    [searchParams]
  );

  const updateParams = useCallback(
    (updates: Partial<Record<string, string>>) => {
      setSearchParams((prev) => {
        const next = new URLSearchParams(prev);
        for (const [key, value] of Object.entries(updates)) {
          if (value) {
            next.set(key, value);
          } else {
            next.delete(key);
          }
        }
        next.set('page', '1');
        return next;
      });
    },
    [setSearchParams]
  );

  const setSearch = useCallback(
    (value: string) => updateParams({ q: value }),
    [updateParams]
  );

  const setStatus = useCallback(
    (value: string) => updateParams({ status: value }),
    [updateParams]
  );

  const setDateRange = useCallback(
    (start: string, end: string) => updateParams({ startDate: start, endDate: end }),
    [updateParams]
  );

  const setPage = useCallback(
    (page: number) =>
      setSearchParams((prev) => {
        const next = new URLSearchParams(prev);
        next.set('page', String(page));
        return next;
      }),
    [setSearchParams]
  );

  const reset = useCallback(() => setSearchParams({}), [setSearchParams]);

  const queryParams: Record<string, string> = useMemo(() => {
    const params: Record<string, string> = {};
    if (filter.search) params['q'] = filter.search;
    if (filter.status) params['status'] = filter.status;
    if (filter.startDate) params['startDate'] = filter.startDate;
    if (filter.endDate) params['endDate'] = filter.endDate;
    params['page'] = String(filter.page);
    return params;
  }, [filter]);

  return { filter, setSearch, setStatus, setDateRange, setPage, reset, queryParams };
};
