import { useCallback } from 'react';
import { analytics } from '@/services/analytics/analytics.service';

type TrackProperties = Record<string, unknown>;

/**
 * 이벤트 추적 훅. 컴포넌트 내부에서 프로그래밍 방식으로 이벤트를 발송합니다.
 *
 * @example
 * const { track } = useTrack();
 * <Button onClick={() => track('logout_clicked')}>로그아웃</Button>
 */
export const useTrack = () => {
  const track = useCallback((event: string, properties?: TrackProperties) => {
    analytics.track(event, properties);
  }, []);

  const trackPage = useCallback((name: string, properties?: TrackProperties) => {
    analytics.page(name, properties);
  }, []);

  return { track, trackPage };
};