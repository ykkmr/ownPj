// @vitest-environment jsdom
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { renderHook, act } from '@testing-library/react';
import { useCareTimer } from './useCareTimer';

const FAKE_NOW = new Date('2025-04-30T12:00:00Z');

const ISO = (offsetSeconds: number) =>
  new Date(FAKE_NOW.getTime() - offsetSeconds * 1000).toISOString();

describe('useCareTimer', () => {
  beforeEach(() => {
    vi.useFakeTimers();
    vi.setSystemTime(FAKE_NOW);
  });
  afterEach(() => vi.useRealTimers());

  it('startedAt이 없으면 00:00:00 반환, isRunning=false', () => {
    const { result } = renderHook(() => useCareTimer(null));
    expect(result.current.elapsed).toBe('00:00:00');
    expect(result.current.totalSeconds).toBe(0);
    expect(result.current.isRunning).toBe(false);
  });

  it('startedAt이 있으면 isRunning=true', () => {
    const { result } = renderHook(() => useCareTimer(ISO(1)));
    expect(result.current.isRunning).toBe(true);
  });

  it('경과 시간을 HH:MM:SS 형식으로 반환', () => {
    const { result } = renderHook(() => useCareTimer(ISO(3600 + 30 * 60 + 45)));
    expect(result.current.elapsed).toBe('01:30:45');
    expect(result.current.totalSeconds).toBe(5445);
  });

  it('interval 발화 시 totalSeconds가 증가', () => {
    const { result } = renderHook(() => useCareTimer(ISO(10)));
    expect(result.current.totalSeconds).toBe(10);

    // 시계를 앞으로 이동 후 interval 1회 발화 → totalSeconds 증가 확인
    // runOnlyPendingTimers()는 clock을 추가 이동시키므로 정확한 값 대신 증가 여부를 검증
    vi.setSystemTime(new Date(FAKE_NOW.getTime() + 3000));
    act(() => {
      vi.runOnlyPendingTimers();
    });

    expect(result.current.totalSeconds).toBeGreaterThan(10);
  });

  it('startedAt이 null로 바뀌면 타이머 정지 후 00:00:00', () => {
    const { result, rerender } = renderHook(({ startedAt }) => useCareTimer(startedAt), {
      initialProps: { startedAt: ISO(5) as string | null },
    });

    expect(result.current.isRunning).toBe(true);

    rerender({ startedAt: null });
    expect(result.current.elapsed).toBe('00:00:00');
    expect(result.current.isRunning).toBe(false);
  });

  it('미래 시각이면 0초(음수 방지)', () => {
    const future = new Date(Date.now() + 60_000).toISOString();
    const { result } = renderHook(() => useCareTimer(future));
    expect(result.current.totalSeconds).toBe(0);
    expect(result.current.elapsed).toBe('00:00:00');
  });
});
