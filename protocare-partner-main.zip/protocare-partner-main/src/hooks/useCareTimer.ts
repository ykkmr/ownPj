import { useState, useEffect, useRef, useCallback } from 'react';

const pad = (n: number) => String(n).padStart(2, '0');

const formatElapsed = (seconds: number): string => {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = seconds % 60;
  return `${pad(h)}:${pad(m)}:${pad(s)}`;
};

interface UseCareTimerResult {
  elapsed: string;
  totalSeconds: number;
  isRunning: boolean;
}

/**
 * 돌봄 서비스 시작 시각(ISO 문자열)을 받아 실시간 경과 시간을 반환.
 * startedAt이 없으면 타이머가 멈춘 상태로 '00:00:00'을 반환.
 */
export const useCareTimer = (startedAt: string | null | undefined): UseCareTimerResult => {
  const getElapsedSeconds = useCallback(() => {
    if (!startedAt) return 0;
    return Math.max(0, Math.floor((Date.now() - new Date(startedAt).getTime()) / 1000));
  }, [startedAt]);

  const [totalSeconds, setTotalSeconds] = useState(getElapsedSeconds);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    if (!startedAt) {
      setTotalSeconds(0);
      return;
    }

    setTotalSeconds(getElapsedSeconds());
    intervalRef.current = setInterval(() => {
      setTotalSeconds(getElapsedSeconds());
    }, 1000);

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
    };
  }, [startedAt, getElapsedSeconds]);

  return {
    elapsed: formatElapsed(totalSeconds),
    totalSeconds,
    // 미래 시각(totalSeconds=0)이면 아직 시작 전으로 간주 — isRunning=false
    isRunning: !!startedAt && totalSeconds > 0,
  };
};
