export const ROUTES = {
  root: '/',
  login: '/login',
  app: '/app',
  home: '/app',
  signupStep1: '/signup/step1',
  signupStep2: '/signup/step2',
  signupComplete: '/signup/complete',
} as const;
