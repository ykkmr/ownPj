import { defineConfig } from 'vitest/config';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';
import path from 'path';

export default defineConfig({
  plugins: [react(), tailwindcss()],
  resolve: {
    alias: { '@': path.resolve(__dirname, './src') },
  },
  build: {
    // hidden: .map 파일 생성하지만 번들에 URL 미포함 — CI에서 Sentry에만 업로드
    sourcemap: 'hidden',
    target: 'es2020',
  },
  test: {
    globals: true,
    // 기본 환경은 node (유틸 테스트). DOM이 필요한 훅 테스트는
    // 파일 상단에 // @vitest-environment jsdom 어노테이션 사용
    environment: 'node',
    include: ['src/**/*.{test,spec}.{ts,tsx}'],
    coverage: {
      provider: 'v8',
      include: ['src/utils/**', 'src/hooks/**'],
      exclude: ['src/**/*.d.ts'],
    },
  },
});
