1. 파일 명명 규칙 (File Naming)

모든 파일명은 lowercase-hyphen.tsx (Kebab-case) 형식을 따르며, 역할에 따른 접미사를 붙입니다.

종류	규칙	예시
컴포넌트	lowercase-hyphen.tsx	pet-card.tsx, mission-list.tsx
커스텀 부품	*-custom.tsx	button-custom.tsx, gauge-custom.tsx
서비스(API)	*.service.ts	auth.service.ts, pet.service.ts
커스텀 훅	use-*.ts	use-camera.ts, use-pet-status.ts
타입/모델	*.model.ts	pet.model.ts, api.model.ts
매퍼/상수	*.mapper.ts, *.constant.ts	pet.mapper.ts, api.constant.ts

2. TypeScript 네이밍 규칙

인터페이스: I 접두사 사용 (예: IPetData, IUserPayload)

Zod 스키마 타입: T 접두사 또는 SchemaType 접미사 사용 (예: TPetRegisterForm)

열거형 (Enum): 소문자 e 접두사 + PascalCase 값 사용

TypeScript
export enum ePetStatus {
  Hungry = 'HUNGRY',
  Happy = 'HAPPY',
}

3. 아키텍처 패턴 (Layered)

백엔드의 레이어드 아키텍처를 프론트엔드에 그대로 이식합니다.

Routes (Controller): URL 경로에 따른 페이지 진입점.

Hooks (Service): 비즈니스 로직 및 서버 상태 관리 (useQuery, useMutation).

Services (Repository): Axios를 이용한 순수 API 호출 함수.

Mapper: API 응답(Entity)을 프론트용 모델(Model)로 변환.

4. 핵심 코딩 규칙

폼 처리: 필드명 하드코딩 금지. 항상 Enum을 사용합니다.

상태 관리: 서버 데이터는 TanStack Query, 전역 UI 상태는 Zustand를 사용합니다.

Capacitor 연동: 기기 기능(카메라, GPS 등) 접근 코드는 반드시 hooks/ 폴더 내에 캡슐화하여 사용합니다.